// RTX20 preview: inherited loading/COM hooks with a Turing optical-flow backend.
#include "nvs30/dxgi_hooks.hpp"
#include "nvs30/config.hpp"
#include "nvs30/log.hpp"
#include "nvs30/nvpresent.hpp"
#include "interpolator.hpp"
#include "performance.hpp"
#include "dx12_transfer.hpp"
#include "policy.hpp"
#include "present_sequence.hpp"
#include "pacing_clock.hpp"
#include <algorithm>
#include "creation_policy.hpp"
#include "nvs30/presentation_policy.hpp"
#include "nvs30/slot_patch.hpp"
#include "nvs30/module_watch.hpp"
#include "nvs30/hook_group.hpp"
#include "nvs30/initialization_gate.hpp"
#include "nvs30/presentation_ownership.hpp"
#include "nvs30/presentation_profile.hpp"
#include "nvs30/graphics_initialization.hpp"
#include "nvs30/startup_bootstrap.hpp"
#include "nvs30/loader_context.hpp"
#include <cstdio>
#include <memory>
#include <cwchar>
#include <initializer_list>
#include <limits>
#include <type_traits>
#include <utility>
// Import-hook fragments are included inside the private namespace below.
// Include their standard-library dependencies globally rather than relying
// on transitive includes, which vary between compiler/library releases.
#include <tlhelp32.h>
// Expand at the actual hook entry. An out-of-line helper would capture its
// own caller, and Zig's GNU target does not lower the MSVC _ReturnAddress API.
#if defined(_MSC_VER)
#include <intrin.h>
#define NVS30_CALLER_ADDRESS() _ReturnAddress()
#elif defined(__GNUC__) || defined(__clang__)
#define NVS30_CALLER_ADDRESS() __builtin_extract_return_addr(__builtin_return_address(0))
#else
#error A caller-address intrinsic is required for graphics origin admission.
#endif
extern "C" {
extern decltype(&D3D11CreateDevice) __imp_D3D11CreateDevice;
extern decltype(&D3D11CreateDeviceAndSwapChain) __imp_D3D11CreateDeviceAndSwapChain;
extern decltype(&D3D12CreateDevice) __imp_D3D12CreateDevice;
extern decltype(&CreateDXGIFactory) __imp_CreateDXGIFactory;
extern decltype(&CreateDXGIFactory1) __imp_CreateDXGIFactory1;
extern decltype(&CreateDXGIFactory2) __imp_CreateDXGIFactory2;
}
namespace {
using namespace nvs30;
#include "nvs30/com.hpp"
bool patch(void**,void*,void*);
bool readSlot(void** slot,void*& value){SIZE_T count{};return ReadProcessMemory(GetCurrentProcess(),slot,&value,sizeof value,&count)&&count==sizeof value;}
void registerSwapchain(IUnknown*,IUnknown* input=nullptr);
void beforeSwapchain(HWND){}
template<class Function,class Entry,size_t N> Function recoverOriginal(Function observed,Function own,const std::array<Entry,N>& entries,unsigned count,Function Entry::* member){
 if(observed!=own)return observed;Function result=nullptr;
 for(unsigned i=0;i<count;++i){auto candidate=entries[i].*member;if(!candidate||candidate==own)continue;if(result&&result!=candidate)return nullptr;result=candidate;}return result;
}
#include "nvs30/import_hooks.hpp"
GraphicsInitialization runtimeOnce;
startup_bootstrap::Controller bootstrap;
InitializationGate logOnce;
thread_local bool initialising=false,nested=false,internalCreation=false;
thread_local bool inNativePresentation=false;
std::atomic<presentation_profile::Profile> presentationProfile{presentation_profile::Profile::standard};
bool observeGraphicsObjects() noexcept {
 return true; // The RTX20 interpolator owns presentation; no NvPresent native profiles.
}
std::atomic_bool nativeReady{false};
// Set while an admitted D3D11CreateDeviceAndSwapChain runs; d3d11.dll's own
// nested factory call is then registered by that outer hook, not twice.
thread_local bool outerSwapchainCreation=false;
#include "factory_hooks.hpp"
std::atomic_ullong calls{0},bridgeSubmissions{0},passthroughs{0},bridgeAttempts{0},bridgeFailures{0},bridgeProbes{0},bridgeOccluded{0},bridgeBusy{0};
enum class Skip { reentrant, internal, not_ready, hooks, test, context, busy, queue, partial, interval, flags, tearing_contract, disabled, write_failed, exception, transition, unsupported_mode, count };
constexpr const char* skipNames[]={"reentrant","internal","not_ready","incomplete_hooks","test","missing_context","busy","missing_queue","partial","sync_interval","flags","tearing_contract","disabled","write_failed","exception","transition","unsupported_mode"};
std::array<std::atomic_ullong,static_cast<size_t>(Skip::count)> skips{};
std::atomic_ullong eligiblePresents{0},eligibleTearing{0},eligibleIntervals{0};
std::atomic_ullong generatedQueueBusy{0};
void recordSkip(Skip reason,UINT sync,UINT flags,bool partial){
 if(++skips[static_cast<size_t>(reason)]==1)
  logf("[rtx20] Present bypass: reason=%s sync=%u flags=0x%x partial=%d. First occurrence; totals in present_skips.\n",skipNames[static_cast<size_t>(reason)],sync,flags,partial?1:0);
}
void openDiagnostics() noexcept {
 try {
  // Diagnostic setup has its own gate. A busy logger cannot suppress runtime
  // initialization from an eligible graphics call or a selected startup entry.
  logOnce.run([]{
   log_open();logf("[normal] %s RTX20 NVOF mode requested. API success is not proof of displayed interpolation.\n",NVS30_VERSION);
   std::wstring exe(32768,L'\0');const auto n=GetModuleFileNameW(nullptr,exe.data(),static_cast<DWORD>(exe.size()));
   if(n&&n<exe.size())logf("[normal] Host executable: %ls\n",exe.c_str());
   HMODULE own{};
   if(GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
       reinterpret_cast<LPCWSTR>(&openDiagnostics),&own)){
    const auto count=GetModuleFileNameW(own,exe.data(),static_cast<DWORD>(exe.size()));
    if(count&&count<exe.size())logf("[normal] Backend module: %ls\n",exe.c_str());
   }
   return true;
  });
 }catch(...){}
}
bool configure() {
 // The winning graphics call or selected early entry owns configuration and
 // native initialization together through the same nonblocking gate.
 load_config();
 openDiagnostics();
 // Publish the process profile before nativeReady can become true. No COM
 // observation path can install a table hook before driver initialization.
 presentationProfile=presentation_profile::Profile::standard;
 return true;
}
void logGraphicsCaller(const void* caller) noexcept {
 imports::LastErrorScope error;
 try{
  HMODULE image{};
  if(caller&&GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
      reinterpret_cast<LPCWSTR>(caller),&image)){
   std::wstring path(32768,L'\0');const auto length=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
   if(length&&length<path.size()){
    logf("[normal] First graphics caller: module=%ls RVA=0x%llx.\n",path.c_str(),
         static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(caller)-reinterpret_cast<std::uintptr_t>(image)));
    return;
   }
  }
  logf("[normal] First graphics caller: unknown module address=%p.\n",caller);
 }catch(...){logf("[normal] First graphics caller: module lookup unavailable.\n");}
}
bool ensureRuntime(const char* trigger,const void* caller) noexcept {
 if(initialising)return false;
 struct Guard{Guard(){initialising=true;}~Guard(){initialising=false;}} guard;
 try{
  const bool ready=runtimeOnce.run(configure,[&]{
   logf("[normal] Runtime initialization: trigger=%s thread=%lu.\n",trigger,GetCurrentThreadId());
   if(caller)logGraphicsCaller(caller);
   try{nativeReady=sm20::load_runtime();}
   catch(...){logf("[normal] Native initialization exception; original game presentation retained.\n");}
   return nativeReady.load();
  });
  // A different caller may currently be initializing while it acquires the
  // loader lock. Preserve this caller's original API instead of waiting under
  // its possible DllMain/loader context. A later graphics creation can attach.
  return ready&&nativeReady.load();
 }catch(...){logf("[normal] Runtime initialization unavailable; original graphics call retained.\n");return false;}
}
startup_bootstrap::Profile selectStartup() {
 std::wstring executable(32768,L'\0');const auto n=GetModuleFileNameW(nullptr,executable.data(),static_cast<DWORD>(executable.size()));
 if(!n||n>=executable.size())return startup_bootstrap::Profile::graphics_call;executable.resize(n);
 return startup_bootstrap::selectProfile(executable,[](const wchar_t* path){
  const auto attributes=GetFileAttributesW(path);
  if(attributes==INVALID_FILE_ATTRIBUTES)return startup_bootstrap::MarkerKind::unavailable;
  return attributes&FILE_ATTRIBUTE_DIRECTORY?startup_bootstrap::MarkerKind::directory:startup_bootstrap::MarkerKind::file;
 });
}
void startSelectedGame(const char* source,startup_bootstrap::Profile profile) {
 openDiagnostics();
 logf("[normal] %s early startup: source=%s; outside loader callout; starting before waiting for an intercepted graphics call.\n",startup_bootstrap::title(profile),source);
 ensureRuntime(source,nullptr);
}
using PresentFn=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
using Present1Fn=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain1*,UINT,UINT,const DXGI_PRESENT_PARAMETERS*);
using FullscreenFn=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*,BOOL,IDXGIOutput*);
using ResizeFn=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT,UINT,DXGI_FORMAT,UINT);
using Resize1Fn=HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain3*,UINT,UINT,UINT,DXGI_FORMAT,UINT,const UINT*,IUnknown* const*);
struct Hooks {void** table=nullptr;PresentFn present=nullptr;Present1Fn present1=nullptr;FullscreenFn fullscreen=nullptr;ResizeFn resize=nullptr;Resize1Fn resize1=nullptr;unsigned extent=0;bool hooked=false;};
std::array<Hooks,256> tables{};unsigned tableCount=0;SRWLOCK tableLock=SRWLOCK_INIT;
Hooks lookup(void* swap){Hooks found;auto table=*reinterpret_cast<void***>(swap);AcquireSRWLockShared(&tableLock);for(unsigned i=0;i<tableCount;++i)if(tables[i].table==table){found=tables[i];break;}ReleaseSRWLockShared(&tableLock);return found;}
// DXGI owns this state and releases it with the swapchain, so pointer reuse and
// a new game window cannot inherit another chain's resources.
const GUID contextKey={0xcc95229e,0x0bfa,0x4257,{0x86,0x4e,0x45,0x18,0x63,0x79,0x56,0x84}};
struct Context final:IUnknown {
 ComPtr<ID3D12CommandQueue> presentQueue;bool isDX12=false;
 std::atomic_ulong refs{1};std::atomic_bool presenting{false};
 // Set when a Present reached the game without our pair (busy/queue pass-
 // through); the pipelined order must not then show an older pair.
 std::atomic_bool presentedOutside{false};std::mutex mutex;sm20::Interpolator interpolator;bool keyHeld=false;bool enabled=true;sm20::PresentationRevision revision;
 HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void** out)override{if(!out)return E_POINTER;*out=nullptr;if(id!=IID_IUnknown)return E_NOINTERFACE;*out=static_cast<IUnknown*>(this);AddRef();return S_OK;}
 ULONG STDMETHODCALLTYPE AddRef()override{return ++refs;}
 ULONG STDMETHODCALLTYPE Release()override{auto n=--refs;if(!n)delete this;return n;}
};
ComPtr<Context> contextFor(IDXGISwapChain* swap,bool create){
 static std::mutex lock;std::scoped_lock hold(lock);ComPtr<Context> result;UINT bytes=sizeof(Context*);
 if(SUCCEEDED(swap->GetPrivateData(contextKey,&bytes,result.GetAddressOf()))&&bytes==sizeof(Context*))return result;
 result.Reset();if(!create)return result;result.Attach(new Context);
 if(FAILED(swap->SetPrivateDataInterface(contextKey,result.Get())))result.Reset();return result;
}
static_assert(DXGI_PRESENT_TEST==presentation::test_flag);
static_assert(DXGI_PRESENT_TEST==sm20::present_test);
static_assert(DXGI_PRESENT_ALLOW_TEARING==sm20::present_allow_tearing);
static_assert(DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING==sm20::swapchain_allow_tearing);
static_assert(static_cast<unsigned>(DXGI_ERROR_WAS_STILL_DRAWING)==presentation::still_drawing);
static_assert(static_cast<unsigned>(DXGI_STATUS_OCCLUDED)==presentation::occluded);
const GUID adoptKey={0x6d1f4a52,0x93c0,0x4e0b,{0xa7,0x3e,0x1b,0x52,0x0c,0x9d,0x44,0x21}};
// Once per swapchain: register a chain that reached a hooked Present table
// without a Context (created before, or outside, the factory hooks).
void adoptAtPresent(IDXGISwapChain* swap) noexcept {
 try{
  UINT bytes=1;BYTE seen=0;
  const bool attempted=SUCCEEDED(swap->GetPrivateData(adoptKey,&bytes,&seen))&&bytes==1;
  if(!sm20::creation::adopt_at_present(nativeReady.load(),false,internalCreation,false,attempted))return;
  seen=1;if(FAILED(swap->SetPrivateData(adoptKey,1,&seen)))return;
  logf("[normal] Present reached an unregistered swapchain; adopting it once.\n");
  registerSwapchain(swap,nullptr);
 }catch(...){}
}
template<class Forward> HRESULT dispatch(IDXGISwapChain* swap,UINT sync,UINT flags,const DXGI_PRESENT_PARAMETERS* params,Forward forward,bool hooked=true){
 const bool partial=params&&(params->DirtyRectsCount||params->pScrollRect||params->pScrollOffset);
 auto original=[&](Skip reason){++passthroughs;recordSkip(reason,sync,flags,partial);return forward(sync,flags);};
 if(nested)return original(Skip::reentrant);
 if(internalCreation)return original(Skip::internal);
 if(!nativeReady)return original(Skip::not_ready);
 if(!hooked)return original(Skip::hooks);
 struct Guard {Guard(){nested=true;}~Guard(){nested=false;}} guard;
 // TEST, including combinations, is observational: do not adopt a swapchain,
 // poll keys, allocate a session, copy, wait, or change interpolation history.
 if(flags&DXGI_PRESENT_TEST){++bridgeProbes;return original(Skip::test);}
 ComPtr<Context> state;try{state=contextFor(swap,false);if(!state){adoptAtPresent(swap);state=contextFor(swap,false);}}catch(...){return original(Skip::exception);}
 if(!state)return original(Skip::context);
 if(state->revision.transitioning()||state->presenting.exchange(true)){state->presentedOutside=true;return original(Skip::busy);}
 struct Release {Context* p;~Release(){p->presenting=false;}} sequence{state.Get()};
 bool generated=false,generatedAccepted=false,interrupted=false;sm20::PairPlan plan{};std::uint64_t revision{};
 auto interruptedPair=[&]{if(!interrupted){interrupted=true;recordSkip(Skip::transition,sync,flags,partial);}};
 {
  std::unique_lock hold(state->mutex,std::try_to_lock);if(!hold.owns_lock()){state->presentedOutside=true;return original(Skip::busy);}if(state->revision.transitioning()){state->presentedOutside=true;hold.unlock();return original(Skip::busy);}
  if(state->presentedOutside.exchange(false))state->interpolator.break_pipeline();
  if(FAILED(state->interpolator.terminal_error()))return state->interpolator.terminal_error();
  if(state->isDX12&&!state->presentQueue){state->interpolator.break_pipeline();hold.unlock();return original(Skip::queue);}
  DXGI_SWAP_CHAIN_DESC desc{};
  const bool described=SUCCEEDED(swap->GetDesc(&desc));
  const auto admission=sm20::request_admission(sync,flags,partial,described&&desc.Windowed,desc.Flags);
  if(admission!=sm20::Admission::eligible){
   Skip reason=Skip::flags;
   switch(admission){
    case sm20::Admission::partial:reason=Skip::partial;break;
    case sm20::Admission::interval:reason=Skip::interval;break;
    case sm20::Admission::tearing_contract:reason=Skip::tearing_contract;break;
    default:break;
   }
   state->interpolator.discard_history();hold.unlock();return original(reason);
  }
  bool held=(GetAsyncKeyState(VK_F11)&0x8000)!=0;
  if(held&&!state->keyHeld){state->enabled=!state->enabled;state->interpolator.discard_history();logf("[rtx20] F11 interpolation=%s\n",state->enabled?"enabled":"disabled");}
  state->keyHeld=held;
  if(state->revision.consume_reset())state->interpolator.reset();
  if(FAILED(state->interpolator.terminal_error()))return state->interpolator.terminal_error();
  if(described&&!desc.Windowed&&!sm20::exclusive_fullscreen_allowed()){state->interpolator.discard_history();hold.unlock();return original(Skip::unsupported_mode);}
  if(!state->enabled){hold.unlock();return original(Skip::disabled);}
  revision=state->revision.checkpoint();
  if(!state->revision.current(revision)){state->interpolator.discard_history();hold.unlock();return original(Skip::transition);}
  if(++eligiblePresents==1)logf("[rtx20] Present admitted: sync=%u flags=0x%x partial=%d api=%s windowed=%d.\n",sync,flags,partial?1:0,state->isDX12?"D3D12":"D3D11",described?int(desc.Windowed):-1);
  if(sync>1&&++eligibleIntervals==1)logf("[rtx20] Sync interval %u (the game locks to 1/%u of the refresh): generated and real frames share those refreshes (%u + %u).\n",sync,sync,sm20::paired_intervals(sync).generated,sm20::paired_intervals(sync).real);
  if(flags==DXGI_PRESENT_ALLOW_TEARING&&++eligibleTearing==1)logf("[rtx20] Tearing Present admitted; generated sync=0 flags=ALLOW_TEARING|DO_NOT_WAIT, real frame keeps the game's sync=0 flags=ALLOW_TEARING (Pacing=vblank pairs use sync=1 without tearing).\n");
  {sm20::performance::Scope timing(sm20::performance::Phase::prepare);generated=state->interpolator.prepare(swap,state->presentQueue.Get(),sync);}
  plan=state->interpolator.plan();plan.generated=generated;
  if(FAILED(state->interpolator.terminal_error()))return state->interpolator.terminal_error();
  if(!state->revision.current(revision)){state->interpolator.discard_history();hold.unlock();return original(Skip::transition);}
  if(generated){
   sm20::performance::Scope timing(sm20::performance::Phase::generated_write);
   if(!state->interpolator.write_generated(swap)){state->interpolator.discard_history();if(FAILED(state->interpolator.terminal_error()))return state->interpolator.terminal_error();hold.unlock();return original(Skip::write_failed);}
  }
 }
 // Never hold the resource mutex over Present: DXGI may need the window thread.
 if(generated)++bridgeAttempts;
 unsigned submitted=0;
 auto timedForward=[&](UINT interval,UINT f){
  const auto phase=generated&&submitted++==0?sm20::performance::Phase::generated_present:sm20::performance::Phase::real_present;
  sm20::performance::Scope timing(phase);return forward(interval,f);
 };
 const auto result=static_cast<HRESULT>(sm20::present_scheduled(plan,sync,flags,timedForward,
  [&](bool shown){std::scoped_lock hold(state->mutex);
   if(!state->revision.current(revision)){interruptedPair();return -1.0;}
   return state->interpolator.after_generated(shown);
  },
  [&](double until){
   // Spacing: hold the real frame so both frames are shown for equal time.
   // Never under the resource mutex; a window-thread transition ends it.
   sm20::performance::Scope timing(sm20::performance::Phase::spacing_wait);
   const double start=sm20::pacing::now();
   sm20::pacing::wait_until(until,[&]{return !state->revision.current(revision);});
   sm20::performance::spacing_wait_us+=static_cast<unsigned long long>(std::max(0.0,sm20::pacing::now()-start)*1e6);
   // The restored frame belongs to the checked revision; never submit it
   // into buffers recreated by a resize that began during the wait.
   if(state->revision.current(revision))return true;
   interruptedPair();return false;
  },
  [&]{std::scoped_lock hold(state->mutex);
   if(!state->revision.current(revision)){interruptedPair();return sm20::RestoreResult::interrupted;}
   sm20::performance::Scope timing(sm20::performance::Phase::original_write);
   return state->interpolator.write_original(swap)?sm20::RestoreResult::restored:sm20::RestoreResult::failed;
  },
  [&](bool accepted){std::scoped_lock hold(state->mutex);
   if(!state->revision.current(revision))interruptedPair();
   if(accepted&&!interrupted){state->interpolator.accepted();++sm20::real_submissions;if(generatedAccepted)++bridgeSubmissions;}
   else{state->interpolator.discard_history();if(generated&&!interrupted)++bridgeFailures;}
  },[&]{generatedAccepted=true;++sm20::generated_submissions;},[]{
   if(++generatedQueueBusy==1)logf("[rtx20] Generated queue busy: skipped optional generated Present; restoring and forwarding the original frame without a synthetic VSync wait.\n");
  }));
 std::scoped_lock hold(state->mutex);
 return FAILED(state->interpolator.terminal_error())?state->interpolator.terminal_error():result;
}

void recordPresentEntry(){
 if(++calls==1)logf("[normal] First intercepted Present entry; runtime_ready=%d. Raw calls include internal/probe entries and are not application FPS or generated frames.\n",nativeReady.load()?1:0);
}
HRESULT STDMETHODCALLTYPE onPresent(IDXGISwapChain* swap,UINT sync,UINT flags){
 const void* caller=NVS30_CALLER_ADDRESS();recordPresentEntry();auto h=lookup(swap);if(!h.present)return DXGI_ERROR_INVALID_CALL;
 auto original=[&]{return h.present(swap,sync,flags);};
 auto submit=[&](UINT interval,UINT f){return h.present(swap,interval,f);};
 return presentation_ownership::entry(inNativePresentation,nvpresent::contains_address(caller),nvpresent::contains_address(reinterpret_cast<const void*>(h.present)),
  [&]{++passthroughs;return original();},[&]{return dispatch(swap,sync,flags,nullptr,submit,h.hooked);});
}
HRESULT STDMETHODCALLTYPE onPresent1(IDXGISwapChain1* swap,UINT sync,UINT flags,const DXGI_PRESENT_PARAMETERS* p){
 const void* caller=NVS30_CALLER_ADDRESS();recordPresentEntry();auto h=lookup(swap);if(!h.present1)return DXGI_ERROR_INVALID_CALL;
 auto original=[&]{return h.present1(swap,sync,flags,p);};
 auto submit=[&](UINT interval,UINT f){return h.present1(swap,interval,f,p);};
 return presentation_ownership::entry(inNativePresentation,nvpresent::contains_address(caller),nvpresent::contains_address(reinterpret_cast<const void*>(h.present1)),
  [&]{++passthroughs;return original();},[&]{return dispatch(swap,sync,flags,p,submit,h.hooked);});
}
struct Transition {
 ComPtr<Context> state;bool entered=false;
 explicit Transition(IDXGISwapChain* swap){try{
  state=contextFor(swap,false);if(!state)return;
  state->revision.begin_transition();entered=true;
  std::unique_lock lock(state->mutex,std::try_to_lock);
  if(lock.owns_lock()&&!state->presenting)state->interpolator.reset();
 }catch(...){}}
 ~Transition(){if(entered)state->revision.end_transition();}
};
HRESULT STDMETHODCALLTYPE onFullscreen(IDXGISwapChain* swap,BOOL enabled,IDXGIOutput* output){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=lookup(swap);if(!h.fullscreen)return DXGI_ERROR_INVALID_CALL;
 auto original=[&]{return h.fullscreen(swap,enabled,output);};
 return presentation_ownership::entry(inNativePresentation,nvpresent::contains_address(caller),nvpresent::contains_address(reinterpret_cast<const void*>(h.fullscreen)),
  original,[&]{Transition transition(swap);return original();});
}
HRESULT STDMETHODCALLTYPE onResize(IDXGISwapChain* swap,UINT n,UINT w,UINT h,DXGI_FORMAT format,UINT flags){
 const void* caller=NVS30_CALLER_ADDRESS();auto hks=lookup(swap);if(!hks.resize)return DXGI_ERROR_INVALID_CALL;
 auto original=[&]{return hks.resize(swap,n,w,h,format,flags);};
 return presentation_ownership::entry(inNativePresentation,nvpresent::contains_address(caller),nvpresent::contains_address(reinterpret_cast<const void*>(hks.resize)),
  original,[&]{Transition transition(swap);return original();});
}
HRESULT STDMETHODCALLTYPE onResize1(IDXGISwapChain3* swap,UINT n,UINT w,UINT h,DXGI_FORMAT format,UINT flags,const UINT* masks,IUnknown* const* queues){
 const void* caller=NVS30_CALLER_ADDRESS();auto hks=lookup(swap);if(!hks.resize1)return DXGI_ERROR_INVALID_CALL;
 auto original=[&]{return hks.resize1(swap,n,w,h,format,flags,masks,queues);};
 return presentation_ownership::entry(inNativePresentation,nvpresent::contains_address(caller),nvpresent::contains_address(reinterpret_cast<const void*>(hks.resize1)),
  original,[&]{
   Transition transition(swap);auto hr=original();
   if(SUCCEEDED(hr)&&transition.state&&queues){
    std::scoped_lock lock(transition.state->mutex);auto& state=*transition.state.Get();
    if(state.isDX12){
     DXGI_SWAP_CHAIN_DESC d{};ComPtr<ID3D12CommandQueue> selected;
     const bool valid=SUCCEEDED(swap->GetDesc(&d))&&sm20::resize_queue(d.BufferCount,
      [&](unsigned i){return masks?masks[i]:0u;},
      [&](unsigned i){ComPtr<ID3D12CommandQueue> candidate;sm20::presentation_queue(swap,queues[i],candidate);return candidate;},
      [](const auto& a,const auto& b){return sm20::same_object(a.Get(),b.Get());},selected);
     state.presentQueue=valid?selected:ComPtr<ID3D12CommandQueue>{};
     logf("[rtx20-dx12] ResizeBuffers1 presentation queue %s.\n",valid?"updated":"unsupported; interpolation disabled");
    }
   }
   return hr;
  });
}
bool patch(void** address,void* expected,void* replacement){
 if(!address||reinterpret_cast<std::uintptr_t>(address)%alignof(void*))return false;
 static SRWLOCK lock=SRWLOCK_INIT;AcquireSRWLockExclusive(&lock);
 DWORD old{};MEMORY_BASIC_INFORMATION mapping{};
 const auto result=slot_patch::apply(expected,replacement,
  [&](void*& current){
   if(!VirtualQuery(address,&mapping,sizeof(mapping))||mapping.State!=MEM_COMMIT||
      (mapping.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
   SIZE_T bytes{};return ReadProcessMemory(GetCurrentProcess(),address,&current,sizeof(current),&bytes)&&bytes==sizeof(current);
  },
  [&]{
   // A table may share an executable allocation. Do not briefly remove its
   // execute permission while another thread runs elsewhere on that page.
   const bool executable=(mapping.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))!=0;
   const DWORD protection=(executable?PAGE_EXECUTE_READWRITE:PAGE_READWRITE)|(mapping.Protect&(PAGE_NOCACHE|PAGE_WRITECOMBINE));
   return VirtualProtect(address,sizeof(void*),protection,&old)!=FALSE;
  },
  [&](void* before,void* after){return InterlockedCompareExchangePointer(address,after,before);},
  [&]{DWORD unused{};return VirtualProtect(address,sizeof(void*),old,&unused)!=FALSE;});
 ReleaseSRWLockExclusive(&lock);
 if(!result.protection_restored)logf("[normal] Hook page protection restore failed at %p; slot not activated.\n",address);
 return result.installed;
}
void registerTable(void* swap,unsigned size){
 if(!observeGraphicsObjects())return;
 auto v=*reinterpret_cast<void***>(swap);AcquireSRWLockExclusive(&tableLock);
 struct Unlock{~Unlock(){ReleaseSRWLockExclusive(&tableLock);}} unlock;
 unsigned index=0;for(;index<tableCount;++index)if(tables[index].table==v)break;
 if(index==tableCount){if(tableCount==tables.size()){
  static bool reported=false;if(!reported){reported=true;logf("[normal] Swapchain table capacity reached; new untracked tables are not patched.\n");}return;
 }++tableCount;}
 auto& h=tables[index];
 if(size<h.extent||(h.hooked&&size==h.extent))return;
 h.table=v;h.extent=size;h.hooked=false;
 // A shared vtable first seen through a base interface may later expose
 // Present1/ResizeBuffers1. Keep its known originals and capture only new slots.
 if(!h.present)h.present=reinterpret_cast<PresentFn>(v[8]);
 if(!h.fullscreen)h.fullscreen=reinterpret_cast<FullscreenFn>(v[10]);
 if(!h.resize)h.resize=reinterpret_cast<ResizeFn>(v[13]);
 if(size>22&&!h.present1)h.present1=reinterpret_cast<Present1Fn>(v[22]);
 if(size>39&&!h.resize1)h.resize1=reinterpret_cast<Resize1Fn>(v[39]);
 h.fullscreen=recoverOriginal(h.fullscreen,&onFullscreen,tables,tableCount,&Hooks::fullscreen);
 h.present=recoverOriginal(h.present,&onPresent,tables,tableCount,&Hooks::present);h.resize=recoverOriginal(h.resize,&onResize,tables,tableCount,&Hooks::resize);
 if(h.present1)h.present1=recoverOriginal(h.present1,&onPresent1,tables,tableCount,&Hooks::present1);
 if(h.resize1)h.resize1=recoverOriginal(h.resize1,&onResize1,tables,tableCount,&Hooks::resize1);
 if(!h.present||!h.fullscreen||!h.resize||(size>22&&!h.present1)||(size>39&&!h.resize1))return;
 // Publish the original pointers before the replacement can be entered.
 const std::array<hook_group::Slot,5> slots{{
  {v+10,reinterpret_cast<void*>(h.fullscreen),reinterpret_cast<void*>(&onFullscreen)},
  {v+13,reinterpret_cast<void*>(h.resize),reinterpret_cast<void*>(&onResize)},
  {size>39?v+39:nullptr,reinterpret_cast<void*>(h.resize1),reinterpret_cast<void*>(&onResize1)},
  {v+8,reinterpret_cast<void*>(h.present),reinterpret_cast<void*>(&onPresent)},
  {size>22?v+22:nullptr,reinterpret_cast<void*>(h.present1),reinterpret_cast<void*>(&onPresent1)}}};
 h.hooked=hook_group::install(slots,readSlot,patch);
}
struct SwapchainInterfaces {
 Com<IDXGISwapChain4> s4;Com<IDXGISwapChain3> s3;Com<IDXGISwapChain2> s2;Com<IDXGISwapChain1> s1;Com<IDXGISwapChain> base;
 explicit SwapchainInterfaces(IUnknown* swap){
 if(!swap)return;
 swap->QueryInterface(__uuidof(IDXGISwapChain),reinterpret_cast<void**>(base.put()));
 swap->QueryInterface(__uuidof(IDXGISwapChain4),reinterpret_cast<void**>(s4.put()));
 swap->QueryInterface(__uuidof(IDXGISwapChain3),reinterpret_cast<void**>(s3.put()));
 swap->QueryInterface(__uuidof(IDXGISwapChain2),reinterpret_cast<void**>(s2.put()));
 swap->QueryInterface(__uuidof(IDXGISwapChain1),reinterpret_cast<void**>(s1.put()));
 }
 presentation_ownership::Evidence evidence() const noexcept {
 presentation_ownership::Evidence ownership;
 auto observe=[&](void* object,unsigned extent){
  if(!object)return;
  auto** table=*reinterpret_cast<void***>(object);
  void* livePresent=nullptr;void* livePresent1=nullptr;
  readSlot(table+8,livePresent);if(extent>22)readSlot(table+22,livePresent1);
  // Read originals after live slots: a concurrent installer publishes its
  // saved originals under tableLock before making our replacement visible.
  const auto previous=lookup(object);
  const auto found=presentation_ownership::inspect(livePresent,livePresent1,
   reinterpret_cast<const void*>(previous.present),reinterpret_cast<const void*>(previous.present1),nvpresent::contains_address);
  ownership.observe(found.live_method,found.saved_present,found.saved_present1);
 };
 // QueryInterface may return different interface pointers/tables. Inspect all
 // saved originals before patching any interface, including a separately
 // implemented Present1 table already hooked for an earlier chain.
 observe(base.p,18);observe(s4.p,40);observe(s3.p,40);observe(s2.p,29);observe(s1.p,29);
 return ownership;
 }
};
void registerSwapchain(IUnknown* swap,IUnknown* input){
 // A rejected/duplicate backend must not attach its Context to a swapchain
 // owned by another build, or mutate COM tables after failing initialization.
 if(!swap||internalCreation||initialising||!nativeReady||!observeGraphicsObjects())return;
 try{
 SwapchainInterfaces interfaces(swap);
 auto& base=interfaces.base;auto& s4=interfaces.s4;auto& s3=interfaces.s3;auto& s2=interfaces.s2;auto& s1=interfaces.s1;
 const auto ownership=interfaces.evidence();
 if(s4.p)registerTable(s4.p,40);
 if(s3.p)registerTable(s3.p,40);
 if(s2.p)registerTable(s2.p,29);
 if(s1.p)registerTable(s1.p,29);
 if(base.p){
  registerTable(base.p,18);
  DXGI_SWAP_CHAIN_DESC desc{};ComPtr<ID3D11Device> d11;ComPtr<ID3D12Device> d12;
  const char* api=SUCCEEDED(base.p->GetDevice(IID_PPV_ARGS(&d11)))?"D3D11":SUCCEEDED(base.p->GetDevice(IID_PPV_ARGS(&d12)))?"D3D12":"unknown";
  // An overlay can return the same chain through more than one hook layer.
  if(contextFor(base.p,false))return;
  if(d11&&!ownership.native())contextFor(base.p,true);
  if(d12&&!ownership.native()){
   auto state=contextFor(base.p,true);
   if(state){std::scoped_lock lock(state->mutex);state->isDX12=true;
    if(input)sm20::presentation_queue(base.p,input,state->presentQueue);
    // For a D3D12 chain DXGI's GetDevice returns the creation queue; used when
    // the creation input was unavailable (Present-time adoption) or unusable.
    if(!state->presentQueue){ComPtr<ID3D12CommandQueue> own;
     if(SUCCEEDED(base.p->GetDevice(IID_PPV_ARGS(&own))))sm20::presentation_queue(base.p,own.Get(),state->presentQueue);}
    logf("[rtx20-dx12] Swapchain presentation queue %s.\n",state->presentQueue?"captured":"unavailable; passthrough");
   }
  }
  if(d11&&ownership.native())logf("[normal] Native NvPresent D3D11 wrapper detected; diagnostic interception retained, driver calls forwarded without Context reads or writes. Output remains unverified.\n");
  if(SUCCEEDED(base.p->GetDesc(&desc)))logf("[normal] game swapchain created: api=%s %ux%u format=%u buffers=%u effect=%u windowed=%d samples=%u flags=0x%x native_ready=%d.\n",
      api,desc.BufferDesc.Width,desc.BufferDesc.Height,unsigned(desc.BufferDesc.Format),desc.BufferCount,unsigned(desc.SwapEffect),desc.Windowed,desc.SampleDesc.Count,desc.Flags,nativeReady.load()?1:0);
 }
 }catch(...){logf("[normal] Game swapchain registration failed; original graphics objects retained.\n");}
}
void observeDevice(ID3D11Device* device){
 if(!device||!nativeReady||!observeGraphicsObjects())return;Com<IDXGIDevice> dxgi;Com<IDXGIAdapter> adapter;Com<IDXGIFactory> factory;
 if(SUCCEEDED(device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(dxgi.put())))&&SUCCEEDED(dxgi->GetAdapter(adapter.put()))&&SUCCEEDED(adapter->GetParent(__uuidof(IDXGIFactory),reinterpret_cast<void**>(factory.put()))))dx12::hookFactory(factory.p);
}
HRESULT WINAPI onD3D11CreateDevice(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 const void* caller=NVS30_CALLER_ADDRESS();
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime("D3D11CreateDevice",caller);},
  [&]{return D3D11CreateDevice(adapter,type,software,flags,levels,count,sdk,device,level,context);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&observeGraphicsObjects()){if(device&&*device)observeDevice(*device);else if(context&&*context){Com<ID3D11Device> actual;(*context)->GetDevice(actual.put());observeDevice(actual.p);}}});
}
HRESULT WINAPI onD3D11CreateDeviceAndSwapChain(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,const DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** swap,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 const void* caller=NVS30_CALLER_ADDRESS();
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime("D3D11CreateDeviceAndSwapChain",caller);if(desc)beforeSwapchain(desc->OutputWindow);},
  [&]{struct Outer{bool before=outerSwapchainCreation;Outer(){outerSwapchainCreation=true;}~Outer(){outerSwapchainCreation=before;}} outer;
      return D3D11CreateDeviceAndSwapChain(adapter,type,software,flags,levels,count,sdk,desc,swap,device,level,context);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&device)observeDevice(*device);if(SUCCEEDED(hr)&&swap&&*swap)registerSwapchain(*swap);});
}
template<class Create> HRESULT createFactory(const char* trigger,const void* caller,Create create,REFIID iid,void** result){
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime(trigger,caller);},[&]{return create(iid,result);},
  [&](HRESULT hr){if(nativeReady&&observeGraphicsObjects()&&SUCCEEDED(hr)&&result&&*result){Com<IDXGIFactory> factory;auto unknown=static_cast<IUnknown*>(*result);if(SUCCEEDED(unknown->QueryInterface(__uuidof(IDXGIFactory),reinterpret_cast<void**>(factory.put()))))dx12::hookFactory(factory.p);}});
}
HRESULT WINAPI onCreateFactory(REFIID iid,void** result){const void* caller=NVS30_CALLER_ADDRESS();return createFactory("CreateDXGIFactory",caller,[](REFIID id,void** out){return CreateDXGIFactory(id,out);},iid,result);}
HRESULT WINAPI onCreateFactory1(REFIID iid,void** result){const void* caller=NVS30_CALLER_ADDRESS();return createFactory("CreateDXGIFactory1",caller,[](REFIID id,void** out){return CreateDXGIFactory1(id,out);},iid,result);}
HRESULT WINAPI onCreateFactory2(UINT flags,REFIID iid,void** result){const void* caller=NVS30_CALLER_ADDRESS();return createFactory("CreateDXGIFactory2",caller,[&](REFIID id,void** out){return CreateDXGIFactory2(flags,id,out);},iid,result);}
FARPROC WINAPI onGetProcAddress(HMODULE dll,LPCSTR name){const void* caller=NVS30_CALLER_ADDRESS();return imports::resolved(dll,name,GetProcAddress(dll,name),caller);}
#include "nvs30/library_hooks.hpp"
void observeDevice12(IUnknown* created) noexcept {
 // Covers a factory the game obtained outside our creation hooks. All DXGI
 // factories share the patched table, so one internal factory suffices.
 try{
  if(!created||!nativeReady||internalCreation)return;
  ComPtr<ID3D12Device> device;if(FAILED(created->QueryInterface(IID_PPV_ARGS(&device))))return;
  Com<IDXGIFactory> factory;
  if(SUCCEEDED(CreateDXGIFactory1(__uuidof(IDXGIFactory),reinterpret_cast<void**>(factory.put()))))dx12::hookFactory(factory.p);
 }catch(...){}
}
HRESULT WINAPI onD3D12CreateDevice(IUnknown* adapter,D3D_FEATURE_LEVEL level,REFIID iid,void** device){const void* caller=NVS30_CALLER_ADDRESS();return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime("D3D12CreateDevice",caller);},[&]{return D3D12CreateDevice(adapter,level,iid,device);},[&](HRESULT hr){if(SUCCEEDED(hr)&&device&&*device)observeDevice12(static_cast<IUnknown*>(*device));});}
#include "nvs30/provider_thunks.hpp"
#include "nvs30/loader_thunks.hpp"
namespace imports {
std::atomic_bool diagnosticsReady{false};
void reportNamed(const std::wstring& path,const char* dll,const char* name,bool delayed){
 if(!diagnosticsReady.load())return;
 static std::atomic_uint count{0};if(count.fetch_add(1)>=96)return;
 logf("[normal] Named import bound: module=%ls import=%s!%s delayed=%d; exact current target retained.\n",path.c_str(),dll,name,delayed?1:0);
}
void reportScan(const std::wstring& path,bool valid,unsigned changed,unsigned graphics){
 if(!diagnosticsReady.load()||(!changed&&valid))return;
 // Only emit the first rejected scan per path, or a changed import set. A
 // nonblocking gate prevents scan diagnostics introducing a loader lock wait.
 static std::atomic_flag writing=ATOMIC_FLAG_INIT;
 if(writing.test_and_set(std::memory_order_acquire))return;
 struct Unlock {~Unlock(){writing.clear(std::memory_order_release);}} unlock;
 static std::array<std::wstring,64> rejected;static unsigned count=0;
 if(!valid){
  for(unsigned i=0;i<count;++i)if(rejected[i]==path)return;
  if(count==rejected.size())return;rejected[count++]=path;
 }
 logf("[normal] Import scan: module=%ls result=%s new_hooks=%u graphics_hooks=%u.\n",path.c_str(),valid?"accepted":"unreadable_or_invalid_PE_tables",changed,graphics);
}
const std::array<Hook,12> hooks={{
 {"D3D12CreateDevice",reinterpret_cast<void*>(__imp_D3D12CreateDevice),reinterpret_cast<void*>(&onD3D12CreateDevice)},
 {"D3D11CreateDeviceAndSwapChain",reinterpret_cast<void*>(__imp_D3D11CreateDeviceAndSwapChain),reinterpret_cast<void*>(&onD3D11CreateDeviceAndSwapChain)},
 {"D3D11CreateDevice",reinterpret_cast<void*>(__imp_D3D11CreateDevice),reinterpret_cast<void*>(&onD3D11CreateDevice)},
 {"CreateDXGIFactory",reinterpret_cast<void*>(__imp_CreateDXGIFactory),reinterpret_cast<void*>(&onCreateFactory)},
 {"CreateDXGIFactory1",reinterpret_cast<void*>(__imp_CreateDXGIFactory1),reinterpret_cast<void*>(&onCreateFactory1)},
 {"CreateDXGIFactory2",reinterpret_cast<void*>(__imp_CreateDXGIFactory2),reinterpret_cast<void*>(&onCreateFactory2)},
 {"GetProcAddress",reinterpret_cast<void*>(&GetProcAddress),reinterpret_cast<void*>(&onGetProcAddress)},
 {"LoadLibraryA",reinterpret_cast<void*>(&LoadLibraryA),reinterpret_cast<void*>(&onLoadLibraryA)},
 {"LoadLibraryW",reinterpret_cast<void*>(&LoadLibraryW),reinterpret_cast<void*>(&onLoadLibraryW)},
 {"LoadLibraryExA",reinterpret_cast<void*>(&LoadLibraryExA),reinterpret_cast<void*>(&onLoadLibraryExA)},
 {"LoadLibraryExW",reinterpret_cast<void*>(&LoadLibraryExW),reinterpret_cast<void*>(&onLoadLibraryExW)},
 {"LoadPackagedLibrary",reinterpret_cast<void*>(&LoadPackagedLibrary),reinterpret_cast<void*>(&onLoadPackagedLibrary)}
}};
}
}
namespace nvs30::dxgi {
bool native_wrapper(IUnknown* swapchain) noexcept {return SwapchainInterfaces(swapchain).evidence().native();}
bool install_hooks(){try{HMODULE pinned{};if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<LPCWSTR>(&install_hooks),&pinned))return false;imports::owner=pinned;return imports::refresh();}catch(...){return false;}}
void asi_startup() noexcept {
 imports::LastErrorScope error;
 try{
  const auto context=startup_bootstrap::loaderContext();
  if(context==startup_bootstrap::Context::outside_loader)install_hooks();
  bootstrap.asi([&]{return context;},selectStartup,startSelectedGame);
 }catch(...){bootstrap.policy="startup_probe_failed";}
}
void service_startup(bool standalone) noexcept {
 imports::LastErrorScope error;
 try{bootstrap.service(standalone,startup_bootstrap::loaderContext,selectStartup,startSelectedGame);}catch(...){bootstrap.policy="startup_probe_failed";}
}
void shutdown(){} // Hooks and their executable storage live until process exit.
void set_internal_creation(bool value){internalCreation=value;}
bool internal_creation(){return internalCreation;}
void startup(){
 // Publish creation hooks before filesystem logging can delay first discovery.
 // Runtime setup belongs to the admitted graphics call or selected early entry.
 install_hooks();openDiagnostics();imports::diagnosticsReady=true;
 logf("[normal] creation hooks ready: %lu imports; %zu Streamline providers, %lu provider imports; waiting for real game graphics creation.\n",imports::patched.load(),imports::providers.count(),imports::providerPatches.load());
}
}
extern "C" __declspec(dllexport) unsigned WINAPI SmoothMotionGetStatus(char* out,unsigned size){
 char timingStatus[2048]{};sm20::performance::json(timingStatus,sizeof timingStatus);
 char gpuStatus[1024]{};sm20::performance::gpu_json(gpuStatus,sizeof gpuStatus);
 char skipStatus[1024]{};size_t used=0;
 for(size_t i=0;i<skips.size();++i){
  const int written=std::snprintf(skipStatus+used,sizeof(skipStatus)-used,"%s\"%s\":%llu",i?",":"",skipNames[i],skips[i].load());
  if(written<0||static_cast<size_t>(written)>=sizeof(skipStatus)-used)break;
  used+=static_cast<size_t>(written);
 }
 int n=std::snprintf(out,out?size:0,
  "{\"schema\":17,\"version\":\"" NVS30_VERSION "\",\"initialization_status\":\"%s\","
  "\"backend\":\"Turing NVOF + custom synthesis\",\"mode\":\"rtx20_preview\",\"runtime_loaded\":%s,"
  "\"import_patches\":%lu,\"module_scans\":%llu,\"loader_notifications\":%llu,\"loader_notifications_active\":%s,"
  "\"graphics_provider_count\":%zu,\"provider_import_patches\":%lu,\"provider_resolutions\":%lu,"
  "\"loader_provider_count\":%zu,\"loader_alias_import_patches\":%lu,\"loader_alias_resolutions\":%lu,"
  "\"graphics_import_patches\":%lu,\"import_scan_failures\":%llu,"
  "\"named_graphics_bindings\":%zu,\"named_loader_bindings\":%zu,\"named_graphics_patches\":%lu,\"named_loader_patches\":%lu,"
  "\"named_delay_patches\":%lu,\"named_resolutions\":%lu,\"named_bind_failures\":%lu,"
  "\"startup_policy\":\"%s\",\"startup_entry\":\"%s\",\"asi_entries\":%lu,\"early_startup_attempts\":%lu,\"startup_loader_deferrals\":%lu,"
  "\"graphics_entries\":%llu,\"graphics_admitted\":%llu,\"graphics_excluded\":%llu,\"resolver_entries\":%llu,"
  "\"presentation_profile\":\"%s\",\"presentation_hooks_enabled\":%s,\"present_counter_kind\":\"%s\",\"present_calls\":%llu,\"bridge_submissions\":%llu,\"bridge_present_attempts\":%llu,\"bridge_present_failures\":%llu,"
  "\"bridge_test_calls\":%llu,\"bridge_occluded\":%llu,\"bridge_busy\":%llu,\"passthrough_calls\":%llu,"
  "\"present_eligible\":%llu,\"present_tearing_eligible\":%llu,\"present_skips\":{%s},"
  "\"dx12_sessions\":%llu,\"dx12_captures\":%llu,\"dx12_writes\":%llu,\"dx12_transfer_failures\":%llu,\"flow_pairs\":%llu,\"generated_present_accepted\":%llu,\"real_present_accepted\":%llu,\"rtx20_failures\":%llu,\"legacy_cuda_calls\":%llu,\"performance_cpu_wall_us\":{%s},\"performance_gpu_us\":{%s,\"generated_present_queue_busy\":%llu,\"pacing\":\"generated_half_interval_spaced_or_paired\",\"runtime_fps_cap\":0,\"interpolation_verified\":false}",
  sm20::runtime_status(),nativeReady?"true":"false",imports::patched.load(),imports::scans.load(),
  static_cast<unsigned long long>(module_watch::generation.load()),module_watch::registered?"true":"false",
  imports::providers.count(),imports::providerPatches.load(),imports::providerResolutions.load(),
  imports::loader_api::providers.count(),imports::loader_api::patches.load(),imports::loader_api::resolutions.load(),
  imports::graphicsPatches.load(),imports::scanFailures.load(),
  imports::named::graphics.count(),imports::named::loaders.count(),imports::named::graphicsPatches.load(),imports::named::loaderPatches.load(),
  imports::named::delayPatches.load(),imports::named::resolutions.load(),imports::named::bindFailures.load(),
  bootstrap.policy.load(),bootstrap.entry.load(),bootstrap.asiEntries.load(),bootstrap.attempts.load(),bootstrap.loaderDeferrals.load(),
  imports::graphicsEntries.load(),imports::graphicsAdmitted.load(),imports::graphicsExcluded.load(),imports::resolverEntries.load(),
  presentation_profile::name(presentationProfile.load()),observeGraphicsObjects()?"true":"false",presentation_profile::counter_kind(presentationProfile.load()),
  calls.load(),bridgeSubmissions.load(),bridgeAttempts.load(),bridgeFailures.load(),bridgeProbes.load(),bridgeOccluded.load(),
  bridgeBusy.load(),passthroughs.load(),eligiblePresents.load(),eligibleTearing.load(),skipStatus,sm20::dx12_sessions.load(),sm20::dx12_captures.load(),sm20::dx12_writes.load(),sm20::dx12_transfer_failures.load(),sm20::flow_pairs.load(),sm20::generated_submissions.load(),sm20::real_submissions.load(),sm20::failures.load(),0ull,timingStatus,gpuStatus,generatedQueueBusy.load());
 return n<0?0:unsigned(n)+1;
}
