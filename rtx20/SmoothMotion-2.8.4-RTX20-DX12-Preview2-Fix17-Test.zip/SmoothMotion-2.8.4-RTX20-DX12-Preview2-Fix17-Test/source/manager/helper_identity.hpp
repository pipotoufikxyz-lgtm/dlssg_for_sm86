#pragma once
namespace helper_identity {
inline constexpr char installer[]="c8685da2eb607a8fdc7a881c5130b4d207c65adc5db3b4e51d79ed8497694017";
inline constexpr char collector[]="98c4faf9cb4c42dc83b8f6a3ffd0032ee031b808a27d6ab6f959ae89ea7606b7";
}
