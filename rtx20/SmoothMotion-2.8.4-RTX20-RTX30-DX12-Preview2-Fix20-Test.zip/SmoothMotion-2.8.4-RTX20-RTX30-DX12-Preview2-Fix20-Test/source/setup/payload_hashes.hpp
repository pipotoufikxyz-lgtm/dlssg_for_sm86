// Generated from current payloads and pinned legacy ownership identities.
#pragma once
namespace payload_hashes {
inline constexpr const char native_proxy[] = "b5ab6a5bd0a2796b686ce8bee09cd33f3038e285da4764babf28bb4f55fc19a0";
inline constexpr const char motion[] = "e2bcc64053e7233f65ba66a9c14656ea191f8a7ce0d74e4f6b4b36f9978e5b93";
inline constexpr const char loader[] = "031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
inline constexpr const char ini[] = "7fbe28780c05b182220c61197ba7ea9506816fb3637897c3ae4a0ecd7fd7d650";
inline constexpr const char standalone[] = "feb05f255d09bc207a7eeacd55cb87b0bbfeedc5337b97aaa37245ed36a98bc7";
inline constexpr const char asi[] = "16b7b560d100f9f26d3d0454617a128337374320c468f4a5ec46b99dcc6c594e";
}
