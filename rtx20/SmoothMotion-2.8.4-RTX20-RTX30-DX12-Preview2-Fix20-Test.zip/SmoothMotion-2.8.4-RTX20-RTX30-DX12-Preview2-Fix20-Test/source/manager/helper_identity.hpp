#pragma once
namespace helper_identity {
inline constexpr char installer[]="484c9755697bb79335858f9dc3c43b4d65a0dd30c70d9c52e8506be92a377e38";
inline constexpr char collector[]="49d2f4bcb6d02100515248dd33ca605be35eeb8fb98e4fa779c73a085c1939cd";
}
