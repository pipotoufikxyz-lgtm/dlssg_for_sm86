# GP8 — Xbox/Game Pass detection

## Problems found in GP7

- Automatic discovery covers Steam, Epic and GOG but never checks XboxGames.
- Browse folder sends XboxGames through a single-installation scan, combining
  all children into one candidate list and one game card.
- Folder traversal has no MicrosoftGame.config launch hints. Denied executable
  reads can use metadata only after the wildcard scanner finds the file.
- The metadata policy rejects a missing TargetDeviceFamily instead of applying
  the documented current-device default (PC for these Windows tools).
- A protected EXE with unknown imports loses ranking with each directory level,
  even when its executable identity was established by metadata.
- Failed inspections are counted and discarded; Browse folder does not pass
  scan statistics and always reports completion even when no game was found.

These are source findings. The supplied screenshot does not establish which
specific metadata/permission/layout condition applies inside Ragebound.

## Changes

- Discover XboxGames installations on fixed local drives. Browse folder uses
  the same collection/grouping path for XboxGames and metadata-marked folders.
- Separate game cards for each Xbox installation; normalize a selected Content
  folder to its owner game. Exclude the sibling GameSave directory.
- Extract supported executable declarations from the existing bounded XmlLite
  parser and inspect them before file enumeration in that directory. Prioritize
  Content directories before bulk asset directories.
- Apply documented PC/x64 defaults only when attributes are omitted. Explicit
  empty, console, ARM64, development-only and duplicate declarations remain
  ineligible for protected x64 fallback.
- Retain verified metadata in candidate ranking and explicit target selection.
  Keep unknown API/import information unknown. Missing/corrupt files and sharing
  errors do not become valid executables through metadata fallback.
- Report unreadable paths, their errors, scan cutoffs and zero-result scans.
  Cancellation and failed manual scans preserve the previous library.
- Rebuild Manager, installer and diagnostic collector. Reuse the exact GP7
  standalone DLL and ASI, including the existing Dead Space/Genshin startup code.

## Validation scope

The production folder traversal and grouping functions run in host tests with
filesystem seams. The fixtures use the visible Ragebound/Marvel folder names
and synthetic Game.exe declarations; no actual game manifest was provided.
The released GP7 metadata policy is executed as a control and reproduces
rejection of the omitted family attribute. Windows APIs, XmlLite and gameplay
are not executed by these fixtures.

The official schema reference used for the default behavior is:
https://learn.microsoft.com/en-us/gaming/gdk/docs/reference/system/microsoftgameconfig/elements/microsoftgameconfig-element-executable?view=gdk-2510
