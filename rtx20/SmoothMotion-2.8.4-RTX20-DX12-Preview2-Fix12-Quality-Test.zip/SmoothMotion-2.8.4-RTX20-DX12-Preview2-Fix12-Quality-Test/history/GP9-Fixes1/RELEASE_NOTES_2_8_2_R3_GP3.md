# R3 GP3 — Streamline graphics creation / Dead Space report

The supplied Dead Space Remake log proves that GP1 `new.asi` loaded through
the selected carrier, but initialization stayed `not_started`: zero graphics
creation observations, Present calls and CUDA module loads over 450 seconds.
The screenshot also shows the game's `sl.interposer.dll`.

A reproduced runtime defect matches this path: GP1 only recognized addresses
from its own Windows DXGI/D3D imports. Streamline exports the same graphics
APIs at different addresses, which could escape interception entirely.
NVIDIA documents both static imports and dynamic resolution of these exports:
https://github.com/NVIDIA-RTX/Streamline/blob/main/docs/ProgrammingGuide.md

## Changes

- Discover existing Streamline exports before scanning consuming modules, so
  an EXE enumerated before `sl.interposer.dll` is intercepted on the first scan.
- Discover late Streamline exports synchronously during an intercepted
  `GetProcAddress`, while preserving ordinal and missing-export behavior.
- Bind separate forwarding thunks to each recognized provider instance for
  `CreateDXGIFactory`, `CreateDXGIFactory1`, `CreateDXGIFactory2`,
  `D3D12CreateDevice`, `D3D11CreateDevice`, and
  `D3D11CreateDeviceAndSwapChain`. Forward through the exact Streamline export.
- Retain a module reference for each published provider; never recycle a
  callback slot or change its destination. Publication is bounded and
  nonblocking, with no loader API calls under its publication guard.
- Preserve protected-origin exclusions across nested graphics calls so a
  Steam overlay probe cannot initialize the backend through a helper module.
- Expose provider discovery/import/dynamic-resolution counters in status
  schema 9. Log the first `Streamline!…` graphics initialization trigger.
- Recognize the exact GP1/GP2 DLL and ASI identities for reviewable upgrades,
  including manually installed copies. Keep the existing loader when selected.

## Install for the reported layout

Close Dead Space and the older Manager. Extract this full package and open
its `SmoothMotion_Manager.exe` (About: `2.8.2-r3-gp3`). Select:

`E:\EA Games\Dead Space (2023)\Dead Space.exe`

Choose **new.asi + winmm.dll**, then review and apply the update. Your log
already confirms that this carrier loads the ASI. The new installer updates
its ownership record and `uninstall.bat`. Keep one backend route installed.

For a purely manual installation, `Manual/ASI_Only/new.asi` is the new runtime
for the existing loader; manual copying does not update an existing ownership
record. The Manager is the recommended upgrade method.

## What is and is not verified

The missed-provider case is reproduced using the production import scanner and
all six production provider thunks. Tests cover static imports, dynamic exports,
late providers, distinct providers, repeated scans, exact forwarding, failed
calls, retained module references and nested protected callers. Windows x64
cross-compilation, package/source hashes, PDB pairs and host regression tests
are verified. Game Pass picker and metadata repairs remain included.

This environment cannot run Dead Space, Windows graphics or an NVIDIA GPU.
This fixes the reproduced interception defect; successful Smooth Motion in
Dead Space still needs an actual game run. A loaded DLL, a provider counter,
or CUDA activity alone is not proof of displayed frame interpolation.

The new log identifies `2.8.2-r3-gp3-normal`. In this route, expect
`graphics_provider_count` to become nonzero and the first graphics trigger to
name Streamline. If initialization still stays `not_started`, provide the new
log; it can distinguish provider detection from loading after graphics creation.
