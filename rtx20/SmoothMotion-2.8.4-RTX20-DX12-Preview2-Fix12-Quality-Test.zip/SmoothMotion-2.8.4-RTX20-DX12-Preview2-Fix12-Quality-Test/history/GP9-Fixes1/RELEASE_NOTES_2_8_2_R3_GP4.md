# GP4 — Windows loader aliases and Dead Space diagnostics

The new report confirms that the GP3 ASI was installed and running. It found
one Streamline provider, but no intercepted graphics creation, Present calls
or CUDA activity. The installed 616.64 driver file passed its static profile
check. These facts do not establish that frame interpolation is working.

GP3's Streamline change was insufficient for this reported installation.
The report does not identify the precise API path used by the engine.

## Runtime repair

The import dispatcher previously matched one linked Windows address for each
loader API. Windows API-set imports can bind to KernelBase exports with
different addresses. Missing those calls can also miss the renderer's first
graphics calls before the background module scan catches up.

GP4 discovers the exports of Kernel32, KernelBase and Kernel32Legacy from
already loaded Windows modules before scanning consumer import tables.
It binds GetProcAddress, LoadLibraryA/W, LoadLibraryExA/W and
LoadPackagedLibrary to separate forwarding callbacks. Each callback retains
its exact original destination and module reference for process lifetime.
Publication is bounded and nonblocking. The Windows and Steam overlay import
tables remain excluded; cached resolver callbacks retain caller exclusions.

A successful executable DLL load synchronously scans the new renderer before
returning to the game. Resource-only loads and failed loads do not scan.
Ordinal/missing export lookups, filenames, flags, handles, return values and
LastError are preserved. No graphics initialization is performed merely by
discovering a module: initialization stays on a graphics caller.

Status schema 10 adds loader-provider, alias, graphics-import and rejected-scan
counters. The log now identifies changed or rejected module scans, with a
bounded list of rejected paths. This avoids another report containing only
an unexplained zero graphics count.

## Diagnostic and upgrade repairs

The collector's 256 MiB whole-file read limit rejected the report's
423,070,256-byte executable. Collector 1.4 now uses the Manager's existing
bounded, read-only mapped PE parser. File length no longer determines a
whole-file heap allocation or rejects an otherwise valid executable.

The installer recognizes the exact GP3 ASI and standalone DLL hashes for
upgrades and retains ownership records for uninstall.bat.

## Install

Close Dead Space and the older Manager. Extract this complete package and
open its SmoothMotion_Manager.exe. Select the Dead Space.exe in the Steam
installation shown in your latest report. Choose **new.asi + winmm.dll** and
apply the update. The report already establishes that winmm loads your ASI.
Use this Manager to keep the uninstall receipt consistent with the new files.

The runtime log must identify **2.8.2-r3-gp4-normal**. Standalone version.dll
and the ASI contain the same repair. Game Pass fixes remain included.

## Verification and limits

The production scanner and all six loader-alias forwarding callbacks are
executed in the host regression fixture. It reproduces an immediate
load-renderer -> resolve-function -> create-graphics sequence using distinct
KernelBase addresses, before any background scan. Existing Streamline,
small-stack, protected-origin, upgrade and uninstall regressions remain.

The supplied report establishes the collector defect directly. The loader
alias defect is reproduced in source tests and fits the missing-interception
symptom, but the report does not prove that Dead Space used that exact path.
No Windows, NVIDIA GPU or Dead Space execution occurred in this environment.
Build and host-test success do not verify displayed frame interpolation.

If GP4 remains inactive, collect a new report with this package's
Collect_Diagnostics.exe after entering gameplay. It will include the new
module-scan evidence and the executable imports that the old collector could
not read.
