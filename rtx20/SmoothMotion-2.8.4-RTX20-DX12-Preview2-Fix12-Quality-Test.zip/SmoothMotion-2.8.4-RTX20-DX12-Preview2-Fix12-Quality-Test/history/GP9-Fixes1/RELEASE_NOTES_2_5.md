# 2.5 normal-mode candidate

Improves DLL startup and graphics-hook failure handling.

- Validates copied import tables completely before modifying them. The mapped
  module size comes from the module snapshot; unreadable pages fail safely.
  A 4 KiB cache avoids one ReadProcessMemory call per import slot. Descriptor
  and slot limits bound work on malformed images.
- Reads loader/backend exclusion exports through that same bounded copy path.
  Does not reject unrelated long C++ export names merely because of their length.
- Checks graphics-hook page-protection restoration. A failed restore undoes
  this hook's pointer using compare/exchange and retries protection restoration.
  A pointer installed by a later owner is preserved. Pages that were executable
  keep executable permission during the pointer update.
- Forwards incomplete Present hook groups directly to the saved game function.
  The bridge cannot activate through a partially installed group.
- Moves executable-path lookup outside the logging mutex to remove a possible
  loader-lock inversion. Module snapshots close even if scanning throws.
- Adds the exact shipped 2.4 ASI to Manager/installer upgrade identities.

Normal mode only. The .asi and version.dll/dinput8.dll/winmm.dll routes remain
available. Upgrade the existing route through the Manager; preserve the winmm
route that successfully loaded the supplied Haydee 2 installation.

36 optimized/sanitized host runs cover 18 suites. Windows x64 binaries and
package identities are checked. This is a compiled candidate: Windows game
execution, NVIDIA kernel compatibility, and displayed interpolation remain
unverified. See VALIDATION.md for the precise evidence and remaining tests.
