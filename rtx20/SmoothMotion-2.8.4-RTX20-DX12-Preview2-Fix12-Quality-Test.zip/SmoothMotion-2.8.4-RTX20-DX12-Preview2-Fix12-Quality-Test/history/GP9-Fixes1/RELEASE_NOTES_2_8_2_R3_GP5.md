# GP5 — named graphics imports and first-call delay interception

The latest report confirms that GP4 is installed and the collector can now
read Dead Space's executable. Both GP4 sessions reach the renderer with no
import-scan failures, but graphics initialization remains not_started. The
report lists a D3D12 delay import, a DXGI ASI loader and RTSSHooks64.dll.
It does not contain the game's function addresses or execution stacks.

GP3 and GP4 did not resolve this installation's failure. GP5 changes the
interception method for the remaining source defects, rather than adding
another DLL-name alias to the same address-only matching scheme.

## Runtime changes

- Read bounded DLL/function identity from normal and delay import-name tables.
  Recognize only the established graphics and Windows loader API signatures.
  Retain address matching when identity metadata is absent or unreadable.
- Intercept the actual current target of a recognized import, including a
  proxy/overlay replacement or unresolved delay thunk. Forward through that
  exact target with the original arguments, outputs, HRESULT and LastError.
- Initialize on the first graphics call before forwarding to the delay helper.
  Allow the helper's normal active-IAT update. Bound and unload-IAT copies
  remain untouched. A later scan can bind the newly resolved target.
- Recognize a named GetProcAddress/LoadLibrary import even after its address
  was replaced by another hook. Preserve that resolver/loader in the chain.
- Bind the actual graphics address returned by a recognized module's export
  lookup, including System32 graphics exports when our linked address belongs
  to a local DXGI proxy. Different returned addresses get distinct callbacks.
- Keep each (API, original address) binding immutable. Retain the module that
  owns the actual target. Repeated scans do not wrap our own callbacks.
- Keep Steam overlay and Windows import-table exclusions. Cached graphics
  callbacks still check the actual caller before starting initialization.
- Status schema 11 records named bindings, graphics/loader/delay patches,
  dynamic resolutions and binding failures. Bounded log entries identify the
  imported DLL, function and whether it is delay-loaded.

No executable instructions are patched, no foreign module is unloaded and
no delayed API is invoked merely to inspect it. Unsupported targets or full
binding capacity retain the original call path.

## Install for the latest report

Close Dead Space and the older Manager. Extract the full package, open its
SmoothMotion_Manager.exe and select the same Steam Dead Space.exe. Update
the existing **new.asi + dxgi.dll** route. Your report proves that this loader
already loads the ASI. Do not add a second backend beside it.

The log must show **2.8.2-r3-gp5-normal**. The standalone version.dll also
contains this repair. GP4 hashes are recognised for upgrades, and updating
through the Manager keeps uninstall.bat's ownership record current.

## Verification

The host fixture includes the exact GP4 scanner body with only its function
name changed. GP4 leaves the named graphics wrappers and unresolved D3D12
delay thunk unchanged. GP5 binds them and executes all six graphics signatures
and six loader/resolver signatures through the production forwarding code.

Tests cover the first delay call, the helper's IAT replacement, subsequent
calls, untouched bound/unload copies, stable cached callbacks, distinct
System32 and local-proxy targets, missing/ordinal lookups, repeated scans,
protected callers, malformed identity metadata and concurrent publication.
The full release includes 39 host suites in optimized and ASan/UBSan builds.

This is a source-level reproduction and repair. No native Windows, NVIDIA
GPU or Dead Space execution was available here. The report does not prove
the game's complete call sequence, and successful tests do not prove
displayed frame interpolation. A live GP5 run is still needed.

If it remains inactive, use this package's Collect_Diagnostics.exe after
entering gameplay and provide the new report. Its named-import entries and
first graphics trigger distinguish discovery from driver initialization.
