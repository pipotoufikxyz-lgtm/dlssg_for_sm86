# 2.8.2 R3 GP1 — targeted Game Pass loading repairs

Baseline: SmoothMotion-2.8.2-R3-Stability.zip, SHA256
`5842e07cc5b2d5af8b17ae6536c6e70733c9871615b8948b5ea9210123112fba`.
Runtime status: `2.8.2-r3-gp1-normal` (schema 8 retained).

The Steam-success/Game-Pass-failure report justifies checking packaged loading,
but does not identify a crash address or the graphics path in the affected games.
This update repairs concrete source defects without removing the Steam guards.

## Runtime changes

1. `LoadPackagedLibrary` is added to the existing exact-address IAT and eligible
   GetProcAddress dispatch. The wrapper calls the real API once and refreshes
   imports after success, before returning. It preserves the filename, reserved
   argument, module handle and LastError, including failure in a process without
   package identity. It never substitutes ordinary LoadLibrary to bypass package
   resolution and never initializes graphics itself.
2. Windows-origin exclusions now compare extended DOS drive paths and mixed
   separators consistently. The directory boundary is retained, so WindowsGames
   is not mistaken for Windows. WindowsApps and ordinary Xbox game paths are
   not blanket-excluded. UNC/device aliases, short names and junction identity
   resolution are outside this change.
3. Module snapshots retry ERROR_BAD_LENGTH, with a maximum of three attempts
   and no sleeps. Other failures return immediately. Handle ownership, the
   same-thread reentry guard and subsequent worker retry remain intact.
4. Exact R3/R4 runtime hashes are added to existing upgrade/removal policy.
   Changed files and unrelated mods keep their existing protections.

The ordinary LoadLibrary wrappers were extracted to a shared header so their
actual production forwarding code can be tested alongside the packaged wrapper.
The driver patch profile, CUDA model transform, interpolation backend, D3D11
bridge and version-API forwarding are otherwise unchanged from attached R3.

## Verification and limits

All three targeted regressions fail using the attached R3 scanner/policy and
pass using GP1. The full 35-suite optimized and ASan/UBSan regression run, Windows
cross-build, exact binary/PDB matches and final package checks are described in
VALIDATION.md. These tests inject Win32 seams; no Windows game was executed.

Interception must already be installed in the loading caller. Graphics created
inside a newly loaded DLL's static initializer, before the load API returns,
remain an uncovered timing case. Cached/raw pointers, unmatched API aliases,
custom loaders and late ASI loading retain existing limitations. Many Game Pass
Win32 games do not use LoadPackagedLibrary at all; this change is relevant only
when that path is used. Game Pass does not expand the renderer support matrix.

Use the Manager to upgrade one existing carrier route. Keep a working ASI
carrier; for dinput8 select new.asi + dinput8.dll, rather than renaming the
standalone version.dll. Each Manager installation still creates uninstall.bat.
Launch Game Pass titles normally through the Xbox app.
