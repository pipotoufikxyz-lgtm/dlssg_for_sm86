# Compatibility scope

## GP7 update

GP7 extends the GP6 early startup path to GenshinImpact.exe with its adjacent
GenshinImpact_Data directory. The user reported GP6 working in Dead Space.
There is no Genshin gameplay validation yet. The API/driver limitations below
still apply; early initialization alone does not verify frame interpolation.

## Earlier baseline evidence

The supplied Haydee 2 log identifies three actual 2.7 sessions. Each rejected
NvPresent `f36a5f...` before loading it; one continued through the 15-second
status report with no CUDA or presentation activity. 2.8 adds the exact matching
616.64 profile and repairs a separately reproduced import-scanner stack failure.
No exception stack identifies the user's exact crash site, and this build has
not been executed in a Windows game or on an NVIDIA GPU.

| Path | Implemented behavior | Validation status |
| --- | --- | --- |
| Normal native DX12 | Initialize recognized NvPresent before graphics creation and forward game presentation | Compiled; no GPU execution |
| DX11 legacy DISCARD, windowed SDR, one sample | Share frames on the same GPU to an owned DX12 shadow chain | Compiled; no GPU execution |
| DX11 flip/fullscreen/HDR/MSAA/special flags | Preserve original presentation; no injected bridge | Code path inspected |
| Vulkan, OpenGL, DX9, 32-bit | No backend | Unsupported |
| SM86 with exact 616.64/reference profile | Checked 41-site transform of 20 non-FP8 modules; 17 FP8 modules and SETGE retained | Exact transform/original bytes tested on supplied reference; actual 616.64 file and GPU not executed here |
| SM89/SM120 without an SM86 device | Original model metadata; SM120 entries always preserved | No GPU execution; mixed-GPU configurations unverified |
| Unknown NvPresent layout | Reject private patching and preserve original graphics startup | Code/layout regression tested |
| ASI loaded after graphics startup | No reliable retrofit to an existing swapchain | Needs an earlier carrier/loader |

## Emulator and late-renderer behavior in 2.6

The host graphics API selected in the emulator matters; the emulated console
does not change the API the DLL intercepts. There is no separately verified
emulator compatibility list.

| Host renderer or loading pattern | Current behavior |
| --- | --- |
| x64 Direct3D 12 through DXGI | Existing native DX12 interception; requires a compatible NvPresent runtime |
| x64 Direct3D 11 through DXGI | Existing restricted bridge or detected native wrapper; flip-model chains remain outside the bridge contract |
| Vulkan or OpenGL | No frame-generation backend in this DLL |
| Renderer selected after a long frontend idle | Resident worker continues discovery beyond the old 30-second cutoff |
| Resolved delay imports | Active delay IAT is scanned alongside normal imports |
| Newer COM interface on a previously seen table | Extend the tracked hook group while retaining original method pointers |

Loader notifications request a worker scan on the next 500 ms tick. They do
not patch memory inside the loader callback. Scans otherwise run every 500 ms
during the initial 30 seconds, then every 30 seconds with notifications or
every 5 seconds without them. Failed module snapshots remain due for retry.
Hooked LoadLibrary calls and, from R3 GP1, LoadPackagedLibrary calls also refresh
imports before returning to their caller. ERROR_BAD_LENGTH snapshots receive up
to three immediate attempts; other failures remain eligible for later scans.
This does not intercept previously cached raw function pointers, guarantee a
callback before an immediate graphics call through a custom loader, or attach
to a device/swapchain created before the ASI was loaded. Use one early loader
route for the actual emulator EXE. Actual Windows execution remains untested.

The copied import parser supports PE32+ RVA-form delay descriptors. It rejects
malformed/unsupported tables before applying any slot from that scan. It does
not resolve pending delay loads or modify the loader's unload/bound table copies.

An unconfirmed bridge declines after 64 accepted Presents without fresh observed
NvPresent CUDA activity. R3 retains a wrapper confirmed from public Present/Present1
entries or saved originals, and logs missing activity instead of disabling it.
An intercepted CUDA execution or synchronization failure still stops the bridge. Tests,
occlusion and temporary backpressure do not consume that observation window.
Counters are module-wide activity signals, not per-chain proof of GPU completion
or displayed interpolation. A fatal shadow Present or copy/queue failure stops
that bridge for the lifetime of its game swapchain; a new game swapchain gets
fresh state. A detected native NvPresent D3D11 wrapper is presented directly.

D3D11.4-capable runtimes use a CPU fence-event wait for the bridge copy.
Older runtimes keep the completion-query fallback; neither path queues an
unbounded cross-device wait. Both retain a 500 ms deadline and preserve the
actual completion error. This has been compiled and its wait policy tested
with host callbacks; runtime synchronization and performance remain unverified.
Failed initialization survives resource resets when the descriptor is unchanged.

Present flags/partial updates outside the implemented bridge contract retire
the bridge before original presentation. A nonblocking call returns temporary
backpressure while an earlier bridge copy is still in flight, rather than
waiting on the copy for up to 500 ms. The actual Windows behavior of these
changes still requires the tests listed in VALIDATION.md.

A single HWND supports one flip-model chain; creating another over an existing
flip chain is not a universal DX11 solution. Microsoft documents this constraint:
https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_2/nf-dxgi1_2-idxgifactory2-createswapchainforhwnd

The shared-resource route follows the documented D3D12 NT-handle/D3D11
OpenSharedResource1 contract:
https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12device-createsharedhandle

## Loading and removal in 2.7

The standalone version.dll contains the same backend source as the ASI. Its
worker still depends on Windows scheduling; it cannot guarantee interception
if the game creates graphics before its hooks are installed. An ASI loader
that invokes InitializeASI early is the alternative. Never load both engines.
A process-wide reservation prevents two of our DLL/ASI copies from privately
initializing NvPresent. Known combined providers exposing both SM_Prepare and
SM_ProviderPath are detected before initialization; generic ASI loaders and
plain OptiScaler are not identified by those names alone. This is not a claim
that all third-party hooks interoperate or that later-loaded engines are blocked.
Failed initialization also skips our factory/swapchain COM registration and
context attachment, preserving existing graphics ownership.

Wardogs launcher resolution fixes the observed installer destination error.
The report also says a manual move to the renderer EXE did not help; its runtime
failure remains unconfirmed without that process's current logs and GPU output.
Simplified Chinese support addresses issue #14's installer-language request.
Nexus reports of successful loading without interpolation and launch crashes
remain reports to reproduce, not certified runtime fixes.

Uninstall uses exact receipt hashes. Changed mod files and logs remain. The
small helper/receipt/batch remain for repeatable removal, and old backup folders
are not deleted automatically. Without a receipt, the Manager can remove complete
recognized legacy groups after review; it cannot infer ownership from a generic
ASI loader alone. Choose installed EXE selects the original folder without
renderer redirection. A loader and INI needed by other or modified ASI plugins
are preserved, and mode switches that would remove a shared loader are blocked.

## Exact driver profile and initialization in 2.8

An exact original 616.64 full-file hash must pass CPU layout, CPU fingerprint,
all 41 original byte sequences and the full transformed-output hash. The
separate supplied reference has its own independently calculated output oracle.
Metadata variants must match all initialized CPU/CUDA sections and the normalized
output transform; modified CUDA data is rejected. All loaded-image sites are
read before mutation, then changed transactionally before NVP initialization.
No on-disk NVIDIA component is changed.

The configuration contract writes DWORD +0x6c=1, DWORD +0x48=0 and BYTE +0xe9=1
before init, and requires config[0] afterward. It does not force +0x4c, overwrite
+0xe8, force SETGE, or rewrite config after successful initialization. CUDA
module calls retain the original image pointer on this exact-profile path.
The prior upstream-reference path remains separate and experimental.

Initialization is synchronous for its first caller. Concurrent/reentrant calls
continue through the original graphics API without waiting on private once
locks; such a concurrent creation can occur before initialization completes.
The existing ASI early-hook path remains synchronous. Graphics objects created
before interception and dynamic System32/proxy export aliases remain coverage
limitations. The repair removes blocking and oversized stack usage, not every
possible third-party interaction.

Module-load errors remain visible in diagnostics but are counted separately
from kernel/graph/synchronization failures. A successfully recovered module
selection no longer inherits fatal status from an earlier failed load; an unconfirmed bridge
still fails the existing fresh-activity deadline. A confirmed wrapper is not
retired from missing activity observations alone in R3.

## 2.8.2 Steam Overlay interaction

New Windows events identify the recent startup fault as an access violation in
gameoverlayrenderer64.dll at offset 0xd4b07. The import scanner previously could
redirect that module's private graphics lookups. This candidate excludes the
two exact Steam Overlay basenames and protects creation calls entered through
shared hooks. Game and engine modules remain eligible. Unknown dynamic callers
retain API forwarding; a GetProcAddress lookup with no reliable caller identity
returns its real resolved address.

This addresses an observed source-level interaction surface, not a recovered
Steam/NVIDIA call stack. Inline hooks already installed in shared graphics
implementations remain outside this repair. The origin guard identifies the
immediate caller, not an overlay farther back behind another module's trampoline. Host regressions cannot establish
that the specific game crash is resolved. The new reports also contain a
successful 2.8 initialization with 19 CUDA modules and continuing activity;
that is supporting runtime evidence, not independent displayed-frame proof.

## 2.8.1 initializer tracing (retained)

The latest actual 2.8 log passes the exact installed driver profile and stops at
NVP_Init_D3D. Version 2.8.1 preserves that backend and adds passive first-chance
exception records, loading-route context and collection of the new trace file.
It is a diagnostic update, not a verified fix for the remaining initializer
failure. Records distinguish exception address/registers from proof of a final
crash; the handler neither resumes faulting instructions nor skips assertions.

## R3 GP1 packaged-game loading

LoadPackagedLibrary interception preserves the native package graph and errors;
it does not add arbitrary DLL search paths or bypass package/installation rules.
The early-scan benefit applies when the calling module's IAT or dynamic lookup
has already been intercepted. A DLL's own initializer runs before the load API
returns and is not covered by this after-load scan. Game Pass Win32 titles can
use ordinary LoadLibrary instead; storefront does not identify the loading path.

Extended DOS Windows paths and slash variants now share the ordinary Windows
exclusion policy. This is not full canonical filesystem identity resolution.
XboxGames/WindowsApps renderers remain eligible for the existing supported APIs.
Ninja Gaiden Ragebound and Marvel Cosmic Invasion remain hardware-unverified.
