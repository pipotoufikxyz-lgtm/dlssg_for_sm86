# 2.3 normal-mode candidate

Improves runtime failure handling while retaining normal Smooth Motion, the
ASI payload and all existing loader routes. Multiplier controls remain removed.

- Fatal shadow Present and GPU copy/queue failures disable the affected bridge
  instead of recreating it each frame. Failures include the actual HRESULT and
  D3D11/D3D12 removal reasons; the original game Present result is preserved.
- Present(TEST) does no frame-copy work, and tests/occlusion/backpressure are
  separated from accepted Presents. Temporary statuses do not trigger a second
  source Present. Unsupported presentation contracts retire the bridge.
- Resize/fullscreen transitions block new bridge preparation. No resource mutex
  is held over source or shadow Present. Native DX12 avoids bridge allocation;
  a detected native NvPresent D3D11 wrapper retains its own presentation.
- Replaces the lifetime CUDA-success flag with a recent-activity window.
  Records cuEventSynchronize failures and distinguishes API activity from GPU
  completion/display evidence in status schema 5.
- Rolls back replacement bytes if instruction-cache or page-protection updates
  fail. Hook storage remains resident if an explicit rollback cannot finish.
- LoadLibrary hooks preserve the wrapped call's Win32 error value.
- Manager detection and installer ownership use one previous-build list,
  including the exact shipped 2.1 and 2.2 ASIs. Upgrades preserve existing logs
  and keep the selected winmm/version/dinput8/other supported carrier.

Windows x64 binaries cross-compiled; 28 optimized/sanitized host runs cover
production policies and parsers, including injected presentation/patch failures.
Actual Haydee 2, NVIDIA kernel execution and displayed frame interpolation
remain unverified. The installed f36a... NvPresent bytes were not available for
comparison. Existing evidence and remaining runtime tests are in VALIDATION.md.
