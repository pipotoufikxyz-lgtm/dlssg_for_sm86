# Driver profile review for 2.8

The affected system supplied an NvPresent identity that 2.7 rejected. Version 2.8 recognizes it through a complete input-and-output transformation contract, not an added unchecked hash or a driver-version string.

## Exact identities

| Item | SHA-256 |
| --- | --- |
| Reported 616.64 original, 8,417,512 bytes | `f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e` |
| Its reported `.text` section | `d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0` |
| Upstream expected prepared output | `e6e578af927495084021cb7dfe9e008d066e1504f602a0b678caf35a5466887c` |
| Locally supplied, different reference original | `bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68` |
| Independently calculated prepared reference output | `b9387d39a872e2d6f9a6be7d8af572d10e8030697349b1f0127d00c6c6f1bfb8` |

The upstream 0.5.0 archive's serialized profile data contains the first source/output pair and all patch records. The affected system's diagnostics independently report the original file size and source/code hashes. Its 2.7 rejection reason also establishes that the file passed the reference PE section/export/ABI layout check before failing the old code fingerprint check. The local `bec8...` reference is a separate specimen; it must not be described as the user's `f36...` file.

## Transformation and runtime contract

There are **41 sites and 61 changed bytes**: one CPU comparison changes `83 79 14 03` to `83 79 14 02`; twenty non-FP8 CUDA objects each receive a fatbinary architecture-tag change and ELF architecture-flags change from SM89 to SM86. The subsequent CPU `SETGE SIL`, seventeen FP8 objects, and SM120 objects stay unchanged. `616.64-profile-facts.json` records the factual offsets and before/after bytes; the independently written `driver_profile.hpp` implements the contract.

Before loading, 2.8 checks the exact source identity, CPU ABI/code fingerprint, all original-site bytes, and SHA-256 of a fully prepared in-memory candidate. Every byte outside the specified transformation is thereby covered. The reference's metadata variants additionally require the complete initialized bytes of every PE section, unchanged loader controls, original patch records, and the corresponding prepared-section digest. Timestamp, checksum, certificates and raw alignment padding may differ; other CPU/CUDA payloads do not inherit acceptance. The separately recognized legacy `cd395...` specimen does not acquire this profile.

For SM86, runtime translates all reviewed file offsets through the validated section table. It preflights all 41 loaded-image sites, checks each again before writing, records originals, and rolls back attempted writes on failure. CUDA receives the original pointer into the owning loaded module; this path does not perform broad per-call fatbinary rewriting.

The observed upstream initialization settings are reproduced before explicit initialization:

| Configuration address | Write |
| --- | --- |
| Base + `0x7d7810 + 0x6c` | DWORD `1` |
| Base + `0x7d7810 + 0x48` | DWORD `0` |
| Base + `0x7d7810 + 0xe9` | BYTE `1` |

There is no forced `+0x4c`/`+0xe8` write or post-init overwrite. The export is at RVA `0x59e0`; the reference returns a Boolean in AL, not a 32-bit Win32 BOOL. Upstream ignores that return and requires the configuration byte at offset `0` to become nonzero. Inspection found no launcher-added Smooth Motion environment variable or DRS write.

## Evidence and limits

Profile constants and runtime behavior were observed by inspecting archived data and raw compiled-bytecode structure without executing archived Python modules. Applying the 41 records to the local reference independently reproduced the stated reference output hash and exactly 61 changes, with FP8 and the capability-result instruction preserved.

Focused host tests passed: 251 transaction checks, the exact reference transformation oracle, 19 real-reference layout cases, and 10,000 malformed-header cases. Address/undefined-behavior sanitizer checks passed; container ptrace required disabling LeakSanitizer. These are CPU/static tests.

There is a remaining timing difference: upstream prepares a private file before LoadLibrary and initializes a suspended game; 2.8 modifies the loaded image before explicit initialization. Reference DllMain performs configuration setup and does not directly call the initialization export. This supports the chosen ordering but does not establish equivalence on every driver or game.

The actual `f36...` binary, an NVIDIA SM86 GPU, and Haydee 2 were unavailable locally. Its prepared-output oracle comes from the upstream profile and will be checked against the actual bytes at runtime. Successful model loading, executed CUDA work and displayed interpolated frames remain distinct milestones; this audit is not a claim of verified GPU interpolation or Haydee 2 compatibility.
