# NvPresent initialization review after the actual 2.8 Haydee 2 stop

This is a read-only static review, not a reproduced crash. The supplied `nvsmooth30(2).log` reaches the exact driver profile, SM86 detection, CUDA interception and all 41 model edits, then ends immediately before the explicit `NVP_Init_D3D` call returns. It contains no exception code, faulting module/RVA or termination reason. The actual `f36a...` driver file is not available locally; the disassembled reference is the distinct `bec8...` specimen with the same reviewed ABI layout. JSON records full hashes and the source snapshot extracted from the released 2.8 ZIP.

## Established call path

Reference `NVP_Init_D3D` starts at RVA `0x59e0`. It needs no incoming argument and returns a C++ Boolean in AL. The released 2.8 implementation already uses this ABI and its nonblocking `InitializationGate`; neither is a newly discovered missing fix in this log.

1. Call `0x9fd0(config,3)` to compute eligibility. This checks initialization guards at `+2/+3`; `DWORD+6c!=0` sets `+12a1=1` without calling the ordinary capability helper `0x243f0`. `+12a3=1`. If `(DWORD+48 & 3)!=0` and `BYTE+4c==0`, `+12a4=0`; otherwise `+12a4=BYTE+e9`. `+12a5` combines the three eligibility components.
2. When eligibility succeeds, initialization may call auxiliary helper `0x24c10` if `+7a!=0`, then opens a shared mapping through `0x20630`. The mapping's open/map failures are explicitly checked and return without dereferencing a null mapping.
3. Check `+12a5` through `0x9ed0`. A false result returns false.
4. Check `+4f` through `0xa110`, then `+50` through `0xa120`. If both are zero, return true **without setting the main readiness byte**. If either is nonzero, enter factory-hook initialization at `0x37960`.
5. Factory initialization resolves loaded `dxgi.dll!CreateDXGIFactory2`, creates a factory, and obtains vtable slots 10 (`+0x50`) and 15 (`+0x78`). It installs internal detours and sets config byte `+0=1` on success. Null factory methods or a failed detour commit reach an explicit `INT3` at `0x37ab9`. Missing DXGI, absent factory export and failed factory creation have ordinary false-return paths.

The exact profile's `DWORD+6c=1`, `DWORD+48=0`, `BYTE+e9=1` matches the previously audited 0.5.0 launcher contract. `+48` does **not** directly select the Detours path. `+4f/+50` do, but the driver's own diagnostic strings identify these as **DX11/DX12 allowed bits**. They are also consumed elsewhere, including `0xa640`, so clearing them is not a justified hook-only switch.

Allowed bits originate from profile ID `0xb0cc0875`, default `0xffffffff`, at `0x26db7..0x26de6`: bit2 becomes Vulkan `+4e`, bit1 DX11 `+4f`, bit0 DX12 `+50`. The containing configuration routine receives `config+8`, which accounts for its local member offsets being eight bytes smaller.

## Concrete differences from the other launchers

| Behavior | Small supplied version (21) | 0.5.0 launcher | Released 2.8 |
| --- | --- | --- | --- |
| Explicit initialization context | Dedicated worker, before its own DXGI hooks | Remote bootstrap while main game thread is suspended | First intercepted D3D/DXGI creation call |
| Input preparation | Loaded-image patches | Prepared private file before loading | Loaded-image patches |
| Before-init config | `+4c=1`, `+e9=1`; other fields retained | `DWORD+6c=1`, `DWORD+48=0`, `+e9=1` | Same observed exact-profile config |
| Internal factory detours avoided? | No: calls export at small-DLL RVA `0x1b1b` | No evidence of bypass | No |
| Init return/readiness | Tests AL | Requires config byte `+0` | Correct AL type plus exact-profile byte `+0` check |

Small version (21) starts its worker from `DllMain` (`0x4c80`), calls its setup from worker `0x3eb0`, and enters `NVP_Init_D3D` at its own RVA `0x1b1b`. Only after initialization succeeds does it add CUDA telemetry and its own dummy-DXGI hooks. It does not use per-device exports as a replacement for internal initialization. This is direct disassembly evidence, not an assumption from its export list.

The concrete unresolved mismatch is the **call context and ordering**: released 2.8 enters driver startup synchronously inside a real game's graphics call, while the compared implementations initialize from separate bootstrap contexts. Reentrant graphics/driver entry or a loader context is plausible, but no supplied stack or exception record proves it caused this stop. Moving work to a worker also does not itself guarantee a loader-safe situation if another caller holds the loader lock and waits.

## What this does and does not justify

The reviewed early-init path has no direct CUDA model compilation call. It prepares eligibility/mapping state and installs factory hooks; model work occurs later with device/swapchain use. No CUDA module callback appears in this log. This evidence does not justify further kernel rewrites as a fix for the present stop.

The immediate evidence gap is the last completed init stage and exception code/RVA, with these config bytes captured around entry/return: `+0,+1,+2,+3,+4e,+4f,+50,+7a,+12a1,+12a3,+12a4,+12a5`. A first-chance trace must preserve normal exception handling; it should not swallow an unknown driver fault and continue through potentially partial detours.

No native source was edited and no supplied DLL was executed. Static finding of an `INT3` is **not proof it was hit**. No API eligibility bits, driver instructions, per-device ABI or opaque internal modes should be changed solely on this hypothesis.
