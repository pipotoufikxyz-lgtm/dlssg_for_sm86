# Two Haydee 2 diagnostic reports

The new reports correlate five stopped 2.8 initialization sessions with Windows access violations in **`gameoverlayrenderer64.dll` at offset `0xd4b07`**. They also contain an earlier session that completed initialization, loaded nineteen CUDA modules successfully and recorded continuing CUDA/API presentation activity. The faulting module identifies where Windows recorded the failure; it does not by itself identify the originating bug or call chain.

Sources are `diagnostics-20260923-001141-7376.txt` and `diagnostics-20260923-001321-35088.txt`, collected at 00:11:41 and 00:13:21 UTC on 2026-09-23. Both select Haydee 2's `SteamGame.exe`. `REPORT-COMPARISON-2.8.2.json` records full source hashes, source-line references, deduplicated sessions/events and file identities.

## Collection-time files and launch labels

| Report suffix | User's launch label | Files observed when collecting |
| --- | --- | --- |
| `001141-7376` | ASI + version.dll ASI loader | `version.dll`: released **2.8 standalone**, 992,768 bytes, SHA-256 `d807037caac7a2a47a3c8a6a8c2573f0226f9d54771027987c13d42178bdd83f`; `new.asi` absent/inaccessible |
| `001321-35088` | Standalone version.dll | `version.dll`: **Ultimate ASI Loader**, 1,198,304 bytes, SHA-256 `031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf`; `new.asi`: released **2.8 native ASI**, 986,624 bytes, SHA-256 `36dd40e72c6cb3f341dd305b83d4e01f4234149ba8b485b365de4fa753d5671f` |

These are different types of evidence. The user's labels describe their launches; the collector describes files present later. The snapshots do not prove which module was loaded in every historical session and do not establish a mistaken installation. The identities above match the recorded release hashes, not merely filenames. All embedded sessions report `2.8-normal`; neither report contains `nvsmooth30-init-exception.log`.

Both reports independently accept the installed NvPresent file, SHA-256 `f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e`, with the complete 41-site transformation oracle. They identify RTX 3070 and driver `32.0.16.1664`. The driver-profile rejection is no longer the observed failure.

## Session/event correlation

The first report contains five sessions; the second repeats those and adds PID 34440. Windows event PIDs are hexadecimal; the table converts them to match log PIDs. Every matched event below has exception code **`c0000005`** and faulting module **`gameoverlayrenderer64.dll+0xd4b07`**.

| Session start UTC | Log PID / event PID | Last recorded progress | Matching event UTC |
| --- | --- | --- | --- |
| Sep 22 23:46:35 | 51848 / none in returned events | Init returned AL=1, ready=1; native D3D11 wrapper; 15.110 seconds of log coverage | No matching event in inspected results |
| Sep 22 23:47:20 | 3560 / `0xde8` | Profile/config prepared; no init return | Sep 22 23:47:21.0507494 |
| Sep 22 23:49:28 | 47812 / `0xbac4` | Profile/config prepared; no init return | Sep 22 23:49:29.4172367 |
| Sep 22 23:49:57 | 50180 / `0xc404` | Profile/config prepared; no init return | Sep 22 23:49:57.8117590 |
| Sep 23 00:10:57 | 44220 / `0xacbc` | Profile/config prepared; no init return | Sep 23 00:10:58.8252786 |
| Sep 23 00:12:41 | 34440 / `0x8688` | Profile/config prepared; no init return | Sep 23 00:12:41.8851685 |

PID 51848 reports nineteen module loads with `rc=0`, **1,090 successful intercepted CUDA kernel/graph calls**, **965 application Present calls**, and **zero recorded CUDA failures** at its last status. Its swapchain is D3D11, 1920×1009, windowed, format 28, two buffers, DISCARD, one sample. A native NvPresent wrapper was detected; our shadow bridge submitted zero frames. This establishes successful initialization and observed execution activity for that session. It does not establish displayed interpolated frames, output quality, or a clean eventual exit; status still says `interpolation_verified=false`.

## Older events and limits

The deduplicated reports contain ten Windows fault events in total: seven at the same Steam overlay offset, one in `ntdll.dll+0xb7037` (PID 35592), one in `new.asi+0x48f66` (PID 37768), and one in `VERSION.dll+0x4a0d6` (PID 49684). The last three are distinct older records; these snapshots do not identify their loaded binary hashes. The two other overlay events have PIDs 50028 and 10740, without corresponding sessions in these embedded logs.

The newly correlated faults are access violations in the Steam overlay, **not evidence for the earlier reference-only NvPresent `INT3` hypothesis**. No call stack, exception register trace or overlay binary hash is included, so the precise interaction remains unresolved. Disabling or replacing any component has not been tested by this comparison.

Each collector query inspected 200 recent provider events and reached its limit, returning nine and ten exact-executable matches respectively with zero render/parse failures. Missing records therefore cannot establish absence of a crash. The earlier successful session and later faults must both be retained when assessing compatibility.
