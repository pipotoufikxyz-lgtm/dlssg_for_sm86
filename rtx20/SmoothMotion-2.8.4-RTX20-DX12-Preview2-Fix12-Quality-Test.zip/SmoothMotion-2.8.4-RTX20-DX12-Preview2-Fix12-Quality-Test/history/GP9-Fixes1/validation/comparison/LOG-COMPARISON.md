# Supplied log comparison for the 2.8 investigation

All 418 lines across the six logs below were read. The six newly supplied screenshots were also inspected. These are recorded observations, not new game or GPU tests performed here. Log build names do not uniquely identify DLL bytes; none of these logs records the hash of the injected mod DLL.

## Results by file

| Input | Build and context | Actual observation | What it does not establish |
|---|---|---|---|
| `sm86_stability (4).log` — 73 lines | Other implementation, unversioned `sm86_stability` startup. `D3D11Bridge=0`, `PresentPassThrough=1`. Screenshot `1e046b61-0fb7-4b53-b659-3ed3f921f94f.png` matches its pointer values and lines, and attributes the run to PCSX2, RTX 3090, driver 595.79, Smooth Motion enabled in NVIDIA Profile Inspector. | Rehost initialization returns true. Nineteen retargeted fatbin loads return zero. Twelve `cuGraphLaunch` calls and eight `cuEventSynchronize` calls report CUDA success. The selected primary chain is D3D12, 2560×1440, format 28, two buffers, swap effect 4. The reporter says it worked in PCSX2. | The primary-chain wrapper probes all report `NONE`; the implementation says the chain is not a validated NvPresent wrapper. CUDA graph submission and successful event waits do not prove which images were generated or displayed. No output capture or frame-content verification is supplied. |
| `sm86_stability (5).log` — 6 lines | Other implementation labelled `V2.7 RTSS-FIRST FIXED PROFILE`; not our `2.7-normal`. DriverStore directory starts `nvmdi.inf_amd64_21e6b42b376b80b2`. GPU, game and exact driver version are absent. | Finds architecture gate at `+0xc41f/+0xc437`, then aborts because `cuModuleLoadData` IAT entry is not found. Explicitly does not install DXGI hooks. | No CUDA rejection, graph execution, interpolation, exception or crash stack is shown. |
| `sm86_stability (6).log` — 12 lines | Two starts of an unversioned other implementation. DriverStore directory starts `nvlti.inf_amd64_c284234d5322c92e`. | Both starts find the same `+0xc41f/+0xc437` gate and abort at missing CUDA IAT entry, before DXGI hook installation. | No GPU or game identity and no successful backend initialization. |
| `sm86_stability (7).log` — 18 lines | Two `V2.5` starts followed by one `V2.7 RTSS-FIRST FIXED PROFILE` start of the other implementation. DriverStore directory starts `nv_dispi.inf_amd64_b20cc8aeaed64fc2`. | All three attempts fail at the same missing CUDA IAT entry after finding the `+0xc41f/+0xc437` gate. | These version labels must not be mistaken for our 2.5/2.7 release results. The log does not demonstrate a runtime crash. |
| `DD2_20260912_002652_321_PID1784.log` — 251 lines | `RTXMFG-SM-test4-vulkan`, PID 1784, Dragon's Dogma 2. Loaded as `reframework/plugins/version.dll`. Actual observed graphics-device entries are D3D12, not Vulkan. UTC run is 2026-09-11 22:26:52–22:31:42. | Smooth Motion startup remains unobserved (`calls=0`, loader/admission `-1`). All periodic Smooth Motion CUDA launch/graph counters remain zero. Streamline 2.9.0 modules are present. At least 2,048 NGX Create calls are blocked with `unresolved-provider`; the resolved dispatch target is another `_storage_/version.dll`. Vulkan Create/Evaluate probe hooks at that module report conflicts. | The `maxMultiplier=4x` capability and `framesPresentedSinceLastQuery=1` values are DLSS-G telemetry, not evidence of Smooth Motion interpolation. The log is test4, not the supplied test27 DLL and not our 2.7. No GPU model or exact display-driver version is logged. |
| `nvsmooth30(1).log` — 58 lines | Append-only mixture of old `0.1.0`, our historical `2.1`, one separate not-found message, then three clearly delimited `2.7-normal` Haydee 2 sessions. Current process is `SteamGame.exe`; old bridge log identifies RTX 3070. | All three 2.7 sessions load our hooks and discover NvPresent, then refuse its executable/unwind/Detours fingerprint. Last run remains alive long enough to log status about 5 and 15 seconds later. It has 43 import patches and zero Present, bridge and CUDA calls. | These sessions did not initialize the patched NvPresent backend. The file contains no exception code, crash location or stack proving the cause of any reported game crash. Earlier CUDA failures cannot be assigned to 2.7. |

## Haydee 2: the precise current failure

The 2.7 sessions begin at log lines 31, 40 and 49, with PIDs 49684, 37768 and 38768. They all encounter:

```
NvPresent SHA256:
f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e
Code SHA256:
d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0
initialization_status: driver_validation_rejected
```

This is an identity/layout admission failure before native initialization, not a CUDA execution failure in 2.7. It explains why this backend cannot activate in those sessions. A log hash alone is insufficient to approve new private patch sites or binary-layout assumptions.

The old 0.1.0 part is different: it reaches `NVP_Init_D3D=TRUE`, hooks presentation, and attempts a D3D11-to-D3D12 shadow bridge on a 1920×1009 single-buffer DISCARD chain. Both fatbin loads return `rc=200`. Its NT-handle texture creation fails with `0x80070057` and it retries a legacy sharing mode. The bridge then continues despite failing to identify a wrapper. That earlier behavior supplies useful failure clues, but was not repeated by the three 2.7 sessions.

## CUDA and presentation evidence

The PCSX2 report is the strongest positive supplied example: the reporter observed an effect, CUDA accepted multiple module images and graph launches, and event waits returned success. A successful wait establishes completion of its recorded event; this log does not expose the complete graph/event dependency or an output-to-display mapping. It should be recorded as a user-reported working PCSX2 configuration with supporting CUDA activity, not discarded as having no evidence, and not promoted to instrumented frame-generation proof.

None of these logs proves distinct interpolated frame content reaching the display. Conversely, the successful PCSX2 example means that rejecting every SM89-retargeted image on theoretical grounds would go beyond the supplied evidence. Compatibility must be assessed per actual driver image, active GPU and workload.

## Substantive implementation clues

1. **Separate loader failure from runtime failure.** Our 2.7 current blocker is the driver fingerprint check. Other stability builds fail CUDA import discovery. An actionable diagnostic must name the actual stage and image identity rather than reporting a generic unsupported game.
2. **Do not assume a named normal import exists.** The successful stability log uses gate `+0xb9ef/+0xba07` and CUDA IAT `+0x1c8810`; failing logs find a different gate and no named IAT slot. The old Haydee log finds the latter gate and a CUDA slot at `+0x1d2820`. Those observations justify robust normal/delay/resolved import discovery but do not establish why each lookup failed, or authorize copying RVAs into another image. Our native source already includes multiple CUDA discovery routes; check their exact validation and owner contracts against a supplied driver image.
3. **Handle real swapchain lifetimes and changing Present threads.** The PCSX2 log records a Present thread change at call 35. Do not make a permanent single-thread assumption from the first Present. Its wrapper probe remains inconclusive even with positive user/CUDA evidence; private object offsets alone should not be advertised as conclusive presentation detection.
4. **Keep mod/provider ownership distinct.** DD2 loads the mod from `reframework/plugins`, while graphics-provider modules are under `_storage_`; multiple files named `version.dll` have different roles. Its unresolved NGX provider and hook conflicts support exact module/path ownership checks and duplicate-engine diagnostics. They do not justify adding the combined DLSS-G/MFG machinery to a normal Smooth Motion backend.
5. **Do not interpret a Vulkan-labelled build as a Vulkan test.** The DD2 log's live device observations are D3D12. Vulkan export-hook installation, without matching calls and output evidence, establishes no Vulkan interpolation support.
6. **Preserve uncertainty around crashes.** No supplied log has an exception trace. DD2 reports one transient DLSS-G GetState failure (`result=39`) followed by success; do not assign it a guessed error name or treat it as a fatal exception. Its writer explicitly warns that process exit may lose the queued tail.

## Screenshot context

- `1e046b61-0fb7-4b53-b659-3ed3f921f94f.png`: positive PCSX2 report, RTX 3090/595.79, matching stability (4) excerpts.
- `4ead555f-1c89-41da-b5fe-f06c22e243f9.png` and `8fb605ca-caab-4e82-ba43-f537ea86bebf.png`: game-folder/archive listings include `new.asi`, `dxgi.dll`, `uninstall.bat`, current and legacy logs, plus several mod directories. This demonstrates coexistence of files, not which modules were loaded in any specific session or which caused a crash.
- `07f0be1a-6491-4a30-8b91-0a74af898201.png`: community installation advice to use the executable directory and enable the profile setting. It is not a test result.
- `2e9b0305-f68e-47a6-82f6-0f016854448c.png` and `fa26d632-bfe1-459e-94fa-32abc602144a.png`: request for DX11/DX12/Vulkan testers with a DLL and debug configuration; no reported result in the visible excerpt.

## Input identities

| File | SHA-256 |
|---|---|
| `sm86_stability (4).log` | `425cbcf44d682f8436983f026f899516c82bceb3a4ff96cc7fdc53e2a1786094` |
| `sm86_stability (5).log` | `961e12bcecaf664d0af2fa234b88d4ae7d0942e7e84491ddcdb65de3eaebe157` |
| `sm86_stability (6).log` | `c0a4378648578cfc6c37658bffe18c9e433a8a0269d295c8dcf4b0592e1f1890` |
| `sm86_stability (7).log` | `44f5b88ca1f99904ca2045ddf51dfd8dca35f2e86438bd4687419922dc30fc9e` |
| `DD2_20260912_002652_321_PID1784.log` | `672d2d21458ff7df9145be2a3c619639ccc6c52b7d3b8bbf5e1fd046bcb80e93` |
| `nvsmooth30(1).log` | `0c3e3aedf64610d6ed7a0ee5a216bd40f0ed10c2c456ef1cea0deb56fbd578d7` |
