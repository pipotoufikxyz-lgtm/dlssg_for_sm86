# Haydee 2: repeated Steam overlay fault and import-provider exposure

## New runtime evidence

All embedded sessions identify their backend as **2.8-normal**. The user's launch labels and the collection-time files are separate evidence:

| Report suffix | User's launch label | Collection-time snapshot |
| --- | --- | --- |
| `001141-7376` | ASI + version.dll ASI loader | `version.dll` matches released 2.8 standalone: 992,768 bytes, SHA-256 `d807037caac7a2a47a3c8a6a8c2573f0226f9d54771027987c13d42178bdd83f`; `new.asi` absent/inaccessible |
| `001321-35088` | Standalone version.dll | `version.dll` matches Ultimate ASI Loader: 1,198,304 bytes, SHA-256 `031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf`; `new.asi` matches released 2.8 native ASI: 986,624 bytes, SHA-256 `36dd40e72c6cb3f341dd305b83d4e01f4234149ba8b485b365de4fa753d5671f` |

The user's labels describe the launches; the snapshots describe files present later. These snapshots do not prove which route loaded any specific historical PID and do not establish a mistaken installation. The table below therefore does not assign routes to PIDs. The collector's “2.8.1 CPU layout validation” describes its own validator, not the loaded backend. Neither report includes an initializer exception trace.

| PID | Session / Windows event UTC | Evidence |
| --- | --- | --- |
| 44220 (`0xacbc`) | 2026-09-23 00:10:57 / 00:10:58.825 | 2.8 session; initialization preparation completes; WER reports access violation `c0000005` in `gameoverlayrenderer64.dll+0xd4b07` |
| 34440 (`0x8688`) | 2026-09-23 00:12:41 / 00:12:41.885 | 2.8 session; same initialization boundary and same overlay fault offset |
| 51848 | 2026-09-22 23:46:35; last status about 15 seconds later | `NVP_Init_D3D` returns AL1, ready byte 1; 19 successful model loads, 1090 CUDA activity calls, 965 intercepted application Presents, zero reported CUDA errors |

The same overlay offset also matches the earlier 2.8 sessions PID 3560, 47812 and 50180 by their WER PID/timestamps. PID 51848 establishes that the profile and driver can initialize and execute CUDA work in this environment. It does not establish generated-frame presentation, a stable full game session, or which overlay state differed between launches.

No Steam overlay binary exists in the workspace or any of 14 inspected local ZIP central directories. The reports omit its content hash/version and memory/stack dump. Consequently the instruction at Steam RVA `0xd4b07` cannot be disassembled or named reliably here; no replacement specimen was downloaded.

## Concrete source-level collision surface

Released 2.8 `import_hooks.hpp::refresh()` enumerates every loaded module. `module()` excludes its owner, modules beneath the Windows directory, and selected modules identified by SmoothMotion/NvPresent/ASI-loader exports. It has no filename/provider exclusion for Steam's overlay. The observed path `C:\Program Files (x86)\Steam\gameoverlayrenderer64.dll` is outside the Windows directory.

If that provider imports a matching resolved API, the scanner can rewrite its slots for graphics creation, `GetProcAddress`, and `LoadLibrary*`, just as it rewrites game modules. `onGetProcAddress` returns a Smooth Motion wrapper whenever a resolved address matches the original graphics API. It does not distinguish a game's request from a graphics-hook provider's request. `ensureRuntime()` is then called synchronously on intercepted creation calls before the original API is forwarded.

This creates two concrete, source-supported ways to mix provider initialization:

- A graphics provider resolves an API for its own hook machinery but receives Smooth Motion's wrapper as the target. Its private hook initialization can consequently target a wrapper rather than the system entry point it requested.
- A provider's private device/factory setup becomes the first call that initializes NvPresent. NvPresent in turn calls `CreateDXGIFactory2` and installs internal factory detours before that provider's original setup call has completed.

The reports do **not** identify actual Steam import patches or the initiating caller. These are established reachable behaviors of our scanner, with a plausible connection to the repeated overlay fault, not a recovered Steam stack trace or proof that Steam alone is faulty. An aggregate count such as 26/39 import patches is insufficient to identify the provider.

## Earlier own-module crashes are a separate failure

The older report records map exactly to prior **2.7** sessions in `nvsmooth30(1).log`:

| PID | Event UTC | Fault |
| --- | --- | --- |
| 49684 (`0xc214`) | 2026-09-22 22:49:37.087 | `VERSION.dll+0x4a0d6` |
| 37768 (`0x9388`) | 2026-09-22 22:50:24.174 | `new.asi+0x48f66` |

Both 2.7 sessions rejected the NvPresent fingerprint before loading/initializing it. In the pinned released 2.7 binaries, both fault RVAs contain `test qword ptr [rcx], rcx` in an identical stack-probe loop which subtracts `0x1000` and touches each page. This is consistent with exhaustion/corruption of the calling stack; the caller is unknown without a dump. These records cannot be used as evidence that the present 2.8 overlay crash occurred inside our module, nor as evidence of a CUDA/interpolation fault.

## Justified changes and validation

Exclude only the exact Steam overlay basenames `gameoverlayrenderer64.dll` and `gameoverlayrenderer.dll` from import rewriting before any writes, using case-insensitive basename matching with path-separator handling. This evidence does not justify a broader graphics-provider blocklist. Keep game/engine imports eligible so late renderer discovery still works. Steam overlay private `GetProcAddress` and load slots must remain original; merely blocking runtime initialization after returning wrapper addresses would leave the target-substitution problem present.

Record the first graphics API/caller that initiates NvPresent and bounded provider/module decisions. This makes it possible to distinguish game startup from private provider setup in the next report. Tests should establish exclusion of those exact names and preserved normal game resolution, including alternate capitalization, both path separators, and similarly named modules that must remain eligible. Do not infer an actual game fix from those host tests alone.

This source-level mitigation cannot remove existing third-party inline hooks from shared DXGI implementations. NvPresent can still encounter an already-detoured factory method even when no Steam imports are touched. Changing opaque Steam/NVIDIA instructions, clearing API eligibility flags, swallowing access violations, or claiming full compatibility is not supported by this evidence.
