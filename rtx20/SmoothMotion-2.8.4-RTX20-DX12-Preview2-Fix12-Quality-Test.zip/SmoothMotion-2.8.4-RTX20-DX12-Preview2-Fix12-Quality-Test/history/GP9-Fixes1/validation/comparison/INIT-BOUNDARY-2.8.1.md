# NvPresent initialization boundary — 2.8.1

Version 2.8.1 is a targeted diagnostic update. The available evidence does not establish a repaired crash, a repaired freeze, or working interpolation.

## What the new Haydee 2 log establishes

The supplied `nvsmooth30(2).log` records a 2.8-normal session on 2026-09-22 at 23:35:57 UTC, PID 35592, running Haydee 2's `SteamGame.exe`.

| Observed item | Result |
| --- | --- |
| Actual NvPresent file SHA-256 | `f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e` |
| Actual `.text` SHA-256 | `d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0` |
| Exact driver profile | CPU layout, original sites and complete 41-site transformation oracle verified by 2.8 against the user's installed file |
| Driver loading | LoadLibrary succeeded; seven expected exports enumerated |
| CUDA device | Compute capability 8.6 |
| CUDA interception | Named `cuModuleLoadData` import hook installed |
| Loaded-image preparation | All 41 profile sites applied; 61 changed bytes; 20 non-FP8 modules adapted |
| Configuration | DWORD `+0x6c=1`, DWORD `+0x48=0`, BYTE `+0xe9=1` written before initialization |

The final recorded message is:

> NvPresent preparation complete: profile=exact non-FP8 CUDA interception=active.

The next operation in the production source sets the initialization state and calls `NVP_Init_D3D`. There is no subsequent return/readiness message, observed CUDA module load, or game graphics-creation message. The earlier 2.7 profile rejection is therefore resolved on the actual affected system. This new boundary does not identify an exception, its address, or whether the process crashed, hung, or ended before further logging.

## What the separate reference shows

Static inspection used the locally supplied `bec8...` NvPresent reference, not a local copy of the user's `f36...` binary. The reference initializer takes no meaningful incoming arguments: it establishes its own configuration pointer and API selector before its first internal call. It returns a Boolean in AL. There is no evidence here of a calling-convention defect in the current zero-argument x64 call.

The reference initialization path creates an IDXGIFactory2 through `CreateDXGIFactory2`, checks the HRESULT, and installs embedded Detours hooks for `CreateSwapChain` and `CreateSwapChainForHwnd`. A null target or failed hook transaction can reach an explicit `INT3` at reference RVA `0x37ab9`. When reached from a failed transaction commit, EAX retains that error result. This is a concrete candidate for a pre-CUDA initialization failure; the log does not establish that it happened, nor that the differing `f36...` CPU code has the same instruction at that RVA.

Our own factory-vtable hooks are installed only after native initialization reports ready. They are not active at this first initialization boundary in the inspected code. Other graphics components or hooks have not been ruled out by this log.

The inspected upstream 0.5 launcher invokes the initializer on a fresh remote thread while the game's primary thread remains suspended. Version 2.8 invokes it synchronously from the first intercepted graphics-creation call. This timing/context difference is real, but it does not prove a loader-lock problem, an asynchronous initialization deadlock, or the cause of the reported stop.

## Purpose of 2.8.1 diagnostics

Targeted exception capture is intended to record the exception code, instruction address, module-relative location and register context around initialization, while preserving normal exception handling. In particular, an observed breakpoint and its register result could distinguish the reference hook-failure candidate from access violations, stack faults or other failures. An exception-free stall requires separate progress/thread evidence.

The capture must not skip the driver's breakpoint, guess a private return value, or label continued loading as successful interpolation. Runtime evidence from this diagnostic update is needed before selecting a repair for the newly localized failure.

Source log SHA-256: `4a2a08baadea6c976b8fc03f9ffcd6393a8a8535c2bb2d7244a576c3cd9d0761`.
