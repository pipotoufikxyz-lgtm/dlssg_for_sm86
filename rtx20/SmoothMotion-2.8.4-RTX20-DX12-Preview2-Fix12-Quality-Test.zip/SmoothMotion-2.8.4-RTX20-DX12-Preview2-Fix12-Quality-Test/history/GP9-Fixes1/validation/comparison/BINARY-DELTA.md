# New DLL comparison and failure-stage analysis

Four newly uploaded DLLs were inspected. Two are exact copies of earlier inputs; the two distinct additions change loader/provider discovery rather than supplying a verified universal interpolation fix. The new Haydee 2 log identifies an installed-driver validation refusal in our 2.7 sessions.

## Pinned comparison baseline

Both baseline binaries were extracted from the released `SmoothMotion-2.7-Normal-Candidate.zip` and inspected independently of concurrent builds. The ASI SHA-256 is `e6b822c18c60368a736e8b94cf6ff6b5d2127adb8ced933a03a3523d63ee6e2b`; the standalone DLL SHA-256 is `0b34907a5c5c134f27047dc4d7ebb06a2b2eab3fbaea2a178c4762ff33a0826c`. These are 2.7 artifacts, not the previously audited 2.6 baseline.

| File | Bytes | Exports | Identity |
|---|---:|---:|---|
| RTXMFG-SM-test27-ampere-outputpull (4).dll | 2,852,864 | 1079 | Exact duplicate of test27 (3); combined NGX/MFG/SM |
| version (20).dll | 2,191,360 | 1067 | Exact duplicate of version (19); test4-vulkan |
| version (21).dll | 61,440 | 17 | sm86_stability NvPresent rehost; 17 forwarder exports |
| version (22).dll | 2,228,736 | 1076 | test18-ota-config; combined NGX/MFG/SM |
| version.dll | 983,040 | 19 | Released 2.7 standalone baseline |
| normal.asi | 976,384 | 2 | Released 2.7 ASI baseline |

All are AMD64. Full hashes, entry/TLS/debug metadata, import-library names, selected exported interfaces and kernel-code hash comparisons are recorded in `BINARY-DELTA.json`. No third-party DLL was executed or copied into the product.

## Mechanisms and consequences

### D01 — Two newly attached DLLs are exact duplicates of previously audited inputs.

Evidence: **exact binary comparison**.

- RTXMFG-SM-test27-ampere-outputpull (4).dll equals (3).dll byte-for-byte.
- version (20).dll equals version (19).dll byte-for-byte; embedded identity is test4-vulkan.

There is no new loader, timing or kernel fix in those renamed copies.

### D02 — version (21).dll is a small NvPresent rehost, not the combined NGX/MFG engine.

Evidence: **PE forwarder table and disassembly**.

- 61,440 bytes, 17 named version exports, all export forwarders,zero TLS callbacks, no InitializeASI export.
- All 17 forwarder strings specify C:////Windows////System32////version.dll.
- D3D11, D3D12, DXGI, D3DCOMPILER_47, MSVCP140, VCRUNTIME140 and VCRUNTIME140_1 are static dependencies; D3D12 also has ordinal 101 import.
- Process-attach code at RVA0x4C80 starts worker RVA0x3EB0. No module pin is visible in that startup path.

Forwarder paths and dependencies add loader constraints. Renaming to .asi can invoke DllMain but provides no explicit InitializeASI entry. No actual Windows loading was performed.

### D03 — version (21) driver discovery is timestamp-based and uses fixed Windows paths.

Evidence: **disassembly**.

- RVA0x3132–0x3142 returns an already-loaded NvPresent64 module without ownership verification.
- RVA0x3195–0x32D1 enumerates C:\Windows\System32\DriverStore\FileRepository\nv*.inf_amd64_* and chooses the greatest file LastWriteTime.
- RVA0x32DC–0x32E3 falls back to LoadLibraryA with a bare NvPresent64.dll name.

Latest file time is not proof of the active adapter driver. Existing-module reuse and bare-name fallback can select another provider. Preserve active-driver and ownership validation.

### D04 — version (21) only searches ordinary named CUDA imports.

Evidence: **disassembly correlated with supplied logs**.

- RVA0x16B6 reads the ordinary import directory.
- RVA0x16F0–0x1713 searches nvcuda.dll descriptors.
- RVA0x17BA–0x180D walks OriginalFirstThunk names; if absent, it falls back to FirstThunk and still interprets entries as name RVAs.
- No delay-import or resolved-address fallback appears in this search.
- Multiple sm86_stability logs stop after reporting the CUDA IAT entry missing. These logs lack the DLL hash, so exact file-to-session attribution is unavailable.

This explains the search failure class. A resolved FirstThunk is not a name table; its fallback also deserves bounds protection. Copying this discovery routine would regress the existing bounded/delay-import resolver.

### D05 — version (21) installs Present hooks using a dummy device and ignores page-protection failures before writes.

Evidence: **disassembly**.

- RVA0x2970 creates a 64x64 dummy window/device/swapchain.
- RVA0x2B38 calls VirtualProtect,then RVA0x2B5E writes vtable slot 8 without checking its result.
- RVA0x2B84 calls VirtualProtect,then RVA0x2BB0 writes slot 22 without checking its result.
- The patch helper at RVA0x4A40 reports success after its restore/flush calls without testing their return values.

If the page remains read-only, the direct write can fault. This is a concrete failure condition, not a reproduced crash. One dummy table also cannot establish coverage of every real game or emulator swapchain.

### D06 — version (21) enables a heuristically discovered private wrapper.

Evidence: **disassembly**.

- RVA0x2070 checks a pointer at swapchain+0x18,then scans pointer-sized offsets 0x08 through0x78.
- RVA0x1582–0x159F calls wrapper vtable offsets 0x98 and0xA0 with a true argument after its wrapper checks.

This depends on a private object layout. Module-range/readability checks are not a verified ABI contract for every driver. Keep layout authorization separate from pointer discovery.

### D07 — version (21) rewrites CUDA target metadata; it contains no replacement CUDA kernel payload.

Evidence: **disassembly and bounded CUDA container parse**.

- No bounded-valid CUDA fatbinary payload is embedded.
- RVA0x4BC6 changes a fatbinary entry architecture 89 to 86.
- RVA0x4BF6 overwrites the embedded ELF e_flags field with 0x00560556 after checking ELF magic.
- It does not translate machine instructions in that routine.

This can affect module admission but does not prove ISA or model compatibility. Successful load and successful graph submission remain distinct from interpolated output.

### D08 — version (22), test18-ota-config, has the same embedded CUDA code as test4-vulkan.

Evidence: **exact CUDA payload/code hashes**.

- 62 valid SM86-labelled fatbins, 31 unique fatbin SHA256 values; every unique hash matches version (19)/(20).
- Every per-kernel .text-section hash set matches test4.
- Compared with test27, the shared Kernel_OutputPull code differs and main_kernel is absent.
- It does not match any complete fatbinary payload in the separately audited NvPresent reference.

The new test18 build does not supply test27 output-pull code or a replacement NvPresent neural network. Architecture labels are metadata, not GPU validation.

### D09 — test18 adds NGX OTA discovery, diagnostic exports and different worker waits.

Evidence: **disassembly and export delta**.

- RVA0x18D78 passes CSIDL_COMMON_APPDATA 0x23 to SHGetFolderPathW at 0x18D7F. The worker appends NVIDIA\NGX\models\dlssg and enumerates OTA candidates.
- Nine additional SM diagnostic exports are present,including candidate probe, timeline, kernel compatibility and Present/flip diagnostics.
- The async-log worker changes WaitForSingleObject timeout from 100 ms at test4 RVA0x1E9D7 to INFINITE at test18 RVA0x1E3F7.
- The candidate-discovery worker has a 100 ms Sleep call at test4 RVA0x1A05D; no Sleep call is present in the corresponding test18 worker range. Its diagnostics describe callback-driven profile/config changes.

These are provider-discovery, diagnostic and CPU-wakeup changes. They do not themselves fix native NvPresent driver validation or prove improved GPU output.

### D10 — The newly supplied 2.7 sessions stop at driver validation before graphics/CUDA work.

Evidence: **supplied runtime log**.

- nvsmooth30(1).log contains three 2.7-normal sessions for SteamGame.exe in Haydee 2.
- All reject NvPresent full SHA256 f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e.
- Reported code fingerprint is d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0.
- Last session records statuses approximately 5 and 15 seconds after startup with driver_initialized:false, present_calls:0,CUDA counters 0 and bridge counters 0.

This establishes refusal for the installed driver layout. It does not show a CUDA crash in 2.7, and continued logging does not rule out a later or separate crash.

### D11 — Old and third-party log segments demonstrate different failure stages.

Evidence: **supplied logs and NVIDIA API documentation**.

- The earlier 0.1.0 portion reports CUDA rc 200, which NVIDIA defines as CUDA_ERROR_INVALID_IMAGE.
- sm86_stability (4).log reports 19 successful module loads,graph calls and event synchronizations on a different DriverStore component, but wrapper probes remain NONE.
- sm86_stability (5), (6), (7) stop when ordinary CUDA IAT discovery fails.
- The DD2 log identifies test4-vulkan loaded under reframework/plugins and records NGX hook conflicts against another version.dll under _storage_. It supplies no crash stack or confirmed generated-frame measurement.

Do not merge these into one current-build crash explanation. Identify exact provider, build, process and failure stage before changing runtime admission.

## What to carry into the repair

- Keep the existing bounded CUDA import resolver, real-game creation observation, conditional pointer publication and page-protection restoration checks. The small rehost adds observable failure conditions in these areas.
- Keep the baseline driver identity/ABI checks until the differing installed provider can be examined. Hash recognition alone cannot establish private-layout or GPU instruction compatibility.
- Keep normal Smooth Motion independent of NGX/MFG provider tables. The test18 OTA changes are not a native NvPresent backend upgrade.
- Distinguish module loading, driver initialization, CUDA completion signals, wrapper admission and independently measured interpolated output in diagnostics.
- Preserve a current-build session boundary when collecting evidence. The supplied log appends old 0.1, 2.1 and current 2.7 runs, which otherwise suggest the wrong failure stage.

## Limits and reproducibility

PE imports, exports, forwarders, TLS and unwind function ranges were parsed statically. Capstone disassembly was correlated with import thunks and diagnostic-string references. CUDA containers were bounded before parsing ELF section tables; code sections were compared by SHA-256 without executing them. The machine-code mechanisms above are observed; their crash consequences are conditional unless a supplied log specifically demonstrates that stage. No dump/stack establishes the cause of the user-reported crash. Successful static inspection does not establish Windows loading, game/emulator compatibility or generated-frame quality.

The CUDA result mapping was checked against [NVIDIA CUDA Driver API types](https://docs.nvidia.com/cuda/cuda-driver-api/group__CUDA__TYPES.html). No unrestricted driver compatibility or universal support claim follows from this audit.
