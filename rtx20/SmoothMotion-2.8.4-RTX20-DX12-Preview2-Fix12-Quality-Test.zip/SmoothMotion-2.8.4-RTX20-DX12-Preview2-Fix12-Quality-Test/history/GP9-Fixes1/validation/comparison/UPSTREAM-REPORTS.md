# Upstream reports reviewed for 2.7

Reviewed on 22 September 2026 (UTC). Reports describe other builds and are not test results for this package. This release uses one maintained normal-mode backend with DLL and ASI loading options. No Windows game or NVIDIA GPU execution was available for this review.

## Requested reports

| Report | Reported problem | 2.7 response and remaining evidence gap |
|---|---|---|
| [Pipo issue 12, requested comment](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/issues/12#issuecomment-5784328812) | On RTX 3070, the Manager put files beside `WardogsLauncher-Shipping.exe` instead of `Wardogs/Binaries/Win64/WardogsClient-Win64-Shipping.exe`. The reporter explicitly says manually moving the files beside the client executable also failed. | Executable selection now addresses launcher-versus-renderer placement. This fixes the identified installation defect; it does not establish successful Wardogs interpolation or explain the remaining runtime failure. |
| [Pipo issue 14](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/issues/14) | Request for Chinese; the follow-up specifies the installer. | Simplified Chinese installer and Manager text address the requested interface support. This issue did not report a GPU or interpolation defect. |
| [NVSmooth-30 Nexus posts](https://www.nexusmods.com/site/mods/2344?tab=posts) | Silent Hill: Townfall reportedly showed successful logs without an effect. Euro Truck Simulator reportedly had no effect on a 3080 Ti, including ASI and driver-update attempts. Helldivers 2 reportedly crashed at launch. Other posts ask about OptiScaler coexistence, Vulkan/DXVK, emulators and RTX 20 support. | These are user observations without a reproducible captured workload here. The author suggested an anti-cheat connection for Helldivers 2; the cause was not demonstrated. Positive reports for other games do not resolve these failures. Page 1 was read; the remaining page was not retrieved. |

The Nexus author also described emulator/Vulkan observations as uncertain. Those comments do not establish a tested Vulkan backend. A loaded DLL, a successful profile change or initialization log is insufficient proof that distinct interpolated frames reached the display.

## Other implementation examined

[xikarioz/Smooth-Motion-RTX30](https://github.com/xikarioz/Smooth-Motion-RTX30) was reviewed at commit `892d5ec892fb2a4add84d642766b2cd02917402e`.
Its [compatibility table](https://github.com/xikarioz/Smooth-Motion-RTX30/blob/892d5ec892fb2a4add84d642766b2cd02917402e/COMPATIBILITY.md) identifies RTX 3090 with driver 616.64 as its reference configuration, describes the exact recognized 591.86 NvPresent build as experimental and statically validated, and refuses unknown NvPresent builds. Its [emulator plan](https://github.com/xikarioz/Smooth-Motion-RTX30/blob/892d5ec892fb2a4add84d642766b2cd02917402e/docs/EMULATOR_TEST_PLAN.md) marks emulator testing incomplete. These are upstream claims, not validation reproduced for 2.7.

That public repository contains documentation and release metadata, not application source. Its [EULA](https://github.com/xikarioz/Smooth-Motion-RTX30/blob/892d5ec892fb2a4add84d642766b2cd02917402e/EULA.txt) does not grant permission to repackage its software. The supplied 0.5.0 package was examined as a comparison input; its proprietary application and DLL are not bundled into this release. Binary findings and exact input identities are recorded separately in this comparison directory.

The [Pipo source tree](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/tree/314e4e31337ab96b3a50a2ee69b7648c201b69d7) was reviewed at commit `314e4e31337ab96b3a50a2ee69b7648c201b69d7`. Its [Vulkan integration notes](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/blob/314e4e31337ab96b3a50a2ee69b7648c201b69d7/VULKAN_SUPPORT.md) explicitly distinguish standalone route/proxy components from a working game interception and NGX integration. Copying those components would not itself provide normal Smooth Motion in Vulkan games.

[ItsAdeline/NVSmooth30](https://github.com/ItsAdeline/NVSmooth30) remains a public reference for the original project. References and observations do not imply that the reviewed binaries are interchangeable, or that one implementation can inherit another implementation's compatibility claims.

## Scope of the fixes

2.7 addresses executable placement, Chinese interface support and per-game `uninstall.bat` removal. Native hardening covers copied CUDA image capture across readable regions, proxy ABI handling and duplicate-engine detection. The validation files describe the checks actually performed. These changes are concrete repairs, not a claim that the unresolved game reports have been reproduced and fixed on hardware.

Wardogs, Silent Hill: Townfall, Euro Truck Simulator, Helldivers 2, OptiScaler combinations and emulator renderer configurations still require real runs with the exact GPU, driver, executable, graphics API and loading route recorded. Normal mode only; x3/x4 are outside this release.
