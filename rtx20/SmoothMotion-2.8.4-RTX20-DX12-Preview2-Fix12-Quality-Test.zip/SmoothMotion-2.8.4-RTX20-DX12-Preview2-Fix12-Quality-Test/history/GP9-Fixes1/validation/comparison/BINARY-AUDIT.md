# Supplied Smooth Motion binaries: static audit

This audit identifies the supplied builds, compares their native payloads, and separates usable compatibility ideas from unverified GPU behavior. No uploaded program was executed. The comparison baseline is the released 2.6 normal engine extracted from `SmoothMotion-2.6-Normal-Candidate.zip`, member `SmoothMotion-2.6-Normal/payload/native/normal.asi`. Its SHA-256 was pinned before inspection; no live build output is used as the baseline.

## What was inspected

The outer archive was extracted with normalized-path, traversal, duplicate-name, symlink, total-size and expansion-ratio checks. All 42/42 manifest-covered files match the shipped SHA-256 manifest. PyInstaller CArchive and PYZ containers were parsed as data, without executing their Python application code. Across supplied, baseline, reference, supporting and embedded runtime binaries: 106 PE file instances, 60 distinct hashes; all AMD64.

PE inspection covers imports, delay imports, complete exports/ordinals, sections, entry points, TLS callbacks, version resources, debug records and certificate-directory presence. Selected entry/export instruction streams and bounded CUDA fatbinary/ELF section metadata were inspected. SM architecture labels are metadata; this audit did not validate GPU instruction compatibility. This is not a complete formal proof of every instruction or callback.

| Binary | Bytes | Identified role |
|---|---:|---|
| version (18).dll | 2,849,792 | test108-reload-boundary-probe; combined MFG/SM carrier |
| version (19).dll | 2,191,360 | test4-vulkan; combined MFG/SM carrier |
| RTXMFG-SM-test27-ampere-outputpull (3).dll | 2,852,864 | test27-ampere-outputpull-r40; combined MFG/SM carrier |
| sm86_vk_shim.dll | 161,280 | 0.5.0 experimental Vulkan activator |
| normal.asi | 974,848 | Our 2.6 normal engine; audit baseline |
| nvpresent64.dll | 8,417,512 | NVIDIA reference NvPresent; comparison only |
| dlssg_vulkan_ngx.dll | 15,872 | NGX Vulkan loader/lifecycle helper |
| dlssg_vulkan_proxy.dll | 14,848 | Vulkan route proxy helper |
| dlssg_vulkan_route.dll | 22,528 | Vulkan synchronization/adapter route helper |

The shipping `binary-audit-summary.json` records full hashes, loader metadata, selected exports, import-library names and kernel-code hash comparisons for the relevant engines/helpers. Standard Python, OpenSSL, Tcl/Tk and VC/UCRT runtime dependencies were also inventoried during the audit but are omitted from the compact shipping summary. A certificate-directory entry was recorded but cryptographic signature validity was not tested.

## Findings

### B01 — Uploaded generic names hide distinct experimental builds.

Evidence class: **observed**.

- version (18): PE version resource says test108-reload-boundary-probe 0.108.2.0.
- version (19): embedded build marker says test4-vulkan; no version resource.
- test27: PE version resource says test27-ampere-outputpull-r40 0.27.0.0.

Use exact hashes to track behavior; never infer identity from version.dll name.

### B02 — All three supplied DLLs combine carrier forwarding, NGX/MFG and Smooth Motion interfaces.

Evidence class: **observed**.

- InitializeASI is exported in all three.
- SM_Prepare, SM_ProviderPath, SM_InstallAdmission and RTXMFG_* interfaces are exported.
- Test108/test27 have 1,079 exports; test4 has 1,067.
- All import VERSION.dll while exporting version proxy names. Dispatch slots initially target lazy resolvers, not null.

Do not concatenate or load all engines together. Import/export overlap is not itself proof of a crash.

### B03 — Test108 and test27 carry identical sets of embedded CUDA fatbinary payload hashes.

Evidence class: **observed**.

- Each has 93 bounded-valid SM86-labelled fatbins, 56 unique fatbin hashes.
- Per-kernel CUDA .text hash sets are identical across these two builds.
- Test4 has 62 bounded-valid SM86-labelled fatbins, 31 unique hashes. Thirty unique hashes overlap test27.
- Kernel_OutputPull is the only shared kernel name whose .text hash set differs between test4 and test27. Test27 adds main_kernel.

A higher test label does not establish a newer GPU interpolation implementation. Counts include duplicate copies and are not independent algorithms.

### B04 — NGX kernel replacements are not a verified substitute for this NvPresent backend.

Evidence class: **observed-and-inference**.

- Supplied DLLs contain Kernel_InputMvecProcessing, Kernel_OutputPull, Kernel_DL1Net_Input and related FG names.
- Reference NvPresent contains 37 fatbins, 74 entries (37 SM89 and 37 SM120), with attention/convolution/downscale/warp names.
- Zero complete fatbin hashes overlap between supplied test DLLs and the reference.

Different kernel signatures, model inputs, launch contracts and resource ownership require verification. Merely using an SM86-labelled blob would not establish correctness.

### B05 — The 0.5.0 ZIP has no standalone core NvPresent DLL or native ASI.

Evidence class: **observed**.

- 43 outer ZIP entries, 42 manifest-covered payload files, all 42 SHA256 values match.
- Two PyInstaller Python 3.13 executables; extracted CArchive inventories contain standard runtime DLLs.
- Only outer payload DLL is assets/sm86_vk_shim.dll; no PE exports.

It is a driver-derived runtime manager/launcher plus experimental activator, not a drop-in standalone engine DLL.

### B06 — The 0.5.0 Vulkan route is narrow and tied to exact driver/front-end identities.

Evidence class: **upstream-claim-and-static-observation**.

- Compiled-module strings describe VK_LAYER_NV_present, nvoglv64.dll, exact frontend/backend verification and 41 in-memory patch sites.
- Actual shim imports KERNEL32 only, has no API exports and no embedded CUDA fatbins.
- Embedded entry path and strings refer to SM86_DRIVERSTORE, NvPresent64.dll and NVPRESENT_ENABLE_SMOOTH_MOTION.

Cannot add Vulkan support to arbitrary games by renaming/copying this activator or toggling an INI option. No execution in this audit.

### B07 — Runtime activity is explicitly weaker than generated-frame proof.

Evidence class: **observed**.

- 0.5 compiled runtime text identifies NVP_Swapchain+0x280 as application-present instrumentation sequence.
- Supplied test DLL trace headings distinguish temporal requests/CPU markers from displayed frames.
- Our 2.6 status schema 6 keeps interpolation_verified:false.

Keep loaded, initialized, CUDA activity, successful submission and independently measured interpolation as separate states.

### B08 — Third-party packaging does not authorize copying its engine into our product.

Evidence class: **observed**.

- 0.5 EULA grants no source license and forbids repackaging/bundling without permission.
- No license provenance accompanies the three standalone uploaded test DLLs.
- No opaque binary from these inputs was modified or copied into rework by this audit.

Use independently implemented compatibility fixes. Preserve auditable hashes, not third-party binary payloads, in deliverables.

### B09 — The repository Vulkan helper trio are integration libraries, not game hooks.

Evidence class: **source-and-binary-observed**.

- Audited checkout 314e4e31337ab96b3a50a2ee69b7648c201b69d7; all three binaries match its SHA256SUMS.txt.
- route exposes DlssgVulkan_GetRouteApi; proxy exposes Create/Destroy/Evaluate/Reset/LastError; ngx exposes loader/lifecycle status.
- Source requires host-supplied adapter callbacks and image/flow/depth/device resources.

Adding the helper DLLs beside a game does not create a Smooth Motion Vulkan backend.

## Loader and runtime details

The three supplied test DLLs have broad carrier surfaces, including version, winmm, dxgi and dbghelp-style exports. Their common version names use high ordinals (32819–32827 and 33069–33076); they do not export VerQueryValueIndexA/W. Do not assume one combined carrier reproduces every system DLL ordinal contract. The version forwarding slots begin at assembly lazy resolvers that save register arguments, call a resolver, restore arguments and tail-jump; failed resolution reaches a fail-fast path. Thus the observed self-import overlap is a reason to inspect initialization and verify forwarding, not evidence that these DLLs necessarily crash.

Test108 has two CRT-style TLS callbacks; test4 and test27 have no TLS directory callbacks. All three use CreateThread, VirtualProtect, GetProcAddress and image/module-query APIs and carry provider identity/admission diagnostics. These features are normal for injected compatibility software; their presence is not a malware verdict. Neither unsigned status nor static parsing establishes safety or stability.

The 0.5 shim has no callable exports and depends on its process-attach path and launcher setup. The 0.5 executables carry Python 3.13 and packaged modules for driver compatibility, runtime state, profile handling, capture, Vulkan activation and management. Their application-level compatibility claims were not independently reproduced. Documentation within the archive distinguishes static 591.86 support from reported 616.64 validation; the compatibility table still describes other drivers as untested, so the release notes and compatibility page are not fully synchronized.

## Concrete engineering decisions

- Keep one normal Smooth Motion implementation behind the standalone DLL and ASI routes; do not stack the provided combined MFG runtimes into that engine.
- Preserve a proper System32 forwarding implementation and exact documented carrier contracts, including register-safe forwarding and a loader-safe initialization boundary.
- Detect conflicting native engines using strong export/provider identity rather than the generic InitializeASI export. A second engine may be resident before NvPresent itself is initialized.
- Keep exact provider identity, patch-site validation, transactional rollback and rendering-adapter identity checks. Treat module presence and success-returning counters as separate from measured output.
- Do not reuse the supplied NGX Kernel_OutputPull blob as a NvPresent convolution/attention kernel. The audit found distinct payload families and no verified launch-ABI correspondence.
- Treat Vulkan library adapters and the exact-driver activator as research evidence. A production Vulkan path still requires real integration and GPU validation.
- Install beside the actual rendering executable. The provided Wardogs screenshots show a root launcher and a separate Wardogs/Binaries/Win64/WardogsClient-Win64-Shipping.exe; root placement alone is not evidence of loading in that process.

## Verification limits

No Windows loader run, NVIDIA execution, game/emulator launch, generated-frame measurement or crash reproduction was possible in this static audit. It establishes binary identity and concrete implementation differences; it does not establish universal compatibility, superiority, source completeness or interpolation quality. Existing upstream claims remain attributed claims.

## Audit fingerprints

| Input | SHA-256 |
|---|---|
| version (18).dll | `8d62734f3ff966734c239349f1ae3aaeaf5b9c742124f2929c67c6b5f3f88e31` |
| version (19).dll | `2fa6de23b1b87392b94d666ddce3eeab4034ff1781d9cee49c2b40c64aa2989f` |
| RTXMFG-SM-test27-ampere-outputpull (3).dll | `60b49314a1e16105945840ea0a903f9bf416de48843e2fc1a5f2afd0c82b2255` |
| sm86_vk_shim.dll | `229e59d75a331b07106483dc22fe4452cf30c238d136353ff98331b94395bb95` |
| normal.asi | `5df6064aa7253a98f0dd0b80dcbbbb0bce5ac2f0c6d1ddcb237bb9d0ba46eed5` |
| nvpresent64.dll | `bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68` |
| dlssg_vulkan_ngx.dll | `f34b293a8f77c82f90fcd4ebb95e8fe7758b3c0dc7820bf891c7ced50b40c2c3` |
| dlssg_vulkan_proxy.dll | `f1bf27a0b394829efc23a2dd89ed758a86a2bef3f49ff384b46959ec9ec559ba` |
| dlssg_vulkan_route.dll | `07444794cc62c15feb1c303161035570634b4afe05d84aca123f44e30d680a2b` |
| SmoothMotionSM86-0.5.0-win64.zip | `239913c3e1036e5358056f3e103671e9c3b7803859d047e85a70da67cd8faf84` |
