# GP9 Fixes1 — Trails and KCD II

2026-09-24. Compatibility candidate; game confirmation pending.

Trails in the Sky 2nd Chapter now retains native NVIDIA factory and swapchain
interfaces. The mod's additional observation and legacy bridge hooks are disabled
for sora_2nd.exe, avoiding that mod-owned contribution to a shared graphics hook
chain implicated by the Steam-only stack-overflow report.

Kingdom Come: Deliverance II gets the same native presentation policy and a
marker-checked early startup entry for the reported Win64MasterMasterSteamPGO
layout. NVIDIA initialization can occur before the engine's first intercepted
factory call. This addresses a timing/interposition hypothesis; the report does
not establish its complete activation failure cause.

The GP9 617.14 driver/model compatibility code is retained unchanged. Both DLL
and ASI builds carry the update. The Manager/installer recognize GP9 hashes and
preserve installation ownership when upgrading. Runtime version labels and
native-profile counter semantics are corrected.

No Windows/GPU/game run has been performed here. Production-code regression and
cross-build results are included in validation/. This is not a guarantee for
Helldivers 2 or games not covered by these two profiles.
