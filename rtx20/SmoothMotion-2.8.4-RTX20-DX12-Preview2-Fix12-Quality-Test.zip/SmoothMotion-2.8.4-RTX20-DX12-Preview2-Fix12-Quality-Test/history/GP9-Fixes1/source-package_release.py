#!/usr/bin/env python3
"""Package the normal runtime, exact build evidence, sources and crash symbols."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='SmoothMotion-2.8.2-R3-GP9-Fixes1'
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()

# Exclude obsolete custom-renderer validation scripts and compiler intermediates.
# Every file recorded in the active build reports remains included.
files={str(p.relative_to(ROOT)):p for p in ROOT.glob('*.md')}
for name in ['Open_Manager_Recovery.cmd','Install.exe','SmoothMotion_Manager.exe','Collect_Diagnostics.exe',
             'payload/loader/version.dll',
             'payload/loader/loader-template.ini','payload/native/normal.asi','payload/native/version.dll',
             'source/build_release.py','source/verify_driver_inheritance.py','source/verify_package.py','source/package_release.py',
             'source/test_update.py','source/stage_manual.py','source/normal_policy.hpp',
             'source/release-inputs.json','source/requirements-build.txt']:
    files[name]=ROOT/name
for directory in ['Manual','history','third_party','validation','source/setup','source/manager',
                  'source/diagnostic','source/motion','source/native','source/ui','source/guard']:
    for path in (ROOT/directory).rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts:continue
        if directory.startswith('source/') and path.suffix in ['.exe','.pdb','.lib','.pyc']:continue
        files[path.relative_to(ROOT).as_posix()]=path
for name,source in [('normal','payload/native/normal.pdb'),('version','payload/native/version.pdb'),('Install','Install.pdb'),
                    ('SmoothMotion_Manager','SmoothMotion_Manager.pdb'),('Collect_Diagnostics','source/diagnostic/Collect_Diagnostics.pdb')]:
    files['Symbols/'+name+'.pdb']=ROOT/source
files['Symbols/README.txt']=ROOT/'Symbols/README.txt'

with tempfile.TemporaryDirectory() as temp:
    stage=Path(temp)
    for name,source in sorted(files.items()):
        target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    subprocess.run([sys.executable,str(stage/'source/verify_package.py'),'--root',str(stage)],check=True)
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    sums=''.join(sha(stage/name)+'  '+name+'\n' for name in sorted(files))
    (stage/'SHA256SUMS.txt').write_text(sums)
    names=sorted([*files,'SHA256SUMS.txt'])
    a.output=a.output.resolve();a.output.parent.mkdir(parents=True,exist_ok=True)
    partial=None
    try:
        with tempfile.NamedTemporaryFile(prefix=a.output.name+'.',suffix='.partial',dir=a.output.parent,delete=False) as output:
            partial=Path(output.name)
            with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
                for name in names:z.write(stage/name,PREFIX+'/'+name)
            output.flush();os.fsync(output.fileno())
        with zipfile.ZipFile(partial) as z:
            assert z.testzip() is None,'Archive CRC failure'
            assert set(z.namelist())=={PREFIX+'/'+name for name in names},'Archive file list mismatch'
            for line in z.read(PREFIX+'/SHA256SUMS.txt').decode().splitlines():
                expected,name=line.split('  ',1)
                assert hashlib.sha256(z.read(PREFIX+'/'+name)).hexdigest()==expected,'Archive checksum mismatch: '+name
        os.replace(partial,a.output)
    finally:
        if partial and partial.exists():partial.unlink()
print(str(a.output),a.output.stat().st_size,'bytes; SHA256='+sha(a.output))
