# GP6 — remove Dead Space's dependency on a missed startup callback

Input: diagnostics-20260923-185426-29852.txt. Both GP5 sessions have the
correct ASI, successful renderer import scans, three named graphics bindings,
zero binding failures, and `initialization_status:not_started`. There is no
native initializer exception because the initializer was never entered.
The report does not identify the exact execution path that bypassed the hooks.

GP3–GP5 broadened import interception but did not solve the reported failure.
GP6 changes the activation path for the reported title:

- Require the exact executable filename `Dead Space.exe` and the Frostbite
  DX12 renderer DLL beside it. Other titles retain graphics-call activation.
- Start the same checked NVIDIA backend in the exported `InitializeASI` entry,
  after checking native loader-callout state. This entry is called by the
  bundled official ASI loader; its call sequence was also inspected in the
  exact shipped loader binary.
- Defer an entry under the Windows loader to the existing worker. Do not scan,
  open logs, read game files, configure CUDA, or initialize NVIDIA from that
  unsafe entry. Unknown context also defers. DllMain itself still only starts
  the resident worker and does not initialize the driver.
- For standalone version.dll, activate the selected profile from the worker
  after DllMain has returned. This avoids an indefinite wait for an IAT hook.
- Share the existing nonblocking, single-owner initialization gate with the
  graphics hooks. Reentry/concurrent calls never repeat native initialization
  or wait for a thread which could own the loader lock.
- Record the selected startup policy, entry, attempts, loader deferrals and
  actual graphics/resolver entry counters in status schema 12. Driver errors
  and `interpolation_verified:false` retain their real meaning.
- Recognize exact GP5 DLL/ASI hashes for upgrade/removal. Keep generated
  uninstall.bat, collision protection and other-plugin ownership protections.

The native driver/CUDA patch profile and frame generation algorithm are not
changed. This is a scoped activation repair, not an independently verified
Dead Space or universal-compatibility release. An already-created swapchain,
a native driver failure, or a loader which never calls InitializeASI can still
prevent activation. The existing graphics intercepts remain available.
