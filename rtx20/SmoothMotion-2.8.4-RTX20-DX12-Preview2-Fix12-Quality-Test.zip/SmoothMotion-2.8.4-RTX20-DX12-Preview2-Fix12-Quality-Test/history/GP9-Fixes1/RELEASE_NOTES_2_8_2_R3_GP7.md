# GP7 — apply the confirmed Dead Space startup approach to Genshin

Baseline: GP6, followed by the user's Dead Space confirmation, “It worked.”
The new Genshin log identifies GP1, not a Genshin run of GP6. Its ASI loads
and installs imports, but the native initializer remains unstarted across
three status reports. The screenshot identifies GenshinImpact.exe and its
adjacent GenshinImpact_Data directory.

## Changes

- Select early startup for the exact GenshinImpact.exe filename plus its
  adjacent data directory. A launcher, unrelated executable, missing marker
  or marker with the wrong file type keeps graphics-call activation.
- Use GP6's existing InitializeASI/worker entry, loader-context guard and
  nonblocking initialization gate. Early selection no longer depends on a
  later graphics hook being called in this title.
- Preserve the Dead Space executable/renderer selection and startup behavior.
  Driver validation, CUDA/model transformation, graphics interception and
  frame presentation source are unchanged except for startup dispatch and
  release identification in dxgi_hooks.cpp.
- Identify Genshin's selection as genshin_early in status schema 12. Log the
  actual initializer result; interpolation_verified remains false.
- Rebuild standalone version.dll, new.asi and all three application helpers.
  The official ASI loader bytes are unchanged.
- Recognize exact GP6 hashes for upgrade and removal. Keep prior GP1/GP2 and
  other release recognition, generated uninstall.bat and file ownership rules.

## Evidence and limits

The startup fixture executes the released GP6 controller as a control: it
leaves Genshin on graphics-call activation. The production GP7 entry starts
its simulated backend without a graphics callback, just as it does for Dead
Space. Tests also retain the GP5 stalled-Dead-Space control, loader-context
checks, marker type/path checks, failure, reentry and concurrent entry checks.
There are 212 targeted checks per test configuration.

The supplied log does not identify Genshin's GPU/driver, native initialization
result, graphics API or swapchain format. This change repairs the demonstrated
startup dependency; it is not evidence of a live Genshin interpolation pass.
An already-created swapchain, a native driver failure, or a loader that never
calls InitializeASI can still prevent activation. Standalone worker ordering
continues to depend on process scheduling.
