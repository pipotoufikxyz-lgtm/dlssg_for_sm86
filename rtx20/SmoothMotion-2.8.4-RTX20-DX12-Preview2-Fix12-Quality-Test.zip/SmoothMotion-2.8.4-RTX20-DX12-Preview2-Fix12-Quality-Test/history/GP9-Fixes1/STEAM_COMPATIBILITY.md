# Steam startup

Start games through their normal launcher after installation. The loader
configuration uses DontLoadFromDllMain=1 and explicitly loads new.asi.
The plugin exports InitializeASI and installs creation hooks synchronously when
that entry point is called; a bounded background refresh supports other loaders.
No Steam game, including Haydee 2, was executed in this environment. Deferred
startup and an alternative imported carrier address loading risks, but do not
establish game or interpolation compatibility.
