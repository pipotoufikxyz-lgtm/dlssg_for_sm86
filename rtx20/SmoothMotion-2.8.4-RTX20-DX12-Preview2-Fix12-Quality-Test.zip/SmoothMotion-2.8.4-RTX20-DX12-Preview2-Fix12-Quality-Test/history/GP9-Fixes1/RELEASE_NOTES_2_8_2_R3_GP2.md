# R3 GP2 — protected Game Pass EXE selection

The supplied screenshot is the Windows file-open dialog rejecting Game.exe
before it returns a selection to the Manager. GP1 used GetOpenFileNameW and
then required a readable PE in both Manager inspection and installer planning.
Changing only the dialog would leave the second blocker in place.

All EXE selection entry points now share IFileOpenDialog with FOS_NOVALIDATE,
FOS_FORCEFILESYSTEM and existing-file/path requirements. EXE validation is owned
by the application; the dialog no longer probes whether file data can be opened.
The path is not executed. Restore-file selection retains normal validation.

Normal readable games use the existing PE parser. Only ERROR_ACCESS_DENIED from
opening/mapping the selected EXE enables the new metadata route. Missing files,
sharing violations and corrupt/readable PEs retain their errors. Metadata is
limited to an ordinary MicrosoftGame.config within six ancestor levels, 1 MiB,
32 element levels and 256 executable entries. Windows XmlLite parses the whole
document with DTDs prohibited before any entry is accepted. Exact relative path,
PC family, non-development and x64 architecture must match; omitted architecture
uses Microsoft's documented x64 default. Nested decoys and duplicate matching
entries cannot establish architecture. Linked paths are not accepted.

This metadata declares architecture only. Graphics API and carrier imports stay
unknown; the installation review explicitly says so. The manifest path and full
content hash enter the existing review token, so changing it invalidates apply.
Existing close-game, collision, ownership, uninstall and write checks still run.
No file permissions are changed. GameLaunchHelper is excluded from discovery.

The Manager, Install.exe and Collect_Diagnostics.exe are rebuilt together. GP1
version.dll and normal.asi remain byte-identical, including their GP1 runtime
version labels. GP2 labels the Manager/installer update. Keep one loading route.

74 host regression runs pass, including production picker calls through simulated
COM APIs and protected-target decision tests. Windows dialogs, XmlLite execution
and the actual Game Pass game require confirmation on Windows. This update fixes
the selection/inspection code path; it does not certify displayed interpolation.
