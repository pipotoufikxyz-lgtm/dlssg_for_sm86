# 2.2 normal-mode candidate

Addresses the activation blocker identified in the supplied Haydee 2 log:

- Replaces the two-file hash restriction with bounded validation of reviewed
  CPU code, section/directory layout, unwind/Detours data and exact patch sites.
  Different signing/timestamp metadata can pass. Unknown code is not patched.
- Keeps a read handle open across validation and loading, preventing a file
  replacement between the two operations. File selection, validation rejection,
  loading errors and driver initialization failures have separate diagnostics.
- Bounds normal and delay-import name lookups before CUDA interception.
- Adds CUDA error names/descriptions, per-launch version/UTC/PID markers,
  observed game swapchain descriptors and timed runtime status records.
- Collector 1.2 includes nvsmooth30.log contents, relevant environment overrides
  and a read-only check of the installed driver using the runtime's validator.
- Recognizes the exact 2.1 ASI for upgrades while preserving the working winmm
  loader, existing logs and unrelated configuration.
- Retains version.dll, dinput8.dll, winmm.dll and ASI-only manual kits.
  Normal Smooth Motion only; the multiplier controls remain removed.

24 optimized/sanitized host test runs passed, including malformed driver files,
reference metadata/code mutations, CUDA-container bounds and the 2.1 upgrade.
Windows binaries were cross-compiled; no new Windows/NVIDIA/game execution was
available. Acceptance of the installed f36a... driver and actual interpolated
output remain unverified. See VALIDATION.md for the exact evidence.
