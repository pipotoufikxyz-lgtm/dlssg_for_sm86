# 2.8.2 — Steam Overlay compatibility candidate

The two latest Haydee 2 launches correlate with access violations in
`gameoverlayrenderer64.dll+0xd4b07`. Three earlier 2.8 sessions have the same
fault. Another session initializes successfully, loads 19 CUDA modules and
records 1,090 successful CUDA calls with zero reported CUDA errors. The driver
profile can activate on this setup; intermittent startup remains the problem.

The import scanner previously treated Steam Overlay like a game module. That
allowed its private graphics imports and API resolution to receive our hooks,
and its setup calls could become the trigger for NvPresent initialization.
2.8.2 removes this interaction from both the standalone DLL and ASI:

- Skip exact Steam Overlay module names before scanning or changing imports.
- Preserve real API addresses when a protected or unresolved caller uses our
  GetProcAddress hook, including the API's LastError value.
- Check the immediate caller at graphics and factory creation entries. Calls
  from positively identified protected modules forward without initializing
  NvPresent or registering the created graphics objects.
- Keep game/engine/emulator modules eligible, including games inside Steam's
  directory. No general Steam-directory or third-party-renderer exclusion.
- Record the first initialization caller's module and relative address.
- Recognize released 2.8.1 files during upgrades and owned uninstall removal.

Normal Smooth Motion only; no x3/x4. Standalone version.dll and new.asi use the
same backend. Alternative ASI carriers and generated uninstall.bat are retained.
The exact driver adaptation, small-stack repair, passive exception recorder,
crash-event collection and all prior source/binary audit evidence remain.

The identified interception paths are covered by production-code host tests.
The complete Steam/NVIDIA call stack has not been recovered. Existing inline
hooks inside shared graphics APIs can still interact; immediate-caller
classification cannot identify an overlay deeper behind another trampoline; this package does not
claim that a Windows/GPU retest has passed. No Steam setting is changed, no
driver assertion is suppressed and no proprietary driver DLL is redistributed.

Install one route through the Manager, launch normally, then collect a report
for SteamGame.exe. Check that the runtime session identifies 2.8.2-normal.
The fresh report is needed to establish whether the observed startup fault is
resolved and whether interpolation remains active during play.
