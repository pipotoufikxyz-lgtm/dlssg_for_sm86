# GP9 — 617.14 driver compatibility

The report was that Smooth Motion stopped working after updating to NVIDIA
617.14. The official Windows installer was downloaded without being executed,
and its `Display.Driver/nvpresent64.dll` was extracted for analysis. A frozen
copy of GP8's validation code rejects this actual file. The new code accepts it
only with its exact full-file identity and reviewed transformation result.

## Changes

- Add the 617.14 PE layout and exact input, executable-code and output hashes.
- Select the configuration RVA for the identified profile: `0x7f0cd0` for
  617.14, preserving `0x7d7810` for the earlier exact profiles.
- Add 20 reviewed non-FP8 CUDA object locations and the ELF ABI 8 encoding
  `0x06005904` → `0x06005604`. The fatbin SM tags and the virtual SM field in `.note.nv.cuinfo` also change
  89 → 86. The note version and tool version stay intact.
- Keep the existing gate comparison change 3 → 2, without forcing SETGE.
- Pass the selected profile explicitly into the all-or-rollback transaction.
  The transaction previously assumed the old 41-site layout; it now handles
  both old and new layouts, with per-site failure and rollback tests.
- Preserve original CUDA image pointers after the exact profile is installed.
  The generic legacy CUDA rewriter is unchanged; this adds no broad acceptance
  of arbitrary ABI 8 models.
- Recognize exact GP7/GP8 standalone and ASI hashes for owned upgrades.
- Rebuild both native carriers, Manager, installer and diagnostic collector.
  The collector now evaluates the added driver profile too.

## Evidence

The five inspected CPU blocks governing configuration/readiness/accessors and
capability comparison are byte-identical to the earlier reference. The
99-byte initialization entry differs only in five configuration addresses.

All 74 CUDA objects were inventoried. The 20 selected SM89 objects were decoded
as shipped and with SM86 metadata using NVIDIA nvdisasm. Their 39,352 decoded
instructions remain the same except for nvdisasm's architecture-specific name
for 11 FP32-to-FP16 conversions in two kernels. Those two kernels' instruction
bytes are themselves identical to the earlier reference. Seventeen of the 20
normal kernel text sections match that reference exactly; three have changed
code. No new opcode names appeared relative to the reference. This comparison
is not a proof of complete GPU semantic or scheduling compatibility.

The transformation changes exactly 61 bytes at 61 reviewed sites. All other
file bytes remain identical, including every excluded FP8 and SM120 object.
The transformed whole-file hash is checked independently. The input driver file
is never rewritten on disk by the mod.

No 617.14 Windows/game/GPU run is claimed. Confirmation requires a run on the
affected system; use the new diagnostic collector if a failure remains.
