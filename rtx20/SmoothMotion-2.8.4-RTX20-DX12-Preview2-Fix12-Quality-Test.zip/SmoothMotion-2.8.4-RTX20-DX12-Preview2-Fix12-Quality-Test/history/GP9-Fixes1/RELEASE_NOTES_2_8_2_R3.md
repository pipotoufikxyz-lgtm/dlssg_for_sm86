# 2.8.2 R3 — targeted stability repairs

Baseline: the user-supplied 2.8.2 Overlay Compatibility package. The release
keeps its normal-mode architecture, standalone DLL, ASI alternatives, D3D11
bridge, existing Manager pages and generated per-game uninstall.bat.

## Runtime

Configuration and native initialization share one gate owned by the winning
graphics caller. Background work publishes import hooks and may open logging,
but cannot claim configuration and make the only graphics creation skip setup.
Concurrent or reentrant graphics callers still forward without blocking.

NvPresent-originated calls and saved native originals bypass bridge/context
work through Present, Present1, fullscreen and resize transitions. A scoped
thread-local flag preserves that ownership across nested/tail-forwarded calls.
Native registration does not set or clear context through a wrapper, because
private-data forwarding can otherwise modify an inner swapchain's lifetime.

Registration and bridge detection use the same public-interface evidence.
Saved originals count even after another chain shares an already-hooked table;
Present1 evidence on a separate interface is retained. No private object-field
offsets or guessed COM methods are used for wrapper detection.

The 64-accepted-frame activity rule no longer shuts down a confirmed native
wrapper solely because intercepted CUDA calls disappear. That condition emits
a bounded warning. An unconfirmed bridge still retires when its observation
window expires. Actual execution, copy, wait and Present errors keep their
existing fallback paths. This repairs a false-negative policy, not the cause
of every reported FPS change.

Runtime logs explicitly allow shared access. Raw Present counters are labeled
as intercepted calls in schema 8; interpolation remains independently unverified.

## Manager and installation

The launcher now captures up to the JSON reader's 2 MiB limit, drains buffered
output after helper completion, and signals overflow. It continues consuming
excess output while the child runs so the pipe cannot block merely because
the retained report reached its size limit. Failure messages no longer imply
that an unreadable report proves no installation changes occurred.

Known previous DLL/ASI hashes are included only for migration ownership.
Upgrades preserve foreign/modified files and shared ASI loaders. No previous
experimental binary or separate Version 2 menu entry is shipped.

## Verification

Five x64 binaries cross-compiled; 35 suites passed in optimized and ASan/UBSan
configurations (70 runs). Source/payload hashes, four manual kits, all 17 version
API ordinals and five matching PDBs are checked. See VALIDATION.md.

This build has not run in Windows games or on an NVIDIA GPU. It does not certify
Haydee 2, other games/emulators, displayed interpolation or performance.
