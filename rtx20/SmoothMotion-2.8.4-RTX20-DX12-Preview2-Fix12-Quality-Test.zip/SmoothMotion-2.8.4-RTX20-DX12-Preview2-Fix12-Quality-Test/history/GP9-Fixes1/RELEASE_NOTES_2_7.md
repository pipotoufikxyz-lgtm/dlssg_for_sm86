# 2.7 normal-mode candidate

The standalone `version.dll` and ASI now share one rebuilt backend. Alternative
ASI carriers remain available. The Manager installs the standalone engine alone
for the version route, and the loader plus `new.asi` for ASI routes.

The proxy implements the Windows version API signatures and ordinals, with
absolute System32 forwarding, concurrent resolution, recursion protection and
`LastError` preservation. CUDA image capture now uses bounded exact copies
before parsing and supports input spanning adjacent readable memory regions.
Competing Smooth Motion engines are detected before our private NvPresent
initialization. Runtime diagnostics continue beyond the initial 30 seconds.

The Manager resolves the reported Wardogs launcher to its nested renderer and
requires an explicit choice for ambiguous layouts. Main Manager/installer UI
supports English and Simplified Chinese. Installer-created `uninstall.bat`
removes only unchanged recorded mod files; successful installs no longer leave
an `SM86-backup-*` folder. Legacy restore remains for existing old installations.
Reviewed removal also recognizes complete older installation groups without a
receipt. Choose installed EXE targets their original launcher folder directly.
Shared ASI loaders are retained when other plugins may depend on them; mode
switches that would remove such a loader are blocked.

The supplied test108 and test27 DLLs contain identical embedded CUDA kernel code
hash sets. Their NGX kernels do not match the reference NvPresent payloads.
The 0.5.0 package is a separate driver-derived manager/runtime with an
experimental Vulkan activator. Those opaque payloads were inspected, not merged.
Full findings, identities and report-specific outcomes are included under
`validation/comparison/`.

Validation uses Windows x64 cross-compilation, production-code host regressions,
ASan/UBSan, export/import checks and package identities. Actual Windows/GPU/game
execution remains unavailable. No universal-compatibility or better-output
claim is made. Normal mode only; no x3/x4 controls or new Vulkan/OpenGL backend.
