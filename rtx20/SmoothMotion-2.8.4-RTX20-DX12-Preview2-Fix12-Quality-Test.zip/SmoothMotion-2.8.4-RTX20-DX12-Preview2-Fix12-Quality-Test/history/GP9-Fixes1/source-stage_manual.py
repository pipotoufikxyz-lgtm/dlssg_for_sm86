"""Build mutually exclusive normal Smooth Motion carrier kits."""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
for name,carrier in [('Version','version'),('Dinput8','dinput8'),('Winmm','winmm'),('ASI_Only',None)]:
 kit=root/'Manual'/name
 if kit.exists():shutil.rmtree(kit)
 kit.mkdir(parents=True)
 if name=='Version':
  shutil.copy2(root/'payload/native/version.dll',kit/'version.dll')
 else:
  shutil.copy2(root/'payload/native/normal.asi',kit/'new.asi')
 if carrier and name!='Version':
  shutil.copy2(root/'payload/loader/version.dll',kit/(carrier+'.dll'))
  shutil.copy2(root/'payload/loader/loader-template.ini',kit/(carrier+'.ini'))
 expected={'version.dll'} if name=='Version' else ({'new.asi',carrier+'.dll',carrier+'.ini'} if carrier else {'new.asi'})
 assert {p.name for p in kit.iterdir()}==expected,'Unexpected file in manual kit: '+name
(root/'Manual/README.md').write_text('''# Choose one loading route

For a clean installation, copy the contents of exactly one kit beside the actual x64 game executable.

| Kit | Loading route |
| --- | --- |
| Version | standalone version.dll; the normal backend is inside this DLL |
| Dinput8 | dinput8.dll + dinput8.ini loads new.asi |
| Winmm | winmm.dll + winmm.ini loads new.asi |
| ASI_Only | new.asi for an existing compatible ASI loader |

Both the standalone DLL and ASI are built from the same normal NVIDIA Smooth Motion backend.
There is no multiplier setting and no custom interpolation shader in this runtime.
Do not combine the kits or overwrite unrelated mod files. The standalone
version.dll must not be combined with new.asi or renamed to dinput8.dll.
For dinput8, use the actual Dinput8 kit with its matching new.asi. Use the Manager for upgrades and
for an installation with a generated uninstall.bat. Files copied manually do
not establish an installer ownership record; the Manager can review/adopt
matching current files before creating the uninstaller.

The game must actually import or load the selected carrier. If there is no
nvsmooth30.log, use the Manager's import evidence to select an alternative.
An existing ASI loader must load new.asi early enough to intercept graphics
creation. Loading after device/swapchain creation is not supported reliably.

Runtime requirements and unverified behavior are described in ../README.md
and ../VALIDATION.md. These kits are not certified working in Haydee 2.
''')
print('Four normal-mode kits staged.')
