# 2.1 normal-mode candidate

Removed the multiplier button/menu and all install-time multiplier selections.
Replaced the active custom renderer with the rebuilt normal NVIDIA compatibility
backend. Preserved version.dll, dinput8.dll, winmm.dll, and standalone ASI loading.

Hardened graphics creation interception, CUDA metadata bounds/flags, driver
layout selection, per-chain lifetime, adapter identity, resource sharing,
completion waits, and failure diagnostics. Old 2.0 installs are recognized and
backed up; their owned motion.ini is removed during the transaction.

This release is not certified working in Haydee 2 or any other game. It cannot
support every graphics API/game/GPU. See VALIDATION.md for completed checks and
the missing runtime evidence. NVIDIA's private interpolation model was not
rewritten; its SM86 execution remains experimental.
