#!/usr/bin/env python3
import argparse,pathlib,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--zig',required=True);p.add_argument('--nvp-reference',type=pathlib.Path);driver=p.add_mutually_exclusive_group(required=True);driver.add_argument('--nvp-61714',type=pathlib.Path);driver.add_argument('--baseline-package',type=pathlib.Path,help='Reuse only the unchanged GP9 driver audit; the input archive hash and all driver sources must match');p.add_argument('--reuse-native',action='store_true',help='Reuse the already built runtime and symbols; source and artifact identities are verified at the end');a=p.parse_args();zig=str(pathlib.Path(a.zig).resolve())
def run(*args):subprocess.run([sys.executable,*map(str,args)],cwd=root,check=True)
if a.reuse_native:
 for name in ['normal','version']:
  destination=root/'payload/native'/f'{name}.pdb'
  if not destination.exists():shutil.copy2(root/'Symbols'/f'{name}.pdb',destination)
else:run('source/native/build.py','--zig',zig)
run('source/diagnostic/build.py','--zig',zig)
shutil.copy2(root/'source/diagnostic/Collect_Diagnostics.exe',root/'Collect_Diagnostics.exe')
run('source/setup/build.py','--zig',zig,'--package-root',root)
run('source/manager/build.py','--zig',zig,'--package-root',root)
run('source/test_update.py',*(['--nvp-61714',a.nvp_61714.resolve()] if a.nvp_61714 else []),*(['--nvp-reference',a.nvp_reference.resolve()] if a.nvp_reference else []))
if a.baseline_package:run('source/verify_driver_inheritance.py','--baseline-package',a.baseline_package.resolve())
run('source/native/tools/verify_symbols.py','--root',root)
run('source/stage_manual.py')
run('source/verify_package.py','--root',root)
