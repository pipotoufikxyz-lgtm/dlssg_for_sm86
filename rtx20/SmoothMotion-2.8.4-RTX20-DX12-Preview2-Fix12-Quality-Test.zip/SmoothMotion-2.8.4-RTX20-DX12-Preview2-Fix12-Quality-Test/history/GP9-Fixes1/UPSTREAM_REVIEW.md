# Upstream review — 22 September 2026

## Findings that affect the rework

Haydee 2 should be investigated as a **Direct3D 11** game. Do not confuse it with Haydee 1's OpenGL renderer. The game's Steam discussion [Framerate cap?](https://steamcommunity.com/app/1444650/discussions/0/2966145784730515409/) has a directly indexed reply stating, “Yes, D3D11. It is stated in the system requirements section.” The full discussion was behind Steam's content-preference page in this environment, so the speaker's identity was not verified. This establishes a useful API lead, but the game executable's imports and runtime log remain the authoritative evidence for the user's installed build.

Both supplied projects rely on proprietary NVIDIA runtimes for their NVIDIA frame-generation features. Neither public tree provides a replacement for NVIDIA's motion-vector/optical-flow model or a complete independent Smooth Motion interpolation implementation. A renamed DLL, successful load, or private-hook presence is not proof that generated frames reach the display.

## ItsAdeline/NVSmooth30

Reviewed commit: `21fa43521c2753ffd5c8e9d2092cfc79f9c6c456`.

- [Repository and README](https://github.com/ItsAdeline/NVSmooth30)
- [Pinned NVIDIA compatibility code](https://github.com/ItsAdeline/NVSmooth30/blob/21fa43521c2753ffd5c8e9d2092cfc79f9c6c456/src/nvpresent.cpp)
- [Pinned D3D11 bridge](https://github.com/ItsAdeline/NVSmooth30/blob/21fa43521c2753ffd5c8e9d2092cfc79f9c6c456/src/d3d11_bridge.cpp)
- [Pinned DXGI hooks](https://github.com/ItsAdeline/NVSmooth30/blob/21fa43521c2753ffd5c8e9d2092cfc79f9c6c456/src/dxgi_hooks.cpp)
- [Pinned CUDA metadata rewrite](https://github.com/ItsAdeline/NVSmooth30/blob/21fa43521c2753ffd5c8e9d2092cfc79f9c6c456/src/fatbin.cpp)

The MIT-licensed source is explicitly an alpha compatibility experiment. It locates an installed `NvPresent64.dll`, intercepts CUDA module loading, changes SM89 cubin metadata to SM86, patches private architecture/configuration gates, and calls `NVP_Init_D3D`. The D3D11 bridge copies finished game images through a shared texture to a D3D12 shadow swapchain. NVIDIA's runtime still performs any actual NVIDIA frame synthesis. There is no native 3x/4x frame-count implementation in this tree.

Useful ideas are source availability, real Windows version-export forwarding, conservative failure paths, structured logging, and an explicit D3D11 presentation bridge. They do **not** make this implementation safe to copy unchanged:

| Area | Source observation | Consequence |
|---|---|---|
| Hook dispatch | `dxgi_hooks.cpp` retains one global original `Present` and `Present1` for all patched vtables. | Distinct swapchain wrappers/overlays can need different originals. |
| Lifetime | The primary swapchain is a raw pointer, selected once, with no destruction or replacement handling. | Recreated windows/swapchains can lose interception or retain stale identity. |
| Reentrancy | Presentation dispatch has no recursion-depth guard; an internal-creation flag only affects hook installation. | Other hooks and bridge presentation require careful recursion handling. |
| Same-window bridge | A new flip-model shadow swapchain uses the game's existing HWND. | A game that already owns a flip-model swapchain can reject the second chain. |
| GPU selection | D3D12 creation tries the default adapter first and logs, but does not reject, a mismatch with the D3D11 adapter LUID. | Hybrid and multi-GPU systems can fail sharing or use the wrong GPU. |
| Resource sharing | The fallback obtains a legacy `GetSharedHandle` and passes it to D3D12 `OpenSharedHandle`. | Legacy shared handles are not NT handles; this is not a dependable D3D11/D3D12 interop fallback. |
| MSAA | The shared texture is forced to one sample, while presentation always uses `CopyResource`. | A multisampled source needs a resolve path or explicit rejection. |
| GPU failure | Fence wait uses `INFINITE`; queue `Signal` return value is ignored. | GPU removal or a failed signal can hang the game. |
| Private ABI | Vtable slots 19 and 20 are called as `void(void*, bool)` after checking only address ownership/readability. | Being inside the NVIDIA module does not establish method identity or signature on another runtime build. |
| Active status | `wrapper_active()` accepts a chained NVIDIA trampoline as active, and the OSD latches active status. | Hook presence can be reported as working Smooth Motion without evidence of generated display frames. |
| CUDA rewrite | Architecture identifiers and ELF flags are changed; machine instructions are not translated. | It only works when the particular shipped kernels are actually compatible with the target GPU. |

Microsoft's API documentation supports the two concrete resource constraints above: [only one flip-model swapchain per HWND](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_2/nf-dxgi1_2-idxgifactory2-createswapchainforhwnd), [legacy GetSharedHandle does not return an NT handle](https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgiresource-getsharedhandle), and [D3D12 OpenSharedHandle takes an NT handle](https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12device-opensharedhandle).

The repository's `tools/validate_project.py` checks source strings, export names, and expected private signatures. It does not run a game, validate the Direct3D bridge, execute CUDA kernels, inspect generated image quality, or measure displayed frames. Passing that script is not runtime validation.

## pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version

Reviewed commit: `314e4e31337ab96b3a50a2ee69b7648c201b69d7`.

- [Repository](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version)
- [Release history](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/releases)
- [Pinned Vulkan status document](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/blob/314e4e31337ab96b3a50a2ee69b7648c201b69d7/VULKAN_SUPPORT.md)

The checked-out source contains Vulkan route/proxy/loader components and renderer scaffolding. It does not contain the Smooth Motion binary's implementation. Its status document explicitly explains that the existing binary proxies do not automatically load its Vulkan route, that the host must supply the NGX adapter and actual game-resource interception, and that export discovery alone does not perform NGX evaluation. This is more specific than the broad README/release claim of Vulkan support. These components cannot be represented as a working universal game-injection backend.

Its DLSS-G MFG releases are separate from its Smooth Motion releases. A DLSS-G multiplier patch is not evidence of an available NvPresent Smooth Motion 3x/4x setting or implementation.

Relevant first-hand issue reports:

- [Issue 4](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/issues/4): an RTX 3080 user reports several Steam-launched games crashing while some DRM-free executables run directly with Smooth Motion; the same report describes greater UI artifacts. These are user observations, not a confirmed shared root cause.
- [Issue 11](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/issues/11): an RTX 3080 Ti user reports Version 2 working in Ace Combat 7 and failing in God of War, Okami HD, and Final Fantasy X. This directly argues against assuming cross-game compatibility.
- [Issue 8](https://github.com/pipotoufikxyz-lgtm/dlssg_for_sm86-MFG-version/issues/8): the installer labels Ghost Recon Wildlands as “Other APIs” and refuses installation. Installer API detection is therefore distinct from runtime compatibility.

## What can and cannot be concluded

The upstream evidence supports redesigning loading, API interception, swapchain lifetime, diagnostics, and frame-synthesis integration. It does not identify the user's exact Haydee 2 crash without a crash dump or runtime log. It also does not establish that changing a loader name alone will enable frame generation.

An independent image-based interpolation backend can implement its own 2x/3x/4x output scheduling, but that is a distinct backend and must be named accurately. Its generated images, scene-cut behavior, occlusion artifacts, presentation timing, and resource handling still need executable tests. It must not be called a verified native NVIDIA MFG unlock.

Static checks and compilation establish limited, useful facts. A claim that Haydee 2 or all other games work requires representative Windows execution, the actual GPU/driver, successful motion/interpolation output, and measured presentation behavior. No such in-game result was obtained during this upstream review.
