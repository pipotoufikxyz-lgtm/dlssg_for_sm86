# Native normal-mode backend

The active runtime is payload/native/normal.asi. The Manager installs it as
new.asi. It is built from source/native and uses the installed NVIDIA driver
component for motion estimation and frame interpolation.

This package does not contain the source of NVIDIA's optical-flow/motion-vector
model, generated-frame synthesis, or private scheduler. Those components have
not been rewritten or proven correct on SM86. Modifying an architecture field
in a CUDA image is not an implementation of those algorithms.

source/motion retains only shared import parsing and legacy ownership helpers.
The old independent renderer and its test binaries are absent from this package.
The build_release.py entry point builds the native normal-mode runtime.
