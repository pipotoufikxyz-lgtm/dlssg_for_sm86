# 2.6 normal-mode candidate

Improves discovery of graphics modules loaded by launchers and emulator
frontends after a delay, and handles later DXGI interface registration.

- Keeps the discovery worker active after 30 seconds. The loader notification
  callback only increments an atomic counter; imports are scanned by the worker.
  Periodic fallback remains available if notification registration fails.
- Scans the active delay-import table as well as ordinary imports, validating
  both before applying changes. Does not execute unresolved delay thunks or edit
  bound/unload copies.
- Extends previously tracked factory and swapchain tables with later methods.
  Hook groups preflight all slots; partial failures roll back new writes while
  retaining earlier hooks and exact original pointers. An incomplete group
  cannot start a bridge, and a failed extension retires an existing bridge.
- Raises tracking limits to 64 factory and 256 swapchain tables. Additional
  untracked tables are left untouched if those limits are reached.
- Pins the ASI before its worker thread starts. Resource-only LoadLibraryEx
  calls do not trigger a synchronous import scan. Failed snapshots are retried.
- Adds discovery counters to status schema 6 and the exact shipped 2.5 ASI to
  Manager/installer upgrade identities.

Normal mode remains the only option. The same ASI is included in the version.dll,
dinput8.dll, winmm.dll and existing-ASI-loader kits. Upgrade through the Manager
using the loading route that already works for the game or emulator.

20 production-code host suites run in optimized and ASan/UBSan configurations
(40 runs). The Windows x64 DLL and helpers are cross-compiled and checked against
their source and payload identities. This does not constitute Windows, emulator,
GPU or displayed-frame validation.

No Vulkan, OpenGL, DX9 or 32-bit backend was added. Existing DX11 bridge limits
still apply. Intercepting a late-loaded renderer does not retrofit an already
created swapchain. See COMPATIBILITY.md and VALIDATION.md for the precise scope.
