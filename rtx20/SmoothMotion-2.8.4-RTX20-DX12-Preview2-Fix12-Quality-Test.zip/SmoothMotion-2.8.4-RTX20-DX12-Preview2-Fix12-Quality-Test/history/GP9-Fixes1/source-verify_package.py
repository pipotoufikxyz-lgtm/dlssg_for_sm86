#!/usr/bin/env python3
"""Verify normal-mode payload, helpers, source provenance and manual kits."""
import argparse,hashlib,json,pathlib,struct,sys
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);a=p.parse_args();root=a.root.resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
legacy_inputs=json.loads((root/'source/release-inputs.json').read_text())
retired={'payload/standalone/version.dll','payload/asi/new.asi'}
for name,digest in legacy_inputs.items():
 assert len(digest)==64 and all(c in '0123456789abcdef' for c in digest)
 if name not in retired or (root/name).exists():assert sha(root/name)==digest,name
checks.append('Pinned legacy ownership identities and official ASI loader are unchanged; retired engines are not required')
for rel,binary in [('native','payload/native/normal.asi'),('setup','Install.exe'),('manager','SmoothMotion_Manager.exe'),('diagnostic','Collect_Diagnostics.exe')]:
 src=root/'source'/rel;report=json.loads((src/'build-report.json').read_text());assert sha(root/binary)==report['sha256'],binary
 for name,digest in report['source_sha256'].items():assert sha(src/name)==digest,f'Stale source: {rel}/{name}'
 assert not report['native_windows_executed']
checks.append('All rebuilt binaries match their recorded source and SHA256 identities')
symbols=json.loads((root/'validation/runtime-review-2.8.2-r3-gp9-fixes1-normal.json').read_text())
assert symbols['status']=='PASS' and len(symbols['symbol_pairs'])==5
assert {r['binary'] for r in symbols['symbol_pairs']}=={'payload/native/normal.asi','payload/native/version.dll','Install.exe','SmoothMotion_Manager.exe','Collect_Diagnostics.exe'}
for entry in symbols['symbol_pairs']:
 assert entry['matches'] and sha(root/entry['binary'])==entry['sha256']
 symbol=root/entry['pdb']
 if not symbol.exists():symbol=root/'Symbols'/pathlib.Path(entry['pdb']).name
 assert sha(symbol)==entry['pdb_sha256'],str(symbol)
checks.append('Five exact binary/PDB GUID and age matches; staged crash symbols match those validated files')
native=json.loads((root/'source/native/build-report.json').read_text())
assert native['version']=='2.8.2-r3-gp9-fixes1-normal'
for name,artifact in native['artifacts'].items():assert sha(root/'payload/native'/name)==artifact['sha256'],name
manager=json.loads((root/'source/manager/build-report.json').read_text())
for name,file in [('installer','Install.exe'),('collector','Collect_Diagnostics.exe')]:assert manager['helpers'][name]==sha(root/file)
setup=json.loads((root/'source/setup/build-report.json').read_text())
for name,file in [('loader','loader/version.dll'),('ini','loader/loader-template.ini'),('motion','native/normal.asi'),('native_proxy','native/version.dll')]:assert setup['payload_sha256'][name]==sha(root/'payload'/file)
for name,file in [('standalone','payload/standalone/version.dll'),('asi','payload/asi/new.asi')]:assert setup['payload_sha256'][name]==legacy_inputs[file]
checks.append('Manager pins the correct helpers; installer pins the unified normal-mode standalone DLL and ASI')
portable=json.loads((root/'validation/portable-normal.json').read_text());assert portable['result']=='PASS' and portable['suite_count']==43 and len(portable['results'])==86
assert all(x['result']=='PASS' for x in portable['results']) and not portable['native_windows_executed'] and not portable['GPU_tested']
for name,digest in portable['source_sha256'].items():assert sha(root/name)==digest,f'Stale portable test: {name}'
assert (root/'source/native/include/nvs30/import_slots.hpp').read_bytes()==(root/'source/motion/import_slots.hpp').read_bytes()
if portable['driver61714_sha256'] is None:
 sys.path.insert(0,str(root/'source'))
 from verify_driver_inheritance import validate_report
 validate_report(root)
 checks.append('617.14 specimen evidence inherited from hash-pinned GP9; all driver/model sources unchanged; specimen not rerun in this build')
else:assert portable['driver61714_sha256']=='1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f' 
checks.append('86 optimized/sanitized host runs pass; initialization, native ownership, bridge activity and Manager helper code match recorded inputs')
for file in ['Install.exe','SmoothMotion_Manager.exe','Collect_Diagnostics.exe','payload/native/normal.asi','payload/native/version.dll','payload/loader/version.dll']:
 b=(root/file).read_bytes();assert b[:2]==b'MZ';off=struct.unpack_from('<I',b,60)[0]
 assert b[off:off+4]==b'PE\0\0' and struct.unpack_from('<H',b,off+4)[0]==0x8664,file
sys.path.insert(0,str(root/'source/native/tools'))
from inspect_nvp import PE
def named_imports(image):
 rva,size=struct.unpack_from('<II',image.data,image.optional+112+8)
 offset=image.rva_to_offset(rva);names=[]
 for i in range(0,size,20):
  fields=struct.unpack_from('<IIIII',image.data,offset+i)
  if not any(fields):break
  thunk=image.rva_to_offset(fields[0] or fields[4])
  while True:
   entry=struct.unpack_from('<Q',image.data,thunk)[0];thunk+=8
   if not entry:break
   if entry&(1<<63):continue
   start=image.rva_to_offset(entry)+2
   names.append(image.data[start:image.data.index(0,start)].decode('ascii'))
 return names
for filename in ['SmoothMotion_Manager.exe','Install.exe','Collect_Diagnostics.exe']:
 helper_names=named_imports(PE(root/filename))
 assert 'GetOpenFileNameW' not in helper_names,filename
 assert 'CoCreateInstance' in helper_names,filename
 if filename!='Collect_Diagnostics.exe':assert 'CreateXmlReader' in helper_names,filename
checks.append('All three helpers use the COM picker without legacy GetOpenFileNameW; Manager and installer link the Xbox metadata reader')
pe=PE(root/'payload/native/normal.asi');exports=pe.exports();assert {'InitializeASI','SmoothMotionGetStatus'}<=exports.keys()
imports=[];rva,size=struct.unpack_from('<II',pe.data,pe.optional+112+8);off=pe.rva_to_offset(rva)
for i in range(0,size,20):
 fields=struct.unpack_from('<IIIII',pe.data,off+i)
 if not any(fields):break
 n=pe.rva_to_offset(fields[3]);imports.append(pe.data[n:pe.data.index(0,n)].decode('ascii').lower())
assert not any(any(s in name for s in ['vcruntime','msvcp','libgcc','libstdc','libc++']) for name in imports)
checks.append('Windows x64 PE headers; ASI initialization/status exports; no external MSVC/MinGW C++ runtime DLL')
proxy=PE(root/'payload/native/version.dll');proxy_exports=proxy.exports()
for image in [pe,proxy]:
 assert 'LoadPackagedLibrary' in named_imports(image)
 assert '2.8.2-r3-gp9-fixes1-normal'.encode() in image.data
checks.append('Both runtime carriers contain the Fixes1 identity and resolve the real Windows LoadPackagedLibrary API')
audit=json.loads((root/'validation/driver-61714-gp9.json').read_text())
assert audit['input_sha256']=='1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f' and audit['profile_tested']
assert audit['changed_bytes']==61 and audit['patch_sites']==61 and audit['retargeted_kernels']==20
assert audit['GPU_tested'] is False
assert '2.8.2-r3-gp9-fixes1'.encode('utf-16-le') in (root/'SmoothMotion_Manager.exe').read_bytes()
checks.append('Fixes1 Manager and both native carriers retain the reviewed 617.14 driver profile')
version_names=['GetFileVersionInfoA','GetFileVersionInfoByHandle','GetFileVersionInfoExA','GetFileVersionInfoExW',
 'GetFileVersionInfoSizeA','GetFileVersionInfoSizeExA','GetFileVersionInfoSizeExW','GetFileVersionInfoSizeW','GetFileVersionInfoW',
 'VerFindFileA','VerFindFileW','VerInstallFileA','VerInstallFileW','VerLanguageNameA','VerLanguageNameW','VerQueryValueA','VerQueryValueW']
assert set(proxy_exports)==set(version_names)|{'InitializeASI','SmoothMotionGetStatus'}
er,_=struct.unpack_from('<II',proxy.data,proxy.optional+112);eo=proxy.rva_to_offset(er)
base,count,names,functions,names_rva,ordinals=struct.unpack_from('<IIIIII',proxy.data,eo+16)
actual_ordinals={}
for i in range(names):
 nr=struct.unpack_from('<I',proxy.data,proxy.rva_to_offset(names_rva)+4*i)[0];no=proxy.rva_to_offset(nr)
 name=proxy.data[no:proxy.data.index(0,no)].decode('ascii')
 actual_ordinals[name]=base+struct.unpack_from('<H',proxy.data,proxy.rva_to_offset(ordinals)+2*i)[0]
assert all(actual_ordinals[name]==i+1 for i,name in enumerate(version_names))
proxy_imports=[];ir,size=struct.unpack_from('<II',proxy.data,proxy.optional+112+8);io=proxy.rva_to_offset(ir)
for i in range(0,size,20):
 fields=struct.unpack_from('<IIIII',proxy.data,io+i)
 if not any(fields):break
 no=proxy.rva_to_offset(fields[3]);proxy_imports.append(proxy.data[no:proxy.data.index(0,no)].decode('ascii').lower())
assert 'version.dll' not in proxy_imports
assert not any(any(s in name for s in ['vcruntime','msvcp','libgcc','libstdc','libc++']) for name in proxy_imports)
checks.append('Standalone version.dll has all 17 version APIs at Windows ordinals plus backend exports; no self-import or external C++ runtime')
ini=(root/'payload/loader/loader-template.ini').read_text()
for value in ['DontLoadFromDllMain=1','LoadExtraPlugins=new.asi','LoadFromScriptsOnly=1','LoadRecursively=0','DisableCrashDumps=1']:assert value in ini
for name,carrier in [('Version','version'),('Dinput8','dinput8'),('Winmm','winmm'),('ASI_Only',None)]:
 folder=root/'Manual'/name
 if name=='Version':
  assert sha(folder/'version.dll')==sha(root/'payload/native/version.dll')
  assert not (folder/'new.asi').exists() and not (folder/'version.ini').exists()
 else:assert sha(folder/'new.asi')==sha(root/'payload/native/normal.asi')
 assert not (folder/'SM86/motion.ini').exists()
 if carrier and name!='Version':
  assert sha(folder/(carrier+'.dll'))==sha(root/'payload/loader/version.dll')
  assert sha(folder/(carrier+'.ini'))==sha(root/'payload/loader/loader-template.ini')
checks.append('Four mutually exclusive manual kits: standalone version.dll or identical ASI bytes with alternate loading routes')
ui=(root/'source/manager/manager.cpp').read_text()
for value in ['x3','x4','frameGenerationMenu','frameLabel','id>=560','DLSS 5 Swapper','Automatic driver setup','Enable driver setting','Driver_Settings.exe','Version 2','SM-only','Smooth Motion flow']:assert value not in ui,value
assert 'NVIDIA Smooth Motion' in ui
checks.append('Multiplier controls and retired driver actions are absent from the Manager')
report={'release':'2.8.2-r3-gp9-fixes1','result':'PASS','checks':checks,'native_exports':list(exports),'native_imports':imports,'standalone_exports':actual_ordinals,'standalone_imports':proxy_imports,'native_windows_executed':False,'GPU_tested':False,'game_compatibility_verified':False,'sha256':sha(root/'payload/native/normal.asi'),'standalone_sha256':sha(root/'payload/native/version.dll')}
(root/'validation/package-normal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
