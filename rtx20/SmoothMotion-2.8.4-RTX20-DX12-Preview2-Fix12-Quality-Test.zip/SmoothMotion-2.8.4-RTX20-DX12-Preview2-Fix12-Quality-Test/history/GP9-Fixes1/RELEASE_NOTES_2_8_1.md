# 2.8.1 initializer diagnostic update

The new Haydee 2 log confirms the 2.8 exact driver transformation succeeds.
Execution then stops at NVP_Init_D3D, without an initializer return or a CUDA
module-load record. The log does not contain the exception site.

This update adds a narrowly scoped passive exception trace with exception code,
address, NvPresent RVA and registers including RAX. It also records backend path,
first graphics API, thread, eligibility flags and initializer elapsed time. The
diagnostics collector includes nvsmooth30-init-exception.log. Exact 2.8 DLL/ASI
identities remain recognized for upgrade and uninstall.

Reference disassembly identifies a possible deliberate breakpoint on failed
DXGI hook setup; it is not confirmed as the user's failure. The trace always
continues Windows exception search, does not change the fault context, and
cannot guarantee a record for fail-fast, hangs or severe stack exhaustion.
First-chance exceptions can be handled later and are labelled accordingly.

This is a diagnostic update, not a newly verified Haydee 2 crash repair.
The model/profile, initialization thread and interpolation behavior remain as
in 2.8. Normal-only controls, ASI/alternate loaders and uninstall.bat remain.

The updated collector can also read Windows Application Error records from the
last 24 hours for the exact selected game executable. It reads at most 200
recent matching-provider events and only reports events whose full AppPath
matches the selected EXE. This may identify the existing 2.8 crash without
launching again. Records from other games are not included. Windows may not
have recorded a crash, and hangs require different evidence.
