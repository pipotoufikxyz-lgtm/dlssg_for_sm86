# 2.4 normal-mode candidate

- Uses D3D11 fence events for copy completion when supported. The query
  fallback remains available and yields CPU time after a short polling phase.
- Shares a tested bounded fence-wait policy between D3D11 and D3D12. Checks
  actual fence completion after wakes, rejects device-removal sentinels,
  handles completion racing timeout, and preserves the real API error.
  A timeout is no longer mislabeled as DXGI_ERROR_DEVICE_HUNG.
- Separates failed-initialization descriptors from disposable bridge resources.
  Same-size resets no longer bypass failure suppression. Actual window,
  dimension, format, buffer, sampling or presentation-descriptor changes can
  receive a fresh attempt. Permanent runtime failures remain permanent per chain.
- Tracks exact CUDA import originals in an allocation-free journal. Rollback
  preserves delay-loader thunks and retains records when restoring fails.
  Pre-driver setup exceptions roll back recorded patches; CUDA container
  inspection exceptions forward the original image once without crossing the
  driver C ABI as a C++ exception.
- Recognizes the exact delivered 2.3 ASI for Manager detection and upgrades.
  Normal mode, .asi and alternate carriers remain; multiplier controls remain
  absent. The same winmm loading route used in the supplied Haydee 2 log can
  be retained when upgrading through the Manager.

34 optimized/sanitized host test runs cover 17 suites, including the production
wait/retry/rollback policies. Windows x64 binaries cross-compile and the package
verifies its payload, source and helper identities. Hardware execution,
performance and displayed interpolation remain unverified. See VALIDATION.md.
