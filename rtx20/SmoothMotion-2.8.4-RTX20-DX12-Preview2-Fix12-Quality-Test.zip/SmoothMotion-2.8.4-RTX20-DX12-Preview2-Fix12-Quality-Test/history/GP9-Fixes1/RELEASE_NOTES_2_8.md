# 2.8 normal-mode candidate

This release addresses the concrete driver rejection in the new Haydee 2 log
and a reproduced small-stack failure in the production import scanner.

- Adds the exact installed 616.64 NvPresent profile, with full source/output
  identities and a 41-site/61-byte checked transform before initialization.
- Adapts only the 20 non-FP8 CUDA modules in that profile. Keeps the 17 FP8
  modules, SETGE instruction and original CUDA image pointers intact.
- Corrects the runtime configuration sequence and 8-bit init return ABI.
- Moves large path buffers off game thread stacks and replaces blocking once
  gates with nonblocking first-owner initialization.
- Separates failed module discovery from failed CUDA execution so a recovered
  model selection does not inherit a permanently fatal module-load counter.
- Recognizes released 2.7 standalone/ASI files and uninstall receipts during
  upgrades; Manager detection now recognizes current and prior native proxies.
- Preserves the single standalone DLL, matching ASI, alternative loaders,
  normal-only controls, Chinese UI and generated uninstall.bat.

Every new DLL and all supplied logs were examined. Two new DLL uploads are
byte-identical to earlier inputs; the two other builds have separate loader,
discovery and kernel implementations described in validation/comparison.
No opaque third-party application code or CUDA payload was copied into this
release. Driver offsets/byte contracts were independently implemented as
compatibility facts against the supplied reference and reported exact profile.

Host regressions and Windows cross-compilation are recorded in validation/.
The reported user crash lacks an exception stack; no local Windows/NVIDIA GPU
run proves end-to-end Haydee 2 interpolation yet. The specific activation gate
and reproduced stack defect are repaired in code, with their test boundaries
recorded rather than a universal compatibility claim.
