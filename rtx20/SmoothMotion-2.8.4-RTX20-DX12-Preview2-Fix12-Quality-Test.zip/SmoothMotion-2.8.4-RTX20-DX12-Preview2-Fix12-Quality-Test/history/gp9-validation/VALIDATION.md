# GP9 validation

The package is verified using production-code host tests, static inspection of
the actual official 617.14 component, Windows x64 cross-compilation, matching
PDB checks and packaged-file hashes. These do not substitute for a game run on
an NVIDIA GPU.

## Driver regression

`source/native/driver61714_test.cpp` includes frozen GP8 validation headers and
proves rejection of the actual 617.14 DLL by the old policy and acceptance by
the new exact profile. It verifies the 61-byte output against a whole-file hash,
rejects mutated inputs and already-transformed input, and checks that the
616.64 and 617.14 runtime addresses cannot be interchanged. Ninety-two actual
binary mutation cases accompany synthetic wrong-profile and offset cases.

The prior reference tests continue to verify the original 41-site/61-byte
transformation and metadata-normalized legacy acceptance. Startup, presentation,
rollback, protected Game Pass EXE and Xbox collection tests remain in the suite.

The required release gate is 42 suites in optimized and ASan/UBSan builds:
84 runs, recorded in `validation/portable-normal.json`. The gate requires the
actual 617.14 input hash and all runs to pass before packaging. The static
review and its paired profile-test results appear in
`validation/driver-61714-gp9.json`.

## Static CUDA/CPU inspection

`source/native/tools/audit_driver61714.py` inventories every CUDA object,
compares the relevant CPU blocks, runs NVIDIA nvdisasm for the 20 normal model
objects and checks preservation of the 54 excluded objects. It verifies 61
changed bytes and the whole-file transformation identity. Two decoder spelling
aliases are explicitly recorded; no GPU execution is inferred from them.

NVIDIA nvdisasm 12.8.90 reports that it switches to standard ELF output and
disables dataflow analysis for these ABI 8 objects. Its return codes, warnings
and decoded instruction counts are recorded. No dataflow analysis or full ISA
translation is claimed.

Official installer SHA-256:
`63d3da5ed52547bf3fd86204bb9ea1455947b24e2aa2519f359126f9a6efe13f`

Unmodified 617.14 NvPresent64.dll SHA-256:
`1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f`

Transformed in-memory candidate SHA-256:
`bcdc615f9492070c7a9ba31addd910373766ad293e777abdcbface28ad493c49`

## Build and archive checks

`validation/runtime-review-2.8.2-r3-gp9-normal.json` matches all five source-built
PE files to their PDB GUIDs and ages. `validation/package-normal.json` checks
artifact/source hashes, helper identities, exports, manual installation kits,
x64 architecture and required test evidence. Packaging validates ZIP CRCs and
every archived entry in SHA256SUMS.txt.

## Remaining runtime validation

The reported failure came without a 617.14 game log. The older supplied logs
are not treated as evidence from the updated driver. This release has not been
run under Windows or on a GPU here; displayed interpolation, frame pacing,
resource behavior and per-game compatibility remain unverified on 617.14.
The earlier user confirmation that GP6 worked in Dead Space is preserved as
baseline history, not reused as a GP9 hardware test result.
