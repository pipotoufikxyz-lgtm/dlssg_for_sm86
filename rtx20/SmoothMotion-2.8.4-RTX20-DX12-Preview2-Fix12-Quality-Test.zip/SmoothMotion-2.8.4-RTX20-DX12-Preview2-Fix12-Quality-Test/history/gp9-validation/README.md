# Smooth Motion 2.8.2 R3 GP9 — NVIDIA 617.14 compatibility

GP9 adds a separate, exact-binary compatibility profile for the Smooth Motion
component extracted from NVIDIA's official 617.14 Windows driver installer.
Both the standalone `version.dll` and `new.asi` use this updated normal 2× backend.

The previous package rejects this DLL because NVIDIA changed its PE layout,
moved the configuration block, and changed the SM89 CUDA objects from ELF ABI 7
to ABI 8. GP9 selects the new configuration address and retargets the 20 normal,
non-FP8 model objects using the new flag encoding and the virtual SM value in `.note.nv.cuinfo`. The reviewed model conversion
changes 61 bytes; it preserves CUDA instruction bytes, all 17 FP8 objects, all
37 SM120 objects, and the capability SETGE instruction. Runtime configuration
writes and import hooks remain separate from this 61-byte model conversion.

This fixes the compatibility rejection reproduced against the actual 617.14
component. Windows game execution and displayed interpolation on 617.14 still
need confirmation on the affected PC. No 617.14 runtime log was attached to the
report that prompted this release, so another failure on that PC is still possible.

## Install or upgrade

1. Close the game and extract the complete package into a separate folder.
2. Run `SmoothMotion_Manager.exe`, select the actual game executable or game
   folder, and install using the same loader choice that already worked for it.
   Existing GP7/GP8 files are recognized by their exact hashes and upgraded.
3. If you enabled Smooth Motion in NVIDIA Profile Inspector, reapply the game's
   setting after the driver update. The upstream setup instructions call for
   this after driver updates. Then launch the game through its usual launcher.

The standalone option installs `version.dll`. The ASI option installs `new.asi`
and the selected loader, such as `dinput8.dll`, `winmm.dll`, or `dxgi.dll`.
Use one installation route. The installer creates an owned `uninstall.bat`
beside the selected game executable and preserves unrelated files.

For manual installation, use exactly one folder under `Manual`: `Version`,
`Dinput8`, `Winmm`, or `ASI_Only`. `ASI_Only` requires an existing compatible ASI
loader. The Manager handles installation ownership and upgrades automatically.

## Driver evidence and diagnostics

The added 617.14 input is `NvPresent64.dll`, 8,525,544 bytes, SHA-256:

`1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f`

The runtime loads the installed driver component. It does not install or bundle
an NVIDIA driver DLL. A different driver binary is not accepted just because its
version string says 617.14. The prior 616.64 and reviewed reference paths remain.

On the matching 617.14 build, `nvsmooth30.log` should identify the exact 617.14
profile and the 61-site ELF ABI 8 transform. These messages establish that the
component was recognized and prepared; they do not measure generated display
frames. Initialization, CUDA failures and presentation status are recorded
separately. If it still fails, run `Collect_Diagnostics.exe` after that launch
and send the resulting report. It includes the installed driver identity and
the game log needed to locate the remaining failure.

## Existing fixes retained

The Dead Space startup fix, Genshin startup selection, Game Pass protected-EXE
picker and Xbox folder discovery from GP8 are retained. The Manager supports
English and Simplified Chinese. There are no x3/x4 or Version 2 controls.

This remains a Windows x64 normal Smooth Motion compatibility experiment for
the reviewed SM86/RTX 30 path, with native D3D12 and a restricted legacy D3D11
bridge. It does not add x86, RTX 20/SM75, Vulkan, OpenGL, DX9, or universal game
compatibility. General D3D11 flip-model/HDR bridge support remains unimplemented.

## Validation and source

See `VALIDATION.md`, `RELEASE_NOTES_2_8_2_R3_GP9.md`, and
`validation/driver-61714-gp9.json` for the binary evidence and test scope.
Source, matching crash symbols and third-party notices are included. Previous
release notes describe historical work; this README describes GP9.

Build with the supplied Zig build scripts, the earlier reference DLL, and the
unmodified 617.14 DLL as test inputs. Neither NVIDIA input belongs in the release
package. `source/native/tools/audit_driver61714.py` reproduces the static audit
with NVIDIA `nvdisasm`; `source/build_release.py --help` lists build arguments.

Upstream activation instructions:
https://github.com/ItsAdeline/NVSmooth30
