# Validation — 2.8.2 R3

The release is rebuilt from the attached 2.8.2 Overlay Compatibility archive,
SHA256 `da1882b83ab81e12cf6533e6e8caeca4fa9c12917d444dc323849a4e659a651d`.
Windows game execution and NVIDIA GPU output were not available. These are
source, cross-compilation, host regression and package-integrity results.

## Completed checks

- Five Windows x64 binaries: standalone version.dll, normal.asi, Manager,
  installer and diagnostics collector. DLL exports/ordinals, import tables,
  static C++ runtime linkage and exact build-source hashes are checked.
- 35 suites run twice: optimized and AddressSanitizer/UndefinedBehaviorSanitizer,
  for 70 successful host runs. See validation/portable-normal.json.
- Startup regression reproduces the old two-gate worker/configuration race;
  checks the sole graphics call, callback ordering, concurrent publication,
  reentry, rejection and exception retry through production gate helpers.
- Native presentation regression invokes callable originals for Present,
  Present1, SetFullscreenState, ResizeBuffers and ResizeBuffers1; checks exact
  parameters, return values, nested forwarding, scope unwinding, thread
  isolation and prevention of private-context mutation for native entries.
- Shared-table regression shows the original live-method-only detector losing
  native evidence after hooks replace the entries. The production evidence
  helper retains saved Present or Present1 evidence across separate interfaces.
  Actual Windows QueryInterface discovery is cross-compiled, not executed.
- Bridge regression retains an independently confirmed wrapper through 10,000
  missing-activity observations, while preserving the unconfirmed 64-frame
  deadline, activity recovery, reset, HRESULT propagation and failure fallback.
  This does not prove that the retained wrapper outputs interpolated frames.
- Manager launcher regression reproduces silent truncation of a valid roughly
  300 kB helper report in the attached source. The repaired launcher passes
  complete-report, completed-child backlog, 2 MiB boundary/overflow, handle
  lifetime, inheritance, command/path and error cases using injected Win32 APIs.
- Migration identities for the attached build, 2.8.3, R1, R2 and 3.0 are verified
  against their immutable archives. Upgrade/removal tests cover both routes,
  mixed old backends, modified files and loaders needed by other ASI plugins.
  These are identity/policy tests, not Windows filesystem execution.
- Existing tests retain malformed PE bounds, Steam Overlay exclusions,
  small-stack import dispatch, exact driver profile/output oracle, CUDA image
  parsing, transactional patch rollback, bounded GPU wait policy, installer
  journals, game discovery and English/Chinese localization coverage.
- Five matching binary/PDB CodeView GUID and age pairs are checked. The final
  ZIP validates CRCs and every SHA256SUMS entry after staging package checks.

## Evidence and scope

| File | Evidence |
| --- | --- |
| validation/portable-normal.json | Test outputs, configurations and source hashes |
| validation/launcher-output-baseline-failure.json | Reproduced old Manager truncation |
| validation/migration-identities-r3.json | Prior archive and owned payload hashes |
| validation/package-normal.json | Current binary, source and manual-kit consistency |
| validation/runtime-review-2.8.2-r3-normal.json | Exact binary and crash-symbol matches |
| validation/baseline-diff-r3.json | Changed/new source files relative to the attachment |

The exact NVIDIA model profile, private driver patches and standalone version
API forwarding implementation remain the attached implementation. This update
does not implement new motion-vector, optical-flow or frame-synthesis algorithms.
The live-log sharing change uses documented `_wfsopen` and `_SH_DENYNO`; actual
file sharing with the Windows collector remains a hardware-side check:
https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/fsopen-wfsopen

Raw Present and successful CUDA API counters are diagnostic signals, not
application FPS, GPU completion or proof of displayed generated frames.
`interpolation_verified` remains false. Module-wide activity can belong to a
different swapchain. Third-party hooks and first-load scheduling still affect
coverage; graphics objects created before interception cannot be retrofitted
reliably by these changes.

## Windows verification still needed

1. Install one route using the Manager with the game closed. For an existing
   working ASI installation, retain its carrier. Confirm the actual rendering EXE.
2. Launch and close Haydee 2 repeatedly, including through Steam with its overlay.
   Keep the current log and matching fault events for any failure.
3. Exercise gameplay, menu transitions, resize, alt-tab and new windows; test a
   native DX12 title and a compatible D3D11 bridge separately. Repeat with an
   emulator configured for a supported host API.
4. Compare displayed frame captures and pacing independently of Steam's counter.
   A working initializer or a retained wrapper is insufficient confirmation.
5. Exercise real uninstall.bat, locked files and interrupted installation recovery;
   confirm unrelated/modified mods and shared ASI loaders remain intact.

Historical runtime evidence belongs to earlier builds. It is preserved in
history/VALIDATION_2_8_2_OVERLAY.md and validation/comparison/ and is not a
Windows or GPU test of R3.
