# Validation — GP6 Dead Space startup

Baseline GP5 ZIP SHA256:
`4f83d3f41371c00305b061be0d5ae8be2f4a1a68954184c7ec3c170dc38afdbe`.

## Targeted reproduction

The host fixture uses GP5's exact InitializeASI body as its control. It installs
hooks and starts the worker; 501 import scans without an intercepted graphics
call still leave the driver unstarted. The GP6 test executes the production ASI
entry header and startup controller with a simulated native initializer.
It initializes before the entry returns even when no graphics callback follows.

89 checks cover the startup ordering, native BOOLEAN loader-context probe,
LastError preservation, missing context API, deferral out of loader callouts,
standalone startup, exact host/renderer selection, other Steam/Game Pass games,
failed initialization, repeated entries, reentry and 12 concurrent contenders.
The existing production import-dispatch tests and 64 KiB caller-stack fixture
remain. The host test seams do not execute the Windows loader or NVIDIA driver.

## Release checks

- Five Windows x64 binaries cross-compiled, with matching PDBs.
- 40 suites run in optimized and ASan/UBSan configurations (80 runs).
- Existing driver validation, rollback, CUDA, presentation, bridge, installer,
  protected Xbox executable, upgrade and uninstall regressions remain enabled.
- GP5 migration hashes come from the previous released artifacts and this log.
- Source/payload identities, all 17 version API ordinals, manual kits, package
  CRC and archived SHA256SUMS are checked.

## Evidence

- `validation/dead-space-gp6.json`: report facts and scope of the startup change.
- `validation/portable-normal.json`: per-test output and input hashes.
- `validation/runtime-review-2.8.2-r3-gp6-normal.json`: binary/PDB identity.
- `validation/package-normal.json`: package checks.
- `source/native/startup_bootstrap_test.cpp`: baseline and production-entry test.
- `history/GP5_README.md` and `history/GP5_VALIDATION.md`: prior release text.

## Limits

The latest input establishes that GP5 still does not initialize. It does not
prove exactly which factory/device call bypassed interception. GP6 bypasses
that dependency for the identified title, but no live Dead Space, Windows or
NVIDIA GPU execution occurred here. Driver startup success, stability across
relaunches, displayed interpolation and performance remain unverified.

The ASI path starts synchronously at the loader's plugin entry. Standalone
startup uses a worker, which cannot guarantee it runs before every application
thread. Host regression success must not be described as a gameplay pass.
