# Smooth Motion 2.8.2 R3 GP7 — Genshin startup

GP7 uses the GP6 Dead Space fix that you confirmed worked as its baseline.
It extends early backend startup to `GenshinImpact.exe` with the adjacent
`GenshinImpact_Data` directory shown in the supplied screenshot.

The Genshin log is from GP1: the ASI loads, but all three status entries say
`initialization_status:not_started`, with no CUDA or presentation activity.
GP6's early profile selects only Dead Space, so updating to GP6 alone would
not extend that profile to Genshin. GP7 adds the Genshin selection explicitly.

**Update the reported installation:** close Genshin and the old Manager,
extract this complete package, open `SmoothMotion_Manager.exe`, select
`GenshinImpact.exe`, and update **new.asi + dinput8.dll**. Keep that carrier:
the supplied log already establishes that it loads the ASI. The runtime must
identify itself as `2.8.2-r3-gp7-normal` after the update.

For the selected Genshin profile, `InitializeASI` attempts the same checked
native initialization before returning to the loader. It does not wait for a
later intercepted graphics creation call. Loader-callout or unavailable
context defers the request to the existing worker. Standalone `version.dll`
uses its worker outside DllMain. Dead Space retains its exact executable and
renderer marker, startup ordering and initialization gate.

The log records `Genshin Impact early startup: source=InitializeASI` for a
safe direct ASI entry, or the deferred/standalone worker source when used.
Status records `startup_policy:genshin_early` and the actual native initializer
result. Neither entering initialization nor loading the DLL proves that frame
interpolation is active.

The production startup controller and ASI entry pass 212 host checks,
including Genshin, Dead Space, marker validation, loader-callout deferral,
failed initialization, repeated entry and concurrency. This environment has
not run Genshin or the NVIDIA driver. Genshin gameplay and interpolation
remain unverified; the Dead Space success is the user's report for GP6.

See RELEASE_NOTES_2_8_2_R3_GP7.md and VALIDATION.md for evidence and limits.

## Install

1. Close the older Manager, extract this complete ZIP into a fresh folder, and
   open its `SmoothMotion_Manager.exe` (About identifies 2.8.2-r3-gp7).
2. Use Browse EXE and select the actual game EXE. For this report, select
   `HoYoPlay\games\Genshin Impact game\GenshinImpact.exe` and confirm the
   destination in the installation review.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

For Game Pass, select the actual x64 rendering executable in the installed
content directory, not a launcher or Gaming Services executable. Start the game
through the Xbox app as usual. This build preserves Windows package loading
rules and does not change installation-folder permissions. Storefront alone
does not establish a supported graphics API or a working carrier.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Diagnostics and compatibility

The startup log identifies **2.8.2-r3-gp7**, and runtime status identifies
**2.8.2-r3-gp7-normal**. Status schema 12 labels Present counts as raw intercepted
calls; they can include internal calls and probes, so they are not displayed FPS.
The Steam counter dropping from roughly 500 to 300 does not by itself identify
which path stopped or verify displayed interpolation.

Run `Collect_Diagnostics.exe` for the actual game executable after reproducing
an issue. The collector includes available logs and matching Windows fault
events. The underlying CPU-layout validator is unchanged from 2.8.2, so its
report still labels that specific validation as 2.8.2.

The backend targets x64 Direct3D 12 and a restricted windowed D3D11 legacy
DISCARD, single-sample SDR bridge. Emulator support depends on the selected
host renderer. Vulkan, OpenGL, Direct3D 9, 32-bit and general DX11 flip/HDR
bridging are not implemented here. See COMPATIBILITY.md.

Both runtime carriers and all three application helpers are rebuilt.
40 host suites pass in optimized and ASan/UBSan builds (80 runs). This environment has not executed this release
on Windows or an NVIDIA GPU; Haydee 2 compatibility, repeated launches,
frame pacing and displayed interpolation remain unverified.

Source, crash symbols and validation reports are included. The historical
2.8.2 reports and earlier DLL comparisons remain under history/ and
validation/comparison/. No new third-party binary is merged into the runtime.
