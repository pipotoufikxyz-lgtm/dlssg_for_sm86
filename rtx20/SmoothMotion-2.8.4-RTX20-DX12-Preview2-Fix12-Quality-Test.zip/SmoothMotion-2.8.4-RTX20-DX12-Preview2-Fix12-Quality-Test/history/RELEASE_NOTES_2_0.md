# 2.0 Rework Preview

This release addresses concrete defects in the supplied 1.8.1 package. It does not certify Haydee 2, all games, native Windows execution or displayed FPS.

## Loading

- The active `version.dll` path now uses the pinned Universal ASI Loader plus the rebuilt custom `new.asi`, instead of the opaque standalone native patch with hardcoded system-DLL forwarding.
- ASI installation remains available with imported alternatives including dinput8.dll and winmm.dll. The installer ranks imports from local engine DLLs as well as the EXE.
- Both routes use x2/x3/x4 and default to x2. Old recognised installations are backed up and replaced; unknown files are preserved.
- The runtime supports InitializeASI and deferred automatic startup. Hook initialization avoids waiting on a competing bootstrap while under loader lock.
- Direct D3D11 device/swapchain creation, real-device parent factories and dynamic graphics lookup/loading are observed. The old factory-only assumption missed common game startup paths.

## Rendering

- Fix coordinate mapping for odd-sized colour pyramids and final motion-grid cells.
- Add half-pixel matching refinement, motion-boundary candidate selection and inverse-warp residual checks.
- Use bidirectional inconsistency to reject low-contrast scene cuts the old absolute-error threshold missed.
- Improve independent foreground/background motion and one-sided disocclusion. Keep exact unchanged image regions stable in the synthetic fixtures.
- Retain actual image-generation phases: x3 uses 1/3 and 2/3; x4 uses 1/4, 1/2 and 3/4.

## Stability and evidence

- Serialize page-protection edits and avoid recursively recording an already-hooked vtable method as its own original.
- Reset stale history on bypasses; preserve normal game presentation on unsupported paths.
- Disable game DX12 interpolation. The old path advanced engine-owned swapchain buffers multiple times; its bridge tests did not prove engine scheduling safety. This is an explicit compatibility limit.
- Add a separately loaded production-ASI integration fixture covering both startup methods, direct/factory D3D11 creation, x2/x3/x4, resize, focus, pause and state preservation. It is compiled here but still needs execution on Windows.
- Include executed portable and software-rendered pixel reports, exact binary/source checksums and a recorded execution-environment limitation.

Synthetic pixel tests improved the moving-foreground midpoint from 1.25 times crossfade error to approximately 0.63 times crossfade error. This describes a controlled fixture, not measured game quality or speed. The occlusion contact sheet intentionally shows remaining contour artifacts.

The renderer remains synchronous, image based, SDR-only and limited to D3D11 for active game interpolation. It is not a rewritten NVIDIA driver backend or a universal frame-generation solution. See `VALIDATION.md` before interpreting this preview as a confirmed fix.
