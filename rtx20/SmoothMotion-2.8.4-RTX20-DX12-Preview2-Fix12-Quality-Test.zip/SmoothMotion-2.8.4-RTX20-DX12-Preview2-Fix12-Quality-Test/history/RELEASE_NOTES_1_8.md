# 1.8 — experimental DirectX 12 support

- Added a DX12 path for custom x2/x3/x4 interpolation using the existing optical-flow shaders through D3D11On12.
- Capture the exact presentation queue from DXGI swapchain creation and update it after successful ResizeBuffers1 calls. Unknown or incompatible queues use pass-through.
- Read the current DX12 backbuffer index for each capture and generated frame. Wrapped resources return to PRESENT, release their views and flush before presentation.
- Drain submitted work before resize or queue changes. Timeouts keep resources alive; stale fence events cannot authorize early cleanup.
- Detect DX11/DX12 automatically, accept DX12 executables in the installer and include the active API in per-session diagnostics.
- Recognise the released 1.7 renderer for upgrades, retain its per-game multiplier and preserve recognised configuration.
- Added portable queue/resource regression tests and a compiled native DX12 self-test covering D3D12 readback, interpolation, buffer rotation and queue replacement.

DX12 support is experimental and limited to single-node, single-presentation-queue SDR swapchains. Actual gameplay, displayed FPS and the reported Steam crashes remain unverified. Original compatibility payloads and the official loader are unchanged.
