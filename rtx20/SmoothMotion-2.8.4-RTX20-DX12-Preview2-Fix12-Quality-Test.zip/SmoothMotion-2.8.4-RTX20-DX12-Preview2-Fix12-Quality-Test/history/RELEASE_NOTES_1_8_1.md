# 1.8.1 — startup and resize crash fixes

This hotfix addresses concrete failure paths found while investigating the report that 1.8 opens and then crashes. The exact reported crash has not been reproduced; there was no exception trace or failing executable identified in the report.

## Fixes

- The custom ASI starts through the loader's deferred `InitializeASI` entry point. `DllMain` only records the module and disables thread notifications; it no longer starts the renderer.
- Remove all disposable graphics-device and swapchain startup probes. Observe real game swapchain creation through DXGI factories instead. This leaves DX12 device configuration to the game. Microsoft requires [enabling the debug layer before device creation](https://learn.microsoft.com/en-us/windows/win32/api/d3d12sdklayers/nf-d3d12sdklayers-id3d12debug-enabledebuglayer); pre-creating a device can conflict with that order.
- Restore the game's DX11 context and release the render lock before calling the original DXGI Present. Normal window-thread and same-thread resize callbacks can release our resources and continue. An interrupted interpolation sequence checks its resource generation before using the renderer again. Device-removal results stop further interpolation work.
- Close stale multiplier menus and clear their selection/hit state when discovery replaces the game list. Every multiplier action and menu paint checks the current selection. Native EXE menus locate the game again after their nested message loop returns.
- Contain C++ exceptions at the Manager's window and background-worker boundaries. Failed paints release their resources; background failures reset the busy state.
- Retry failed translucent drawing with an opaque surface. `Open_Manager_Recovery.cmd` explicitly opens the Manager without glass textures or artwork while retaining the theme and installation controls.
- Write per-launch Manager checkpoints and unhandled exception code/address information to `%LOCALAPPDATA%\SM86Manager\startup-<PID>-<ticks>.log`. Windows Error Reporting retains control of fatal exceptions.
- Recognize both shipped 1.7 and 1.8 custom ASI hashes, so reviewing a replacement upgrades the existing installation rather than treating it as an unknown plugin.

## Install the hotfix

1. Extract this complete ZIP into a new folder and open `Install.exe`.
2. For a game that already has custom x2/x3/x4 installed, choose that same game and multiplier, then use **Review replacement** and apply the reviewed changes. Updating the Manager folder alone does not replace the game's `new.asi`.
3. If the Manager still fails while drawing, open `Open_Manager_Recovery.cmd` from the extracted folder. Startup logs are retained automatically.

The original NVIDIA compatibility payloads and the official Ultimate ASI Loader binary retain their pinned original bytes. This is not a confirmed fix for every Steam game or for an unknown crash inside those original payloads.

## Verification

The portable suite runs 12 suites in optimized and AddressSanitizer/UndefinedBehaviorSanitizer configurations (24 results). New regressions cover a library replacement while a menu selection is active, rejected stale indices, a window thread acquiring the render lock during Present forwarding, lock restoration on exceptions, and upgrades from the delivered 1.8 renderer. Windows x64 tools are cross-compiled; source/build identities, exports, imports and archive checksums are verified. The compiled custom DLL contains neither a D3D12CreateDevice probe nor a D3D11CreateDeviceAndSwapChain import.

Native game injection, DirectX execution, Manager rendering and the user's specific crash remain unverified by these portable checks. See `VALIDATION.md` for the exact scope. The unchanged shared-shader pixel report is retained with its source hashes.
