# Validation — R3 GP5 named import update

Baseline GP4 package SHA256:
`5b56dd79d679bc822e6f959f00e154c899fe5a93f26ae56f418ef68b95cc908b`.

## Release checks

- Both runtime carriers and all three helpers cross-compiled for Windows x64.
- 39 host suites in optimized and ASan/UBSan configurations: 78 runs.
- The exact GP4 scanner body, renamed only for the test, misses six named
  graphics wrappers and an unresolved D3D12 delay thunk in the fixture.
  The GP5 production scanner intercepts those same entries.
- All six graphics signatures and six loader/resolver signatures execute
  through production callbacks. Exact forwarding, initialization ordering,
  arguments, outputs, return values and LastError are asserted.
- A simulated delay helper updates its active IAT. The first and subsequent
  calls work through distinct retained bindings; bound/unload copies remain
  unchanged. The Windows delay helper itself is not executed here.
- Dynamic resolution through a simulated overlay resolver preserves that
  resolver and the actual returned graphics function. Distinct System32/local
  targets and cached callbacks do not share mutable destinations.
- Repeated scans, protected callers, missing/ordinal exports, resource-only
  loads, 64 KiB caller stacks and exact lookalike exclusions remain covered.
- Binding publication uses 12 concurrent writers and a concurrent reader.
  Tests cover API separation, capacity exhaustion and immutable destinations.
- PE tests cover normal/delay identity bounds, malformed strings/RVAs,
  inaccessible reads, ordinal imports and 5,000 malformed mutations.
- Existing large-file, Game Pass, installer, upgrade and uninstall tests remain.
  GP4's exact native DLL/ASI identities are included in migration tests.
- Five binary/PDB pairs, source and payload hashes, manual kits, archive CRC
  and archived SHA256SUMS are verified during packaging.

## Evidence

- `validation/dead-space-gp5.json`: input facts and baseline comparison scope.
- `validation/portable-normal.json`: individual tests and source hashes.
- `validation/runtime-review-2.8.2-r3-gp5-normal.json`: exact symbol pairs.
- `validation/package-normal.json`: package integrity checks.
- `source/native/test_reference/gp4_module.hpp`: GP4 comparison scanner.
- `history/GP4_README.md` and `history/GP4_VALIDATION.md`: previous release text.

## Limits

No native Windows, NVIDIA GPU or Dead Space execution occurred. Windows and
COM operations in the host fixture are controlled substitutes. These tests
establish source behavior, not verified game compatibility, image quality,
performance or displayed interpolation.

The latest report identifies the delay import and loaded proxy/RTSS modules,
but not their exact runtime call chain. Their presence alone does not prove
that RTSS caused the failure. GP5 repairs reproduced interception gaps and
adds evidence for the live run; successful Dead Space output remains unverified.
