# Changes in 1.6

- Two selectable builds: the uploaded standalone version.dll and uploaded new.asi, preserved byte-for-byte.
- ASI loader menu with every official v9.7.4 Win64 carrier, automatic import-based selection and file-conflict details. Win32-only choices are clearly unavailable for these payloads.
- The selected new.asi is explicitly loaded from the game folder. Unrelated root ASIs are not automatically enabled. Existing ASIs in scripts/plugins are preserved and identified in review details.
- Reversible switching between known builds and owned loader names. Old bundled bootstrap/menu/guard/backend files are retired by exact known identity, with backups.
- Removed driver controls, backend toggles and DLSS Swapper links. No hidden automatic driver-setting operation remains.
- Six persisted themes and five persisted accent colours.
- Updated read-only diagnostics for all loader names, including both Bink names.
- Source/build/helper hash verification prevents packaging a Manager with the wrong installer.
- Steam compatibility documentation corrected: the reported issue remains unverified, not closed or declared fixed.
