# Smooth Motion 2.8.2 R3 — stability update

Built from the supplied **2.8.2 Overlay Compatibility** package. One normal
Smooth Motion backend is provided as standalone `version.dll` or `new.asi`,
with alternative ASI loader routes. The existing D3D11 bridge remains included.

## Fixes

- Configuration and driver initialization run together on the first eligible
  graphics caller. A background configuration task can no longer make that
  caller skip initialization.
- NVIDIA-owned Present, resize and fullscreen calls forward without touching
  our bridge context, including nested and tail-forwarded calls.
- Native swapchain detection checks saved original functions across the public
  interfaces. Hooks on a shared table no longer hide that native evidence.
- A confirmed NVIDIA wrapper is retained when CUDA interception goes quiet.
  The former 64-frame shutdown could disable that bridge without an actual
  execution failure. Unconfirmed paths still require recent activity, and
  reported execution/device failures retain their original fallback behavior.
- Manager helper reports up to 2 MiB are captured completely, including data
  still buffered when the helper exits. Oversized output produces an explicit
  error instead of parsing a silently truncated report.
- Runtime logs explicitly allow shared access while the game is running.
- Exact earlier release identities are recognized for upgrades and removal;
  modified files and shared ASI loaders keep their existing protection.

The Manager retains its existing installation menu and English/Chinese UI.
There are no multiplier controls, Version 2 entry or SM-only flow in this build.
See RELEASE_NOTES_2_8_2_R3.md for the changes and VALIDATION.md for evidence.

## Install

1. Extract the complete ZIP and open `SmoothMotion_Manager.exe`.
2. Choose the game. Check the executable shown in the installation review.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Diagnostics and compatibility

The startup log identifies **2.8.2-r3**, and runtime status identifies
**2.8.2-r3-normal**. Status schema 8 labels Present counts as raw intercepted
calls; they can include internal calls and probes, so they are not displayed FPS.
The Steam counter dropping from roughly 500 to 300 does not by itself identify
which path stopped or verify displayed interpolation.

Run `Collect_Diagnostics.exe` for the actual game executable after reproducing
an issue. The collector includes available logs and matching Windows fault
events. The underlying CPU-layout validator is unchanged from 2.8.2, so its
report still labels that specific validation as 2.8.2.

The backend targets x64 Direct3D 12 and a restricted windowed D3D11 legacy
DISCARD, single-sample SDR bridge. Emulator support depends on the selected
host renderer. Vulkan, OpenGL, Direct3D 9, 32-bit and general DX11 flip/HDR
bridging are not implemented here. See COMPATIBILITY.md.

All five binaries are rebuilt, and 35 host suites pass in optimized and
ASan/UBSan builds (70 runs). This environment has not executed this release
on Windows or an NVIDIA GPU; Haydee 2 compatibility, repeated launches,
frame pacing and displayed interpolation remain unverified.

Source, crash symbols and validation reports are included. The historical
2.8.2 reports and earlier DLL comparisons remain under history/ and
validation/comparison/. No new third-party binary is merged into the runtime.
