# Validation — 2.8.2 R3 GP1

Built from the attached R3 Stability archive, SHA256
`5842e07cc5b2d5af8b17ae6536c6e70733c9871615b8948b5ea9210123112fba`.
Windows, NVIDIA GPU execution and actual Game Pass games are unavailable here.
These are production-code host tests, Windows cross-builds and integrity checks.

## Targeted regressions

The same callable mapped-PE harness was compiled against the attached R3 import
scanner and origin classifier (verified byte-for-byte against the attachment),
with R3's original 11-hook set, then against GP1's production headers and 12-hook
set. Each isolated case fails on R3 and passes on GP1:

| Case | R3 reproduced failure | GP1 result |
| --- | --- | --- |
| Packaged renderer load | Renderer import remains original when LoadPackagedLibrary returns | IAT/GPA dispatch refreshes before the immediate factory call |
| Changing module snapshot | First ERROR_BAD_LENGTH ends scan | One/two transient failures recover; three attempts bound work |
| Extended Windows path | Protected Windows imports are patched | Exclusion applies to scanner, dynamic lookup and cached graphics entry |

Additional cases cover exact loader arguments and native success/failure/error
results, Unicode names, reserved parameter passthrough, repeated package loads,
resource-only mappings, scan exceptions, reentrant scans, retry exhaustion and
later recovery, nontransient errors and snapshot handle closure. WindowsApps,
XboxGames, ModifiableWindowsApps and WindowsGames renderers stay eligible.
Existing exact Steam Overlay exclusions and the 64 KiB scanner-stack test remain.
The original OS loader and graphics APIs are host seams, not Windows execution.
The baseline fixture is not a reproduction of either reported game's crash.

## Release checks

- 35 suites, optimized and AddressSanitizer/UndefinedBehaviorSanitizer: 70 host
  runs. Existing R3 initialization, native ownership, bridge activity, driver
  transform, rollback, installer and Manager tests remain in the suite.
- Five Windows x64 binaries cross-built. Both native carriers import the real
  LoadPackagedLibrary API and embed the GP1 identity. The standalone proxy retains
  all 17 version APIs at the expected ordinals; no self-import or external C++
  runtime dependency. ASI initialization/status exports remain present.
- Exact R3 and R4 ownership hashes read from their immutable ZIPs. Migration tests
  cover DLL/ASI upgrades and carrier switches while retaining changed files,
  unrelated mods and shared ASI loaders.
- Source-to-build SHA256 manifests, five exact PDB GUID/age matches, four mutually
  exclusive manual kits, staged package checks, ZIP CRC and every SHA256SUMS entry.

| Evidence | File |
| --- | --- |
| Reproduced R3 failures and fixed cases | validation/gamepass-baseline-regressions.json |
| Host runs and source hashes | validation/portable-normal.json |
| Exact prior ownership identities | validation/migration-identities-r3-gp1.json |
| Current binary/source/manual-kit consistency | validation/package-normal.json |
| Exact binary/PDB matches | validation/runtime-review-2.8.2-r3-gp1-normal.json |
| Changes relative to attached R3 | validation/baseline-diff-r3-gp1.json |

## Runtime confirmation still needed

Install one route beside the real rendering EXE, launch through the Xbox app,
and verify Ninja Gaiden Ragebound and Marvel Cosmic Invasion separately. Repeat
launch/close, gameplay, menu transitions, alt-tab and resize; retain Decline's
Drop with Steam overlay as a regression case. Compare displayed output and frame
pacing independently of Steam's counter. Successful DLL loading, raw Present
counts and CUDA submissions are not proof of displayed interpolation.

The restricted x64 DX12/DX11 renderer matrix remains in COMPATIBILITY.md. Graphics
created before hooks are installed, or inside a DLL initializer before its load
call returns, can still escape interception. Windows path normalization does
not resolve all filesystem aliases. No universal Game Pass guarantee follows
from these fixes; actual compatibility with the reported games remains unverified.
`interpolation_verified` remains false until independently verified.

Microsoft API contracts used in this change:
- https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-loadpackagedlibrary
- https://learn.microsoft.com/en-us/windows/win32/api/tlhelp32/nf-tlhelp32-createtoolhelp32snapshot
- https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulefilenamew

Historical R3 documentation is in history/R3_*.md; prior reports are retained as
historical evidence, not runtime results for this build.
