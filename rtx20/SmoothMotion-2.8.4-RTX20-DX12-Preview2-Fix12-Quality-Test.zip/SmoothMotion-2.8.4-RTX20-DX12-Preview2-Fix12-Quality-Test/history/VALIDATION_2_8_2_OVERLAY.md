# Validation — 2.8.2 Steam Overlay compatibility candidate

**Haydee 2 and other games have not been executed with this build. Working
interpolation, output quality, frame pacing, stability, and performance are
not verified. This package is not a guarantee that the game will work.**

## Completed checks

- Native Windows x64 standalone version.dll, ASI, Manager, installer, and diagnostics collector
  cross-compiled successfully. Exports include InitializeASI and
  SmoothMotionGetStatus. No external MSVC/MinGW C++ runtime DLL is required.
- 64 host test runs: 32 suites in optimized and AddressSanitizer/
  UndefinedBehaviorSanitizer configurations. Coverage includes installation
  upgrades and file collisions, imported-carrier selection, malformed PE
  input, game identity, normal-only option policy, and CUDA container parsing.
- The reference-driver regression accepts changed signing data, timestamps,
  PE checksum and unused raw padding, and rejects modified CPU code, unwind
  data, Detours code data, section protections, TLS layout and initialization
  export targets. Malformed PE headers and named import lookups are bounded.
- Upgrade regression covers the exact 2.1 through 2.8.1 ASI hashes with the winmm
  carrier, preserving existing logs/configs and changing only the owned ASI.
  Manager detection and installer ownership share the same identity table.
- Production Present policy exercised with 18 result/probe combinations:
  success, occlusion, backpressure, mode-change status, invalid calls and lost
  devices. Fatal failures retire the bridge before a single original Present;
  the original HRESULT is preserved. Probes/occlusion/busy outcomes get no
  accepted-frame credit. These are injected host callbacks, not real DXGI.
- Eight memory-protection/cache failure combinations exercise the production
  patch transaction. Replacement bytes are rolled back after a failed
  protection restore or cache flush. These are injected host operations;
  actual Windows VirtualProtect and GPU execution are not tested.
- Sixteen production fence-wait cases cover already-completed work, delayed
  completion, stale notifications, one bounded deadline, timeout/completion
  races, device removal and preservation of API errors. These use injected
  clocks/fence/event callbacks; the D3D11.4 event path has not run on Windows.
- The retry-policy regression covers all ten descriptor fields and repeated
  identical failed attempts. The failure record is separate from resources;
  no test claims to execute real ResizeBuffers or fullscreen transitions.
- CUDA pointer-journal tests cover exact normal/delay-import restoration,
  capacity exhaustion without an untracked edit, partial rollback failures,
  repeated install, and preservation of a pointer changed by a later owner.
  Actual NVIDIA imports and concurrent third-party hook changes are not tested.
- Import-table tests now reject the complete scan before any mutation visitor
  when a later descriptor/terminator is invalid or a copied read fails. They
  cover cached page boundaries, failed reads, loader/backend export exclusion,
  long unrelated export names, AMD64 headers, finite work limits, and 5,000
  deterministic malformed-image mutations. Combined normal/delay-import scans,
  delay-only modules, unchanged unload/bound copies, importless images and every
  injected exact-copy failure are covered. Windows ReadProcessMemory itself
  and protected pages in a running game are not executed by these host tests.
- Fourteen graphics-slot patch cases cover failed protection acquisition and
  restoration, exact compare/exchange, idempotence, unreadable slots, and
  intervening pointer owners. The Win32 calls are injected host callbacks.
- Seventy-two hook-group checks cover whole-group preflight, failure at each
  write, preservation of existing base-interface hooks, retry after an extension
  failure, rollback failure and an intervening pointer owner. These use host
  pointers and callbacks; actual COM interface discovery is not executed.
- Twenty-nine discovery-policy checks cover long frontend idle periods, loader
  changes during a scan, notification/fallback intervals, counter wrap, clock
  regression and resource-only LoadLibraryEx flags. They test production policy,
  not a running Windows loader. Notification registration, module pinning and
  incomplete-group bridge retirement were inspected and cross-compiled only.
- All 37 CUDA containers in the supplied reference NvPresent file were parsed
  and rewritten offline under ASan/UBSan. Exactly three architecture bytes per
  container changed; unrelated ELF bits and the SM120 image were preserved.
  This establishes a bounded metadata transformation, not executable SM86 code.
- Standalone proxy forwarding exercises all 17 Windows version functions,
  exact arguments/return values, caller and callee LastError, concurrent first
  resolution, failure retry and recursive-load rejection. These tests compile
  the production wrappers against an injected Windows API; the real Windows
  loader has not been executed. The built DLL's exports, ordinals and imports
  are checked separately.
- CUDA capture tests cover exact reads across adjacent readable regions,
  header changes during capture, truncated/failed reads, allocation bounds and
  address overflow. Native ReadProcessMemory and actual CUDA calls remain
  unexecuted. The transform still changes architecture metadata only.
- The per-game uninstaller tests exact-file ownership, receipt validation,
  modified-file preservation and production recovery policy. Journal tests
  cover interrupted write/rollback prefixes, modified destinations/originals,
  commit-marker validation and cleanup after commit. These use injected file
  identities; actual Win32 filesystem operations have not been executed.
- Manager detection covers the supplied Wardogs launcher/rendering executable
  layout, explicit renderer choices and ambiguity. English/Simplified Chinese
  catalog tests check substitution and preservation of dynamic game paths.
- Both standalone DLL and ASI compile the same backend. The Version kit has
  one standalone DLL; the other three kits contain the same ASI. The Manager has no
  multiplier menu/button. Installer/helper/payload hashes and build inputs
  match. See validation/package-normal.json and portable-normal.json.

Reference NvPresent SHA256:
bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68

This reference uses configuration RVA 0x7d7810; the upstream reference used
0x7f0cd0. The obsolete hardcoded internal CUDA resolver fallback was removed.
The reference's SM89 ELF flags are 0x00590559, not a justification for replacing
all flags with the upstream literal 0x06005604. The new transform preserves
non-architecture bits; it does not validate the kernels' instruction set.

## New 2.8.2 repair and runtime evidence

The two new reports correlate five 2.8 sessions by executable, PID and timestamp
with Windows access violations in Steam Overlay at offset 0xd4b07. Their prior
PID 51848 session initialized successfully, loaded nineteen CUDA modules and
recorded 1,090 CUDA activity calls and 965 Presents over about fifteen seconds,
with zero reported CUDA errors. That session used a native NvPresent wrapper;
zero shadow-bridge submissions is expected and does not imply inactivity.
Displayed intermediate frames and a clean eventual exit remain unverified.

The import-dispatch regression constructs ordinary Steam Overlay modules with
matching graphics/GetProcAddress imports and no special backend exports. The
actual pre-fix scanner rewrites those imports and fails the new assertion.
The revised scanner excludes the exact basenames before mutation while normal
game and engine fixtures remain eligible, including an engine in Steam's own
directory. Similar filenames are not excluded.

Production caller classification and creation dispatch are exercised using
injected Windows module lookup and callable API targets. Protected origins
retain the original API, cannot trigger backend initialization and cannot
register the resulting graphics object. Lookup failure preserves forwarding;
LastError is retained across classification and observation. This validates
the identified hook interaction, not real Steam module execution.

Both carriers retain initializer tracing and add the first initialization
caller's module/RVA. The reference-only NvPresent INT3 hypothesis was not
observed: the new events are access violations in Steam Overlay. Neither a
Steam binary nor an exception stack was supplied, so the exact failing
instruction and complete call chain remain unknown. Shared inline graphics
hooks are not removed or rewritten by this repair.

Released 2.8.1 ownership identities are pinned for upgrades/removal. Modified
files and loaders shared with other ASI plugins remain protected.

See comparison/REPORT-COMPARISON-2.8.2.md and
comparison/OVERLAY-COLLISION-2.8.2.md for source hashes and correlations.
Steam's own documentation confirms that its overlay hooks graphics-device
creation; this is context for the reviewed interaction, not proof of cause:
https://partner.steamgames.com/doc/features/overlay

## New 2.8 regressions

- The prior production import scanner passes on a normal host thread and fails
  with SIGSEGV on a 64 KiB stack; the revised production scanner passes both.
  Host wchar_t is four bytes, so the old arrays consume 256 KiB there; Windows
  wchar_t is two bytes, so those same arrays consume 128 KiB. The newer Windows events also locate two historical 2.7 faults in the
  released binaries' stack-probe instruction; the callers remain unknown.
- The actual production import scanner/dispatcher is exercised with injected
  Windows enumeration and memory APIs, callable local/system targets, own and
  backend exclusions, concurrent refresh and a constrained caller stack.
- Initialization-gate tests cover busy/reentrant entry, success/rejection,
  exception retry and release/acquire publication. A modeled loader-lock
  dependency must return without waiting.
- The exact-profile test checks 41 nonoverlapping sites, exactly 61 changed
  bytes, both source/output identities, unchanged SETGE and all 17 FP8 objects.
  The loaded-image transaction test covers every failed write, full preflight,
  late read failure and incomplete rollback. These are host memory operations.
- Upgrade tests cover the exact released 2.7 ASI and standalone DLL identities,
  old uninstall receipts and transitions between their installation routes.
- NvPresent initializer machine-code inspection shows an AL boolean return.
  The runtime now declares bool, avoiding stale upper EAX bits. No native
  Windows execution is claimed for this ABI repair.

## New 2.8.1 diagnostics and actual launch evidence

The supplied `nvsmooth30(2).log` records the exact f36 driver passing its 41-site
output oracle, successful library load, CUDA capability 8.6, installed module-load
interception and applied profile/configuration. It ends after preparation, with
no initializer return or CUDA module-load call. This establishes that the 2.8
activation rejection is removed on that installation. It does not identify an
exception, prove a crash rather than a hang, or verify interpolation.

Static reference inspection finds an explicit breakpoint after failed internal
DXGI factory hook installation, but this has not been observed on the user's
machine. 2.8.1 adds a bounded, passive exception recorder around the initializer;
it does not suppress a driver assertion or claim a runtime repair. The decoder
and policy regression tests record bounds, truncation and register preservation.
The lifecycle harness exercises the actual production handler with injected
Win32 calls, including failures, reentry, disarming and an in-flight writer.
Real Windows VEH dispatch and actual file writes have not executed here.

The module and preopened handle remain resident so disarming cannot free storage
used by a concurrent handler. The callback has no logging mutex, symbol lookup,
CRT formatter or dynamic allocation, and always returns CONTINUE_SEARCH. It
limits records to sixteen selected first-chance exceptions during init. File
access errors, fail-fast termination, abrupt exit, hangs and exhausted stacks
can still leave no exception record. The collector includes the separate trace
file; no trace is uploaded automatically.

## Supplied Haydee 2 runtime evidence

The 2026-09-22 report identifies SteamGame.exe, an RTX 3070, NVIDIA driver
32.0.16.1664 and NvPresent SHA256
f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e.
The 2.1 section of the log shows 39 import hooks and rejection by the old
whole-file whitelist. This is evidence of an activation blocker, not of a
failed CUDA load by 2.1. The earlier 0.1.0 run has a separate CUDA error 200
(invalid kernel image/module) and shared-texture error. Its output must not be
attributed to this new build.

The newly supplied `nvsmooth30(1).log` contains three 2.7 Haydee sessions with
that same f36a... hash and text fingerprint d4e502.... All reject the driver
before loading; the longest recorded session continues through 15 seconds.
This explains lack of activation. The newer Windows event reports identify two of those historical faults at
stack-probe instructions in the released 2.7 binaries; no caller stack is available.

The 0.5.0 comparison input contains a matching exact 616.64 profile with full
source/output hashes, 41 original/replacement sites and runtime configuration
facts. 2.8 independently implements that factual contract. Tests validate the
same sites and complete transform on the separately supplied bec8... reference,
whose output has its own independently calculated hash. Pattern-only synthetic
inputs and changed source/model data are rejected. The exact f36a... driver
bytes remain unavailable locally; the new 2.8 log confirms its source/output oracle was verified
against the installed file before live private driver patches.

CUDA error definition: https://docs.nvidia.com/cuda/archive/12.9.1/cuda-driver-api/group__CUDA__TYPES.html

## Why a universal theoretical guarantee is unavailable

NVIDIA documents forward cubin compatibility: an SM86 binary can run on SM89,
whereas an SM89 binary is not supported on SM86. The reference contains 37 SM89
and 37 SM120 entries, with no SM86 entry in the inspected containers. Relabeling
these images does not prove that every instruction, model operation, or
resource requirement is supported on the older GPU. Genuine compatibility
requires compatible kernels or execution evidence; the proprietary source
needed to rebuild NVIDIA's model is not provided by the two linked repositories.

Source: https://docs.nvidia.com/cuda/ada-compatibility-guide/index.html

The D3D11 bridge also cannot create another flip-model chain over a game's
existing flip-model HWND. Graphics APIs, swapchain contracts, loader timing,
and driver versions differ across games. Unsupported paths therefore decline
interpolation rather than qualifying as successful Smooth Motion.

## Execution environment

The available environment is a Linux container without an accessible NVIDIA
GPU or Windows game installation. The previous Wine attempt failed at
wineserver socket creation, before a Windows executable could initialize.
No Wine or software-rendering result is claimed as native GPU validation.
The old custom renderer's shader tests are not validation of this native build.

## Windows evidence still required

| Test | Required observation |
| --- | --- |
| Haydee 2, normal Steam launch | Startup succeeds; actual API and swapchain descriptor logged |
| Wardogs root launcher and nested renderer | Correct executable receives files; game starts; independent capture verifies actual intermediate frames |
| Euro Truck Simulator and Silent Hill Townfall reports | Runtime/API/driver evidence explains apparent activation without visible interpolation |
| Standalone Windows version forwarding | Real system APIs preserve arguments, results and LastError through concurrent callers |
| Duplicate/competing engine present | One normal backend only; rejected backend attaches no graphics context or COM hooks |
| Generated uninstall.bat and interrupted install | Real Windows paths, permissions, file locks, restart recovery and unrelated mods retain expected behavior |
| version.dll, dinput8.dll, winmm.dll, existing ASI loader | Early graphics interception occurs through each game-used carrier |
| Windowed legacy DX11 | Same adapter, successful NT sharing, CUDA execution, then actual interpolated output |
| DX11 flip/fullscreen/HDR/MSAA | Original rendering continues without an unsupported shadow bridge |
| DX12 title | Driver initialization before graphics creation; no extra application-owned Present calls |
| Resize, alt-tab, window recreation, exit | No stale state, hang, leaked live game backbuffer, or destruction under an active Present |
| Unsupported/unknown driver and other GPU | Explicit diagnostic and normal game presentation |
| Motion, UI, scene changes, occlusion | Captured intermediate frames are real and visually usable |
| Timing and GPU failures | Measured displayed-frame pacing, bounded waits, useful error logs |
| D3D11 fence event and older query fallback | Successful copy completion before D3D12 reads; timeout/device removal remain distinct |
| Same-size reset after failed initialization | No repeated failed allocation until the actual descriptor changes |
| Partial CUDA hook setup failure | Original import and delay-loader pointer restored; no untracked callback |
| Inaccessible/malformed module imports | Module skipped without a partially scanned import table being applied |
| Graphics pointer protection failure | Own pointer rolled back; later owner preserved; no bridge through an incomplete hook group |
| Concurrent loader callback and log opening | No log-mutex/loader-lock inversion introduced by executable path lookup |
| Emulator frontend idle for more than 30 seconds, then launch | New graphics modules discovered; actual renderer/API and creation timing recorded |
| Delay-load, unload and renderer restart | Resolved active IAT patched; unresolved thunks and unload copies retain their contracts |
| Factory/swapchain base interface followed by newer interface | Required extra methods intercepted; failed extension preserves originals and retires an active bridge |
| Loader notification unavailable or module snapshot fails | Periodic fallback and later retry remain active |
| Present(TEST), occlusion and backpressure | No frame-copy work for TEST; exact status propagation; no duplicate fallback Present |
| Shadow Present/copy/Signal failure | One retirement, useful device reasons, continued original rendering without a recreation loop |
| Native wrapped D3D11 | No additional bridge over a detected NvPresent wrapper |
| Nonblocking/partial-update Present | Retire the unsupported bridge; preserve source call parameters and status |

Runtime status schema 6 introduced module_scans (completed module enumeration),
loader_notifications (load/unload counter), and loader_notifications_active.
Scans do not prove interception of an already-created graphics object. The
existing fields separate accepted bridge Presents, attempts, TEST calls,
occlusion, backpressure and fatal Present failures. The
cuda_activity_calls field records successful intercepted kernel/graph API
calls; calls can include graph capture and do not prove GPU completion.
The 64-Present activity check is a heuristic, and activity is currently scoped
to the NvPresent module rather than uniquely attributed to a swapchain.
A native wrapper detected by its public vtable is allowed to present directly.

The runtime records load, activity and error evidence separately. It always
reports interpolation_verified=false because it has no independent display
measurement. Successful CUDA API activity is supporting evidence, not sufficient proof
of generated frames reaching the monitor.

To continue the Haydee 2 investigation, collect nvsmooth30.log beside its EXE
and the output of Collect_Diagnostics.exe after the same game launch. The latest reports identify the Steam Overlay fault offset. A minidump or
exception stack is still needed to recover its full call chain.

Presentation contract references:
- https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgiswapchain-present
- https://learn.microsoft.com/en-us/windows/win32/direct3ddxgi/dxgi-present
- https://docs.nvidia.com/cuda/archive/12.9.1/cuda-driver-api/group__CUDA__STREAM.html
- https://learn.microsoft.com/en-us/windows/win32/api/d3d11_3/nf-d3d11_3-id3d11devicecontext4-signal
- https://learn.microsoft.com/en-us/windows/win32/api/d3d11_3/nf-d3d11_3-id3d11fence-seteventoncompletion
- https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12fence-seteventoncompletion
- https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-readprocessmemory
- https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualprotect
- https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-best-practices
- https://learn.microsoft.com/en-us/windows/win32/devnotes/ldrregisterdllnotification
- https://learn.microsoft.com/en-us/windows/win32/devnotes/ldrdllnotification
- https://learn.microsoft.com/en-us/windows/win32/debug/pe-format
- https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulehandleexw

Schema 7 additionally separates cuda_module_failures from cuda_execution_failures.
A prior failed module lookup cannot by itself establish failed execution of a
subsequently loaded model. Bridge retirement uses execution/synchronization
failures, while the existing fresh-activity deadline still rejects a path with
no usable running model. The total cuda_failures field remains available.
Optional FP8 probing has not been observed or assumed in this change.

The 2.8.1 collector also queries recent Application Error EventID 1000 records
for the exact selected executable path. Parsing, bounds, entity handling and
path-match policies are host tested. Windows querying did not execute in this development environment. The two
new user reports demonstrate that this collector retrieved matching events
on the user's machine.

Final collector review corrected immediate abandonment on EvtNext timeout.
The reader now retries with waits of at most 100 ms within one 2-second
enumeration budget and a 32-timeout cap. The affected policy/parser suite
passed again in both configurations (1,291 checks); unchanged suites retain
their recorded full-run results. Windows Event Log calls remain unexecuted here.
