# Smooth Motion 2.8.2 R3 GP3 — Streamline / Dead Space fix

This update fixes a reproduced interception gap for games that create their
DXGI/D3D devices through Streamline's `sl.interposer.dll`. It is based on the
confirmed working GP2 package and rebuilds both `version.dll` and `new.asi`.
Game Pass file selection, package loading and uninstall protections are retained.

The supplied Dead Space log shows that the ASI loads but never observes a
graphics-creation call. The new runtime recognizes Streamline's own graphics
exports, initializes Smooth Motion before forwarding them, and preserves the
original Streamline function and its outputs. This does not replace DLSS files.

**For your Dead Space setup:** close the game, open this package's Manager,
select `Dead Space.exe`, keep **new.asi + winmm.dll**, and review/install the
update. The log already confirms that your winmm loader loads the plugin.

Provider discovery now runs before consumer import scanning. Dynamic exports
are handled as soon as they are resolved. Separate immutable callback slots
preserve each provider, and exact module references keep cached calls valid.
Steam overlay exclusions propagate through nested graphics calls.

See RELEASE_NOTES_2_8_2_R3_GP3.md and VALIDATION.md. The missed-hook defect is
reproduced and fixed in host tests. Dead Space gameplay and displayed frame
interpolation have not been executed in this environment.

## Install

1. Close the older Manager, extract this complete ZIP into a fresh folder, and
   open its `SmoothMotion_Manager.exe` (About identifies 2.8.2-r3-gp3).
2. Use Browse EXE and select the actual game EXE. For the reported Marvel demo,
   select `XboxGames\MARVEL Cosmic Invasion Demo\Content\Game.exe`, not
   `gamelaunchhelper.exe`. Check the destination in the installation review.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

For Game Pass, select the actual x64 rendering executable in the installed
content directory, not a launcher or Gaming Services executable. Start the game
through the Xbox app as usual. This build preserves Windows package loading
rules and does not change installation-folder permissions. Storefront alone
does not establish a supported graphics API or a working carrier.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Diagnostics and compatibility

The startup log identifies **2.8.2-r3-gp3**, and runtime status identifies
**2.8.2-r3-gp3-normal**. Status schema 9 labels Present counts as raw intercepted
calls; they can include internal calls and probes, so they are not displayed FPS.
The Steam counter dropping from roughly 500 to 300 does not by itself identify
which path stopped or verify displayed interpolation.

Run `Collect_Diagnostics.exe` for the actual game executable after reproducing
an issue. The collector includes available logs and matching Windows fault
events. The underlying CPU-layout validator is unchanged from 2.8.2, so its
report still labels that specific validation as 2.8.2.

The backend targets x64 Direct3D 12 and a restricted windowed D3D11 legacy
DISCARD, single-sample SDR bridge. Emulator support depends on the selected
host renderer. Vulkan, OpenGL, Direct3D 9, 32-bit and general DX11 flip/HDR
bridging are not implemented here. See COMPATIBILITY.md.

Both runtime carriers and all three application helpers are rebuilt.
38 host suites pass in optimized and ASan/UBSan builds (76 runs). This environment has not executed this release
on Windows or an NVIDIA GPU; Haydee 2 compatibility, repeated launches,
frame pacing and displayed interpolation remain unverified.

Source, crash symbols and validation reports are included. The historical
2.8.2 reports and earlier DLL comparisons remain under history/ and
validation/comparison/. No new third-party binary is merged into the runtime.
