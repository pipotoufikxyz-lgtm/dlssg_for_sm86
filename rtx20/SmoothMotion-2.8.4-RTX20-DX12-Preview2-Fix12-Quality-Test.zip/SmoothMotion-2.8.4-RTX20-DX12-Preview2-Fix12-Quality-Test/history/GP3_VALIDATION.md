# Validation — R3 GP3 Streamline creation update

Baseline: confirmed working GP2 ZIP, SHA256
`deb29997b455dba34e2e4b88ece668625f3da1377d46da24162bf49127020c40`.

## Completed checks

- Both runtime carriers and all three application helpers cross-compiled for
  Windows x64. Version: `2.8.2-r3-gp3-normal`; Manager: `2.8.2-r3-gp3`.
- 38 host suites in optimized and ASan/UBSan builds, 76 runs.
- The production import scanner and six production Streamline forwarding thunks
  are executed with deterministic Win32/graphics seams. Consumer-before-provider
  module order, static imports, immediate dynamic resolution, two providers,
  all six API argument lists, HRESULT/LastError/output preservation, failed
  calls, repeated scans, one retained reference per provider, protected-origin
  forwarding and nested exclusion propagation are covered.
- Immutable provider publication exercised by 12 concurrent writers and a
  concurrent reader; duplicate bindings, capacity exhaustion, empty exports,
  missing symbols and permanent forwarding destinations are checked.
- Existing GP2 Game Pass picker, metadata, WindowsApps renderer and package
  loading regressions retained. GP1/GP2 upgrade and uninstall identity coverage
  includes both standalone and ASI carriers.
- Five exact binary/PDB CodeView GUID/age pairs; build source hashes, helper and
  payload hashes, four manual kits, ZIP CRC and SHA256SUMS verified.

## Evidence

- `validation/portable-normal.json`: exact host test results and source hashes.
- `validation/runtime-review-2.8.2-r3-gp3-normal.json`: binary/PDB matches.
- `validation/package-normal.json`: packaging and payload identity checks.
- `validation/dead-space-gp3.json`: input-log facts and repair scope.
- Earlier narratives remain in `history/GP2_README.md` and `history/GP2_VALIDATION.md`.

## Limits and live check

No native Windows, GPU or Dead Space execution occurred here. Host simulations
verify code behavior, not game compatibility, image correctness, performance or
frame interpolation. The log establishes missed graphics initialization, but
cannot prove that provider interception is the only issue on the user's machine.

After upgrading through the Manager with the existing winmm ASI route, launch
Dead Space normally. Check the GP3 session for provider discovery and the first
`Streamline!CreateDXGIFactory*` or `Streamline!D3D12CreateDevice` initialization
trigger. Then inspect driver initialization and CUDA errors. Verify displayed
interpolation separately; counters and DLL loading alone do not establish it.
