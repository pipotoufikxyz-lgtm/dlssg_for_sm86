# Smooth Motion 2.8.2 R3 GP8 — Xbox folder detection

GP8 repairs the Manager's Xbox/Game Pass discovery and folder scanning.
The standalone DLL and ASI are the exact GP7 binaries, preserving the GP6
Dead Space startup fix and its GP7 extension for Genshin.

**For the reported Ragebound installation:** close the old Manager, extract
this complete ZIP and open its `SmoothMotion_Manager.exe`. Use **Browse
folder** and select `C:\XboxGames\NINJA GAIDEN- Ragebound`, or select
`C:\XboxGames`. **Discover games** also checks XboxGames directories on fixed
local drives. The Manager identifies itself as **2.8.2-r3-gp8**.

The scanner now treats XboxGames as a collection and creates one card per
game. Selecting a game's Content directory resolves to the same installation
identity as selecting its parent game folder.

MicrosoftGame.config declarations are inspected before bulk file enumeration
in each visited directory, and Content directories get traversal priority.
Protected executables retain their declared x64 identity with unknown imports;
they no longer lose their ranking merely because they are nested. Omitted
PC device-family and x64 architecture defaults follow the Microsoft schema.
Explicit console, unsupported architecture, development-only, duplicate and
unsafe-path entries remain ineligible for protected-EXE fallback.

A folder scan that finds no usable executable now reports that outcome. Read
failures include their path and reason, and scan limits are reported. Existing
protected-EXE picker support, per-game uninstall.bat and ownership checks are
retained. File permissions and game files are not changed by scanning.

The screenshot establishes the Ragebound installation folder but contains no
executable listing, MicrosoftGame.config or scan log. The code defects are
reproduced/covered with host fixtures; the exact failure inside that Windows
installation and Ragebound gameplay have not been verified here.

See RELEASE_NOTES_2_8_2_R3_GP8.md and VALIDATION.md for evidence and scope.

## Install

1. Close the older Manager, extract this complete ZIP into a fresh folder, and
   open its `SmoothMotion_Manager.exe` (About identifies 2.8.2-r3-gp8).
2. For this report, use Browse folder and select
   `C:\XboxGames\NINJA GAIDEN- Ragebound`, or select `C:\XboxGames`
   to discover each game separately. Discover games also checks XboxGames
   directories on fixed local drives. Browse EXE remains available.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

For Game Pass, select the actual x64 rendering executable in the installed
content directory, not a launcher or Gaming Services executable. Start the game
through the Xbox app as usual. This build preserves Windows package loading
rules and does not change installation-folder permissions. Storefront alone
does not establish a supported graphics API or a working carrier.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Diagnostics and compatibility

The Manager identifies **2.8.2-r3-gp8**. Its unchanged GP7 runtime status identifies
**2.8.2-r3-gp7-normal**. Status schema 12 labels Present counts as raw intercepted
calls; they can include internal calls and probes, so they are not displayed FPS.
The Steam counter dropping from roughly 500 to 300 does not by itself identify
which path stopped or verify displayed interpolation.

Run `Collect_Diagnostics.exe` for the actual game executable after reproducing
an issue. The collector includes available logs and matching Windows fault
events. The underlying CPU-layout validator is unchanged from 2.8.2, so its
report still labels that specific validation as 2.8.2.

The backend targets x64 Direct3D 12 and a restricted windowed D3D11 legacy
DISCARD, single-sample SDR bridge. Emulator support depends on the selected
host renderer. Vulkan, OpenGL, Direct3D 9, 32-bit and general DX11 flip/HDR
bridging are not implemented here. See COMPATIBILITY.md.

The three application helpers are rebuilt; both GP7 runtime carriers are preserved exactly.
See VALIDATION.md and validation/portable-normal.json for this release’s checks. This environment has not executed this release
on Windows or an NVIDIA GPU; Haydee 2 compatibility, repeated launches,
frame pacing and displayed interpolation remain unverified.

Source, crash symbols and validation reports are included. The historical
2.8.2 reports and earlier DLL comparisons remain under history/ and
validation/comparison/. No new third-party binary is merged into the runtime.
