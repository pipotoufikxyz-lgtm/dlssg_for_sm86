# Smooth Motion 2.8.2 R3 GP2 — Game Pass EXE selection fix

This package fixes the access-denied dialog when selecting a protected Game Pass
`Game.exe`. It rebuilds the Manager, installer and diagnostics collector. The
GP1 standalone `version.dll` and `normal.asi` are retained byte-for-byte.

## What changed

- EXE pickers now select a filesystem path without requiring permission to read
  the file contents. Selecting an EXE does not launch it or alter permissions.
- When Windows denies EXE reads, the Manager and installer look for readable
  `MicrosoftGame.config` metadata, up to six parent levels, and require an exact
  relative-path match for a non-development x64 PC executable. Architecture
  defaults follow the documented GDK x64 default. ARM64, x86, ambiguous or
  mismatched entries are not accepted.
- Protected targets are reviewed with unknown graphics API/imports, not invented
  import evidence. The installation review states when metadata was used. The
  metadata bytes are included in the plan fingerprint and rechecked on apply.
- `gamelaunchhelper.exe` is filtered out of game selection. Select `Game.exe`.
- Restore manifests keep their normal read validation. Diagnostics and uninstall
  EXE selection also use the corrected picker.

The fallback cannot help if Windows also denies metadata/attribute access or
folder writes. In those cases the Manager reports the failure; it does not take
ownership, change ACLs, decrypt game files or pretend compatibility is verified.

## Retained GP1 runtime repairs

The retained **R3 GP1 runtime** was built from the attached R3 Stability ZIP, not the
R4 diagnostics branch. It fixes three reproduced loading/discovery defects:

- Intercept `LoadPackagedLibrary` as well as the existing `LoadLibrary` APIs.
  After a successful intercepted package load, scan the new module before
  returning to its caller, so its immediately following graphics creation can
  reach the backend. Native package resolution, arguments, errors and return
  values are preserved.
- Recognize extended DOS Windows paths and mixed path separators when excluding
  Windows components from hooks. Game renderers in WindowsApps, XboxGames and
  ModifiableWindowsApps remain eligible; exact Steam overlay exclusions remain.
- Retry a transient `ERROR_BAD_LENGTH` module snapshot up to three attempts.
  Persistent or unrelated failures return without blocking indefinitely, and
  later discovery remains available.

All R3 initialization, presentation ownership, bridge activity and Manager
repairs are retained. Standalone DLL and ASI share these changes. Earlier R3
and R4 files are recognized by their exact hashes for upgrades and uninstall.
There are no multiplier controls, Version 2 entry or SM-only flow.

See RELEASE_NOTES_2_8_2_R3_GP2.md and VALIDATION.md. These source defects are
reproduced in host tests; they are not confirmed causes of the reported Game
Pass failures. No claim of tested compatibility for the named games is made.

## Install

1. Close the older Manager, extract this complete ZIP into a fresh folder, and
   open its `SmoothMotion_Manager.exe` (About identifies 2.8.2-r3-gp2).
2. Use Browse EXE and select the actual game EXE. For the reported Marvel demo,
   select `XboxGames\MARVEL Cosmic Invasion Demo\Content\Game.exe`, not
   `gamelaunchhelper.exe`. Check the destination in the installation review.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

For Game Pass, select the actual x64 rendering executable in the installed
content directory, not a launcher or Gaming Services executable. Start the game
through the Xbox app as usual. This build preserves Windows package loading
rules and does not change installation-folder permissions. Storefront alone
does not establish a supported graphics API or a working carrier.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Diagnostics and compatibility

The startup log identifies **2.8.2-r3-gp1**, and runtime status identifies
**2.8.2-r3-gp1-normal**. Status schema 8 labels Present counts as raw intercepted
calls; they can include internal calls and probes, so they are not displayed FPS.
The Steam counter dropping from roughly 500 to 300 does not by itself identify
which path stopped or verify displayed interpolation.

Run `Collect_Diagnostics.exe` for the actual game executable after reproducing
an issue. The collector includes available logs and matching Windows fault
events. The underlying CPU-layout validator is unchanged from 2.8.2, so its
report still labels that specific validation as 2.8.2.

The backend targets x64 Direct3D 12 and a restricted windowed D3D11 legacy
DISCARD, single-sample SDR bridge. Emulator support depends on the selected
host renderer. Vulkan, OpenGL, Direct3D 9, 32-bit and general DX11 flip/HDR
bridging are not implemented here. See COMPATIBILITY.md.

The three application helpers are rebuilt; the GP1 runtime DLL/ASI are unchanged.
37 host suites pass in optimized and ASan/UBSan builds (74 runs). This environment has not executed this release
on Windows or an NVIDIA GPU; Haydee 2 compatibility, repeated launches,
frame pacing and displayed interpolation remain unverified.

Source, crash symbols and validation reports are included. The historical
2.8.2 reports and earlier DLL comparisons remain under history/ and
validation/comparison/. No new third-party binary is merged into the runtime.
