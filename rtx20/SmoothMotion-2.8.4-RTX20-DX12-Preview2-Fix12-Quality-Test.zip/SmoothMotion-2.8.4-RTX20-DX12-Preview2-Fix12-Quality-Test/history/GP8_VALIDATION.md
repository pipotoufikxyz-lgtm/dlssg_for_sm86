# Validation — GP8 Xbox detection

Baseline GP7 ZIP SHA256:
`ab6284a8c08583c9305dfba71cc5e53279c5ab580c091695f056a40dbc6747d2`.

## Targeted coverage

- 35 production folder-scan checks: Xbox collection grouping, per-game and
  Content-folder identity, protected executable detection, metadata before
  file enumeration, Content priority, asset cutoffs, incomplete enumeration,
  invalid declarations, unsafe paths, helper exclusion and cancellation.
- 54 protected-target/metadata checks, including the released GP7 policy as a
  control for omitted TargetDeviceFamily. GP7 rejects the fixture; GP8 accepts
  the documented PC default while retaining explicit invalid-value rejection.
- Existing target-selection tests now cover explicit metadata-verified choices
  following a scan cutoff, while unknown targets still require a choice.

Folder/PE/XML events are seams. The tests execute production traversal and
policy code but do not run the Windows filesystem APIs or XmlLite parser.
The screenshot alone does not supply the actual Ragebound EXE or manifest.

## Release checks

- 41 suites pass in optimized and ASan/UBSan configurations (82 runs).
- Three Windows x64 application helpers rebuilt, with all five runtime/helper
  binaries matched to their exact PDB GUID/age and source identities.
- GP8 Manager identity, exact GP7 runtime hashes, 17 version API ordinals,
  helper/payload hashes and four manual kits pass package validation.
- The final ZIP build verifies every archived SHA256SUMS entry and CRC.

## Runtime baseline

All 92 native source files and both runtime binaries match GP7 exactly:

- normal.asi: `367fa8f41530a1d28c354ddd7c5cbc2be7e3918a14bba995bf7870d1d76d0c37`
- version.dll: `61b17dbd09743bfd0eb8064fa40d8d652167ad006343ec3ecb4f28e00fd1813c`

The Manager/installer changes do not alter frame generation. Dead Space was
reported working by the user on GP6; no new gameplay result is claimed.

## Evidence

- validation/xbox-detection-gp8.json: screenshot, defects and test results.
- validation/baseline-diff-gp8.json: exact GP7 source and runtime comparison.
- validation/portable-normal.json: host regression outputs and input identities.
- validation/runtime-review-2.8.2-r3-gp7-normal.json: five current binary/PDB pairs;
  the report retains the runtime's GP7 identity because those binaries are reused.
- validation/package-normal.json: release, payload and manual-kit verification.
- history/GP7_README.md and history/GP7_VALIDATION.md: previous release text.

No Windows, NVIDIA GPU or game was executed here. Actual detection on the
reported PC and Ragebound interpolation remain unverified.
