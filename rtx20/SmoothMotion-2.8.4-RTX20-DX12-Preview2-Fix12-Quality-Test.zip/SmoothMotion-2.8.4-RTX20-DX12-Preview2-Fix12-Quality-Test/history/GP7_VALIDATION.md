# Validation — GP7 Genshin startup on the GP6 baseline

Baseline GP6 ZIP SHA256:
`32f12fd4c6f2ff02709c6f6cf7eea522c6b0aad678c2cd8ecf1dd74aa4570bac`.

The user confirmed that GP6 worked in Dead Space. That is a user gameplay
report, separate from the automated host tests below. Genshin's new log is
from GP1 and contains three not_started status reports.

## Targeted reproduction

The fixture uses the exact released GP6 startup controller, with only its
namespace and include location changed, as its Genshin control. It retains
graphics-call activation and makes no early driver attempt. GP7's production
ASI entry and controller start the simulated backend before that entry
returns, with no later graphics callback.

212 checks cover both selected games, exact adjacent markers and their file
versus directory type, case-insensitive filenames, extended/Unicode paths,
missing/inaccessible markers, unrelated games and launchers, context API
availability, native BOOLEAN semantics, LastError, loader-callout deferral,
standalone startup, failed initialization, repeated entries, reentry and 12
concurrent contenders. The GP5 stalled-Dead-Space control and GP6 Dead Space
behavior remain covered.

## Release checks

- Both Windows x64 runtime carriers and three application helpers rebuilt.
- 40 suites pass in optimized and ASan/UBSan configurations (80 runs).
- All five binaries match their PDB GUID/age and recorded source hashes.
- Both runtime identities, all 17 version API ordinals, helper/payload hashes,
  four manual kits and prior-release migrations pass package validation.
- Full portable, symbol, upgrade and package results are recorded in the
  machine-readable reports listed below.
- Startup changes are scoped to the exact Genshin executable/data-directory
  combination; other games keep their previous activation selection.
- GP6 migration hashes are pinned to the released artifacts. The existing
  prior-release upgrade/removal matrix now exercises those identities too.

## Evidence

- validation/genshin-gp7.json: input facts, baseline, targeted repair and limits.
- validation/baseline-diff-gp7.json: source differences from the GP6 baseline.
- validation/portable-normal.json: per-test output and source hashes.
- validation/runtime-review-2.8.2-r3-gp7-normal.json: binary/PDB identities.
- validation/package-normal.json: payload, loader, manual kit and export checks.
- source/native/startup_bootstrap_test.cpp: production entry and baseline controls.
- history/GP6_README.md and history/GP6_VALIDATION.md: previous release text.

## Limits

No Windows loader, NVIDIA GPU or game execution occurred in this environment.
Host seams simulate the native initializer; a passing fixture establishes
startup ordering only. A Genshin driver rejection or unsupported presentation
path may require a separate repair once initialization runs. Actual Genshin
interpolation, stability and performance have not been verified.

ASI startup is synchronous at a safe plugin entry. Standalone startup uses
a worker and cannot guarantee it runs before every game thread. Existing
DX12 and restricted D3D11 bridge support is unchanged; this release does not
add a graphics API, GPU architecture or 32-bit backend.
