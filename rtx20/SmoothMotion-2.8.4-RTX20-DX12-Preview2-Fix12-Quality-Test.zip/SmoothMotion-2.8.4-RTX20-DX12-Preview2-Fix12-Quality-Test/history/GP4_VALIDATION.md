# Validation — R3 GP4 loader alias update

Baseline: delivered GP3 package, SHA256
`1e456a4d55a5cb108d39c719c894470fae19ac2204dc2f16c7c8228655941f9c`.

## Required release checks

- Both runtime carriers and three helpers cross-compiled for Windows x64.
- 38 host suites, optimized and ASan/UBSan, 76 runs.
- Production scanner and six loader-alias callbacks execute an immediate
  renderer-load -> export-resolution -> graphics-creation sequence using
  distinct KernelBase addresses and no background refresh between calls.
- Exact original loader/resolver forwarding, successful/failed calls, filenames,
  flags, handles, return values, LastError, missing/ordinal lookups,
  resource-only loads, repeated scans and retained references are checked.
- Protected overlay/system imports and lookalike module exclusions remain.
- Existing six Streamline API, concurrent publication, 64 KiB caller-stack,
  Game Pass picker/package and import-boundary tests remain included.
- Collector uses the Manager's existing bounded mapped PE reader. Shared
  parser tests include a sparse 5 GiB executable and high import offsets.
  The actual Windows mapping calls are cross-compiled, not executed here.
- Exact GP3 hashes are recognized by upgrade and uninstall policy tests.
- Five exact binary/PDB pairs, source/payload/helper hashes, four manual kits,
  archive CRC and every archived SHA256SUMS entry are checked.

## Evidence

- `validation/dead-space-gp4.json`: supplied report facts and causal limits.
- `validation/portable-normal.json`: individual host test results/source hashes.
- `validation/runtime-review-2.8.2-r3-gp4-normal.json`: exact symbol pairs.
- `validation/package-normal.json`: release integrity checks.
- `history/GP3_README.md` and `history/GP3_VALIDATION.md`: previous release text.

## Limits

The provided GP3 report proves loading without graphics initialization. It
also directly establishes the collector's executable-size rejection. It does
not show which Windows resolver the game used. The alias gap is a reproduced
source defect and candidate cause, not a verified sole root cause on hardware.

No native Windows, GPU or Dead Space execution occurred. Successful builds and
host regressions do not verify game compatibility, image quality, performance
or displayed interpolation. After installing GP4, a new game run and log are
needed to establish whether initialization and interpolation succeed.
