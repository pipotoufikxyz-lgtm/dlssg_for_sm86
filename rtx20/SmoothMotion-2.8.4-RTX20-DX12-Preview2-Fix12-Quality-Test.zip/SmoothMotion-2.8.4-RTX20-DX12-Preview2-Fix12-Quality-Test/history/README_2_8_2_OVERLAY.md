# Smooth Motion 2.8.2 — Steam Overlay compatibility

One normal-mode backend, built as a standalone `version.dll` and as `new.asi`.
The Manager keeps alternative ASI loader routes, including `winmm.dll` and
`dinput8.dll`. There are no x3/x4 controls.

## What the latest reports establish

Both latest launches have matching Windows access violations in
`gameoverlayrenderer64.dll+0xd4b07`. Five recorded 2.8 sessions match that same
Steam Overlay fault. An earlier session successfully initialized NvPresent,
loaded 19 CUDA modules and reached 1,090 successful intercepted CUDA calls with
zero recorded CUDA errors. This confirms that the exact driver profile can
initialize on the reported setup; it does not independently verify displayed
interpolated frames or continued game stability.

2.8.2 repairs an identified interaction in our import scanner: Steam Overlay's
private imports and graphics API lookups must not be redirected through our
backend. Exact Steam Overlay modules are excluded, and calls from protected
modules through shared graphics hooks forward without starting NvPresent or
registering their graphics objects. Game and engine modules remain eligible,
including emulators using a supported host rendering API.

The reports identify the fault location, but contain no call stack proving that
this scanner interaction caused every crash. This update fixes that reachable
interaction and retains the initializer exception recorder for the next run.
No Steam setting or NVIDIA driver file is changed.

Upgrade with the Manager using one loading route, launch Haydee 2 normally,
then run `Collect_Diagnostics.exe` and select its `SteamGame.exe`. The new log
must say **2.8.2-normal** and identify the backend module and first graphics
caller. Send the new report whether the game starts or closes; it includes
available Windows fault events and initializer exception records. A captured
first-chance exception is not necessarily a terminal crash.

The supplied reports' launch labels are retained as stated: `001321` standalone
and `001141` ASI plus a version.dll loader. Their later file snapshots identify
the opposite routes, so snapshots are not used to assert which binary was
loaded in a historical session. All embedded runtime sessions identify 2.8;
the collector's 2.8.1 label describes its validator, not the loaded backend.

## Retained 2.8 repairs

The three 2.7 sessions reject NvPresent `f36a5f...` before CUDA or presentation.
2.8 recognizes that exact 616.64 component using its full identity, layout,
original patch bytes and expected transformed-file hash. It adapts 20 non-FP8
modules in memory before initialization, preserves the 17 FP8 modules and the
capability instruction, and uses the matching runtime configuration contract.
It does not replace the installed NVIDIA driver file.

The import scanner's large automatic path arrays were also removed: the prior
production scanner crashes on a 64 KiB host test thread; the revised scanner
passes that same test. Initialization no longer waits on another initializer
that may need the Windows loader lock. The driver init return is now read as
an 8-bit boolean, matching the inspected machine code.

This repairs the identified activation rejection and reproduced crash class.
The new Windows events separate the older stack-probe faults from the current
Steam Overlay faults. This candidate has not been run in Haydee 2 on a GPU.

## Install

1. Extract the complete ZIP and open `SmoothMotion_Manager.exe`.
2. Choose the game. Check the executable shown in the installation review.
3. Choose standalone `version.dll`, or `new.asi` with an imported alternative
   loader. Install one route only, then launch the game normally.

The standalone route installs the engine inside `version.dll`; it does not
need `new.asi` or `version.ini`. ASI routes use the same backend through the
selected loader. If a game never loads the chosen DLL, try a carrier identified
in its import evidence. Keep an already-working ASI route when upgrading. For dinput8, select
**new.asi + dinput8.dll** in the Manager or use Manual/Dinput8. The standalone
version.dll has version-API exports; renaming it does not make it a DirectInput
proxy.

For Wardogs, the renderer shown in the supplied screenshots is:
`Wardogs\Binaries\Win64\WardogsClient-Win64-Shipping.exe`.
The Manager now prefers that renderer over the root
`WardogsLauncher-Shipping.exe`, including when browsing the launcher manually.
Ambiguous renderer choices require selecting the actual EXE.

An older installation beside the launcher is not silently deleted. In the
Manager's **Uninstall** review, use **Choose installed EXE** and select the old
launcher to review removal from that original folder. Complete groups with
exact recognized hashes can be removed even without a new ownership record.
**Legacy restore** can still review a previous `restore.tsv`. The upstream
reporter also tried moving the files manually without success, so correcting
the destination is not proof of a runtime fix.

## Uninstall

Close the game and run `uninstall.bat` beside the selected game EXE, or use
**Uninstall** in the Manager. The generated uninstaller removes files whose
hashes still match the recorded installation. It preserves changed files,
other mods, logs, and unrelated `uninstall.bat` files.
If other ASI plugins or modified files may depend on the ASI loader, its DLL
and configuration remain. Switching that shared loader to the standalone
backend is blocked; an upgrade using the same ASI carrier remains available.

Successful new installations do not leave the old `SM86-backup-*` workflow.
A small `.smooth-motion` folder holds the uninstaller and ownership record;
these tools remain after removal so the operation is repeatable. An interrupted
file transaction can retain a temporary recovery journal until recovery is
completed. Genuine game files are not replaced to force a carrier to fit.

Manual kits are in `Manual/`. Manually copied files do not create an ownership
record; use the Manager to review/adopt matching files and generate the
uninstaller. Do not combine the standalone DLL with the ASI.

## Language

Settings offers **Auto / English / 简体中文**. Auto follows the Windows UI
language. Main Manager and installer captions are translated; executable names,
paths, protocol fields, and unrecognized technical diagnostics are preserved.
The standalone installer accepts `--language auto`, `en-US`, or `zh-CN`.

## Retained from 2.7

- Corrected launcher-versus-renderer selection for Unreal game layouts.
- Added a true standalone proxy with all 17 Windows version APIs and their
  ordinals, corrected `GetFileVersionInfoByHandle`, and preserved `LastError`.
- Added per-game uninstall ownership and reviewed removal.
- Added Simplified Chinese UI support requested in issue #14.
- Copies CUDA input images before parsing them, including readable images
  spanning multiple memory regions. Failed or inconsistent reads are declined.
- Prevents two copies of our backend from initializing NvPresent in one
  process, and detects the competing Smooth Motion providers identified in the
  supplied test DLLs before applying private driver patches.
- Keeps diagnostics active after a late game launch and records the host EXE
  and first application Present separately from generated-frame evidence.
- Retains bounded import/delay-import discovery, transactional hook groups,
  same-adapter sharing and bounded GPU waits from earlier releases.

The detailed comparison of all supplied builds and relevant Vulkan helpers is
in `validation/comparison/BINARY-AUDIT.md`; exact binary and CUDA code hashes are
in `binary-audit-summary.json`. New attachments are covered in `BINARY-DELTA.md`
and `BINARY-DELTA.json`; `DRIVER-PROFILE-2.8.md` explains the exact driver adaptation.
`REPORT-COMPARISON-2.8.2.md` correlates the latest Windows fault records;
`OVERLAY-COLLISION-2.8.2.md` records the provider-interception audit.
`LOG-COMPARISON.md` separates the actual 2.7 Haydee
sessions from the other builds and the reported PCSX2 result. `UPSTREAM-REPORTS.md` records the linked issues
and the Nexus posts retrieved, including the unresolved reports. No third-party test DLL or proprietary 0.5.0
payload was merged into this release.
Retired engine binaries are also excluded; their hashes remain for migration.

## Runtime scope

This is a cross-compiled, host-tested candidate. Windows games, emulators and
NVIDIA GPU output were not executed in the development environment. It is not
certified to fix Wardogs, Haydee 2, Silent Hill Townfall, Euro Truck Simulator or
Helldivers 2.

The existing backend targets native DX12 and a restricted windowed DX11 legacy
DISCARD, single-sample RGBA/BGRA SDR bridge. It does not add Vulkan, OpenGL, DX9,
32-bit, HDR bridge or general DX11 flip-model interpolation. An emulator's
selected host renderer determines which API is used.

The SM86 path changes CUDA binary metadata; it does not translate instructions
or rebuild NVIDIA's motion model. Loaded modules, successful CUDA calls and
application Present counts do not prove displayed intermediate frames. Status
continues to report `interpolation_verified=false`.

Use `Collect_Diagnostics.exe` and the current `nvsmooth30.log` to distinguish
loader, driver-layout, API, CUDA and presentation problems. A crash needs its
exception/minidump evidence to identify the failing call. See `COMPATIBILITY.md`,
`VALIDATION.md` and the comparison report for the precise limits and test scope.

The updated collector can also read Windows Application Error records from the
last 24 hours for the exact selected game executable. It reads at most 200
recent matching-provider events and only reports events whose full AppPath
matches the selected EXE. This may identify the existing 2.8 crash without
launching again. Records from other games are not included. Windows may not
have recorded a crash, and hangs require different evidence.
