# 1.7 — experimental motion-vector x3 / x4

- Added an independent D3D11 optical-flow renderer and built `payload/motion/motion.asi` from the included source.
- Added per-game Original NVIDIA / x2 / x3 / x4 selection in the glass menu. Custom modes select new.asi automatically.
- Added bidirectional matching, intermediate-image warping, consistency checks, scene-change fallback, presentation pacing and Ctrl+F10 pause/resume.
- Added context-state restoration, resize/device recovery and per-session status reports.
- Included multiplier/configuration changes in install review tokens, backup transactions and restore operations. Unknown configuration files are protected.
- Added production policy/cadence tests, offscreen shared-shader image tests and a compiled native D3D11 self-test executable.
- Retained two install choices, all 19 x64 loader names, six themes and five accents.

This is an experimental D3D11 SDR implementation. It adds latency and does not guarantee a displayed-FPS multiplier. Original rendering payloads and the official loader retain their pinned bytes. Affected Steam-game compatibility remains unverified.
