# SmoothMotion 2.8.3 RTX20 Preview 1

A built Windows x64 preview derived from your 2.8.2 R3 GP9 Fixes1 package.
It adds a Turing backend using NVIDIA's public hardware optical-flow API and
new image-space frame synthesis. It does **not** run or port NVIDIA's proprietary
Smooth Motion neural model, and it does not relabel SM86 kernels as SM75.

## Start here

1. Extract the **complete** ZIP into a new folder.
2. Run `Test/RTX20_SmokeTest.exe` first. It draws moving bars for 20 seconds.
   Press **F11** to compare interpolation on/off. Close the result message when done.
3. For a game, close it, run `SmoothMotion_Manager.exe`, select the actual
   **64-bit DirectX 11 game executable**, and install using your existing route.
4. Launch in **windowed or borderless SDR**, with HDR and in-game frame generation off.
   Interpolation starts automatically; **F11 toggles it**.
5. If the game has a frame limiter, start at half the display refresh rate
   (for example 60 FPS on a 120 Hz display). Generated pairs use VSync.

The Manager recognizes the exact native DLL and ASI from your supplied GP9
Fixes1 package and retains its file ownership, backup and uninstall logic.
Run `uninstall.bat` beside the game executable to remove the installed build.
Manual kits are in `Manual/`; use exactly one kit. Do not combine `version.dll`
with `new.asi`. Do not overwrite unrelated mod files.

## Implemented path and limits

| Item | This preview |
|---|---|
| GPU | NVIDIA Turing SM75 on the game's actual adapter; intended for RTX 2060/2070/2080 families |
| OS | Windows 10/11 x64 with D3D11.1 interfaces and an NVIDIA driver exposing NVOF API 2.0 |
| Graphics API | DirectX 11 |
| Display | Windowed/borderless, SDR, RGBA8 or BGRA8, single-sample backbuffer |
| Dimensions | 128–3840 wide and 128–2160 high, also checked against the driver's capabilities |
| Interpolation | One synthesized midpoint between consecutive accepted application frames |
| Pacing | Two VSync Present calls for each generated pair; adds latency and can limit base FPS |
| Unsupported | DX12, Vulkan, OpenGL, HDR/10-bit/float output, exclusive fullscreen, MSAA backbuffers, dirty/scroll presents |
| GPU validation | Not performed here; compatibility, output quality and performance remain unverified |

The CUDA toolkit and Optical Flow SDK do **not** need to be installed on the game PC.
The runtime loads `nvcuda.dll`, `nvofapi64.dll` and `d3dcompiler_47.dll` from Windows
System32. It uses the installed driver and never patches or replaces driver DLLs.
Other GPUs and unsupported presentation paths retain the game's original output.
A failed session stays disabled until the game is restarted or its swapchain is recreated.

## What the new backend does

It snapshots the current frame, keeps the previous accepted frame, obtains
forward/backward flow on Turing's optical-flow engine, and uses a new shader to
warp and combine the frames at their midpoint. It checks flow consistency and
uses current-frame pixels at uncertain occlusions. It restores the game's D3D11
pipeline state and original frame around the extra presentation.

No game motion vectors, depth buffer or HUD mask are available. Expect possible
artifacts around UI, disocclusions, fast motion, cuts and transparent objects.
This is an experimental optical-flow implementation, not a claim of native
Smooth Motion quality, lower latency, or a measured 2x performance improvement.

## Check results

`nvsmooth30.log` remains the log name for compatibility with the collector.
A current session identifies `2.8.3-rtx20-preview1` and backend
`Turing NVOF + custom synthesis`.

- `flow_pairs`: completed bidirectional optical-flow processing.
- `generated_present_accepted`: generated-frame Present calls returning S_OK.
- `real_present_accepted`: accepted application-frame presentations through the backend.
- `rtx20_failures`: failed backend sessions.
- `interpolation_verified`: deliberately remains false; API counters do not prove display output.

The hardware test writes `Test/rtx20-test-report.txt`. For game diagnostics, run
`Collect_Diagnostics.exe` and select the same game EXE. No upload happens automatically.
Source, build scripts, validation results and matching PDB files are included.
See `VALIDATION.md` for the checks actually completed. Older claims under
`history/GP9-Fixes1/` describe the input build, not this preview.
