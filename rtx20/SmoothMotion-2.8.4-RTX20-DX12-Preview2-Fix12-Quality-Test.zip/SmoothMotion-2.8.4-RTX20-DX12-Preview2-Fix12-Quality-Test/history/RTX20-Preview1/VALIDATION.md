# Validation — RTX20 Preview 1

## Completed

- Windows x64 cross-compilation with Zig 0.14.1: standalone proxy, ASI,
  installer, Manager, diagnostic collector, hardware test and shader test.
- 15 host suites / 30 successful optimized and ASan/UBSan runs. The suites cover
  Turing and format admission, history discontinuities, 32 generated/real Present
  failure combinations, installer file plans, uninstall ownership, API detection,
  import dispatch, COM hook transactions, initialization and proxy forwarding.
  LeakSanitizer was disabled because this execution environment does not support
  its process inspection; AddressSanitizer and UndefinedBehaviorSanitizer ran.
- All three HLSL entry points passed glslang 14.0.0 syntax compilation to SPIR-V.
  This is a syntax check, not execution of the Windows DXBC shaders.
- Minimal CUDA 2D-copy ABI size, alignment and field offsets matched NVIDIA's
  CUDA 12.6.77 header through compiler assertions.
- Runtime/helper source hashes, binary hashes, installer payload identities,
  Manager helper identities, manual/test carrier copies, and seven PE/PDB GUID
  and age matches passed verification.
- ZIP creation verifies every archived file against SHA256SUMS.txt.

## Not established

There is no NVIDIA GPU, Windows desktop or game in this build environment.
Windows binaries were not executed. A Wine-based shader compilation attempt
could not start because its required Unix socket operation was unavailable.

The NVOF session creation, CUDA/D3D11 interoperability, runtime DXBC compilation,
actual pixel output, display cadence, driver compatibility, image quality and
performance therefore remain **unverified on hardware**. The code has a real
flow/synthesis/presentation path, but cross-compilation and policy tests alone
cannot establish a working in-game port. No game is certified by this release.

The implementation is limited to D3D11 SDR windowed/borderless output. DX12,
HDR, Vulkan and OpenGL interpolation are not implemented. The proprietary
NVIDIA Smooth Motion model has not been ported.

## On the RTX20 PC

Run Test/ShaderCheck.exe, then Test/RTX20_SmokeTest.exe. During the 20-second
moving-bar test, press F11 to compare on/off. Check rtx20-test-report.txt for
nonzero flow_pairs and generated_present_accepted and inspect nvsmooth30.log
for errors. Those counters report API completion/acceptance; they do not measure
frames physically displayed. A visual/capture comparison is still necessary.

Machine-readable evidence is under validation/. Historical GP9 reports under
history/GP9-Fixes1/ concern the original package and are not RTX20 test results.
