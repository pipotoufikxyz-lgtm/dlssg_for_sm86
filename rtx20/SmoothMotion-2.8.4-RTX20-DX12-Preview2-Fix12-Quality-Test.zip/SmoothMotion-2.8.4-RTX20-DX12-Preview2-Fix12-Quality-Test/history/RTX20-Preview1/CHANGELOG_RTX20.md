# RTX20 Preview 1 changes

- New Turing backend using the public NVOF CUDA API with bidirectional 4x4 flow.
- New frame-synthesis shader with inverse warping and consistency-based occlusion handling.
- D3D11 pipeline-state preservation, adapter matching, CUDA context preservation,
  frame-history resets, supported-format checks, and original-frame restoration.
- Generated pairs use VSync; F11 toggles interpolation.
- Standalone version.dll and ASI built from the same RTX20 backend.
- Manager/installer updated for DX11 admission and exact GP9 Fixes1 upgrades.
- Hardware/shader test executables, source and debug symbols included.

Scope: experimental D3D11 SDR windowed/borderless implementation. The private
NVIDIA Smooth Motion neural model has not been ported. DX12 and GPU/game
validation remain outside the implemented/tested scope of this preview.
