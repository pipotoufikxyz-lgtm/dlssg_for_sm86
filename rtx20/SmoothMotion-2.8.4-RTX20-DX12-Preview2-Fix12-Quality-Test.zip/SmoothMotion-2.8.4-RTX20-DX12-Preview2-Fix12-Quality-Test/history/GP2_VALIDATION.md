# Validation — R3 GP2 picker/installer update

Baseline: delivered GP1 ZIP, SHA256
`e2116774875e130cbcfa8c15c0c9fb970427f6a9d4fa419082f2f000e5464a9e`.

## Completed

- Manager, installer and diagnostics collector cross-compiled for Windows x64.
- 37 suites in optimized and AddressSanitizer/UndefinedBehaviorSanitizer builds:
  74 successful host runs. The retained 35 suites cover GP1/R3 runtime behavior,
  Steam exclusions, upgrade/removal, ownership, graphics and Manager behavior.
- Production file_picker::choose executed through simulated COM APIs: protected
  EXE selection, normal manifest access validation, filter/title/initial folder,
  Unicode return values, cancellation, API errors and balanced COM ownership.
  The simulated protected-file refusal is disabled by the documented dialog flag;
  it is not an actual Windows common-dialog execution.
- Metadata policy and shared target dispatch: exact executable path, case/slash
  aliases, Unicode paths, default/explicit x64, rejected ARM64/x86/console/dev
  entries, duplicate matches, nested decoys, missing/incomplete structure, bounds,
  unsafe paths, preserved readable-PE result and fallback only on access denied.
- GameLaunchHelper exclusion and normal Game.exe eligibility in discovery tests.
- Full-document XML parsing is delegated to Windows XmlLite with DTDs prohibited
  and bounds applied. This adapter is cross-compiled, not executed on Linux.
- Native DLL/ASI and native symbols remain byte-for-byte GP1. Five binary/PDB
  GUID/age pairs and all source/build identities verified. Final package staging,
  four manual kits, ZIP CRC and every SHA256SUMS entry verified.

## Evidence

- validation/portable-normal.json — 74 host runs and tested source hashes.
- validation/package-normal.json — current build/helper/manual-kit consistency.
- validation/runtime-review-2.8.2-r3-gp1-normal.json — exact PDB matches; runtime
  label remains GP1 because its code/binaries did not change.
- validation/picker-update-gp2.json — GP1 baseline diff and unchanged runtime hashes.
- history/GP1_VALIDATION.md — earlier runtime repair scope.

## Windows check

Close the old Manager and open the freshly extracted GP2 Manager. Select the
actual Marvel demo Content\Game.exe; check that selection returns without the
French access-denied popup. A denied PE read should use exact readable Xbox
metadata and explicitly report that API/carrier imports could not be inspected.
With the game closed, review/install one route, then launch from the Xbox app.

If metadata, path attributes or destination writes are also denied, selection
cannot establish an installable target. Those errors remain explicit. Existing
file protections are preserved. No ACL/ownership changes or game-file patches
are used. Runtime GPU interpolation and the affected Game Pass games remain
unverified; passing host tests does not certify those behaviors.

Microsoft contracts:
- https://learn.microsoft.com/en-us/windows/win32/api/shobjidl_core/ne-shobjidl_core-_fileopendialogoptions
- https://learn.microsoft.com/en-us/gaming/gdk/docs/reference/system/microsoftgameconfig/elements/microsoftgameconfig-element-executable
- https://learn.microsoft.com/en-us/previous-versions/windows/desktop/ms752838(v=vs.85)
