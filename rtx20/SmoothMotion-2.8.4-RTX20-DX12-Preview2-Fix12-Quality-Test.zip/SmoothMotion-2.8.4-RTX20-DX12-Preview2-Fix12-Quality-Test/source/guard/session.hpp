#pragma once
#include <cstdint>
#include <string>
namespace sm86session {
struct Identity { std::uint32_t pid=0; std::uint64_t created=0; };
inline std::string encode(Identity i) { return "SM86-SESSION-1\n"+std::to_string(i.pid)+"\n"+std::to_string(i.created)+"\n"; }
inline bool parse(const std::string& s,Identity& out) {
    constexpr char prefix[]="SM86-SESSION-1\n";
    if(s.size()>128||s.compare(0,sizeof(prefix)-1,prefix)!=0)return false;
    std::size_t at=sizeof(prefix)-1;
    auto number=[&](std::uint64_t limit,std::uint64_t& v){v=0;std::size_t start=at;while(at<s.size()&&s[at]!='\n'){unsigned d=static_cast<unsigned char>(s[at++])-'0';if(d>9||v>(limit-d)/10)return false;v=v*10+d;}return at>start&&at<s.size()&&s[at++]=='\n'&&v!=0;};
    std::uint64_t pid=0,created=0;if(!number(UINT32_MAX,pid)||!number(UINT64_MAX,created)||at!=s.size())return false;
    out={static_cast<std::uint32_t>(pid),created};return true;
}
inline bool matches(Identity a,Identity b){return a.pid==b.pid&&a.created==b.created&&a.pid&&a.created;}
// An unexplained/nonzero exit keeps the startup interlock. This is a recovery
// heuristic, not attribution of the exit to this mod. A zero exit is not proof
// that generated frames worked, or that the program reached gameplay.
inline bool mayClear(std::uint32_t exitCode, bool querySucceeded){return querySucceeded&&exitCode==0;}
}
