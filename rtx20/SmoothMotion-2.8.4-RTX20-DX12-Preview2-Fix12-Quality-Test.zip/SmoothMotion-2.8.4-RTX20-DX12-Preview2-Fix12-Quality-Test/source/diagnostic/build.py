import sys
from pathlib import Path as _ToolPath
sys.path.insert(0,str(_ToolPath(__file__).resolve().parents[1]))
import build_toolchain
#!/usr/bin/env python3
"""Cross-build the read-only Windows x64 diagnostics collector with Zig 0.14.1."""
import argparse
import hashlib
import json
import pathlib
import subprocess

p = argparse.ArgumentParser()
build_toolchain.arguments(p)
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parent
version = build_toolchain.identity(a)
if a.zig and version != '0.14.1':
    raise SystemExit(f'Expected Zig 0.14.1, found {version}')
output = root / 'Collect_Diagnostics.exe'
command = [*build_toolchain.command(a,output), '-std=c++17', '-O2',
           '-DNDEBUG', '-Wall', '-Wextra', '-Werror', '-municode',
           str(root / 'collect_diagnostics.cpp'), '-lole32','-luuid','-luser32', '-lcomdlg32',
           '-lsetupapi', '-ladvapi32', '-lbcrypt', '-lshell32', '-lwevtapi', '-o', str(output)]
subprocess.run(command, check=True)
report = {'compiler': version, 'target': 'x86_64-windows-gnu',
          'bytes': output.stat().st_size,
          'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'native_windows_executed': False, 'command': command, 'source_sha256': {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['../build_toolchain.py','build.py','collect_diagnostics.cpp','collector_policy.hpp','crash_events.hpp','pe_reader.hpp','../setup/pe_reader.hpp','../setup/windows_pe.hpp','../setup/game_config_policy.hpp','../ui/file_picker.hpp','../native/include/nvs30/driver_file.hpp','../native/include/nvs30/driver_layout.hpp']}}
(root / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
