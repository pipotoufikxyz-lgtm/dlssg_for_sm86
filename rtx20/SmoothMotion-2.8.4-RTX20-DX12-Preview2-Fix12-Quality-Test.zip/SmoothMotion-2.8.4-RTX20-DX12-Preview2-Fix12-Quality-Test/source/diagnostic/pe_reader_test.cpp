#include "pe_reader.hpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
void put16(std::vector<unsigned char>&b,size_t p,uint16_t x){b[p]=x;b[p+1]=x>>8;}
void put32(std::vector<unsigned char>&b,size_t p,uint32_t x){for(unsigned i=0;i<4;++i)b[p+i]=x>>(8*i);}
std::vector<unsigned char> fixture(){std::vector<unsigned char>b(2048);put16(b,0,0x5a4d);put32(b,60,0x80);put32(b,0x80,0x4550);put16(b,0x84,0x8664);put16(b,0x86,1);put16(b,0x94,240);size_t o=0x98;put16(b,o,0x20b);put32(b,o+24,0x400000);put32(b,o+60,512);put32(b,o+108,16);size_t s=o+240;put32(b,s+12,0x1000);put32(b,s+16,1536);put32(b,s+20,512);return b;}
void fails(std::vector<unsigned char>b){static unsigned test=0;++test;bool did=false;try{preflight::PE(b.data(),b.size()).parse();}catch(const std::exception&){did=true;}if(!did)std::cerr<<"Malformed fixture did not fail: "<<test<<"\n";assert(did);}
int main(int argc,char**argv){auto b=fixture();auto x=preflight::PE(b.data(),b.size()).parse();assert(x.machine==0x8664&&x.plus&&x.direct.empty()&&x.delay.empty());put32(b,0x98+112+8,0x1000);put32(b,0x98+112+12,40);put32(b,512+12,0x1080);memcpy(b.data()+640,"VERSION.dll",12);x=preflight::PE(b.data(),b.size()).parse();assert(x.direct.size()==1&&preflight::named(x.direct,"version.dll"));put32(b,0x98+112+13*8,0x1100);put32(b,0x98+112+13*8+4,64);put32(b,768,1);put32(b,772,0x1180);memcpy(b.data()+896,"DXGI.dll",9);x=preflight::PE(b.data(),b.size()).parse();assert(preflight::named(x.delay,"dxgi.dll"));
 auto dll=b;put16(dll,0x80+22,0x2000);assert(preflight::PE(dll.data(),dll.size()).parse().dll);
 auto c=b;put32(c,0x98+112+12,20);fails(c);c=b;put32(c,512+12,0xfffffff0);fails(c);c=b;c.resize(60);fails(c);c=b;put32(c,60,0xfffffff0);fails(c);c=b;put32(c,512+12,0x15ff);c[2047]='A';fails(c);c=b;put16(c,0x86,100);fails(c);c=b;put32(c,772,0x300000);put32(c,768,0);fails(c);c=b;put32(c,0x98+112+13*8+4,0);fails(c);
 unsigned parsed=0;for(int i=1;i<argc;++i){std::ifstream f(argv[i],std::ios::binary);assert(f);std::vector<unsigned char>p((std::istreambuf_iterator<char>(f)),{});auto info=preflight::PE(p.data(),p.size()).parse();assert(info.machine==0x8664&&info.plus);std::cout<<argv[i]<<": "<<info.direct.size()<<" direct, "<<info.delay.size()<<" delay imports\n";++parsed;}std::cout<<"PASS: import/empty/delay/DLL cases,8 malformed fixtures,"<<parsed<<" supplied PE files\n";}
