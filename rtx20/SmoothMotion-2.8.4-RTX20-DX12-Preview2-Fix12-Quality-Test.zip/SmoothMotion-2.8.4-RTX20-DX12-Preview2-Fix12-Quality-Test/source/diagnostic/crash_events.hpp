#pragma once
// Read-only, exact-executable Windows Application Error evidence. No subprocess,
// publisher message expansion, registry edit, or raw/unrelated event output.
#include <algorithm>
#include <cstdint>
#include <map>
#include <ostream>
#include <string>
#include <string_view>
#include <vector>

namespace collector { namespace crash_event_policy {
inline constexpr std::size_t MaxXmlBytes=64*1024,MaxXmlUnits=MaxXmlBytes/2,MaxEvents=200;
struct WaitBudget {
 std::uint64_t started{};
 unsigned timeouts{};
 std::uint32_t waitMs(std::uint64_t now)const{
  const auto elapsed=now-started;
  return elapsed>=2000?0:static_cast<std::uint32_t>(std::min<std::uint64_t>(100,2000-elapsed));
 }
 bool retryTimeout(std::uint64_t now){return ++timeouts<32&&waitMs(now)!=0;}
};
inline constexpr wchar_t Query[]=L"*[System[Provider[@Name='Application Error'] and (EventID=1000) and TimeCreated[timediff(@SystemTime) >= 0 and timediff(@SystemTime) <= 86400000]]]";
struct Event {std::wstring appPath,time,pid,exception,module,modulePath,offset,reportId,appVersion;};
inline bool space(wchar_t c){return c==L' '||c==L'\t'||c==L'\r'||c==L'\n';}
inline bool scalar(std::uint32_t c){return c==9||c==10||c==13||(c>=0x20&&c<=0xd7ff)||(c>=0xe000&&c<=0xfffd)||(c>=0x10000&&c<=0x10ffff);}
inline void appendScalar(std::wstring& out,std::uint32_t c){if(sizeof(wchar_t)==2&&c>0xffff){c-=0x10000;out+=wchar_t(0xd800+(c>>10));out+=wchar_t(0xdc00+(c&1023));}else out+=wchar_t(c);}
inline bool decode(std::wstring_view raw,std::wstring& out){
 out.clear();if(raw.size()>MaxXmlUnits)return false;
 for(std::size_t i=0;i<raw.size();++i){std::uint32_t c=std::uint32_t(raw[i]);
  if(c==L'<')return false;
  if(c==L'&'){
   auto end=raw.find(L';',i+1);if(end==raw.npos||end-i>16)return false;const auto name=raw.substr(i+1,end-i-1);i=end;
   if(name==L"amp")c=L'&';else if(name==L"lt")c=L'<';else if(name==L"gt")c=L'>';else if(name==L"quot")c=L'"';else if(name==L"apos")c=L'\'';
   else if(name.size()>1&&name[0]==L'#'){
    const bool hex=name.size()>2&&(name[1]==L'x'||name[1]==L'X');std::size_t n=hex?2:1;if(n==name.size())return false;c=0;
    for(;n<name.size();++n){const auto ch=name[n];unsigned digit=ch>=L'0'&&ch<=L'9'?unsigned(ch-L'0'):hex&&ch>=L'a'&&ch<=L'f'?unsigned(ch-L'a'+10):hex&&ch>=L'A'&&ch<=L'F'?unsigned(ch-L'A'+10):99;if(digit>=(hex?16u:10u)||c>(0x10ffff-digit)/(hex?16u:10u))return false;c=c*(hex?16u:10u)+digit;}
   }else return false;
  }else if(sizeof(wchar_t)==2&&c>=0xd800&&c<=0xdbff){if(i+1>=raw.size())return false;const auto low=std::uint32_t(raw[++i]);if(low<0xdc00||low>0xdfff)return false;c=0x10000+((c-0xd800)<<10)+(low-0xdc00);}
  if(!scalar(c))return false;
  appendScalar(out,c);
 }
 return true;
}
inline std::wstring trim(std::wstring s){auto a=std::find_if_not(s.begin(),s.end(),space),b=std::find_if_not(s.rbegin(),s.rend(),space).base();return a>=b?L"":std::wstring(a,b);}
inline bool nameChar(wchar_t c){return(c>=L'a'&&c<=L'z')||(c>=L'A'&&c<=L'Z')||(c>=L'0'&&c<=L'9')||c==L'_'||c==L'-'||c==L'.'||c==L':';}
struct Tag {std::wstring name,text;std::map<std::wstring,std::wstring> attributes;};
inline bool parse(std::wstring_view xml,Event& result){
 result={};if(xml.empty()||xml.size()>MaxXmlUnits||xml.find(L'\0')!=xml.npos)return false;
 Event event;std::vector<Tag> stack;std::vector<std::wstring> dataNames;std::size_t at=0;bool root=false,closed=false,system=false,eventData=false,provider=false,eventId=false,created=false;
 auto skip=[&]{while(at<xml.size()&&space(xml[at]))++at;};
 auto name=[&](std::wstring& out){auto start=at;while(at<xml.size()&&nameChar(xml[at]))++at;if(at==start||at-start>128)return false;out=xml.substr(start,at-start);return true;};
 auto finish=[&](){
  const auto& tag=stack.back();
  if(stack.size()==3&&stack[1].name==L"System"&&tag.name==L"EventID"){if(trim(tag.text)!=L"1000")return false;}
  if(stack.size()==3&&stack[1].name==L"EventData"&&tag.name==L"Data"){
   auto attr=tag.attributes.find(L"Name");if(attr==tag.attributes.end()||attr->second.empty()||dataNames.size()>=64||std::find(dataNames.begin(),dataNames.end(),attr->second)!=dataNames.end())return false;dataNames.push_back(attr->second);
   const auto& field=attr->second;std::wstring* target=nullptr;
   if(field==L"AppPath")target=&event.appPath;else if(field==L"ProcessId")target=&event.pid;else if(field==L"ExceptionCode")target=&event.exception;else if(field==L"ModuleName")target=&event.module;else if(field==L"ModulePath")target=&event.modulePath;else if(field==L"FaultingOffset")target=&event.offset;else if(field==L"AppVersion")target=&event.appVersion;else if(field==L"IntegratorReportId"||field==L"ReportId")target=&event.reportId;
   if(target){if(!target->empty()||tag.text.size()>8192)return false;*target=tag.text;}
  }
  if(stack.size()==1)closed=true;
  stack.pop_back();return true;
 };
 skip();if(xml.substr(at,5)==L"<?xml"){auto end=xml.find(L"?>",at+5);if(end==xml.npos||end-at>256)return false;at=end+2;}
 while(at<xml.size()){
  if(xml[at]!=L'<'){auto end=xml.find(L'<',at);if(end==xml.npos)end=xml.size();std::wstring text;if(!decode(xml.substr(at,end-at),text))return false;if(stack.empty()){if(!std::all_of(text.begin(),text.end(),space))return false;}else if(stack.back().name==L"Data"||stack.back().name==L"EventID")stack.back().text+=text;at=end;continue;}
  ++at;if(at==xml.size()||xml[at]==L'!'||xml[at]==L'?')return false;
  if(xml[at]==L'/'){++at;std::wstring closing;if(!name(closing))return false;skip();if(at==xml.size()||xml[at++]!=L'>'||stack.empty()||stack.back().name!=closing||!finish())return false;continue;}
  if(closed||(!stack.empty()&&(stack.back().name==L"Data"||stack.back().name==L"EventID")))return false;
  Tag tag;if(!name(tag.name))return false;bool self=false;
  for(;;){const auto before=at;skip();if(at==xml.size())return false;if(xml[at]==L'>'){++at;break;}if(xml[at]==L'/'&&at+1<xml.size()&&xml[at+1]==L'>'){at+=2;self=true;break;}if(before==at||tag.attributes.size()>=16)return false;
   std::wstring key,value;if(!name(key))return false;skip();if(at==xml.size()||xml[at++]!=L'=')return false;skip();if(at==xml.size()||(xml[at]!=L'\''&&xml[at]!=L'"'))return false;const auto quote=xml[at++];auto end=xml.find(quote,at);if(end==xml.npos||!decode(xml.substr(at,end-at),value)||!tag.attributes.emplace(key,value).second)return false;at=end+1;
   if(key==L"xmlns"&&value!=L"http://schemas.microsoft.com/win/2004/08/events/event")return false;
  }
  if(stack.empty()){if(root||tag.name!=L"Event")return false;root=true;}
  else if(stack.size()==1&&tag.name==L"System"){if(system)return false;system=true;}
  else if(stack.size()==1&&tag.name==L"EventData"){if(eventData)return false;eventData=true;}
  else if(stack.size()==2&&stack[1].name==L"System"){
   if(tag.name==L"Provider"){if(provider||tag.attributes[L"Name"]!=L"Application Error")return false;provider=true;}
   else if(tag.name==L"EventID"){if(eventId)return false;eventId=true;}
   else if(tag.name==L"TimeCreated"){if(created)return false;created=true;event.time=tag.attributes[L"SystemTime"];if(event.time.empty()||event.time.size()>128)return false;}
  }
  if(stack.size()>=16)return false;
  stack.push_back(std::move(tag));if(self&&!finish())return false;
 }
 if(!stack.empty()||!root||!closed||!system||!eventData||!provider||!eventId||!created||event.appPath.empty())return false;
 result=std::move(event);return true;
}
inline bool normalAbsolute(std::wstring_view path){
 if(path.empty()||path.size()>32767)return false;
 for(std::size_t i=0;i<path.size();++i){const auto c=path[i];if(c<32||c==L'"'||c==L'<'||c==L'>'||c==L'|'||c==L'*'||c==L'?'||(c==L':'&&i!=1))return false;}
 const bool drive=path.size()>=3&&((path[0]>=L'A'&&path[0]<=L'Z')||(path[0]>=L'a'&&path[0]<=L'z'))&&path[1]==L':'&&(path[2]==L'\\'||path[2]==L'/');
 const bool unc=path.size()>5&&path[0]==L'\\'&&path[1]==L'\\'&&path[2]!=L'.'&&path[2]!=L'\\'&&path.find(L'\\',2)!=path.npos;
 return drive||unc;
}
template<class Canonical,class Equal> bool matches(const Event& event,const std::wstring& selected,Canonical canonical,Equal equal){if(!normalAbsolute(selected)||!normalAbsolute(event.appPath))return false;auto path=canonical(event.appPath);return !path.empty()&&equal(path,selected);}
inline std::string oneLine(std::wstring_view value){
 std::string out;for(std::size_t i=0;i<value.size();++i){std::uint32_t c=std::uint32_t(value[i]);if(sizeof(wchar_t)==2&&c>=0xd800&&c<=0xdbff&&i+1<value.size()){const auto low=std::uint32_t(value[++i]);c=0x10000+((c-0xd800)<<10)+(low-0xdc00);}
  if(c==L'\n'){out+="\\n";continue;}if(c==L'\r'){out+="\\r";continue;}if(c==L'\t'){out+="\\t";continue;}if(c==L'\\'){out+="\\\\";continue;}if(c==L'"'){out+="\\\"";continue;}if(c<32||c==127){out+="?";continue;}
  if(c<=0x7f)out+=char(c);else if(c<=0x7ff){out+=char(0xc0|(c>>6));out+=char(0x80|(c&63));}else if(c<=0xffff){out+=char(0xe0|(c>>12));out+=char(0x80|((c>>6)&63));out+=char(0x80|(c&63));}else{out+=char(0xf0|(c>>18));out+=char(0x80|((c>>12)&63));out+=char(0x80|((c>>6)&63));out+=char(0x80|(c&63));}
 }return out;
}
inline void write(const Event& event,std::ostream& out){
 const auto field=[&](const char* name,const std::wstring& value){if(!value.empty())out<<"    "<<name<<"=\""<<oneLine(value)<<"\"\n";};
 field("time_utc",event.time);field("faulting_process_id",event.pid);field("exception_code",event.exception);field("fault_module",event.module);field("fault_module_path",event.modulePath);field("fault_offset",event.offset);field("report_id",event.reportId);field("app_version",event.appVersion);
}
} }

#ifdef _WIN32
#include <windows.h>
#include <winevt.h>
namespace collector { namespace crash_event_detail {
struct EventHandle {EVT_HANDLE value=nullptr;explicit EventHandle(EVT_HANDLE h=nullptr):value(h){}~EventHandle(){if(value)EvtClose(value);}EventHandle(const EventHandle&)=delete;EventHandle& operator=(const EventHandle&)=delete;};
inline std::wstring canonical(const std::wstring& path){
 if(!crash_event_policy::normalAbsolute(path))return {};
 const DWORD needed=GetFullPathNameW(path.c_str(),0,nullptr,nullptr);if(!needed||needed>32768)return {};
 std::wstring result(needed,L'\0');const DWORD got=GetFullPathNameW(path.c_str(),needed,result.data(),nullptr);if(!got||got>=needed)return {};result.resize(got);return result;
}
inline bool equal(const std::wstring& a,const std::wstring& b){return CompareStringOrdinal(a.data(),int(a.size()),b.data(),int(b.size()),TRUE)==CSTR_EQUAL;}
inline bool render(EVT_HANDLE handle,crash_event_policy::Event& event){
 DWORD needed=0,count=0;if(EvtRender(nullptr,handle,EvtRenderEventXml,0,nullptr,&needed,&count)||GetLastError()!=ERROR_INSUFFICIENT_BUFFER||needed<sizeof(wchar_t)||needed>crash_event_policy::MaxXmlBytes||needed%sizeof(wchar_t))return false;
 std::vector<wchar_t> xml(needed/sizeof(wchar_t));DWORD used=0;
 if(!EvtRender(nullptr,handle,EvtRenderEventXml,needed,xml.data(),&used,&count)||used<sizeof(wchar_t)||used>needed||used%sizeof(wchar_t))return false;
 const auto end=xml.begin()+used/sizeof(wchar_t),zero=std::find(xml.begin(),end,L'\0');if(zero==end)return false;
 return crash_event_policy::parse(std::wstring_view(xml.data(),std::size_t(zero-xml.begin())),event);
}
} // namespace crash_event_detail
inline void crashEvents(const std::wstring& gameExe,std::ostream& out){
 using namespace crash_event_detail;
 out<<"\nRecent Windows Application Error events (last 24 hours; exact selected executable)\n";
 const auto selected=canonical(gameExe);const DWORD attributes=selected.empty()?INVALID_FILE_ATTRIBUTES:GetFileAttributesW(selected.c_str());
 if(attributes==INVALID_FILE_ATTRIBUTES||(attributes&FILE_ATTRIBUTE_DIRECTORY)){out<<"  Unavailable: selected executable is not an existing normal absolute file path.\n";return;}
 EventHandle query(EvtQuery(nullptr,L"Application",crash_event_policy::Query,EvtQueryChannelPath|EvtQueryReverseDirection));
 if(!query.value){out<<"  Unavailable: Event Log query failed (Win32 "<<GetLastError()<<").\n";return;}
 std::size_t scanned=0,matched=0,skipped=0;DWORD ended=ERROR_SUCCESS;
 crash_event_policy::WaitBudget budget{GetTickCount64()};
 for(;scanned<crash_event_policy::MaxEvents;){
  const DWORD wait=budget.waitMs(GetTickCount64());
  if(!wait){ended=ERROR_TIMEOUT;break;}
  EventHandle event;DWORD returned=0;
  if(!EvtNext(query.value,1,&event.value,wait,0,&returned)){
   ended=GetLastError();
   if(ended==ERROR_TIMEOUT&&budget.retryTimeout(GetTickCount64()))continue;
   break;
  }
  if(returned!=1||!event.value){ended=ERROR_INVALID_DATA;break;}++scanned;
  crash_event_policy::Event data;if(!render(event.value,data)){++skipped;continue;}
  if(!crash_event_policy::matches(data,selected,canonical,equal))continue;
  out<<"  Matching event "<<++matched<<":\n";crash_event_policy::write(data,out);
 }
 out<<"  Matched="<<matched<<"; inspected="<<scanned<<"; malformed/oversized/render failures="<<skipped<<".\n";
 if(scanned==crash_event_policy::MaxEvents)out<<"  Stopped at the 200-event inspection limit; additional events were not examined.\n";
 else if(ended!=ERROR_NO_MORE_ITEMS&&ended!=ERROR_SUCCESS)out<<"  Enumeration stopped (Win32 "<<ended<<"); the available evidence may be incomplete.\n";
 if(!matched)out<<"  No exact-path match in the inspected events; absence does not establish that the game did not crash.\n";
}
}
#endif
