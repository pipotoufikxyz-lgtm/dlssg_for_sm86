#include "collector_policy.hpp"
#include <cassert>
#include <iostream>

int main() {
    unsigned cases=0;
    auto ini=collector::iniValues("[GlobalSets]\nLoadPlugins=1\nLoadFromAPI=\nLoadExtraPlugins=C:\\secret\\plugin.asi\nPassword=hunter2\n[FileLoader]\nOverloadFromFolder=\n");
    assert(ini.size()==4&&ini[0].key=="loadplugins"&&ini[0].value=="1"&&ini[1].value=="<empty>");
    assert(ini[2].value=="<set; value not collected>"&&ini[3].value=="<empty>");++cases;
    assert(collector::iniValues("[Credentials]\ndebug=true\n").empty());++cases;
    ini=collector::iniValues("[SmoothMotion]\nENABLE_OSD=0\nBASE_FPS_CAP=59.94\n");
    assert(ini.size()==2&&ini[1].value=="59.94");++cases;
    ini=collector::iniValues("\xef\xbb\xbf[GlobalSets]\nLoadPlugins=1\n");assert(ini.size()==1);++cases;
    std::string wide="\xff\xfe";
    for(char c:std::string("[GlobalSets]\nLoadPlugins=1\n")){wide+=c;wide+='\0';}
    ini=collector::iniValues(wide);assert(ini.size()==1&&ini[0].value=="1");++cases;
    auto json=collector::jsonValues("{\"debug\":true,\"writeStatus\":true,\"password\":\"secret\",\"mode\":\"driver\",\"multiplier\":2}");
    assert(json.size()==4&&json[0].value=="true"&&json[2].value=="driver"&&json[3].value=="2");++cases;
    json=collector::jsonValues("{\"debug\":\"secret\\nvalue\",\"mode\":\"C:/private/file\"}");
    assert(json.size()==2&&json[0].value=="<non-simple value; not collected>"&&json[1].value=="<non-simple value; not collected>");++cases;
    json=collector::jsonValues("{\"secret\":\"\\\"debug\\\":true\",\"writestatus\":false}");
    assert(json.size()==1&&json[0].key=="writestatus"&&json[0].value=="false");++cases;
    json=collector::jsonValues("{\"nested\":{\"debug\":true},\"mode\":{\"secret\":\"x\"}}");
    assert(json.size()==1&&json[0].key=="debug");++cases;
    assert(collector::jsonValues(std::string(collector::ConfigLimit+1,'x')).empty());
    assert(collector::iniValues(std::string(collector::ConfigLimit+1,'x')).empty());++cases;
    std::string repeated="[GlobalSets]\n";for(int i=0;i<256;++i)repeated+="LoadPlugins=1\n";
    assert(collector::iniValues(repeated).size()==128);++cases;
    json=collector::jsonValues("{\"debug\":\"unterminated");assert(json.empty());++cases;
    assert(collector::safeValue("mode",std::string(81,'a'))=="<non-simple value; not collected>");++cases;
    std::cout<<"PASS: "<<cases<<" bounded config/redaction fixtures.\n";
}
