#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commdlg.h>
#include <setupapi.h>
#include <bcrypt.h>
#include <shlobj.h>
#include "collector_policy.hpp"
#include "../ui/file_picker.hpp"
#include "crash_events.hpp"
#include "../setup/windows_pe.hpp"
#include "../native/include/nvs30/driver_file.hpp"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {
constexpr std::uint64_t HashLimit=512ull*1024*1024;
const GUID DisplayClass={0x4d36e968,0xe325,0x11ce,{0xbf,0xc1,0x08,0x00,0x2b,0xe1,0x03,0x18}};
struct Handle {
    HANDLE value=INVALID_HANDLE_VALUE;
    explicit Handle(HANDLE h=INVALID_HANDLE_VALUE):value(h) {}
    ~Handle(){if(value!=INVALID_HANDLE_VALUE&&value!=nullptr)CloseHandle(value);}
    Handle(const Handle&)=delete;
    Handle& operator=(const Handle&)=delete;
    explicit operator bool()const{return value!=INVALID_HANDLE_VALUE&&value!=nullptr;}
};
struct RegistryKey {HKEY value=nullptr;~RegistryKey(){if(value)RegCloseKey(value);}};
std::string utf8(const std::wstring& text) {
    if(text.empty())return {};
    const int bytes=WideCharToMultiByte(CP_UTF8,0,text.data(),static_cast<int>(text.size()),nullptr,0,nullptr,nullptr);
    if(bytes<=0)return "<encoding error>";
    std::string out(static_cast<std::size_t>(bytes),'\0');
    WideCharToMultiByte(CP_UTF8,0,text.data(),static_cast<int>(text.size()),out.data(),bytes,nullptr,nullptr);
    return out;
}
std::string printable(const std::string& raw) {
    std::string out;out.reserve(raw.size());
    for(unsigned char c:raw) {
        if(c<32&&c!='\n'&&c!='\r'&&c!='\t') {
            char buffer[5];std::snprintf(buffer,sizeof(buffer),"\\x%02x",c);out+=buffer;
        } else out+=static_cast<char>(c);
    }
    return out;
}
std::wstring absolute(const std::wstring& path) {
    const DWORD required=GetFullPathNameW(path.c_str(),0,nullptr,nullptr);
    if(!required||required>32768)return path;
    std::wstring out(required,L'\0');
    const DWORD actual=GetFullPathNameW(path.c_str(),required,out.data(),nullptr);
    if(!actual||actual>=required)return path;
    out.resize(actual);return out;
}
std::wstring parent(const std::wstring& path) {
    const auto slash=path.find_last_of(L"\\/");
    return slash==std::wstring::npos?L".":path.substr(0,slash);
}
std::wstring join(const std::wstring& dir,const wchar_t* relative) {return dir+L"\\"+relative;}
// Do not follow a plugin/config/log link outside the selected game folder.
// The selected game folder itself may legitimately be on a mounted/junctioned
// Steam library; only descendants used by this collector are checked here.
bool linkedRelative(const std::wstring& base,const wchar_t* relative,std::wstring& blocked) {
    std::wstring path=base,remaining=relative;std::size_t begin=0;
    while(begin<remaining.size()) {
        const auto end=remaining.find_first_of(L"\\/",begin);
        path+=L"\\"+remaining.substr(begin,end==std::wstring::npos?std::wstring::npos:end-begin);
        const DWORD attributes=GetFileAttributesW(path.c_str());
        if(attributes==INVALID_FILE_ATTRIBUTES)return false;
        if(attributes&FILE_ATTRIBUTE_REPARSE_POINT){blocked=path;return true;}
        begin=end==std::wstring::npos?remaining.size():end+1;
    }
    return false;
}
std::wstring env(const wchar_t* name) {
    const DWORD needed=GetEnvironmentVariableW(name,nullptr,0);
    if(!needed||needed>32768)return {};
    std::wstring text(needed,L'\0');
    const DWORD got=GetEnvironmentVariableW(name,text.data(),needed);
    if(!got||got>=needed)return {};
    text.resize(got);return text;
}
std::string systemTime(const SYSTEMTIME& time) {
    char out[40];std::snprintf(out,sizeof(out),"%04u-%02u-%02uT%02u:%02u:%02uZ",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond);
    return out;
}
std::string fileTime(const FILETIME& time) {
    SYSTEMTIME utc={};return FileTimeToSystemTime(&time,&utc)?systemTime(utc):"unavailable";
}
bool metadata(const std::wstring& path,WIN32_FILE_ATTRIBUTE_DATA& data) {
    return GetFileAttributesExW(path.c_str(),GetFileExInfoStandard,&data)!=FALSE;
}
std::uint64_t length(const WIN32_FILE_ATTRIBUTE_DATA& data) {
    return (static_cast<std::uint64_t>(data.nFileSizeHigh)<<32)|data.nFileSizeLow;
}
std::string hashFile(const std::wstring& path) {
    Handle file(CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,nullptr));
    if(!file)return "unavailable (open Win32 "+std::to_string(GetLastError())+")";
    BY_HANDLE_FILE_INFORMATION before={},after={};
    if(!GetFileInformationByHandle(file.value,&before))return "unavailable (file information failed)";
    const std::uint64_t bytes=(static_cast<std::uint64_t>(before.nFileSizeHigh)<<32)|before.nFileSizeLow;
    if(bytes>HashLimit)return "skipped (greater than 512 MiB limit)";
    BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
    const NTSTATUS opened=BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0);
    if(opened<0)return "unavailable (BCrypt provider failed)";
    DWORD objectLength=0,received=0;std::string result;
    if(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objectLength),sizeof(objectLength),&received,0)<0||objectLength>1024*1024) {
        BCryptCloseAlgorithmProvider(algorithm,0);return "unavailable (BCrypt object size failed)";
    }
    std::vector<unsigned char> object(objectLength),chunk(64*1024);unsigned char digest[32]={};
    if(BCryptCreateHash(algorithm,&hash,object.data(),objectLength,nullptr,0,0)<0) {
        BCryptCloseAlgorithmProvider(algorithm,0);return "unavailable (BCrypt hash failed)";
    }
    std::uint64_t total=0;bool okay=true;
    for(;;) {
        DWORD read=0;
        if(!ReadFile(file.value,chunk.data(),static_cast<DWORD>(chunk.size()),&read,nullptr)){okay=false;break;}
        if(!read)break;
        total+=read;
        if(total>HashLimit||BCryptHashData(hash,chunk.data(),read,0)<0){okay=false;break;}
    }
    if(okay&&total==bytes&&BCryptFinishHash(hash,digest,sizeof(digest),0)>=0&&GetFileInformationByHandle(file.value,&after)&&
       before.nFileSizeHigh==after.nFileSizeHigh&&before.nFileSizeLow==after.nFileSizeLow&&
       CompareFileTime(&before.ftLastWriteTime,&after.ftLastWriteTime)==0) {
        static constexpr char hex[]="0123456789abcdef";
        result.reserve(64);for(unsigned char c:digest){result+=hex[c>>4];result+=hex[c&15];}
    } else result="unavailable (read failed or file changed during collection)";
    BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);return result;
}
void fileInfo(const std::wstring& path,std::ostringstream& report,bool hash) {
    report<<"  "<<printable(utf8(path))<<"\n";
    WIN32_FILE_ATTRIBUTE_DATA data={};
    if(!metadata(path,data)) {report<<"    absent or inaccessible (Win32 "<<GetLastError()<<")\n";return;}
    if(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){report<<"    directory, not a file\n";return;}
    report<<"    bytes="<<length(data)<<"; modified UTC="<<fileTime(data.ftLastWriteTime)<<"\n";
    if(data.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)report<<"    reparse point: reads may resolve to another target\n";
    if(hash)report<<"    SHA256="<<hashFile(path)<<"\n";
}
bool readFile(const std::wstring& path,std::size_t limit,std::string& result,bool tail,std::uint64_t& total,DWORD& error) {
    result.clear();error=0;total=0;
    Handle file(CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr));
    if(!file){error=GetLastError();return false;}
    LARGE_INTEGER size={};
    if(!GetFileSizeEx(file.value,&size)||size.QuadPart<0){error=GetLastError();return false;}
    total=static_cast<std::uint64_t>(size.QuadPart);
    if(total>limit&&!tail){error=ERROR_FILE_TOO_LARGE;return false;}
    const auto count=static_cast<DWORD>(std::min<std::uint64_t>(total,limit));
    if(tail&&total>limit) {
        LARGE_INTEGER position;position.QuadPart=static_cast<LONGLONG>(total-limit);
        if(!SetFilePointerEx(file.value,position,nullptr,FILE_BEGIN)){error=GetLastError();return false;}
    }
    result.resize(count);DWORD got=0;
    if(count&&(!ReadFile(file.value,result.data(),count,&got,nullptr)||got!=count)) {
        error=GetLastError();if(!error)error=ERROR_HANDLE_EOF;result.clear();return false;
    }
    return true;
}
bool gameInfo(const std::wstring& game,std::ostringstream& report) {
    fileInfo(game,report,false);
    try {
        const auto pe=preflight::inspectFile(game);
        const bool x64=pe.plus&&pe.machine==0x8664&&!pe.dll;
        report<<"  PE machine=0x"<<std::hex<<pe.machine<<std::dec<<"; optional header="<<(pe.plus?"PE32+":"PE32")<<"\n";
        report<<"  PE DLL flag="<<(pe.dll?"YES (not a game executable)":"NO")<<"\n";
        report<<"  AMD64/x64 executable package match: "<<(x64?"YES":"NO")<<"\n";
        report<<"  Direct DLL imports:";for(const auto& name:pe.direct)report<<" "<<name;if(pe.direct.empty())report<<" (none)";report<<"\n";
        report<<"  Delay DLL imports:";for(const auto& name:pe.delay)report<<" "<<name;if(pe.delay.empty())report<<" (none)";report<<"\n";
        report<<"  A missing direct proxy import does not prove a DLL cannot load transitively.\n";
        return x64;
    }catch(const std::exception& error){report<<"  PE scan rejected file: "<<error.what()<<"\n";return false;}
}
std::wstring regString(HKEY root,const std::wstring& subkey,const wchar_t* name) {
    RegistryKey key;
    if(RegOpenKeyExW(root,subkey.c_str(),0,KEY_QUERY_VALUE|KEY_WOW64_64KEY,&key.value)!=ERROR_SUCCESS)return {};
    DWORD type=0,size=0;
    if(RegQueryValueExW(key.value,name,nullptr,&type,nullptr,&size)!=ERROR_SUCCESS||
       (type!=REG_SZ&&type!=REG_EXPAND_SZ)||size>32768||size%sizeof(wchar_t))return {};
    std::vector<wchar_t> value(size/sizeof(wchar_t)+1,0);
    if(RegQueryValueExW(key.value,name,nullptr,&type,reinterpret_cast<BYTE*>(value.data()),&size)!=ERROR_SUCCESS)return {};
    value.back()=0;return std::wstring(value.data());
}
bool regDword(HKEY root,const std::wstring& subkey,const wchar_t* name,DWORD& value) {
    RegistryKey key;
    if(RegOpenKeyExW(root,subkey.c_str(),0,KEY_QUERY_VALUE|KEY_WOW64_64KEY,&key.value)!=ERROR_SUCCESS)return false;
    DWORD type=0,size=sizeof(value);
    return RegQueryValueExW(key.value,name,nullptr,&type,reinterpret_cast<BYTE*>(&value),&size)==ERROR_SUCCESS&&type==REG_DWORD&&size==sizeof(value);
}
void machineInfo(std::ostringstream& report) {
    report<<"\nWINDOWS AND CPU (read-only registry/system enumeration)\n";
    const std::wstring version=L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
    for(const wchar_t* key:{L"ProductName",L"DisplayVersion",L"CurrentBuildNumber",L"EditionID",L"InstallationType"}) {
        const auto value=regString(HKEY_LOCAL_MACHINE,version,key);
        report<<"  "<<utf8(key)<<"="<<(value.empty()?"<unavailable>":printable(utf8(value)))<<"\n";
    }
    DWORD revision=0;if(regDword(HKEY_LOCAL_MACHINE,version,L"UBR",revision))report<<"  Build revision (UBR)="<<revision<<"\n";
    report<<"  Registry ProductName may retain an older marketing name; build number is recorded separately.\n";
    SYSTEM_INFO info={};GetNativeSystemInfo(&info);
    report<<"  Native architecture="<<info.wProcessorArchitecture<<" (9=AMD64, 12=ARM64); logical processors="<<info.dwNumberOfProcessors<<"\n";
    const std::wstring cpu=L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0";
    for(const wchar_t* key:{L"ProcessorNameString",L"VendorIdentifier",L"Identifier"}) {
        const auto value=regString(HKEY_LOCAL_MACHINE,cpu,key);
        report<<"  CPU "<<utf8(key)<<"="<<(value.empty()?"<unavailable>":printable(utf8(value)))<<"\n";
    }
}
std::wstring deviceProperty(HDEVINFO list,SP_DEVINFO_DATA& device,DWORD property) {
    DWORD type=0,needed=0;
    SetupDiGetDeviceRegistryPropertyW(list,&device,property,&type,nullptr,0,&needed);
    if(!needed||needed>32768||needed%sizeof(wchar_t))return {};
    std::vector<wchar_t> text(needed/sizeof(wchar_t)+1,0);
    if(!SetupDiGetDeviceRegistryPropertyW(list,&device,property,&type,reinterpret_cast<BYTE*>(text.data()),needed,nullptr)||
       (type!=REG_SZ&&type!=REG_MULTI_SZ))return {};
    text.back()=0;return std::wstring(text.data());
}
void gpuInfo(std::ostringstream& report) {
    report<<"\nPRESENT DISPLAY ADAPTERS (SetupAPI; no graphics device created)\n";
    HDEVINFO list=SetupDiGetClassDevsW(&DisplayClass,nullptr,nullptr,DIGCF_PRESENT);
    if(list==INVALID_HANDLE_VALUE){report<<"  Enumeration failed (Win32 "<<GetLastError()<<")\n";return;}
    using StoreLocation=BOOL(WINAPI*)(PCWSTR,PSP_ALTPLATFORM_INFO,PCWSTR,PWSTR,DWORD,PDWORD);
    StoreLocation storeLocation=nullptr;
    const HMODULE setup=GetModuleHandleW(L"setupapi.dll");
    const FARPROC storeAddress=setup?GetProcAddress(setup,"SetupGetInfDriverStoreLocationW"):nullptr;
    static_assert(sizeof(storeLocation)==sizeof(storeAddress),"Windows function pointer width");
    std::memcpy(&storeLocation,&storeAddress,sizeof(storeLocation));
    unsigned found=0;std::vector<std::wstring> inspectedRuntime;
    for(DWORD index=0;index<64;++index) {
        SP_DEVINFO_DATA device={};device.cbSize=sizeof(device);
        if(!SetupDiEnumDeviceInfo(list,index,&device)){
            const DWORD error=GetLastError();if(error!=ERROR_NO_MORE_ITEMS)report<<"  Enumeration stopped (Win32 "<<error<<")\n";break;
        }
        ++found;const auto name=deviceProperty(list,device,SPDRP_DEVICEDESC);
        const auto hardware=deviceProperty(list,device,SPDRP_HARDWAREID);
        const auto driver=deviceProperty(list,device,SPDRP_DRIVER);
        report<<"  Adapter "<<found<<": "<<printable(utf8(name))<<"\n";
        report<<"    Hardware ID="<<printable(utf8(hardware))<<"\n";
        if(driver.empty()){report<<"    Driver class key unavailable\n";continue;}
        const std::wstring key=L"SYSTEM\\CurrentControlSet\\Control\\Class\\"+driver;
        for(const wchar_t* field:{L"DriverVersion",L"DriverDate",L"ProviderName",L"InfPath"}) {
            const auto value=regString(HKEY_LOCAL_MACHINE,key,field);
            report<<"    "<<utf8(field)<<"="<<(value.empty()?"<unavailable>":printable(utf8(value)))<<"\n";
        }
        std::wstring upper=hardware;for(wchar_t& c:upper)if(c>=L'a'&&c<=L'z')c=static_cast<wchar_t>(c-L'a'+L'A');
        if(upper.find(L"VEN_10DE")==std::wstring::npos)continue;
        const auto inf=regString(HKEY_LOCAL_MACHINE,key,L"InfPath");
        if(inf.empty()||inf.find_first_of(L"\\/:\r\n")!=std::wstring::npos){report<<"    Installed NVIDIA INF path unavailable or unexpected\n";continue;}
        wchar_t windows[32768]={};const UINT windowsLength=GetWindowsDirectoryW(windows,32768);
        if(!windowsLength||windowsLength>=32768)continue;
        const auto installed=std::wstring(windows)+L"\\INF\\"+inf;
        if(!storeLocation){report<<"    DriverStore lookup API unavailable\n";continue;}
        DWORD required=0;storeLocation(installed.c_str(),nullptr,nullptr,nullptr,0,&required);
        if(!required||required>32768){report<<"    Active package DriverStore resolution unavailable (Win32 "<<GetLastError()<<")\n";continue;}
        std::wstring store(required,L'\0');
        if(!storeLocation(installed.c_str(),nullptr,nullptr,store.data(),required,nullptr)){report<<"    DriverStore resolution failed (Win32 "<<GetLastError()<<")\n";continue;}
        store.resize(std::wcslen(store.c_str()));const auto runtime=join(parent(store),L"NvPresent64.dll");
        if(std::find(inspectedRuntime.begin(),inspectedRuntime.end(),runtime)==inspectedRuntime.end()) {
            inspectedRuntime.push_back(runtime);
            report<<"    NvPresent file in this installed display driver's package (not loaded/tested):\n";
            fileInfo(runtime,report,true);
            nvs30::driver_file::File file;const bool accepted=file.inspect(runtime);
            report<<"    Normal 2.8.2 CPU layout validation="<<(accepted?"accepted":"rejected")<<"; "<<file.error<<"; Win32="<<file.win32Error<<"\n";
            report<<"    NvPresent executable code SHA256="<<file.codeDigest<<"\n";
            report<<"    This is a read-only file check, not GPU or game execution.\n";
        }
    }
    if(!found)report<<"  No present display-class devices returned. This is not proof no GPU exists.\n";
    SetupDiDestroyDeviceInfoList(list);
}
void configuration(const std::wstring& gameDir,std::ostringstream& report) {
    report<<"\nSAFE CONFIGURATION EXCERPTS (known keys only; not an effective-settings evaluator)\n";
    static const wchar_t* configs[]={
        L"SM86\\backend_config.json",L"SM86\\motion.ini",L"RTXMFG\\config.json",L"smooth_motion.ini",
        L"version.ini",L"dinput8.ini",L"dxgi.ini",L"winmm.ini",L"dsound.ini",L"winhttp.ini",
        L"xinput1_3.ini",L"xinput1_4.ini",L"xinput9_1_0.ini",L"xinput1_1.ini",L"xinput1_2.ini",L"xinputuap.ini",
        L"binkw64.ini",L"bink2w64.ini",L"d3d11.ini",L"d3d12.ini",L"wininet.ini",L"d3d9.ini",L"d3d10.ini",
        L"global.ini",L"scripts\\global.ini",L"plugins\\global.ini",L"update\\global.ini"};
    for(const wchar_t* relative:configs) {
        const auto path=join(gameDir,relative);WIN32_FILE_ATTRIBUTE_DATA data={};
        std::wstring blocked;
        if(linkedRelative(gameDir,relative,blocked)){report<<"  "<<printable(utf8(path))<<"\n    skipped: reparse point beneath selected folder at "<<printable(utf8(blocked))<<"\n";continue;}
        if(!metadata(path,data))continue;
        report<<"  "<<printable(utf8(path))<<"\n";
        std::string content;std::uint64_t total=0;DWORD error=0;
        if(!readFile(path,collector::ConfigLimit,content,false,total,error)){report<<"    unreadable or over 256 KiB (Win32 "<<error<<")\n";continue;}
        const auto entries=std::wstring(relative).find(L".json")!=std::wstring::npos?collector::jsonValues(content):collector::iniValues(content);
        for(const auto& entry:entries)report<<"    ["<<entry.section<<"] "<<entry.key<<"="<<entry.value<<"\n";
        if(entries.empty())report<<"    no recognized simple settings found\n";
    }
    report<<"  Override order and backend interpretation are not inferred by this collector.\n";
    for(const auto* name:{L"SM86_NVPRESENT_PATH",L"SM86_ENABLE_D3D11_BRIDGE",L"SM86_DIAGNOSTICS",L"SM86_FORCE_VSYNC"}){
        const auto value=env(name);report<<"  "<<utf8(name)<<"="<<(value.empty()?"<unset or empty>":printable(utf8(value)))<<"\n";
    }
    const auto custom=env(L"RTX40_MFG_CONFIG_PATH");
    report<<"  RTX40_MFG_CONFIG_PATH="<<(custom.empty()?"<unset or empty>":printable(utf8(custom)))<<"\n";
    if(!custom.empty())report<<"  The environment override path is recorded, but its file is not opened by this collector.\n";
}
void logs(const std::wstring& gameDir,std::ostringstream& report) {
    report<<"\nCURRENT FILES AT THE SELECTED LOCATION\n";
    report<<"These are existing file contents read now, not a claim about who produced them,\nwhich installation wrote them, or whether they describe this collector's run.\n";
    for(const wchar_t* relative:{L"nvsmooth30.log",L"nvsmooth30-init-exception.log",L"SM86\\bootstrap.log",L"SM86\\exception.log",L"SM86\\runtime-status.json",L"SM86\\menu.log"}) {
        const auto path=join(gameDir,relative);report<<"\n  Expected log/status file: "<<printable(utf8(path))<<"\n";
        std::wstring blocked;
        if(linkedRelative(gameDir,relative,blocked)){report<<"    skipped: reparse point beneath selected folder at "<<printable(utf8(blocked))<<"\n";continue;}
        WIN32_FILE_ATTRIBUTE_DATA data={};
        if(!metadata(path,data)){report<<"    absent or inaccessible (Win32 "<<GetLastError()<<")\n";continue;}
        report<<"    bytes="<<length(data)<<"; modified UTC="<<fileTime(data.ftLastWriteTime)<<"\n";
        std::string contents;std::uint64_t total=0;DWORD error=0;
        if(!readFile(path,collector::LogTailLimit,contents,true,total,error)){report<<"    read failed (Win32 "<<error<<")\n";continue;}
        report<<"----- BEGIN "<<utf8(relative)<<" ("<<(total>collector::LogTailLimit?"last 64 KiB; earlier content omitted":"complete within 64 KiB limit")<<") -----\n";
        report<<printable(contents)<<"\n----- END "<<utf8(relative)<<" -----\n";
    }
    // Collect at most four recent custom-renderer status files, without
    // following linked directories/files or reading unrelated JSON names.
    std::wstring motionBlocked;
    if(!linkedRelative(gameDir,L"SM86",motionBlocked)){
        std::vector<WIN32_FIND_DATAW> recent;WIN32_FIND_DATAW entry{};
        const auto pattern=join(gameDir,L"SM86\\motion-*.json");HANDLE search=FindFirstFileW(pattern.c_str(),&entry);
        if(search!=INVALID_HANDLE_VALUE){
            struct CloseSearch{HANDLE handle;~CloseSearch(){FindClose(handle);}} close{search};
            unsigned scanned=0;
            do{
                if(++scanned>4096){report<<"  Motion status enumeration reached its limit.\n";break;}
                if(entry.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))continue;
                const std::wstring name=entry.cFileName;auto separator=name.find(L'-',7);
                if(name.rfind(L"motion-",0)!=0||name.size()<15||name.substr(name.size()-5)!=L".json"||separator==name.npos||separator==7||separator>=name.size()-6)continue;
                bool numeric=true;for(size_t i=7;i<name.size()-5;++i)if(i!=separator&&(name[i]<L'0'||name[i]>L'9'))numeric=false;
                if(numeric)recent.push_back(entry);
            }while(FindNextFileW(search,&entry));
        }
        std::sort(recent.begin(),recent.end(),[](const auto& a,const auto& b){return CompareFileTime(&a.ftLastWriteTime,&b.ftLastWriteTime)>0;});
        if(recent.size()>4)recent.resize(4);
        for(const auto& item:recent){
            const auto relative=std::wstring(L"SM86\\")+item.cFileName;std::wstring blocked;
            if(linkedRelative(gameDir,relative.c_str(),blocked))continue;
            std::string content;std::uint64_t total=0;DWORD error=0;
            report<<"\n  Custom motion status: "<<printable(utf8(relative))<<"; modified UTC="<<fileTime(item.ftLastWriteTime)<<"\n";
            if(readFile(join(gameDir,relative.c_str()),4096,content,false,total,error))report<<printable(content)<<"\n";
            else report<<"    unavailable or over 4 KiB (Win32 "<<error<<")\n";
        }
    }
    report<<"\nEarlier mod log locations (metadata only, contents not collected):\n";
    for(const wchar_t* relative:{L"sm86_loader.log",L"sm86_stability.log",L"sm86_exception.log",L"smooth_motion.log",L"smooth_mfg.log"}) {
        const auto path=join(gameDir,relative);WIN32_FILE_ATTRIBUTE_DATA data={};
        if(metadata(path,data))fileInfo(path,report,false);
    }
}
bool save(const std::wstring& folder,const std::wstring& filename,const std::string& text,std::wstring& actual,DWORD& error) {
    const int created=SHCreateDirectoryExW(nullptr,folder.c_str(),nullptr);
    if(created!=ERROR_SUCCESS&&created!=ERROR_ALREADY_EXISTS&&created!=ERROR_FILE_EXISTS){error=static_cast<DWORD>(created);return false;}
    actual=join(folder,filename.c_str());
    Handle file(CreateFileW(actual.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr));
    if(!file){error=GetLastError();return false;}
    const std::string content="\xef\xbb\xbf"+text+"\nREPORT SAVED: "+printable(utf8(actual))+"\n";
    DWORD written=0;
    if(!WriteFile(file.value,content.data(),static_cast<DWORD>(content.size()),&written,nullptr)||written!=content.size()||!FlushFileBuffers(file.value)) {
        error=GetLastError();if(!error)error=ERROR_WRITE_FAULT;
        CloseHandle(file.value);file.value=INVALID_HANDLE_VALUE;DeleteFileW(actual.c_str());
        return false;
    }
    error=0;return true;
}
std::wstring localFallback() {
    wchar_t appData[MAX_PATH]={};
    if(SUCCEEDED(SHGetFolderPathW(nullptr,CSIDL_LOCAL_APPDATA,nullptr,SHGFP_TYPE_CURRENT,appData)))return join(appData,L"SM86\\Diagnostics");
    wchar_t temp[32768]={};const DWORD len=GetTempPathW(32768,temp);
    return len&&len<32768?join(std::wstring(temp,len),L"SM86-Diagnostics"):L"";
}
} // namespace

int wmain(int argc,wchar_t** argv) {
    SetConsoleOutputCP(CP_UTF8);
    const bool interactive=argc<2;std::wstring game;
    DWORD consoleProcesses[2]={};
    const bool showCompletion=interactive||GetConsoleProcessList(consoleProcesses,2)==1;
    if(interactive) {
        try{game=file_picker::choose(nullptr,L"Select the actual game EXE to collect local diagnostics");}
        catch(const std::exception&){MessageBoxW(nullptr,L"The file picker failed. You can drag the game EXE onto Collect_Diagnostics.exe instead.",L"SM86 diagnostics",MB_OK|MB_ICONERROR);return 2;}
        if(game.empty())return 0;
    } else {
        game=argv[1];
        if(game==L"--help"||game==L"/?") {
            std::cout<<"Collect_Diagnostics.exe [absolute\\path\\to\\game.exe]\nNo argument opens a file picker. The game is not launched.\n";return 0;
        }
    }
    if(game.size()>=2&&game.front()==L'"'&&game.back()==L'"')game=game.substr(1,game.size()-2);
    if(game.empty()){std::cout<<"No game executable path was supplied.\n";return 2;}
    game=absolute(game);const auto gameDir=parent(game);
    SYSTEMTIME now={};GetSystemTime(&now);std::ostringstream report;
    report<<"SM86 LOCAL DIAGNOSTIC COLLECTION 1.4\nUTC: "<<systemTime(now)<<"\n";
    report<<"Collector bitness: x64. It does not explicitly load/execute game, mod, or NVIDIA runtime DLLs.\n";
    report<<"No GPU device, debugger, injection, process launch, upload, or online service is used.\n";
    report<<"This report contains local paths, bounded native/initializer/legacy logs, and matching recent Windows crash records.\n";
    report<<"It does not query account records, computer names, serial numbers, or unrelated folders.\n";
    report<<"Local paths and existing mod logs may themselves contain identifying text.\n";
    report<<"GAME RUNTIME RESULT: NOT TESTED. This collector cannot prove or diagnose a crash by itself.\n\nSELECTED EXECUTABLE\n";
    const bool validGame=gameInfo(game,report);
    machineInfo(report);gpuInfo(report);
    report<<"\nKNOWN LOCAL PROXY / PLUGIN FILES (fixed names only; no recursive scan)\n";
    static const wchar_t* binaries[]={
        L"version.dll",L"dinput8.dll",L"dxgi.dll",L"winmm.dll",L"dsound.dll",L"winhttp.dll",
        L"d3d11.dll",L"d3d12.dll",L"d3d9.dll",L"d3d10.dll",L"wininet.dll",
        L"xinput1_3.dll",L"xinput1_4.dll",L"xinput9_1_0.dll",L"xinput1_1.dll",L"xinput1_2.dll",L"xinputuap.dll",
        L"binkw64.dll",L"bink2w64.dll",L"binkw64Hooked.dll",L"bink2w64Hooked.dll",L"dbghelp.dll",L"sm86_support.dll",L"version (11).dll",L"new.asi",
        L"plugins\\SM86Bootstrap.asi",L"SM86\\backend.asi",L"SM86\\SM86_Menu.exe",L"SM86\\SM86_Guard.exe",L"plugins\\new.asi",L"scripts\\new.asi"};
    for(const wchar_t* relative:binaries) {
        std::wstring blocked;
        if(linkedRelative(gameDir,relative,blocked))report<<"  "<<printable(utf8(join(gameDir,relative)))<<"\n    skipped: reparse point beneath selected folder at "<<printable(utf8(blocked))<<"\n";
        else fileInfo(join(gameDir,relative),report,true);
    }
    report<<"\nMENU AUTOSTART MARKER (presence disables automatic menu launch)\n";
    std::wstring markerBlocked;
    if(linkedRelative(gameDir,L"SM86\\menu.disabled",markerBlocked))report<<"  Marker is redirected; not inspected.\n";
    else fileInfo(join(gameDir,L"SM86\\menu.disabled"),report,false);
    for(const wchar_t* marker:{L"SM86\\session.pending",L"SM86\\backend.disabled"}){std::wstring blocked;if(linkedRelative(gameDir,marker,blocked))report<<"  Recovery marker is redirected; not inspected.\n";else fileInfo(join(gameDir,marker),report,false);}
    configuration(gameDir,report);logs(gameDir,report);
    collector::crashEvents(game,report);
    report<<"\nSTATIC COLLECTION RESULT: "<<(validGame?"Selected executable is AMD64/x64.":"Selected executable could not be validated as AMD64/x64.")<<"\n";
    report<<"No result about game startup, Smooth Motion compatibility, or generated frames is inferred.\n";
    wchar_t filename[128];std::swprintf(filename,128,L"diagnostics-%04u%02u%02u-%02u%02u%02u-%lu.txt",now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,GetCurrentProcessId());
    std::wstring actual;DWORD error=0;
    std::wstring blockedOutput;
    bool saved=false;
    if(linkedRelative(gameDir,L"SM86",blockedOutput)) {
        error=ERROR_ACCESS_DENIED;
        report<<"\nPrimary output folder is a reparse point; using a per-user fallback.\n";
    } else saved=save(join(gameDir,L"SM86"),filename,report.str(),actual,error);
    if(!saved) {
        report<<"\nPrimary report location was not writable (Win32 "<<error<<"); using a per-user fallback.\n";
        const auto fallback=localFallback();
        if(!fallback.empty())saved=save(fallback,filename,report.str(),actual,error);
        if(!saved) {
            wchar_t temp[32768]={};const DWORD count=GetTempPathW(32768,temp);
            if(count&&count<32768) {
                const auto temporary=join(std::wstring(temp,count),L"SM86-Diagnostics");
                if(temporary!=fallback) {
                    report<<"\nPer-user report location failed (Win32 "<<error<<"); trying TEMP.\n";
                    saved=save(temporary,filename,report.str(),actual,error);
                }
            }
        }
    }
    std::cout<<report.str();
    if(saved)std::cout<<"\nReport saved: "<<utf8(actual)<<"\n";
    else std::cout<<"\nReport could not be saved (Win32 "<<error<<"). Copy this console text.\n";
    if(showCompletion) {
        const std::wstring message=saved?L"Diagnostic report saved:\n\n"+actual+L"\n\nIt includes existing logs and matching recent Windows crash records. The game was not started or tested.":L"The report could not be saved. Copy the console text. The game was not started or tested.";
        MessageBoxW(nullptr,message.c_str(),L"SM86 diagnostics",MB_OK|(saved?MB_ICONINFORMATION:MB_ICONERROR));
    }
    return saved?(validGame?0:2):3;
}
