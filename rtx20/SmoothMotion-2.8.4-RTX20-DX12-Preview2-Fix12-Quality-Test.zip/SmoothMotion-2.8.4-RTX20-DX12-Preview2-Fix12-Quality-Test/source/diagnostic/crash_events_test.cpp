#include "crash_events.hpp"
#include <iostream>
#include <sstream>
#include <stdexcept>
using namespace collector::crash_event_policy;
static unsigned checks=0;
void check(bool value){if(!value)throw std::runtime_error("Crash-event scenario "+std::to_string(checks+1)+" failed");++checks;}
std::wstring xml(const std::wstring& data,const std::wstring& extra=L""){
 return L"<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'><System><Provider Name='Application Error' Guid='{a}'/><EventID Qualifiers='0'>1000</EventID><Version>0</Version><Level>2</Level><TimeCreated SystemTime='2026-09-23T01:02:03.1234567Z'/><Execution ProcessID='9999' ThreadID='44'/><Computer>PRIVATE-COMPUTER</Computer><Security UserID='PRIVATE-USER'/></System><EventData>"+data+L"</EventData>"+extra+L"</Event>";
}
std::wstring replace(std::wstring text,const std::wstring& before,const std::wstring& after){const auto n=text.find(before);if(n==text.npos)throw std::runtime_error("Fixture fragment missing");text.replace(n,before.size(),after);return text;}
int main(){
 const auto fields=L"<Data Name='AppName'>SteamGame.exe</Data><Data Name='AppVersion'>1.0.0.0</Data><Data Name='ModuleName'>nvpresent64.dll</Data><Data Name='ExceptionCode'>c0000005</Data><Data Name='FaultingOffset'>0000000000123456</Data><Data Name='ProcessId'>0x1234</Data><Data Name='AppPath'>C:\\Games &amp; More\\SteamGame.exe</Data><Data Name='ModulePath'>C:\\Windows\\System32\\nvpresent64.dll</Data><Data Name='IntegratorReportId'>{1234-abcd}</Data><Data Name='PackageFullName'>PRIVATE-PACKAGE</Data>";
 const auto fixture=xml(fields);Event event;check(parse(fixture,event));
 check(event.appPath==L"C:\\Games & More\\SteamGame.exe"&&event.pid==L"0x1234"&&event.pid!=L"9999");
 check(event.exception==L"c0000005"&&event.module==L"nvpresent64.dll"&&event.offset==L"0000000000123456");
 check(event.time==L"2026-09-23T01:02:03.1234567Z"&&event.reportId==L"{1234-abcd}"&&event.appVersion==L"1.0.0.0");
 std::ostringstream report;write(event,report);const auto text=report.str();check(text.find("0x1234")!=text.npos&&text.find("nvpresent64.dll")!=text.npos);
 for(const auto* secret:{"PRIVATE-COMPUTER","PRIVATE-USER","PRIVATE-PACKAGE","9999","ThreadID","<Event"})check(text.find(secret)==text.npos);
 auto canonical=[](std::wstring p){for(auto& c:p){if(c==L'/')c=L'\\';if(c>=L'A'&&c<=L'Z')c+=32;}return p;};
 auto equal=[&](const auto& a,const auto& b){return canonical(a)==canonical(b);};
 check(matches(event,L"c:\\games & more\\steamgame.exe",canonical,equal));
 check(!matches(event,L"C:\\Other Game\\SteamGame.exe",canonical,equal));check(!matches(event,L"C:\\Games & More\\SteamGame.exe.old",canonical,equal));check(!matches(event,L"",canonical,equal));
 for(const auto* path:{L"SteamGame.exe",L"C:SteamGame.exe",L"\\Games\\SteamGame.exe",L"\\\\?\\C:\\Games\\SteamGame.exe",L"\\\\.\\C:\\Games\\SteamGame.exe",L"C:\\Games\\SteamGame.exe:stream",L"C:\\Game\nInjected.exe",L"C:\\Games\\*.exe"})check(!normalAbsolute(path));
 check(normalAbsolute(L"C:\\Games & More\\SteamGame.exe")&&normalAbsolute(L"\\\\server\\share\\SteamGame.exe"));
 std::wstring decoded;check(decode(L"&amp;&lt;&gt;&quot;&apos;",decoded)&&decoded==L"&<>\"'");
 check(decode(L"&#65;&#x42;&#X43;&#128512;",decoded)&&decoded.substr(0,3)==L"ABC"&&oneLine(decoded)=="ABC\xf0\x9f\x98\x80");
 check(decode(L"&amp;lt;",decoded)&&decoded==L"&lt;");
 for(const auto* entity:{L"&bogus;",L"&amp",L"&#;",L"&#x;",L"&#x110000;",L"&#55296;",L"&#0;",L"&#xFFFE;",L"&#99999999999999999;",L"<bad",L"&#12;"})check(!decode(entity,decoded));
 check(oneLine(L"a\r\nb\t\"\\") == "a\\r\\nb\\t\\\"\\\\");
 check(parse(L"<?xml version='1.0' encoding='utf-16'?>\n"+fixture,event));
 check(parse(replace(fixture,L"Name='AppPath'",L"Name=\"AppPath\""),event));
 check(parse(replace(fixture,L"IntegratorReportId",L"ReportId"),event));
 check(!parse(replace(fixture,L"Name='AppPath'",L"Name='OtherAppPath'"),event));
 check(!parse(replace(fixture,L"Name='AppPath'",L"Name='apppath'"),event));
 check(!parse(replace(fixture,L"Application Error",L"Other Provider"),event));
 check(!parse(replace(fixture,L">1000<",L">1001<"),event));
 check(!parse(replace(fixture,L"<EventID Qualifiers='0'>1000</EventID>",L"<EventID Qualifiers='0'/>"),event));
 check(!parse(replace(fixture,L"<TimeCreated SystemTime='2026-09-23T01:02:03.1234567Z'/>",L"<TimeCreated/>"),event));
 check(!parse(xml(std::wstring(fields)+L"<Data Name='AppPath'>C:\\Other\\SteamGame.exe</Data>"),event));
 check(!parse(xml(std::wstring(fields)+L"<Data Name='App&#80;ath'>C:\\Other\\SteamGame.exe</Data>"),event));
 check(!parse(replace(fixture,L"Name='AppPath'",L"Name='AppPath' Name='Other'"),event));
 check(!parse(replace(fixture,L"<Data Name='AppPath'>",L"<Data Name='AppPath'><Nested>"),event));
 check(!parse(replace(fixture,L"</EventData>",L"</Wrong>"),event));
 check(!parse(replace(fixture,L"<Data Name='AppPath'>",L"<Data Name='AppPath' Bad='&invalid;'>"),event));
 check(!parse(xml(L"<Wrapper><Data Name='AppPath'>C:\\Games &amp; More\\SteamGame.exe</Data></Wrapper>"),event));
 check(!parse(xml(L"<Data Name='AppName'>SteamGame.exe</Data>",L"<RenderingInfo><Data Name='AppPath'>C:\\Games &amp; More\\SteamGame.exe</Data></RenderingInfo>"),event));
 check(!parse(L"<!DOCTYPE Event [<!ENTITY x SYSTEM 'file:///secret'>]>"+fixture,event));
 check(!parse(replace(fixture,L"AppName'>SteamGame.exe",L"AppName'><![CDATA[SteamGame.exe]]>"),event));
 check(!parse(fixture+fixture,event));check(!parse(fixture.substr(0,fixture.size()-1),event));
 check(!parse(replace(fixture,L"http://schemas.microsoft.com/win/2004/08/events/event",L"other-namespace"),event));
 auto nul=fixture;nul.insert(10,1,L'\0');check(!parse(nul,event));
 check(!parse(xml(L"<Data Name='AppPath'>C:\\"+std::wstring(8193,L'a')+L"</Data>"),event));
 check(!parse(std::wstring(MaxXmlUnits+1,L'x'),event));
 std::wstring many;for(unsigned i=0;i<65;++i)many+=L"<Data Name='Other"+std::to_wstring(i)+L"'>x</Data>";check(!parse(xml(std::wstring(fields)+many),event));
 auto deep=fixture;for(unsigned i=0;i<20;++i)deep=replace(deep,L"<Version>0</Version>",L"<Wrapper><Version>0</Version></Wrapper>");check(!parse(deep,event));
 // Deterministic truncation and single-character mutation: parser must reject
 // or return fully validated named-field output; never access beyond a view.
 for(std::size_t n=0;n<fixture.size();++n)check(!parse(std::wstring_view(fixture.data(),n),event));
 for(std::size_t n=0;n<fixture.size();n+=3){auto changed=fixture;changed[n]=L'\0';check(!parse(changed,event));}
 check(MaxXmlBytes==65536&&MaxEvents==200&&std::wstring(Query).find(L"86400000")!=std::wstring::npos);
 // Results may not be immediately ready. A first timeout must allow another
 // bounded request, without extending the original enumeration deadline.
 WaitBudget budget{1000};
 check(budget.waitMs(1000)==100);
 check(budget.retryTimeout(1100)&&budget.waitMs(1100)==100);
 check(budget.waitMs(2999)==1);
 check(budget.waitMs(3000)==0&&!budget.retryTimeout(3000));
 check(budget.waitMs(999)==0);
 WaitBudget rapid{0};
 for(unsigned i=0;i<31;++i)check(rapid.retryTimeout(0));
 check(!rapid.retryTimeout(0));
 WaitBudget wraps{~std::uint64_t{0}-49};
 check(wraps.waitMs(0)==100&&wraps.waitMs(1950)==0);
 std::cout<<checks<<" bounded crash-event XML, exact-path privacy and output policy scenarios passed\n";
}
