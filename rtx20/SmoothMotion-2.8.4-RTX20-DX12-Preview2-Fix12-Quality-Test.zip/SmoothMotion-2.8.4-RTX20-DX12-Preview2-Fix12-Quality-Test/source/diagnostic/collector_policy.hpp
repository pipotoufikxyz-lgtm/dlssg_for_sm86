#pragma once
#include <algorithm>
#include <cstddef>
#include <string>
#include <vector>

namespace collector {
constexpr std::size_t ConfigLimit=256*1024;
constexpr std::size_t LogTailLimit=64*1024;
struct Entry { std::string section,key,value; };
inline std::string lower(std::string text) {
    for(char& c:text) if(c>='A'&&c<='Z') c=static_cast<char>(c-'A'+'a');
    return text;
}
inline std::string trim(const std::string& text) {
    const auto a=text.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return {};
    return text.substr(a,text.find_last_not_of(" \t\r\n")-a+1);
}
inline bool allowedSection(const std::string& section) {
    const auto s=lower(section);
    return s=="globalsets"||s=="fileloader"||s=="smoothmotion"||s=="sm86"||s=="sm86motion"||s=="bootstrap";
}
inline bool allowedKey(const std::string& key) {
    const auto k=lower(key);
    static const char* keys[]={
        "loadplugins","loadfromscriptsonly","loadrecursively","dontloadfromdllmain",
        "loadfromapi","loadextraplugins","disablecrashdumps","overloadfromfolder",
        "enable_osd","enable_d3d11_bridge","force_vsync","diagnostics","low_latency",
        "half_refresh_cap","base_fps_cap","debug","writestatus","kernelrebuild",
        "mode","multiplier","pacingmode","enabled","backend","overlay"};
    for(const char* candidate:keys) if(k==candidate) return true;
    return false;
}
inline bool pathLikeKey(const std::string& key) {
    const auto k=lower(key);
    return k=="loadextraplugins"||k=="overloadfromfolder"||k=="backend";
}
inline std::string safeValue(const std::string& key,std::string value) {
    value=trim(value);
    if(value.empty()) return "<empty>";
    // External plugin paths and unknown path-like content are presence-only.
    if(pathLikeKey(key)) return "<set; value not collected>";
    if(value.size()>80) return "<non-simple value; not collected>";
    for(unsigned char c:value) {
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||
             c=='_'||c=='-'||c=='.'||c=='+'||c==' '||c==','))
            return "<non-simple value; not collected>";
    }
    return value;
}
inline std::string decodeConfig(const std::string& raw) {
    if(raw.size()>=2&&((static_cast<unsigned char>(raw[0])==0xff&&static_cast<unsigned char>(raw[1])==0xfe)||
                      (static_cast<unsigned char>(raw[0])==0xfe&&static_cast<unsigned char>(raw[1])==0xff))) {
        const bool little=static_cast<unsigned char>(raw[0])==0xff;
        std::string out; out.reserve(raw.size()/2);
        for(std::size_t i=2;i+1<raw.size();i+=2) {
            const unsigned char low=static_cast<unsigned char>(raw[i+(little?0:1)]);
            const unsigned char high=static_cast<unsigned char>(raw[i+(little?1:0)]);
            out+=high==0?static_cast<char>(low):'?';
        }
        return out;
    }
    if(raw.size()>=3&&raw.compare(0,3,"\xef\xbb\xbf")==0) return raw.substr(3);
    return raw;
}
inline std::vector<Entry> iniValues(const std::string& raw) {
    if(raw.size()>ConfigLimit) return {};
    const std::string text=decodeConfig(raw);
    std::vector<Entry> entries; std::string section;
    std::size_t start=0;
    while(start<text.size()&&entries.size()<128) {
        const auto end=text.find('\n',start);
        const std::string line=trim(text.substr(start,end==std::string::npos?std::string::npos:end-start));
        start=end==std::string::npos?text.size():end+1;
        if(line.empty()||line[0]==';'||line[0]=='#') continue;
        if(line.front()=='['&&line.back()==']') {section=lower(trim(line.substr(1,line.size()-2)));continue;}
        const auto equals=line.find('=');
        if(equals==std::string::npos||!allowedSection(section)) continue;
        const std::string key=lower(trim(line.substr(0,equals)));
        if(!allowedKey(key)) continue;
        entries.push_back({section,key,safeValue(key,line.substr(equals+1))});
    }
    return entries;
}
// A bounded tokenizer, not a JSON configuration evaluator. Only exact allowlisted
// member names with simple scalar values are included; escaped strings, arrays,
// nested values, and arbitrary unrelated members are never printed.
inline std::vector<Entry> jsonValues(const std::string& raw) {
    if(raw.size()>ConfigLimit) return {};
    const std::string text=decodeConfig(raw); std::vector<Entry> entries;
    for(std::size_t i=0;i<text.size()&&entries.size()<128;) {
        if(text[i]!='"') {++i;continue;}
        const std::size_t begin=++i; bool escaped=false;
        while(i<text.size()&&text[i]!='"') {if(text[i]=='\\'){escaped=true;if(i+1<text.size())++i;}++i;}
        if(i>=text.size()) break;
        const std::string key=text.substr(begin,i-begin); ++i;
        while(i<text.size()&&(text[i]==' '||text[i]=='\r'||text[i]=='\n'||text[i]=='\t'))++i;
        if(i>=text.size()||text[i]!=':') continue;
        ++i;
        while(i<text.size()&&(text[i]==' '||text[i]=='\r'||text[i]=='\n'||text[i]=='\t'))++i;
        if(i>=text.size()) break;
        std::string value;
        if(text[i]=='"') {
            const auto valueBegin=++i; bool valueEscaped=false;
            while(i<text.size()&&text[i]!='"') {if(text[i]=='\\'){valueEscaped=true;if(i+1<text.size())++i;}++i;}
            if(i>=text.size()) break;
            value=valueEscaped?"<complex>":text.substr(valueBegin,i-valueBegin); ++i;
        } else if(text[i]=='['||text[i]=='{') {
            // Do not print this parent value; nested names can still be scanned.
            continue;
        } else {
            const auto valueBegin=i;
            while(i<text.size()&&text[i]!=','&&text[i]!='}'&&text[i]!=']'&&text[i]!='\n'&&text[i]!='\r')++i;
            value=trim(text.substr(valueBegin,i-valueBegin));
        }
        if(!escaped&&allowedKey(key)) entries.push_back({"json",lower(key),safeValue(key,value)});
    }
    return entries;
}
} // namespace collector
