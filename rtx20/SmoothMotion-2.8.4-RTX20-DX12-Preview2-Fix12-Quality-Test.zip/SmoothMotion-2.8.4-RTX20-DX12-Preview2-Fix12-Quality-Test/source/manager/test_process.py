#!/usr/bin/env python3
"""Exercise the production launcher with a Win32 contract double on Linux."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--cxx', default='g++')
p.add_argument('--output-dir')
a = p.parse_args()
root = Path(__file__).resolve().parent
out = Path(a.output_dir).resolve() if a.output_dir else root / 'test-output'
out.mkdir(parents=True, exist_ok=True)
common = [a.cxx, '-std=c++17', '-g', '-Wall', '-Wextra', '-Werror',
          '-I', str(root / 'test/win32'), str(root / 'test/process.cpp')]
asan = ['-O1', '-fsanitize=address,undefined', '-fsanitize-address-use-after-scope',
        '-fno-omit-frame-pointer']
environment = dict(os.environ)
# This host cannot run LeakSanitizer's thread inspection. ASan/UBSan and
# scope poisoning remain enabled; the double separately checks handle/list
# ownership on every path, including partial initialization failures.
environment['ASAN_OPTIONS'] = 'detect_leaks=0:halt_on_error=1'
environment['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
log = []
for mode, flags in [('sanitized', asan), ('optimized', ['-O2'])]:
    binary = out / ('launcher-' + mode)
    subprocess.run(common + flags + ['-o', str(binary)], check=True)
    result = subprocess.run([str(binary)], text=True, capture_output=True, env=environment)
    (out / f'launcher-{mode}.txt').write_text(result.stdout + result.stderr)
    if result.returncode or '31 launcher contract scenarios passed' not in result.stdout:
        raise RuntimeError(f'{mode} launcher test failed: {result.stdout}{result.stderr}')
    log.append(f'{mode}: {result.stdout.strip()}')

legacy = out / 'launcher-legacy-negative'
subprocess.run(common + asan + ['-DSM86_LEGACY_LIFETIME_PROBE', '-o', str(legacy)], check=True)
result = subprocess.run([str(legacy)], text=True, capture_output=True, env=environment)
(out / 'launcher-legacy-negative.txt').write_text(result.stdout + result.stderr)
if result.returncode == 0 or 'ERROR: AddressSanitizer: stack-use-after-scope' not in result.stderr:
    raise RuntimeError('The regression fixture did not reproduce the original lifetime failure')
log.append('legacy negative control: expected ASan stack-use-after-scope reproduced')
sources = ['process.hpp', 'test_process.py', 'test/process.cpp', 'test/win32/windows.h']
report = {
    'result': 'PASS', 'scenarios_per_configuration': 31,
    'configurations': ['ASan + UBSan + use-after-scope', 'O2'],
    'legacy_negative_control': 'expected stack-use-after-scope reproduced',
    'native_windows_executed': False,
    'scope': 'Actual process.hpp with a synthetic Win32 API contract; not an OS/GPU test',
    'source_sha256': {s: hashlib.sha256((root / s).read_bytes()).hexdigest() for s in sources}
}
(root / 'process-test-report.json').write_text(json.dumps(report, indent=2) + '\n')
(out / 'manager-launch-tests.txt').write_text('\n'.join(log) + '\n')
print('\n'.join(log))
