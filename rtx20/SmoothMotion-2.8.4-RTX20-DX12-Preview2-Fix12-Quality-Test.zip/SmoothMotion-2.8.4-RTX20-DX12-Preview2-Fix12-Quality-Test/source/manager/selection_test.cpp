#include "selection.hpp"
#include <climits>
#include <iostream>
#include <stdexcept>

int main(){
 unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("Stale menu selection regression");};
 std::vector<int> games{10,20};int setup=30,selected=1,focus=4,hover=560,pressed=560;bool menu=true;
 check(*manager_selection::current(games,selected,false,setup)==20);
 // Discovery completes while a native popup is open, replacing the library.
 manager_selection::clear(selected,menu,focus,hover,pressed);games={40};
 check(!menu&&selected==-1&&focus==-1&&hover==-1&&pressed==-1);
 check(manager_selection::current(games,selected,false,setup)==nullptr);
 // Previously queued commands and paint messages cannot dereference -1 or
 // an old selection beyond the size of the replacement collection.
 for(int stale:{INT_MIN,-1,1,2,INT_MAX})check(manager_selection::current(games,stale,false,setup)==nullptr);
 games.clear();check(manager_selection::current(games,0,false,setup)==nullptr);
 check(manager_selection::current(games,-1,true,setup)==&setup);
 games={40};check(*manager_selection::current(games,0,false,setup)==40);
 std::cout<<checks<<" stale menu, refreshed library and setup selection checks passed\n";
}
