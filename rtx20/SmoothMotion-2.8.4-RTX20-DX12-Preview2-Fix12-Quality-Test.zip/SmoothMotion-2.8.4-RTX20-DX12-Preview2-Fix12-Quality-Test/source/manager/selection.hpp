#pragma once
#include <cstddef>
#include <vector>

namespace manager_selection {
// Posted scan completions and modal Windows menus can invalidate an index.
// Resolve it again at the point of use, including during painting.
template<class Game> Game* current(std::vector<Game>& games,int selected,bool setupOpen,Game& setupGame) noexcept {
    if(setupOpen)return &setupGame;
    return selected>=0&&static_cast<std::size_t>(selected)<games.size()?&games[static_cast<std::size_t>(selected)]:nullptr;
}
inline void clear(int& selected,bool& menu,int& focus,int& hover,int& pressed) noexcept {
    selected=-1;menu=false;focus=hover=pressed=-1;
}
}
