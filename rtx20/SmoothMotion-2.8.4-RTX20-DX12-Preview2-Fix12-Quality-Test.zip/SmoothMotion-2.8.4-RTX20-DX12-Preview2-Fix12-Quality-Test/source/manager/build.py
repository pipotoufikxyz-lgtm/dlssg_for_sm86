import sys
from pathlib import Path as _ToolPath
sys.path.insert(0,str(_ToolPath(__file__).resolve().parents[1]))
import build_toolchain
import argparse,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser();build_toolchain.arguments(p);p.add_argument('--package-root');a=p.parse_args()
src=pathlib.Path(__file__).resolve().parent;root=pathlib.Path(a.package_root).resolve() if a.package_root else src.parent.parent
helpers={'installer':root/'Install.exe','collector':root/'Collect_Diagnostics.exe'}
if not helpers['collector'].exists():helpers['collector']=root/'diagnostic/Collect_Diagnostics.exe'
hashes={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in helpers.items()}
(src/'helper_identity.hpp').write_text('#pragma once\nnamespace helper_identity {\n'+''.join(f'inline constexpr char {k}[]="{v}";\n' for k,v in hashes.items())+'}\n')
out=root/'SmoothMotion_Manager.exe'
cmd=[*build_toolchain.command(a,out),'-std=c++17','-O2','-static','-municode','-DUNICODE','-D_UNICODE','-Wall','-Wextra','-Werror','-Wl,--subsystem,windows',str(src/'manager.cpp'),'-lwindowscodecs','-lwinhttp','-ld2d1','-ldwrite','-ldwmapi','-lshell32','-lxmllite','-lshlwapi','-lole32','-luuid','-lcomdlg32','-ladvapi32','-lbcrypt','-o',str(out)]
subprocess.run(cmd,check=True)
inputs=['../build_toolchain.py','build.py','selection.hpp','startup_log.hpp','manager.cpp','core.hpp','process.hpp','discovery.hpp','catalog.hpp','folder_scan.hpp','steam_metadata.hpp','art_policy.hpp','artwork.hpp','helper_identity.hpp',
        '../normal_policy.hpp','../motion/dx12_policy.hpp','../motion/identity.hpp','../ui/themes.hpp','../ui/localization.hpp','../setup/install_modes.hpp','../setup/payload_hashes.hpp','../ui/waterglass.hpp','../ui/native_glass.hpp','../ui/windows_backdrop.hpp','../guard/session.hpp','../setup/pe_reader.hpp','../setup/windows_pe.hpp','../setup/windows_game_target.hpp','../setup/game_config_policy.hpp','../ui/file_picker.hpp','../setup/import_graph.hpp','../setup/policy.hpp','../setup/protocol.hpp']
r={'compiler':build_toolchain.identity(a),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'helpers':hashes,
   'source_sha256':{name:hashlib.sha256((src/name).read_bytes()).hexdigest() for name in inputs},
   'native_windows_executed':False}
(src/'build-report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
