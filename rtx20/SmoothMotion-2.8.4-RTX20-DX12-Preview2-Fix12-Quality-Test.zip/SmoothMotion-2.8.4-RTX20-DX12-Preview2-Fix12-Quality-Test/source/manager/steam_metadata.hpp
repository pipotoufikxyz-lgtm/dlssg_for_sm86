#pragma once
#include "catalog.hpp"
#include <cstdint>
#include <map>
#include <set>
#include <stdexcept>
#include <string_view>
namespace steam_metadata {
struct Launch {std::string path,description;bool primary=false;};
struct App {std::string title,type;std::vector<Launch> launches;};
struct Node {std::string text;std::map<std::string,Node> children;const Node& at(const std::string& key)const{static const Node empty;auto i=children.find(key);return i==children.end()?empty:i->second;}};
class Reader {
 std::string_view data;size_t pos=0,end=0,nodes=0;std::vector<std::string_view> strings;bool table=false;
 [[noreturn]] void bad()const{throw std::runtime_error("Unsupported or incomplete Steam app cache");}
 void need(size_t n)const{if(pos>end||n>end-pos)bad();}
 unsigned byte(){need(1);return static_cast<unsigned char>(data[pos++]);}
 std::uint32_t u32(){need(4);std::uint32_t v=0;for(unsigned i=0;i<4;++i)v|=std::uint32_t(byte())<<(8*i);return v;}
 std::uint64_t u64(){auto lo=u32();return std::uint64_t(lo)|(std::uint64_t(u32())<<32);}
 void skip(size_t n){need(n);pos+=n;}
 std::string_view text(){auto start=pos;for(size_t n=0;n<=32768;++n)if(!byte())return data.substr(start,pos-start-1);bad();}
 Node object(unsigned depth){
  if(depth>24)bad();Node result;
  while(true){unsigned type=byte();if(type==8)return result;if(++nodes>50000)bad();std::string key;
   if(table){auto id=u32();if(id>=strings.size())bad();key=std::string(strings[id]);}else key=std::string(text());
   key=discovery::lower(key);if(result.children.count(key))bad();Node value;
   switch(type){case 0:value=object(depth+1);break;case 1:value.text=std::string(text());break;case 2:value.text=std::to_string(u32());break;
    case 3:case 4:case 6:skip(4);break;case 7:case 10:skip(8);break;
    case 5:{unsigned n=0;while(true){unsigned c=byte()|(byte()<<8);if(!c)break;if(++n>32768)bad();}break;}
    default:bad();
   }result.children.emplace(std::move(key),std::move(value));
  }
 }
 static App extract(const Node& root){
  App app;auto& info=root.at("appinfo");app.title=info.at("common").at("name").text;app.type=discovery::lower(info.at("common").at("type").text);
  for(const auto& pair:info.at("config").at("launch").children){auto& entry=pair.second;auto path=entry.at("executable").text,os=discovery::lower(entry.at("config").at("oslist").text),type=discovery::lower(entry.at("type").text);
   if(path.empty()||(!os.empty()&&os.find("windows")==os.npos)||type=="tool"||type=="server"||catalog::auxiliary(path))continue;
   if(app.launches.size()<64)app.launches.push_back({path,entry.at("description").text,pair.first=="0"});
  }return app;
 }
public:
 explicit Reader(std::string_view bytes):data(bytes),end(bytes.size()){}
 std::map<std::uint32_t,App> read(const std::set<std::uint32_t>& wanted){
  if(data.size()>256u*1024u*1024u)bad();auto magic=u32();if(magic<0x07564427||magic>0x07564429)bad();u32();table=magic==0x07564429;
  size_t recordsEnd=data.size();if(table){auto offset=u64();if(offset>data.size()||offset<16)bad();auto start=pos;recordsEnd=static_cast<size_t>(offset);pos=recordsEnd;auto count=u32();if(count>1000000)bad();strings.reserve(count);for(std::uint32_t i=0;i<count;++i)strings.push_back(text());pos=start;end=recordsEnd;}
  std::map<std::uint32_t,App> out;size_t records=0;
  while(pos<recordsEnd){auto id=u32();if(!id)return out;if(++records>500000)bad();auto size=u32();need(size);auto stop=pos+size;
   if(wanted.count(id)&&size<=2u*1024u*1024u){auto outer=end;end=stop;nodes=0;
    try{skip(magic==0x07564427?40:60);auto node=object(0);if(pos!=stop)bad();out[id]=extract(node);}catch(const std::runtime_error&){}end=outer;
   }pos=stop;
  }bad();
 }
};
inline std::map<std::uint32_t,App> parse(std::string_view data,const std::set<std::uint32_t>& wanted){try{return Reader(data).read(wanted);}catch(const std::runtime_error&){return {};}}
inline bool gameType(const std::string& type){return type.empty()||type=="game"||type=="demo"||type=="application"||type=="mod";}
}
