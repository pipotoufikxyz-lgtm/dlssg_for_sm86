#pragma once
#include "discovery.hpp"
#include <map>
#include <stdexcept>
namespace artwork {
enum class ImageRole{Any,Cover,Header};
inline bool dimensions(ImageRole role,unsigned w,unsigned h){
 if(w<32||h<32||w>8192||h>8192||std::uint64_t(w)*h>16000000)return false;
 if(role==ImageRole::Cover)return w>=300&&h>=450&&w*10>=h*5&&w*10<=h*8;
 if(role==ImageRole::Header)return w>=460&&h>=200&&w>=h*14/10&&w<=h*5;
 return true;
}
inline unsigned quality(ImageRole role,unsigned w,unsigned h){return dimensions(role,w,h)?w*h:0;}
inline std::string appId(const std::string& s){
 if(s.empty()||s.size()>10||s[0]=='0')return {};
 std::uint64_t n=0;for(char c:s){if(c<'0'||c>'9')return {};n=n*10+c-'0';}
 return n<=0xffffffffu?s:std::string{};
}
inline std::string normalized(std::string s){std::string o;for(unsigned char c:s){if(c>='A'&&c<='Z')c+=32;if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c>=128)o+=c;}return o;}
inline bool assetFilename(const std::string& name,const std::string& expected){
 if(name.empty()||name.size()>256||name[0]=='/'||name.find("..")!=name.npos)return false;
 for(unsigned char c:name)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='/'||c=='_'||c=='-'||c=='.'))return false;
 auto at=name.find_last_of('/');return name.substr(at==name.npos?0:at+1)==expected;
}
inline bool coverAsset(const std::string& name){for(const char* base:{"library_600x900.jpg","library_600x900_2x.jpg","library_capsule.jpg","library_capsule_2x.jpg","library_600x900.png","library_capsule.png","library_capsule_2x.png"})if(assetFilename(name,base))return true;return false;}
inline bool headerAsset(const std::string& name){for(const char* base:{"header.jpg","header_2x.jpg","header.png","header_2x.png"})if(assetFilename(name,base))return true;return false;}
inline bool sameMiss(const std::string& saved,const std::string& requested){return saved=="SM86-ART-MISS-3\n"+requested+"\n";}
struct Json {
 enum Type{nullValue,stringValue,numberValue,objectValue,arrayValue,boolValue} type=nullValue;
 std::string value;std::map<std::string,Json> object;std::vector<Json> array;
 const Json& at(const std::string& k)const{static const Json empty;auto i=object.find(k);return i==object.end()?empty:i->second;}
};
class Parser {
 const std::string& s;size_t at=0,nodes=0;
 void ws(){while(at<s.size()&&(s[at]==' '||s[at]=='\n'||s[at]=='\r'||s[at]=='\t'))++at;}
 [[noreturn]] void bad(){throw std::runtime_error("Invalid artwork metadata");}
 Json node(unsigned depth){
  if(depth>16||++nodes>12000)bad();ws();if(at==s.size())bad();Json j;char c=s[at];
  if(c=='"'){j.type=Json::stringValue;if(!discovery::quoted(s,at,j.value,true))bad();return j;}
  if(c=='{'||c=='['){++at;j.type=c=='{'?Json::objectValue:Json::arrayValue;ws();char end=c=='{'?'}':']';if(at<s.size()&&s[at]==end){++at;return j;}
   for(;;){ws();std::string key;if(c=='{'){if(!discovery::quoted(s,at,key,true))bad();ws();if(at==s.size()||s[at++]!=':')bad();if(j.object.count(key))bad();}auto v=node(depth+1);if(c=='{')j.object.emplace(key,std::move(v));else j.array.push_back(std::move(v));ws();if(at==s.size())bad();char sep=s[at++];if(sep==end)return j;if(sep!=',')bad();}
  }
  auto begin=at;while(at<s.size()&&s[at]!=','&&s[at]!=']'&&s[at]!='}'&&s[at]!=' '&&s[at]!='\r'&&s[at]!='\n'&&s[at]!='\t')++at;
  j.value=s.substr(begin,at-begin);if(j.value=="null")j.type=Json::nullValue;else if(j.value=="true"||j.value=="false")j.type=Json::boolValue;else{
   // Numeric IDs only need integers; reject non-JSON tokens as well.
   size_t p=0;if(p<j.value.size()&&j.value[p]=='-')++p;auto digits=[&](){size_t start=p;while(p<j.value.size()&&j.value[p]>='0'&&j.value[p]<='9')++p;return p>start;};
   if(p<j.value.size()&&j.value[p]=='0')++p;else if(!digits())bad();if(p<j.value.size()&&j.value[p]=='.'){++p;if(!digits())bad();}if(p<j.value.size()&&(j.value[p]=='e'||j.value[p]=='E')){++p;if(p<j.value.size()&&(j.value[p]=='+'||j.value[p]=='-'))++p;if(!digits())bad();}if(p!=j.value.size())bad();j.type=Json::numberValue;
  }return j;
 }
public:explicit Parser(const std::string& text):s(text){}Json parse(){if(s.size()>2*1024*1024)bad();auto j=node(0);ws();if(at!=s.size())bad();return j;}
};
inline std::vector<std::string> assetChoices(const std::string& metadata,const std::string& id,ImageRole role){
 std::vector<std::string> result;
 auto add=[&](const std::string& name){if((role==ImageRole::Cover?coverAsset(name):headerAsset(name))&&std::find(result.begin(),result.end(),name)==result.end())result.push_back(name);};
 if(!metadata.empty())try{
  auto json=Parser(metadata).parse();
  for(const auto& item:json.at("response").at("store_items").array){
   if(appId(item.at("id").value)!=id||item.at("success").value!="1")continue;
   const auto& assets=item.at("assets");
   if(role==ImageRole::Cover){add(assets.at("library_capsule_2x").value);add(assets.at("library_capsule").value);}
   else {add(assets.at("header_2x").value);add(assets.at("header").value);}
  }
 }catch(const std::exception&){}
 if(role==ImageRole::Cover){add("library_600x900_2x.jpg");add("library_600x900.jpg");add("library_capsule_2x.jpg");add("library_capsule.jpg");}
 else{add("header_2x.jpg");add("header.jpg");}
 return result;
}
inline std::string exactMatch(const std::string& text,const std::string& title){
 auto q=normalized(title);if(q.size()<3)return {};auto j=Parser(text).parse();std::string match;
 for(auto& item:j.at("items").array){auto id=appId(item.at("id").value);if(item.at("type").value!="app"||id.empty()||normalized(item.at("name").value)!=q)continue;if(!match.empty()&&match!=id)return {};match=id;}
 return match;
}
}
