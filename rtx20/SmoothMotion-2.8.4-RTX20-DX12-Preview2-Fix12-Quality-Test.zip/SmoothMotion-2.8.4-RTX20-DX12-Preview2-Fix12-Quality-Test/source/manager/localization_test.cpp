#include "../ui/localization.hpp"
#include <array>
#include <cstdlib>
#include <iostream>
#include <set>

using namespace manager_localization;
static unsigned checks = 0;
static void check(bool value) {
    ++checks;
    if (!value) { std::cerr << "localization check failed: " << checks << '\n'; std::exit(1); }
}
static std::array<unsigned, 10> placeholders(std::wstring_view text) {
    std::array<unsigned, 10> result{};
    for (std::size_t i = 0; i + 2 < text.size(); ++i)
        if (text[i] == L'{' && text[i + 1] >= L'0' && text[i + 1] <= L'9' && text[i + 2] == L'}')
            ++result[unsigned(text[i + 1] - L'0')];
    return result;
}
int main() {
    using L = Language;
    for (unsigned value = 0; value != 3; ++value) {
        const auto language = static_cast<L>(value);
        auto loaded = L::Automatic;
        check(readPreference(preference(language), loaded) && loaded == language);
        check(commandLanguage(commandName(language), loaded) && loaded == language);
    }
    for (std::string_view invalid : {"", "0", "SM86-LANGUAGE-1\n", "SM86-LANGUAGE-1\n3\n",
                                    "SM86-LANGUAGE-1\n-1\n", "SM86-LANGUAGE-1\n1\nextra",
                                    "SM86-LANGUAGE-2\n1\n", "SM86-LANGUAGE-1\r\n2\r\n"}) {
        auto unchanged = L::English;
        check(!readPreference(invalid, unchanged) && unchanged == L::English);
    }
    check(preference(static_cast<L>(0xffffffffu)) == preference(L::Automatic));
    const auto valid = preference(L::SimplifiedChinese);
    for (std::size_t length = 0; length < valid.size(); ++length) {
        auto unchanged = L::English;
        check(!readPreference(std::string_view(valid.data(), length), unchanged) && unchanged == L::English);
    }
    for (std::uint16_t id : {0x0004, 0x0804, 0x1004, 0x0404, 0x0c04}) {
        check(resolve(L::Automatic, id) == L::SimplifiedChinese);
        check(resolve(L::English, id) == L::English);
    }
    for (std::uint16_t id : {0x0409, 0x0809, 0x040c, 0x0411, 0x0000}) {
        check(resolve(L::Automatic, id) == L::English);
        check(resolve(L::SimplifiedChinese, id) == L::SimplifiedChinese);
    }
    auto parsed = L::English;
    check(commandLanguage(L"zh-Hans", parsed) && parsed == L::SimplifiedChinese);
    check(!commandLanguage(L"zh", parsed) && parsed == L::SimplifiedChinese);
    check(!commandLanguage(L"--apply", parsed) && parsed == L::SimplifiedChinese);
    check(!commandLanguage(L"zh-CN extra", parsed));
    check(std::wstring_view(languageName(L::SimplifiedChinese)) == L"简体中文");
    check(std::wstring_view(locale(L::SimplifiedChinese)) == L"zh-CN");
    check(std::wstring_view(fontFamily(L::SimplifiedChinese)) == L"Microsoft YaHei UI");

    std::set<std::wstring_view> keys;
    for (const auto& entry : catalog) {
        check(!entry.english.empty() && !entry.chinese.empty());
        check(keys.insert(entry.english).second);
        check(placeholders(entry.english) == placeholders(entry.chinese));
        check(tr(entry.english, L::English) == entry.english);
        check(tr(entry.english, L::SimplifiedChinese) == entry.chinese);
        bool chinese = false;
        for (const auto ch : entry.chinese) {
            chinese |= ch >= 0x4e00 && ch <= 0x9fff;
            check(ch != 0xfffd && ch != 0 && !(ch >= 0xd800 && ch <= 0xdfff));
        }
        check(chinese);
    }
    // Exact lookup never replaces words inside game paths or arbitrary reports.
    const std::wstring path = L"C:\\Games\\Home\\游戏 {0} 100%\\Settings.exe";
    check(tr(path, L::SimplifiedChinese) == path);
    check(format(path, L::SimplifiedChinese, {L"replacement"}) == path);
    check(tr(L"Unknown driver failure: Home", L::SimplifiedChinese) == L"Unknown driver failure: Home");
    check(tr(L"new.asi", L::SimplifiedChinese) == L"new.asi");
    check(tr(L"version.dll", L::SimplifiedChinese) == L"version.dll");
    const std::wstring nul(L"file\0name", 9);
    check(tr(nul, L::SimplifiedChinese) == nul);

    // Opaque substitutions are never scanned again, even if they look like keys
    // or placeholders. The same template preserves English when requested.
    check(format(L"Install {0} for:\n{1}", L::SimplifiedChinese, {L"Home {1}", path}) ==
          L"为以下游戏安装 Home {1}：\n" + path);
    check(format(L"Install {0} for:\n{1}", L::English, {L"Home {1}", path}) ==
          L"Install Home {1} for:\n" + path);
    check(format(L"Choose EXE ({0})", L::SimplifiedChinese, {L"12"}) == L"选择 EXE（12）");
    check(format(L"Choose EXE ({0})", L::SimplifiedChinese, {}) == L"选择 EXE（{0}）");
    check(format(L"{0}–{1} of {2}", L::SimplifiedChinese, {L"1", L"5", L"9"}) == L"第 1–5 项，共 9 项");
    check(format(L"Loader: {0}  ▾", L::SimplifiedChinese, {L"winmm.dll"}) == L"加载器：winmm.dll  ▾");
    check(known(L"Review uninstall") && known(L"Uninstall these files") && known(L"Install these files"));
    std::cout << checks << " localization checks passed (" << keys.size() << " UI entries)\n";
}
