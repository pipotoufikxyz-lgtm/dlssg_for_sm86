#pragma once
#include <windows.h>
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>

// Kept separate from discovery so the real launcher can be exercised with a
// Win32 contract double. Production includes the Windows SDK, not that double.
namespace manager_process {
struct Handle {
    HANDLE h = INVALID_HANDLE_VALUE;
    explicit Handle(HANDLE value = INVALID_HANDLE_VALUE) : h(value) {}
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    ~Handle() { reset(); }
    void reset(HANDLE value = INVALID_HANDLE_VALUE) noexcept {
        if (h && h != INVALID_HANDLE_VALUE) CloseHandle(h);
        h = value;
    }
};

inline std::string utf8(const std::wstring& value) {
    int size = WideCharToMultiByte(CP_UTF8, 0, value.data(),
        static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    if (size <= 0) return "[Windows message could not be decoded]";
    std::string result(static_cast<size_t>(size), '\0');
    WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()),
        result.data(), size, nullptr, nullptr);
    return result;
}

inline std::runtime_error failure(const wchar_t* operation,
                                 const std::wstring& exe, DWORD error) {
    // The caller snapshots GetLastError before cleanup or message formatting.
    wchar_t message[2048]{};
    DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, error, 0, message, 2048, nullptr);
    std::wstring detail(message, count);
    while (!detail.empty() && (detail.back() == L'\r' || detail.back() == L'\n' || detail.back() == L' '))
        detail.pop_back();
    auto split = exe.find_last_of(L"\\/");
    std::wstring name = split == exe.npos ? exe : exe.substr(split + 1);
    std::wstring text = std::wstring(operation) + L".\n\nHelper: " + name +
        L"\nPath: " + exe + L"\nWindows error " + std::to_wstring(error);
    if (!detail.empty()) text += L": " + detail;
    return std::runtime_error(utf8(text));
}

class Startup {
    // UpdateProcThreadAttribute retains a POINTER to these values. They must
    // survive CreateProcess AND DeleteProcThreadAttributeList. A block-local
    // HANDLE[] previously shared stack storage with PROCESS_INFORMATION.
    HANDLE inherited_[2]{};
    std::vector<unsigned char> storage_;
    bool initialized_ = false;
public:
    STARTUPINFOEXW info{};
    Startup() { info.StartupInfo.cb = sizeof(STARTUPINFOW); }
    Startup(const Startup&) = delete;
    Startup& operator=(const Startup&) = delete;
    ~Startup() {
        if (initialized_) DeleteProcThreadAttributeList(info.lpAttributeList);
    }
    void capture(HANDLE writer, HANDLE input, const std::wstring& exe) {
        SIZE_T bytes = 0;
        BOOL sized = InitializeProcThreadAttributeList(nullptr, 1, 0, &bytes);
        DWORD error = sized ? ERROR_SUCCESS : GetLastError();
        if (sized || error != ERROR_INSUFFICIENT_BUFFER || !bytes || bytes > 65536)
            throw failure(L"Cannot size the helper handle list", exe,
                          error ? error : ERROR_INVALID_DATA);
        storage_.resize(bytes);
        info.lpAttributeList = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(storage_.data());
        if (!InitializeProcThreadAttributeList(info.lpAttributeList, 1, 0, &bytes)) {
            error = GetLastError();
            throw failure(L"Cannot initialize the helper handle list", exe, error);
        }
        initialized_ = true;
        inherited_[0] = writer;
        inherited_[1] = input;
        if (!UpdateProcThreadAttribute(info.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
                inherited_, sizeof inherited_, nullptr, nullptr)) {
            error = GetLastError();
            throw failure(L"Cannot configure the helper handle list", exe, error);
        }
        info.StartupInfo.cb = sizeof info;
        info.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
        info.StartupInfo.hStdOutput = writer;
        info.StartupInfo.hStdError = writer;
        info.StartupInfo.hStdInput = input;
    }
};

// Match the JSON reader's size bound; a review can enumerate thousands of files.
inline constexpr size_t reportLimit = 2u * 1024 * 1024;
struct Result { DWORD code = 0; std::string output; bool outputTruncated = false; };

inline Result run(const std::wstring& exe, std::wstring command,
                  const std::wstring& directory, bool capture) {
    if (command.size() >= 32767) throw std::runtime_error("Command line is too long");
    SECURITY_ATTRIBUTES security{sizeof security, nullptr, TRUE};
    Handle input, reader, writer;
    if (capture) {
        input.reset(CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
            &security, OPEN_EXISTING, 0, nullptr));
        if (input.h == INVALID_HANDLE_VALUE) {
            DWORD error = GetLastError();
            throw failure(L"Cannot open helper input", exe, error);
        }
        HANDLE read = nullptr, write = nullptr;
        BOOL piped = CreatePipe(&read, &write, &security, 0);
        DWORD error = piped ? ERROR_SUCCESS : GetLastError();
        reader.reset(read);
        writer.reset(write);
        if (!piped) throw failure(L"Cannot create helper output pipe", exe, error);
        if (!SetHandleInformation(reader.h, HANDLE_FLAG_INHERIT, 0)) {
            error = GetLastError();
            throw failure(L"Cannot restrict helper output pipe", exe, error);
        }
    }

    PROCESS_INFORMATION child{};
    {
        Startup startup;
        if (capture) startup.capture(writer.h, input.h, exe);
        BOOL started = CreateProcessW(exe.c_str(), command.data(), nullptr, nullptr,
            capture ? TRUE : FALSE, capture ? EXTENDED_STARTUPINFO_PRESENT | CREATE_NO_WINDOW : 0,
            nullptr, directory.c_str(), &startup.info.StartupInfo, &child);
        DWORD error = started ? ERROR_SUCCESS : GetLastError();
        if (!started) throw failure(L"Cannot start packaged helper", exe, error);
    }
    Handle thread(child.hThread), process(child.hProcess);
    writer.reset();
    input.reset();
    Result result;
    auto drain = [&](DWORD budget) {
        if (!capture) return;
        // A noisy child cannot keep us in the drain loop forever. The parent
        // must still observe completion, even after the retained log is full.
        while (budget) {
            DWORD available = 0;
            if (!PeekNamedPipe(reader.h, nullptr, 0, nullptr, &available, nullptr)) {
                DWORD error = GetLastError();
                if (error == ERROR_BROKEN_PIPE) return;
                throw failure(L"Cannot read helper output", exe, error);
            }
            if (!available) return;
            char data[2048];
            DWORD got = 0;
            DWORD wanted = std::min<DWORD>(budget, std::min<DWORD>(available, sizeof data));
            if (!ReadFile(reader.h, data, wanted, &got, nullptr)) {
                DWORD error = GetLastError();
                if (error == ERROR_BROKEN_PIPE) return;
                throw failure(L"Cannot read helper output", exe, error);
            }
            if (!got) return;
            const auto retained = std::min<size_t>(got, reportLimit - result.output.size());
            result.output.append(data, retained);
            result.outputTruncated |= retained != got;
            budget -= got;
        }
    };
    for (;;) {
        drain(65536);
        DWORD wait = WaitForSingleObject(process.h, 50);
        if (wait == WAIT_OBJECT_0) break;
        if (wait == WAIT_FAILED) {
            DWORD error = GetLastError();
            throw failure(L"Cannot observe helper completion", exe, error);
        }
    }
    // Completion does not imply an empty pipe. Drain enough to retain the
    // complete bounded report or detect overflow. A descendant retaining a
    // writer cannot keep this final drain running without a byte limit.
    drain(static_cast<DWORD>(reportLimit + 1));
    if (!GetExitCodeProcess(process.h, &result.code)) {
        DWORD error = GetLastError();
        throw failure(L"Cannot read helper exit code", exe, error);
    }
    return result;
}
}
