#pragma once
#include <windows.h>
#include <atomic>
#include <cstdio>
#include <string>

namespace manager_startup {
inline HANDLE file=INVALID_HANDLE_VALUE;
inline std::atomic<const char*> stage{"entry"};
inline void record(const char* what,DWORD code=0,const void* address=nullptr) noexcept {
    if(file==INVALID_HANDLE_VALUE)return;
    MEMORY_BASIC_INFORMATION region{};
    if(address)VirtualQuery(address,&region,sizeof region);
    char line[512];const auto n=std::snprintf(line,sizeof line,"SM86 1.8.1 tick=%llu thread=%lu stage=%s event=%s code=0x%08lx address=%p module_base=%p\r\n",
        GetTickCount64(),GetCurrentThreadId(),stage.load(),what,code,address,region.AllocationBase);
    if(n>0&&n<int(sizeof line)){DWORD written=0;WriteFile(file,line,DWORD(n),&written,nullptr);if(code)FlushFileBuffers(file);}
}
inline void checkpoint(const char* value) noexcept {stage.store(value);record("checkpoint");}
inline LONG WINAPI crashed(EXCEPTION_POINTERS* exception) noexcept {
    if(exception&&exception->ExceptionRecord)record("unhandled_exception",exception->ExceptionRecord->ExceptionCode,exception->ExceptionRecord->ExceptionAddress);
    // Preserve Windows Error Reporting. Never attempt to resume an access violation.
    return EXCEPTION_CONTINUE_SEARCH;
}
inline void open(const std::wstring& folder) {
    auto path=folder+L"\\startup-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".log";
    file=CreateFileW(path.c_str(),FILE_APPEND_DATA,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
    SetUnhandledExceptionFilter(crashed);checkpoint("application_data_ready");
}
}
