#pragma once
namespace helper_identity {
inline constexpr char installer[]="d9b00958c30e4cd61a98f9491d9a9b26932acddaa11a0816ab5055232699823a";
inline constexpr char collector[]="3ad07fce44a69515394f73f78b160e96a1f5c84701e383bdf639799b6cb28321";
}
