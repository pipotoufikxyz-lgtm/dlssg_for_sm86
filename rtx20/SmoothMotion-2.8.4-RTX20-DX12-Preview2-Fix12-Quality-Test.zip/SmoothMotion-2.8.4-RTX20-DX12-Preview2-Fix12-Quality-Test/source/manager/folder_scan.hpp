#pragma once
#include "catalog.hpp"
#include "../setup/policy.hpp"
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>

// The production bounded traversal is shared by Windows discovery and host
// fixtures. Io only supplies directory listings and parsed Xbox declarations.
namespace folder_scan {
inline std::wstring join(std::wstring path,const std::wstring& name){
 if(!path.empty()&&path.back()!=L'\\'&&path.back()!=L'/')path+=L'\\';return path+name;
}
inline std::wstring base(const std::wstring& path){const auto at=path.find_last_of(L"\\/");return at==path.npos?path:path.substr(at+1);}
inline std::wstring parent(const std::wstring& path){const auto at=path.find_last_of(L"\\/");return at==path.npos?L"":path.substr(0,at);}
inline bool exe(const std::wstring& name){const auto key=catalog::pathKey(name);return key.size()>4&&key.substr(key.size()-4)==L".exe";}
struct Listing {std::vector<std::wstring> names;bool limited=false;};
struct Issue {std::wstring path;std::string message;};
struct Limits {std::size_t entries=24000,directories=4096,perListing=4096;unsigned depth=8;};
struct Report {
 std::size_t visited=0,metadata=0,unreadable=0;bool limited=false,cancelled=false;
 std::vector<Issue> issues;
 void failed(const std::wstring& path,const std::exception& error){++unreadable;if(issues.size()<8)issues.push_back({path,error.what()});}
};
// Metadata targets are attempted before bulk file enumeration. A large asset
// directory cannot consume the scan budget before its declared game EXE.
template<class Io,class Cancel,class Candidate,class Observe>
Report walk(const std::wstring& root,Io& io,Cancel cancelled,Candidate candidate,Observe observe,Limits limits={}){
 struct Dir{std::wstring path;unsigned depth;};std::vector<Dir> queue{{root,0}};Report report;
 for(std::size_t index=0;index<queue.size()&&!cancelled()&&report.visited<limits.entries;++index){
  const auto dir=queue[index];
  try{for(const auto& relative:io.targets(dir.path)){
   if(cancelled())break;
   const auto path=join(dir.path,relative);
   if(setup_policy::safe_relative(relative)&&exe(relative)&&catalog::within(path,root)){++report.metadata;candidate(path,true);}
  }}catch(const std::exception& e){report.failed(join(dir.path,L"MicrosoftGame.config"),e);}
  for(const bool directories:{false,true}){
   if(cancelled()||report.visited>=limits.entries)break;
   Listing listing;
   try{listing=io.list(dir.path,directories,limits.perListing);}catch(const std::exception& e){report.failed(dir.path,e);continue;}
   report.limited|=listing.limited;
   if(directories)std::stable_sort(listing.names.begin(),listing.names.end(),[](const auto& a,const auto& b){return (catalog::pathKey(a)==L"content")>(catalog::pathKey(b)==L"content");});
   for(const auto& name:listing.names){
    if(cancelled())break;
    if(report.visited>=limits.entries){report.limited=true;break;}++report.visited;
    observe(name,directories);
    if(!directories){if(exe(name))candidate(join(dir.path,name),false);continue;}
    std::string relative;for(const auto ch:name)relative+=ch<128?static_cast<char>(ch):'?';
    if(catalog::toolDirectory(relative+"/"))continue;
    if(dir.depth>=limits.depth||queue.size()>=limits.directories){report.limited=true;continue;}
    queue.push_back({join(dir.path,name),dir.depth+1});
   }
  }
 }
 report.limited|=report.visited>=limits.entries;report.cancelled=cancelled();return report;
}
struct Installation {std::wstring path,title;bool xbox=false;};
// Recognize a game, its Content directory, or a collection of Xbox installs.
// A collection yields one root per child, never one combined game card.
template<class Io>
std::vector<Installation> installations(const std::wstring& selected,Io& io){
 const auto key=catalog::pathKey(base(selected));
 if(io.config(selected)){
  const auto owner=key==L"content"?parent(selected):selected;
  return {{owner,base(owner),true}};
 }
 if(io.config(join(selected,L"Content")))return {{selected,base(selected),true}};
 const bool collection=key==L"xboxgames";
 std::vector<Installation> found;
 auto listing=io.list(selected,true,4096);
 if(listing.limited)throw std::runtime_error("The selected folder contains too many installations. Select the game's own folder.");
 for(const auto& name:listing.names){
  const auto path=join(selected,name);
  if(catalog::pathKey(name)==L"gamesave")continue;
  if(io.config(path)||io.config(join(path,L"Content"))||collection)found.push_back({path,name,true});
 }
 if(!found.empty()||collection)return found;
 return {{selected,base(selected),false}};
}
}
