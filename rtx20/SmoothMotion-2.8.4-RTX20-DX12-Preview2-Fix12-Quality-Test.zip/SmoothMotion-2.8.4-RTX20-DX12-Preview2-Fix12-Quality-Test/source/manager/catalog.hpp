#pragma once
#include "discovery.hpp"
#include <string>
#include <vector>
#include <algorithm>
// Portable detection policy. Store identity and installation paths are separate
// from display names and Steam artwork IDs. No manifest is executed.
namespace catalog {
inline std::wstring pathKey(std::wstring p) {
 for(auto& c:p){if(c==L'/')c=L'\\';if(c>=L'A'&&c<=L'Z')c+=32;}
 if(p.rfind(L"\\\\?\\unc\\",0)==0)p=L"\\\\"+p.substr(8);
 else if(p.rfind(L"\\\\?\\",0)==0)p=p.substr(4);
 while(p.size()>3&&p.back()==L'\\')p.pop_back();return p;
}
inline bool within(const std::wstring& path,const std::wstring& root) {
 auto p=pathKey(path),r=pathKey(root);return !r.empty()&&(p==r||(p.size()>r.size()&&p.compare(0,r.size(),r)==0&&(r.back()==L'\\'||p[r.size()]==L'\\')));
}
template<class Game>bool sameInstall(const Game& a,const Game& b) {
 if(!a.installRoot.empty()&&!b.installRoot.empty())return pathKey(a.installRoot)==pathKey(b.installRoot);
 return !a.exe.empty()&&pathKey(a.exe)==pathKey(b.exe);
}

struct Hidden {std::wstring root,exe;};
template<class Game>bool hidden(const Game& game,const Hidden& item){
 return (!item.root.empty()&&pathKey(game.installRoot)==pathKey(item.root))||(!item.exe.empty()&&pathKey(game.exe)==pathKey(item.exe));
}
template<class Game>void filterHidden(std::vector<Game>& games,const std::vector<Hidden>& items){
 games.erase(std::remove_if(games.begin(),games.end(),[&](const Game& game){return std::any_of(items.begin(),items.end(),[&](const Hidden& item){return hidden(game,item);});}),games.end());
}
template<class Game>void reveal(std::vector<Hidden>& items,const Game& game){
 items.erase(std::remove_if(items.begin(),items.end(),[&](const Hidden& item){return hidden(game,item);}),items.end());
}
inline std::string compact(std::string s) {std::string o;for(unsigned char c:discovery::lower(s))if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c>=128)o+=c;return o;}
inline std::string filename(std::string s){auto at=s.find_last_of("\\/");return at==s.npos?s:s.substr(at+1);}
inline std::string stem(std::string s){s=discovery::lower(filename(s));if(s.size()>4&&s.substr(s.size()-4)==".exe")s.resize(s.size()-4);return s;}
inline bool suffix(const std::string& s,const std::string& end){return s.size()>=end.size()&&s.compare(s.size()-end.size(),end.size(),end)==0;}
inline bool toolDirectory(std::string path) {
 path=discovery::lower(path);std::replace(path.begin(),path.end(),'\\','/');size_t at=0;
 while(at<path.size()){auto end=path.find('/',at);if(end==path.npos)break;auto part=path.substr(at,end-at);at=end+1;
  for(const char* token:{"tools","tool","editors","editor","sdk","redist","_commonredist","redistributables","prerequisites","thirdparty","node_modules","__installer","sm86",".smooth-motion","_dlss5_backup"})if(part==token)return true;
  if(part.rfind("sm86-backup-",0)==0)return true;
 }return false;
}
inline bool auxiliary(std::string path) {
 if(toolDirectory(path))return true;auto raw=stem(path);bool unrealBuild=false;
 for(const char* build:{"-win64-shipping","-win64-development","-win32-shipping","-shipping"})if(suffix(raw,build)){raw.resize(raw.size()-std::char_traits<char>::length(build));unrealBuild=true;break;}
 auto name=compact(raw);if(unrealBuild&&suffix(name,"server"))return true;
 if(discovery::helper(filename(path)))return true;
 for(const char* token:{"editor","modelviewer","mapviewer","workshoputility","workshoptool","benchmarktool","crashhandler","reporter","dedicatedserver","shadercompiler","shadercompileworker"})if(suffix(name,token))return true;
 for(const char* token:{"configuration","configtool","config","uninstall","installscript","registergame","registergame32","registergame64","steamcmd","hlmv","hlfaceposer","hplmodelviewer","godotconsole","unityshadercompiler","unitybugreporter","startprotectedgame","gamelaunchhelper"})if(name==token)return true;
 for(const char* prefix:{"crashreport","crashpad","unitycrash","vcredist","vc_redist","dxsetup","ue4prereq","unins000","easyanticheat","eaanticheat","battleye","beservice"})if(discovery::lower(stem(path)).rfind(prefix,0)==0)return true;
 return suffix(name,"console")||suffix(name,"diagnostics");
}
inline bool launcher(std::string path){return stem(path).find("launcher")!=std::string::npos;}
// A Shipping suffix alone does not identify Unreal's renderer: bootstrap
// launchers can use it too. Require the actual Binaries/Win64 location.
inline bool unrealRenderer(std::string path,bool x64=true) {
 if(!x64||auxiliary(path)||launcher(path))return false;
 path=discovery::lower(path);std::replace(path.begin(),path.end(),'\\','/');
 auto at=path.find_last_of('/');if(at==path.npos)return false;
 auto directory=path.substr(0,at),name=stem(path);
 if(directory!="binaries/win64"&&!suffix(directory,"/binaries/win64"))return false;
 if(!suffix(name,"-win64-shipping"))return false;
 name.resize(name.size()-15);
 for(const char* utility:{"server","editor","shadercompileworker"})if(suffix(name,utility))return false;
 return !name.empty();
}
struct TargetEvidence {std::string relative;bool x64=true;unsigned api=0;int rank=0;bool metadataOnly=false;};
struct TargetDecision {std::size_t index=std::string::npos;bool needsChoice=false,redirected=false;};
inline bool boundedRelative(std::string path) {
 std::replace(path.begin(),path.end(),'\\','/');
 if(path.empty()||path.front()=='/'||path.find(':')!=path.npos)return false;
 unsigned depth=0;std::size_t at=0;
 while(at<path.size()){auto end=path.find('/',at);auto part=path.substr(at,end==path.npos?end:end-at);
  if(part.empty()||part=="."||part==".."||part.find_first_of("\r\n\t")!=part.npos)return false;
  if(end==path.npos)return true;if(++depth>8)return false;at=end+1;
 }return false;
}
// Input is already ranked and filesystem-verified by the bounded scanner. An
// incomplete scan cannot establish uniqueness. Multiple rendering binaries
// require an explicit choice; alphabetical order is never install authority.
inline TargetDecision resolveTarget(const std::vector<TargetEvidence>& choices,std::size_t selected=std::string::npos,bool complete=true) {
 TargetDecision result;if(choices.empty())return result;
 const bool explicitChoice=selected<choices.size();result.index=explicitChoice?selected:0;
 if(explicitChoice){const auto& picked=choices[selected];
  if(boundedRelative(picked.relative)&&!auxiliary(picked.relative)&&(unrealRenderer(picked.relative,picked.x64)||(!launcher(picked.relative)&&(picked.api||(picked.metadataOnly&&picked.x64)))))return result;
 }
 std::vector<std::string> renderers;std::size_t candidate=std::string::npos;
 for(std::size_t i=0;i<choices.size();++i){const auto& c=choices[i];if(!boundedRelative(c.relative)||!unrealRenderer(c.relative,c.x64))continue;
  auto key=discovery::lower(c.relative);std::replace(key.begin(),key.end(),'\\','/');if(std::find(renderers.begin(),renderers.end(),key)!=renderers.end())continue;
  renderers.push_back(std::move(key));candidate=i;
 }
 if(renderers.size()==1&&complete){result.index=candidate;result.redirected=explicitChoice&&selected!=candidate;return result;}
 result.needsChoice=renderers.size()>1||!complete;
 if(!explicitChoice&&choices.size()>1&&choices[0].rank==choices[1].rank)result.needsChoice=true;
 return result;
}
struct Evidence {
 std::string relative,title,folder;
 unsigned direct=0,dependencies=0;
 bool launch=false,primary=false,unity=false,godot=false,x64=true;
};
inline int rank(const Evidence& e) {
 if(auxiliary(e.relative))return -10000;
 auto name=stem(e.relative),normalized=compact(name);int score=e.direct?120:e.dependencies?85:0;
 if(e.x64)score+=5;
 if(e.launch)score+=e.primary?280:250;
 bool shipping=unrealRenderer(e.relative,e.x64);
 // Unreal's top-level launcher forwards to this rendering binary. A launch
 // hint is useful evidence, but must not outrank the actual Shipping renderer.
 if(shipping&&e.x64)score+=420;
 if(e.unity)score+=110;if(e.godot)score+=95;
 auto match=[&](const std::string& title){auto n=compact(title);return n.size()>=3&&(normalized==n||(normalized.size()>n.size()&&normalized.compare(0,n.size(),n)==0&&(normalized.substr(n.size())=="dx11"||normalized.substr(n.size())=="dx12"||normalized.substr(n.size())=="x64"||normalized.substr(n.size())=="win64"||normalized.substr(n.size())=="vulkan")));};
 if(match(e.title)||match(e.folder))score+=90;
 if(name.find("launcher")!=name.npos)score-=e.direct||e.dependencies?90:200;
 // A shallower binary is only a final tie-break, never stronger than engine
 // or launcher metadata. Depth alone cannot turn an editor into a game.
 score-=int(std::count(e.relative.begin(),e.relative.end(),'\\')+std::count(e.relative.begin(),e.relative.end(),'/'))*2;
 return score;
}
inline std::wstring legacySteamRoot(const std::wstring& exe) {
 auto key=pathKey(exe);auto at=key.find(L"\\steamapps\\common\\");if(at==key.npos)return {};
 auto end=key.find(L'\\',at+18);return end==key.npos?std::wstring{}:key.substr(0,end);
}
// Keep install identity through a rescan while allowing the scanner to replace
// obsolete editor selections. Explicit user choices are the only pinned ones.
template<class Game>void carryPreferences(Game& fresh,const Game& old) {
 if(fresh.cover.empty())fresh.cover=old.cover;if(fresh.hero.empty())fresh.hero=old.hero;
 if(fresh.steamId.empty()){fresh.steamId=old.steamId;fresh.steamRoot=old.steamRoot;}
 if(fresh.pinnedExe.empty())fresh.pinnedExe=old.pinnedExe;
}
template<class Candidate>void sortCandidates(std::vector<Candidate>& candidates){
 std::sort(candidates.begin(),candidates.end(),[](const Candidate& a,const Candidate& b){return a.rank!=b.rank?a.rank>b.rank:pathKey(a.exe)<pathKey(b.exe);});
}
template<class Game,class Select>void merge(std::vector<Game>& games,Game g,Select select){
 for(auto& old:games){if(pathKey(old.exe)!=pathKey(g.exe)&&!sameInstall(old,g))continue;
  const bool explicitAdd=g.store==L"Manual"&&!g.pinnedExe.empty();
  carryPreferences(g,old);
  if(g.store==L"Manual"&&old.store!=L"Manual"){g.title=old.title;g.store=old.store;g.storeId=old.storeId;g.installRoot=old.installRoot;}
  if(explicitAdd)for(const auto& choice:old.choices){bool found=false;for(const auto& c:g.choices)if(pathKey(c.exe)==pathKey(choice.exe))found=true;if(!found&&g.choices.size()<64)g.choices.push_back(choice);}
  sortCandidates(g.choices);
  for(const auto& choice:g.choices)if(pathKey(choice.exe)==pathKey(g.pinnedExe)){select(g,choice);break;}
  if(!g.choices.empty()&&std::none_of(g.choices.begin(),g.choices.end(),[&](const auto& c){return pathKey(c.exe)==pathKey(g.pinnedExe);}))g.pinnedExe.clear();
  old=std::move(g);return;
 }
 if(games.size()<600)games.push_back(std::move(g));
}
}
