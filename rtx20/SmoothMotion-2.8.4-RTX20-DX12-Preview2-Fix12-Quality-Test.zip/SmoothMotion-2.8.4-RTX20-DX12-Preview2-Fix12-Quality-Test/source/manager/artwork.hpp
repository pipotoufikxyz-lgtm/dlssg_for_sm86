#pragma once
#include "core.hpp"
#include "art_policy.hpp"
#include <winhttp.h>
#include <wincodec.h>
#include <thread>
#include <chrono>
#include <map>
#include <functional>
namespace artwork {
template<class T>struct Com {T* p=nullptr;~Com(){if(p)p->Release();}T** out(){return &p;}T* operator->(){return p;}};
struct Internet {HINTERNET h=nullptr;explicit Internet(HINTERNET v):h(v){}~Internet(){if(h)WinHttpCloseHandle(h);}operator HINTERNET()const{return h;}};
inline std::string get(const wchar_t* host,const std::wstring& path,size_t limit,std::atomic_bool& cancel){
 Internet session(WinHttpOpen(L"SM86Manager/1.5 artwork",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0));if(!session.h)return {};
 WinHttpSetTimeouts(session,1500,2000,2000,2500);
 Internet connection(WinHttpConnect(session,host,INTERNET_DEFAULT_HTTPS_PORT,0));if(!connection.h)return {};
 Internet request(WinHttpOpenRequest(connection,L"GET",path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE));if(!request.h)return {};
 DWORD disable=WINHTTP_DISABLE_COOKIES|WINHTTP_DISABLE_REDIRECTS;WinHttpSetOption(request,WINHTTP_OPTION_DISABLE_FEATURE,&disable,sizeof disable);
 DWORD auth=WINHTTP_AUTOLOGON_SECURITY_LEVEL_HIGH;WinHttpSetOption(request,WINHTTP_OPTION_AUTOLOGON_POLICY,&auth,sizeof auth);
 if(cancel||!WinHttpSendRequest(request,WINHTTP_NO_ADDITIONAL_HEADERS,0,WINHTTP_NO_REQUEST_DATA,0,0,0)||!WinHttpReceiveResponse(request,nullptr))return {};
 DWORD status=0,n=sizeof status;if(!WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&n,WINHTTP_NO_HEADER_INDEX)||status!=200)return {};
 std::string out;char block[32768];ULONGLONG until=GetTickCount64()+8000;
 while(!cancel&&GetTickCount64()<until){DWORD read=0;if(!WinHttpReadData(request,block,sizeof block,&read))return {};if(!read)return out;if(out.size()+read>limit)return {};out.append(block,read);}return {};
}
inline std::wstring encode(const std::string& text){std::wstring s;for(unsigned char c:text){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.')s+=c;else{s+=L'%';s+=L"0123456789ABCDEF"[c>>4];s+=L"0123456789ABCDEF"[c&15];}}return s;}
inline unsigned imageQuality(const std::wstring& file,ImageRole role=ImageRole::Any){
 if(!manager::ordinary(file))return 0;
 WIN32_FILE_ATTRIBUTE_DATA attributes{};if(!GetFileAttributesExW(file.c_str(),GetFileExInfoStandard,&attributes)||attributes.nFileSizeHigh||attributes.nFileSizeLow>8u*1024*1024)return 0;
 Com<IWICImagingFactory> factory;if(FAILED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(factory.out()))))return 0;
 Com<IWICBitmapDecoder> decoder;if(FAILED(factory->CreateDecoderFromFilename(file.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,decoder.out())))return 0;
 GUID format{};if(FAILED(decoder->GetContainerFormat(&format))||(!IsEqualGUID(format,GUID_ContainerFormatJpeg)&&!IsEqualGUID(format,GUID_ContainerFormatPng)))return 0;
 Com<IWICBitmapFrameDecode> frame;UINT w=0,h=0;
 return SUCCEEDED(decoder->GetFrame(0,frame.out()))&&SUCCEEDED(frame->GetSize(&w,&h))?quality(role,w,h):0;
}
inline bool validImage(const std::wstring& file,ImageRole role=ImageRole::Any){return imageQuality(file,role)!=0;}
inline std::wstring local(const manager::Game& g,ImageRole role){
 if(g.steamRoot.empty())return {};
 auto cache=manager::join(g.steamRoot,L"appcache\\librarycache");std::wstring best;unsigned score=0;
 auto consider=[&](const std::wstring& path){auto q=imageQuality(path,role);if(q>score){score=q;best=path;}};
 auto names=role==ImageRole::Cover?std::vector<std::wstring>{L"library_capsule_2x.jpg",L"library_600x900_2x.jpg",L"library_600x900.jpg",L"library_capsule.jpg",L"library_capsule_2x.png",L"library_600x900.png",L"library_capsule.png"}:std::vector<std::wstring>{L"header_2x.jpg",L"header.jpg",L"header_2x.png",L"header.png"};
 for(const auto& name:names){consider(manager::join(manager::join(cache,g.steamId),name));consider(manager::join(cache,g.steamId+L"_"+name));}
 for(const auto& name:manager::children(manager::join(cache,g.steamId),false,128)){
  for(const auto& suffix:names)if(manager::ends(name,suffix.c_str())){consider(manager::join(manager::join(cache,g.steamId),name));break;}
 }
 return best;
}
inline std::wstring cachePath(const manager::Game& g,const std::wstring& cache,ImageRole role){return manager::join(cache,g.steamId+(role==ImageRole::Cover?L"_cover.jpg":L"_header.jpg"));}
inline std::string cdn(const std::wstring& path,std::atomic_bool& cancel){
 // The previous cloudflare hostname now redirects. Keep redirects disabled,
 // use the verified direct Steam CDN endpoints, and try a second provider.
 for(const wchar_t* host:{L"shared.fastly.steamstatic.com",L"shared.akamai.steamstatic.com"}){
  if(cancel)return {};auto bytes=get(host,path,8u*1024*1024,cancel);if(!bytes.empty())return bytes;
 }
 return {};
}
inline std::wstring asset(const manager::Game& g,const std::wstring& cache,ImageRole role,const std::vector<std::string>& candidates,std::atomic_bool& cancel,bool force){
 auto path=cachePath(g,cache,role);auto fallback=local(g,role);
 if(imageQuality(path,role)>imageQuality(fallback,role))fallback=path;
 std::string requested;for(const auto& name:candidates)requested+=name+"\n";
 auto miss=path+L".missing-v3",source=path+L".source";
 if(!force&&validImage(path,role)&&manager::read(source,4096)==requested)return fallback;
 WIN32_FILE_ATTRIBUTE_DATA attr{};FILETIME now{};GetSystemTimeAsFileTime(&now);
 auto ticks=[](FILETIME t){return (std::uint64_t(t.dwHighDateTime)<<32)|t.dwLowDateTime;};
 if(!force&&GetFileAttributesExW(miss.c_str(),GetFileExInfoStandard,&attr)&&ticks(now)>=ticks(attr.ftLastWriteTime)&&ticks(now)-ticks(attr.ftLastWriteTime)<15ull*60*10000000&&sameMiss(manager::read(miss,4096),requested))return fallback;
 for(const auto& candidate:candidates){
  if(cancel)break;
  auto remote=manager::fromUtf8(candidate);
  auto bytes=cdn(L"/store_item_assets/steam/apps/"+g.steamId+L"/"+remote,cancel);
  if(bytes.empty()&&candidate.find('/')==candidate.npos)bytes=cdn(L"/steam/apps/"+g.steamId+L"/"+remote,cancel);
  if(bytes.empty())continue;
  auto temp=path+L".tmp-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetCurrentThreadId())+L"-"+std::to_wstring(GetTickCount64());
  try{
   manager::writeNew(temp,bytes);
   auto downloaded=imageQuality(temp,role);if(downloaded&&downloaded<imageQuality(fallback,role)){DeleteFileW(temp.c_str());return fallback;}
   if(!cancel&&downloaded&&(GetFileAttributesW(path.c_str())==INVALID_FILE_ATTRIBUTES||manager::ordinary(path))&&MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){
    if(manager::ordinary(miss))DeleteFileW(miss.c_str());
    if(manager::ordinary(source))DeleteFileW(source.c_str());manager::writeNew(source,requested);return path;
   }
   DeleteFileW(temp.c_str());
  }catch(...){DeleteFileW(temp.c_str());}
 }
 if(!cancel)try{if(manager::ordinary(miss))DeleteFileW(miss.c_str());manager::writeNew(miss,"SM86-ART-MISS-3\n"+requested+"\n");}catch(...){}
 return fallback;
}
inline void cached(manager::Game& g,const std::wstring& cache){
 for(auto role:{ImageRole::Cover,ImageRole::Header}){
  auto own=cachePath(g,cache,role),steam=local(g,role);
  auto best=imageQuality(own,role)>=imageQuality(steam,role)?own:steam;
  if(!validImage(best,role))best.clear();
  (role==ImageRole::Cover?g.cover:g.hero)=best;
 }
}
inline void resolve(manager::Game& g,const std::wstring& cache,std::atomic_bool& cancel,bool force=false){
 auto id=appId(manager::toUtf8(g.steamId));
 if(id.empty()){
  auto metadata=get(L"store.steampowered.com",L"/api/storesearch/?cc=us&l=en&term="+encode(manager::toUtf8(g.title)),2u*1024*1024,cancel);
  if(metadata.empty())return;id=exactMatch(metadata,manager::toUtf8(g.title));if(id.empty())return;g.steamId=manager::fromUtf8(id);
 }
 cached(g,cache);
 auto input="{\"ids\":[{\"appid\":"+id+"}],\"context\":{\"language\":\"english\",\"country_code\":\"US\"},\"data_request\":{\"include_assets\":true}}";
 auto metadata=get(L"api.steampowered.com",L"/IStoreBrowseService/GetItems/v1/?input_json="+encode(input),2u*1024*1024,cancel);
 if(cancel||(!force&&metadata.empty()&&!g.cover.empty()&&!g.hero.empty()))return;
 g.cover=asset(g,cache,ImageRole::Cover,assetChoices(metadata,id,ImageRole::Cover),cancel,force);
 if(!cancel)g.hero=asset(g,cache,ImageRole::Header,assetChoices(metadata,id,ImageRole::Header),cancel,force);
}
inline size_t enrich(std::vector<manager::Game>& games,const std::wstring& data,std::atomic_bool& cancel,const std::function<void(const manager::Game&)>& updated={},bool force=false){
 auto cache=manager::join(data,L"artwork-v3");CreateDirectoryW(cache.c_str(),nullptr);if(!manager::ordinary(cache,true))return 0;
 std::atomic_size_t next{0};std::vector<std::thread> workers;auto work=[&](){HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);if(FAILED(com))return;
  while(!cancel){auto i=next.fetch_add(1);if(i>=games.size())break;try{resolve(games[i],cache,cancel,force);if(!cancel&&updated)updated(games[i]);}catch(...) {}}CoUninitialize();};
 // Bounded concurrency: offline failure affects artwork only, never installation.
 try{for(unsigned i=0;i<3;++i)workers.emplace_back(work);}catch(...){}work();for(auto& w:workers)w.join();
 size_t count=0;for(auto& g:games)if(!g.cover.empty()||!g.hero.empty())++count;return count;
}
class Images {
 struct Entry{std::wstring key;ID2D1Bitmap* bitmap=nullptr;};std::vector<Entry> cache;size_t bytes=0;
public:
 ~Images(){clear();}void clear(){for(auto& e:cache)if(e.bitmap)e.bitmap->Release();cache.clear();bytes=0;}
 ID2D1Bitmap* get(ID2D1RenderTarget* target,const std::wstring& file,bool icon=false,ImageRole role=ImageRole::Any){
  auto key=std::to_wstring(int(role))+(icon?L"icon:":L"image:")+file;for(auto& e:cache)if(e.key==key)return e.bitmap;if(cache.size()>=24)clear();
  Com<IWICImagingFactory> factory;Com<IWICBitmapDecoder> decoder;Com<IWICBitmapFrameDecode> frame;Com<IWICBitmap> bitmap;IWICBitmapSource* source=nullptr;
  ID2D1Bitmap* result=nullptr;
  if(SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(factory.out())))){
   if(icon){SHFILEINFOW info{};if(SHGetFileInfoW(file.c_str(),0,&info,sizeof info,SHGFI_ICON|SHGFI_LARGEICON)&&info.hIcon){factory->CreateBitmapFromHICON(info.hIcon,bitmap.out());DestroyIcon(info.hIcon);source=bitmap.p;}}
   else if(validImage(file,role)&&SUCCEEDED(factory->CreateDecoderFromFilename(file.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,decoder.out()))&&SUCCEEDED(decoder->GetFrame(0,frame.out())))source=frame.p;
   UINT w=0,h=0;if(source&&SUCCEEDED(source->GetSize(&w,&h))&&w&&h){Com<IWICBitmapScaler> scale;Com<IWICFormatConverter> convert;
    float ratio=std::min(1.f,std::min(960.f/w,1440.f/h));if(SUCCEEDED(factory->CreateBitmapScaler(scale.out()))&&SUCCEEDED(scale->Initialize(source,std::max(1u,UINT(w*ratio)),std::max(1u,UINT(h*ratio)),WICBitmapInterpolationModeFant))&&SUCCEEDED(factory->CreateFormatConverter(convert.out()))&&SUCCEEDED(convert->Initialize(scale.p,GUID_WICPixelFormat32bppPBGRA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom)))target->CreateBitmapFromWicBitmap(convert.p,nullptr,&result);
   }
  }if(result){auto pixels=result->GetPixelSize();size_t size=size_t(pixels.width)*pixels.height*4;if(bytes+size>64u*1024*1024)clear();bytes+=size;}cache.push_back({key,result});return result;
 }
};
}
