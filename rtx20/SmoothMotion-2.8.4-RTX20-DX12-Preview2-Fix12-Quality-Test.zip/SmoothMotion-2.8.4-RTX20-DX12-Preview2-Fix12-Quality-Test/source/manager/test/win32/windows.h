#pragma once
// A Win32 CONTRACT DOUBLE for Linux tests. Never add this directory to a
// production include path. The Windows build uses Zig's real SDK headers.
#include <cstddef>
#include <cstdint>
using DWORD = std::uint32_t;
using WORD = std::uint16_t;
using BOOL = int;
using HANDLE = void*;
using SIZE_T = std::size_t;
using DWORD_PTR = std::uintptr_t;
using LPVOID = void*;
using LPWSTR = wchar_t*;
using LPCWSTR = const wchar_t*;
using BYTE = unsigned char;
using LPBYTE = BYTE*;
using LPPROC_THREAD_ATTRIBUTE_LIST = struct TestAttributeList*;
#define INVALID_HANDLE_VALUE reinterpret_cast<HANDLE>(static_cast<std::intptr_t>(-1))
constexpr BOOL TRUE = 1, FALSE = 0;
constexpr DWORD ERROR_SUCCESS = 0, ERROR_FILE_NOT_FOUND = 2, ERROR_ACCESS_DENIED = 5,
    ERROR_INVALID_HANDLE = 6, ERROR_INVALID_DATA = 13, ERROR_INVALID_PARAMETER = 87,
    ERROR_BROKEN_PIPE = 109, ERROR_INSUFFICIENT_BUFFER = 122;
constexpr DWORD CP_UTF8 = 65001, FORMAT_MESSAGE_FROM_SYSTEM = 0x1000,
    FORMAT_MESSAGE_IGNORE_INSERTS = 0x200, GENERIC_READ = 0x80000000,
    FILE_SHARE_READ = 1, FILE_SHARE_WRITE = 2, OPEN_EXISTING = 3,
    HANDLE_FLAG_INHERIT = 1, EXTENDED_STARTUPINFO_PRESENT = 0x80000,
    CREATE_NO_WINDOW = 0x8000000, STARTF_USESTDHANDLES = 0x100,
    WAIT_OBJECT_0 = 0, WAIT_TIMEOUT = 258, WAIT_FAILED = 0xffffffff;
constexpr DWORD_PTR PROC_THREAD_ATTRIBUTE_HANDLE_LIST = 0x20002;
struct SECURITY_ATTRIBUTES { DWORD nLength; void* lpSecurityDescriptor; BOOL bInheritHandle; };
struct STARTUPINFOW {
    DWORD cb;
    LPWSTR lpReserved, lpDesktop, lpTitle;
    DWORD dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
    WORD wShowWindow, cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput, hStdOutput, hStdError;
};
struct STARTUPINFOEXW { STARTUPINFOW StartupInfo; LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList; };
struct PROCESS_INFORMATION { HANDLE hProcess, hThread; DWORD dwProcessId, dwThreadId; };
static_assert(sizeof(STARTUPINFOW) == 104 && sizeof(STARTUPINFOEXW) == 112);
static_assert(sizeof(PROCESS_INFORMATION) == 24);
extern "C" {
BOOL CloseHandle(HANDLE);
DWORD GetLastError();
int WideCharToMultiByte(DWORD, DWORD, LPCWSTR, int, char*, int, const char*, BOOL*);
DWORD FormatMessageW(DWORD, const void*, DWORD, DWORD, LPWSTR, DWORD, void*);
BOOL InitializeProcThreadAttributeList(LPPROC_THREAD_ATTRIBUTE_LIST, DWORD, DWORD, SIZE_T*);
BOOL UpdateProcThreadAttribute(LPPROC_THREAD_ATTRIBUTE_LIST, DWORD, DWORD_PTR, void*, SIZE_T, void*, SIZE_T*);
void DeleteProcThreadAttributeList(LPPROC_THREAD_ATTRIBUTE_LIST);
HANDLE CreateFileW(LPCWSTR, DWORD, DWORD, SECURITY_ATTRIBUTES*, DWORD, DWORD, HANDLE);
BOOL CreatePipe(HANDLE*, HANDLE*, SECURITY_ATTRIBUTES*, DWORD);
BOOL SetHandleInformation(HANDLE, DWORD, DWORD);
BOOL CreateProcessW(LPCWSTR, LPWSTR, SECURITY_ATTRIBUTES*, SECURITY_ATTRIBUTES*, BOOL,
    DWORD, void*, LPCWSTR, STARTUPINFOW*, PROCESS_INFORMATION*);
BOOL PeekNamedPipe(HANDLE, void*, DWORD, DWORD*, DWORD*, DWORD*);
BOOL ReadFile(HANDLE, void*, DWORD, DWORD*, void*);
DWORD WaitForSingleObject(HANDLE, DWORD);
BOOL GetExitCodeProcess(HANDLE, DWORD*);
}
