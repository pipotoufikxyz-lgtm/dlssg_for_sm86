#include "../process.hpp"
#include <codecvt>
#include <cstring>
#include <iostream>
#include <locale>
#include <map>

struct TestAttributeList { HANDLE* values; SIZE_T bytes; bool initialized; };
namespace mock {
struct Resource { bool inherit; std::string kind; };
std::map<HANDLE, Resource> handles;
std::uintptr_t next = 16;
DWORD error = 0, failureCode = 0, exitCode = 0;
std::string failAt, data;
size_t offset = 0;
int creates = 0, waits = 0, initialized = 0, deleted = 0;
bool expectedCapture = true, brokenPipe = false, unknownMessage = false, exitedWithPending = false;
std::wstring expectedExe, expectedDirectory, expectedCommand;
HANDLE writer = nullptr, input = nullptr;
void need(bool value, const char* text) { if (!value) throw std::runtime_error(text); }
bool fail(const char* where) { if (failAt != where) return false; error = failureCode; return true; }
HANDLE open(const char* kind, bool inherit) {
    auto value = reinterpret_cast<HANDLE>(next++);
    handles.emplace(value, Resource{inherit, kind});
    return value;
}
void reset(bool capture = true) {
    need(handles.empty(), "Handle leak from previous scenario");
    error = failureCode = exitCode = 0;
    failAt.clear(); data.clear(); offset = 0;
    creates = waits = initialized = deleted = 0;
    expectedCapture = capture; brokenPipe = unknownMessage = exitedWithPending = false;
    expectedDirectory = L"C:\\Jeux avec espaces\\caf\u00e9\\";
    expectedExe = expectedDirectory + L"Driver_Settings.exe";
    expectedCommand = L"\"" + expectedExe + L"\" \"--inspect\" \"D:\\Game\\Game.exe\"";
    writer = input = nullptr;
}
manager_process::Result launch() {
    return manager_process::run(expectedExe, expectedCommand, expectedDirectory, expectedCapture);
}
void clean() {
    need(handles.empty(), "Launcher leaked handles");
    need(initialized == deleted, "Attribute list was not deleted exactly once");
}
}
extern "C" {
DWORD GetLastError() { return mock::error; }
BOOL CloseHandle(HANDLE h) {
    mock::need(mock::handles.erase(h) == 1, "Double close or invalid handle close");
    mock::error = 999; // Cleanup is deliberately destructive to last-error.
    return TRUE;
}
int WideCharToMultiByte(DWORD page, DWORD, LPCWSTR text, int size, char* out, int count, const char*, BOOL*) {
    mock::need(page == CP_UTF8, "Wrong code page");
    std::wstring_convert<std::codecvt_utf8<wchar_t>> convert;
    std::string value = convert.to_bytes(text, text + size);
    if (out) {
        mock::need(count >= static_cast<int>(value.size()), "UTF-8 output truncated");
        std::memcpy(out, value.data(), value.size());
    }
    return static_cast<int>(value.size());
}
DWORD FormatMessageW(DWORD flags, const void*, DWORD code, DWORD, LPWSTR text, DWORD size, void*) {
    mock::need(flags == (FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS), "Wrong message flags");
    mock::error = 998;
    if (mock::unknownMessage) return 0;
    auto value = L"System failure " + std::to_wstring(code) + L".\r\n";
    mock::need(value.size() < size, "Message buffer too short");
    std::copy(value.begin(), value.end(), text);
    return static_cast<DWORD>(value.size());
}
BOOL InitializeProcThreadAttributeList(LPPROC_THREAD_ATTRIBUTE_LIST list, DWORD count, DWORD flags, SIZE_T* size) {
    mock::need(count == 1 && flags == 0, "Incorrect attribute configuration");
    if (!list) {
        if (mock::fail("size")) return FALSE;
        *size = sizeof(TestAttributeList); mock::error = ERROR_INSUFFICIENT_BUFFER; return FALSE;
    }
    if (mock::fail("initialize")) return FALSE;
    mock::need(*size == sizeof(TestAttributeList), "Incorrect attribute allocation");
    list->values = nullptr; list->bytes = 0; list->initialized = true;
    ++mock::initialized; return TRUE;
}
BOOL UpdateProcThreadAttribute(LPPROC_THREAD_ATTRIBUTE_LIST list, DWORD flags, DWORD_PTR kind, void* values,
    SIZE_T bytes, void* previous, SIZE_T* returned) {
    mock::need(list->initialized && !flags && kind == PROC_THREAD_ATTRIBUTE_HANDLE_LIST && !previous && !returned,
        "Wrong handle attribute arguments");
    if (mock::fail("update")) return FALSE;
    // This stores the pointer, exactly as required by the Windows contract.
    list->values = static_cast<HANDLE*>(values); list->bytes = bytes;
    return TRUE;
}
void DeleteProcThreadAttributeList(LPPROC_THREAD_ATTRIBUTE_LIST list) {
    mock::need(list->initialized, "Deleting an uninitialized attribute list");
    if (list->values) {
        mock::need(list->bytes == 2 * sizeof(HANDLE), "Wrong attribute size");
        mock::need(list->values[0] == mock::writer && list->values[1] == mock::input,
            "Attribute values expired before deletion");
    }
    list->initialized = false; ++mock::deleted; mock::error = 997;
}
HANDLE CreateFileW(LPCWSTR file, DWORD access, DWORD share, SECURITY_ATTRIBUTES* security,
    DWORD disposition, DWORD flags, HANDLE templateFile) {
    mock::need(std::wstring(file) == L"NUL" && access == GENERIC_READ && share == 3 &&
        security && security->bInheritHandle && disposition == OPEN_EXISTING && !flags && !templateFile,
        "Bad null-input configuration");
    if (mock::fail("input")) return INVALID_HANDLE_VALUE;
    return mock::input = mock::open("input", true);
}
BOOL CreatePipe(HANDLE* read, HANDLE* write, SECURITY_ATTRIBUTES* security, DWORD size) {
    mock::need(security && security->bInheritHandle && size == 0, "Bad pipe configuration");
    if (mock::fail("pipe")) return FALSE;
    *read = mock::open("reader", true);
    if (mock::fail("partial_pipe")) return FALSE;
    *write = mock::writer = mock::open("writer", true);
    return TRUE;
}
BOOL SetHandleInformation(HANDLE value, DWORD mask, DWORD flags) {
    mock::need(mock::handles.at(value).kind == "reader" && mask == HANDLE_FLAG_INHERIT && !flags,
        "Wrong reader inheritance settings");
    if (mock::fail("inherit")) return FALSE;
    mock::handles.at(value).inherit = false; return TRUE;
}
BOOL CreateProcessW(LPCWSTR file, LPWSTR command, SECURITY_ATTRIBUTES* processSecurity,
    SECURITY_ATTRIBUTES* threadSecurity, BOOL inherit, DWORD flags, void* environment,
    LPCWSTR directory, STARTUPINFOW* startup, PROCESS_INFORMATION* child) {
    ++mock::creates;
    mock::need(std::wstring(file) == mock::expectedExe && std::wstring(command) == mock::expectedCommand &&
        std::wstring(directory) == mock::expectedDirectory, "Launch path or command changed");
    mock::need(!processSecurity && !threadSecurity && !environment, "Unexpected launch environment or ACL");
    mock::need(!child->hProcess && !child->hThread && !child->dwProcessId && !child->dwThreadId,
        "Process output was not initialized");
    if (mock::expectedCapture) {
        mock::need(inherit && flags == (EXTENDED_STARTUPINFO_PRESENT | CREATE_NO_WINDOW) &&
            startup->cb == sizeof(STARTUPINFOEXW) && startup->dwFlags == STARTF_USESTDHANDLES,
            "Wrong captured startup flags or size");
        auto list = reinterpret_cast<STARTUPINFOEXW*>(startup)->lpAttributeList;
        mock::need(list && list->initialized && list->bytes == 2 * sizeof(HANDLE), "Missing handle list");
        // ASan catches the old stack-use-after-scope here. Without ASan the
        // released optimized binary overwrites these values with child zeros.
        mock::need(list->values[0] == mock::writer && list->values[1] == mock::input,
            "Inherited handles were overwritten before CreateProcessW");
        mock::need(mock::handles.at(list->values[0]).inherit && mock::handles.at(list->values[1]).inherit,
            "A selected handle is not inheritable");
        mock::need(startup->hStdInput == mock::input && startup->hStdOutput == mock::writer &&
            startup->hStdError == mock::writer, "Standard handle mismatch");
        for (auto& pair : mock::handles) if (pair.second.kind == "reader")
            mock::need(!pair.second.inherit, "Reader leaked to child");
    } else {
        mock::need(!inherit && !flags && startup->cb == sizeof(STARTUPINFOW) && !startup->dwFlags,
            "Wrong normal startup flags or size");
        mock::need(mock::handles.empty(), "Normal helper created unnecessary pipe handles");
    }
    if (mock::fail("create")) return FALSE;
    child->hProcess = mock::open("process", false);
    child->hThread = mock::open("thread", false);
    child->dwProcessId = 123; child->dwThreadId = 456;
    command[0] = L'!'; // API may mutate the command buffer.
    return TRUE;
}
BOOL PeekNamedPipe(HANDLE pipe, void*, DWORD, DWORD*, DWORD* available, DWORD*) {
    mock::need(mock::handles.at(pipe).kind == "reader", "Wrong pipe inspected");
    if (mock::fail("peek")) return FALSE;
    if (mock::brokenPipe && mock::offset == mock::data.size()) { mock::error = ERROR_BROKEN_PIPE; return FALSE; }
    *available = static_cast<DWORD>(mock::data.size() - mock::offset);
    return TRUE;
}
BOOL ReadFile(HANDLE pipe, void* data, DWORD wanted, DWORD* got, void* overlapped) {
    mock::need(mock::handles.at(pipe).kind == "reader" && !overlapped, "Wrong output read");
    if (mock::fail("read")) return FALSE;
    *got = static_cast<DWORD>(std::min<size_t>(wanted, mock::data.size() - mock::offset));
    std::memcpy(data, mock::data.data() + mock::offset, *got); mock::offset += *got;
    return TRUE;
}
DWORD WaitForSingleObject(HANDLE process, DWORD time) {
    mock::need(mock::handles.at(process).kind == "process" && time == 50, "Wrong completion wait");
    mock::need(!mock::handles.count(mock::writer) && !mock::handles.count(mock::input),
        "Parent's inherited handles remained open while waiting");
    ++mock::waits;
    if (mock::fail("wait")) return WAIT_FAILED;
    return mock::exitedWithPending || mock::offset == mock::data.size() ? WAIT_OBJECT_0 : WAIT_TIMEOUT;
}
BOOL GetExitCodeProcess(HANDLE process, DWORD* code) {
    mock::need(mock::handles.at(process).kind == "process", "Wrong process exit query");
    if (mock::fail("exit")) return FALSE;
    *code = mock::exitCode; return TRUE;
}
}

#ifdef SM86_LEGACY_LIFETIME_PROBE
// Exact failing launch sequence from the prior shipped implementation, with
// the surrounding app unrelated code omitted. ASan must reject this fixture.
void legacyProbe() {
    mock::reset();
    SECURITY_ATTRIBUTES security{sizeof security, nullptr, TRUE};
    HANDLE reader = nullptr, writer = nullptr;
    HANDLE input = CreateFileW(L"NUL", GENERIC_READ, 3, &security, OPEN_EXISTING, 0, nullptr);
    CreatePipe(&reader, &writer, &security, 0); SetHandleInformation(reader, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOEXW startup{}; startup.StartupInfo.cb = sizeof startup;
    std::vector<unsigned char> attributes;
    if (mock::expectedCapture) {
        SIZE_T bytes = 0; InitializeProcThreadAttributeList(nullptr, 1, 0, &bytes);
        attributes.resize(bytes); startup.lpAttributeList = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(attributes.data());
        InitializeProcThreadAttributeList(startup.lpAttributeList, 1, 0, &bytes);
        HANDLE allowed[] = {writer, input};
        UpdateProcThreadAttribute(startup.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, allowed, sizeof allowed, nullptr, nullptr);
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
        startup.StartupInfo.hStdOutput = writer; startup.StartupInfo.hStdError = writer; startup.StartupInfo.hStdInput = input;
    }
    PROCESS_INFORMATION child{};
    auto command = mock::expectedCommand;
    CreateProcessW(mock::expectedExe.c_str(), command.data(), nullptr, nullptr, TRUE,
        EXTENDED_STARTUPINFO_PRESENT | CREATE_NO_WINDOW, nullptr, mock::expectedDirectory.c_str(), &startup.StartupInfo, &child);
}
int main() { legacyProbe(); return 0; }
#else
int main() {
    int scenarios = 0;
    for (bool capture : {false, true}) {
        mock::reset(capture); mock::exitCode = 42;
        if (capture) mock::data = "{\"profile\":\"Game\"}\n";
        auto result = mock::launch();
        mock::need(result.code == 42 && result.output == mock::data, "Lost exit code or output");
        mock::need(mock::creates == 1 && mock::waits == 1, "Launch/wait count mismatch");
        mock::clean(); ++scenarios;
    }
    for (auto where : {"input", "pipe", "partial_pipe", "inherit", "size", "initialize", "update", "peek", "read", "wait", "exit"}) {
        mock::reset(); mock::failAt = where; mock::failureCode = 5; mock::data = "x";
        bool caught = false;
        try { mock::launch(); } catch (const std::runtime_error& e) {
            std::string text = e.what();
            mock::need(text.find("Windows error 5: System failure 5.") != text.npos, "Failure error was overwritten by cleanup");
            mock::need(text.find("Driver_Settings.exe") != text.npos && text.find("caf\xc3\xa9") != text.npos,
                "Missing helper identity or Unicode path");
            caught = true;
        }
        mock::need(caught, "Injected failure was not reported"); mock::clean(); ++scenarios;
    }
    for (bool capture : {false, true}) for (DWORD error : {2u, 5u, 6u, 87u, 126u, 193u, 740u}) {
        mock::reset(capture); mock::failAt = "create"; mock::failureCode = error;
        bool caught = false;
        try { mock::launch(); } catch (const std::runtime_error& e) {
            auto expected = "Windows error " + std::to_string(error) + ": System failure " + std::to_string(error) + ".";
            mock::need(std::string(e.what()).find(expected) != std::string::npos, "CreateProcess error was lost"); caught = true;
        }
        mock::need(caught && mock::creates == 1 && !mock::waits, "Failed launch was waited on or ignored");
        mock::clean(); ++scenarios;
    }
    mock::reset(); mock::failAt = "create"; mock::failureCode = 43210; mock::unknownMessage = true;
    try { mock::launch(); mock::need(false, "Unknown failure ignored"); } catch (const std::runtime_error& e) {
        mock::need(std::string(e.what()).find("Windows error 43210") != std::string::npos, "Unknown error number lost");
    }
    mock::clean(); ++scenarios;
    mock::reset(); mock::data = "{\"schema\":1,\"status\":\"ready\",\"warning\":\"" + std::string(300000, 'X') + "\",\"changes\":[]}\n";
    auto large = mock::launch();
    mock::need(!large.outputTruncated && large.output == mock::data && mock::offset == mock::data.size() && mock::waits >= 4,
        "Valid installer report was silently truncated at the old 128 KiB boundary");
    mock::clean(); ++scenarios;
    mock::reset(); mock::data.assign(200000, 'R'); mock::exitedWithPending = true;
    auto exited = mock::launch();
    mock::need(!exited.outputTruncated && exited.output == mock::data && mock::waits == 1,
        "A completed helper's remaining report was not drained");
    mock::clean(); ++scenarios;
    for (bool exitedEarly : {false, true}) {
        for (size_t size : {manager_process::reportLimit, manager_process::reportLimit + 1, manager_process::reportLimit + 200000}) {
            mock::reset(); mock::data.assign(size, 'L'); mock::exitedWithPending = exitedEarly;
            auto bounded = mock::launch();
            mock::need(bounded.output.size() == manager_process::reportLimit &&
                bounded.outputTruncated == (size > manager_process::reportLimit),
                "Capture limit or overflow reporting is incorrect");
            if (!exitedEarly) mock::need(mock::offset == mock::data.size(), "A running helper was left blocked on a full pipe");
            else mock::need(mock::waits == 1 && mock::offset <= 65536 + manager_process::reportLimit + 1,
                "Post-exit draining is unbounded");
            mock::clean(); ++scenarios;
        }
    }
    mock::reset(); mock::brokenPipe = true; mock::data = "last output";
    auto broken = mock::launch(); mock::need(broken.output == "last output", "Broken pipe lost final bytes");
    mock::clean(); ++scenarios;
    mock::reset(); mock::expectedCommand.assign(32767, L'x');
    try { mock::launch(); mock::need(false, "Long command accepted"); } catch (const std::runtime_error& e) {
        mock::need(std::string(e.what()) == "Command line is too long", "Wrong command length diagnostic");
    }
    mock::need(mock::creates == 0, "Oversized command reached Windows"); mock::clean(); ++scenarios;
    std::cout << scenarios << " launcher contract scenarios passed (Win32 double; no native Windows execution).\n";
}
#endif
