#include "../folder_scan.hpp"
#include "../../setup/game_config_policy.hpp"
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>

// Filesystem and PE access are deterministic seams; the production traversal,
// collection grouping, metadata policy and denied-read fallback run unchanged.
namespace {
unsigned checks=0;
void check(bool value,const char* why){++checks;if(!value)throw std::runtime_error(why);}
using folder_scan::join;using folder_scan::parent;
const std::wstring xbox=L"C:\\XboxGames";
const std::wstring ninja=join(xbox,L"NINJA GAIDEN- Ragebound");
const std::wstring marvel=join(xbox,L"MARVEL Cosmic Invasion Demo");
struct Node {
 std::vector<std::wstring> files,dirs;
 preflight::GameConfigPolicy policy;
 bool config=false,deny=false,malformed=false;
 std::vector<std::wstring> rawTargets;
};
struct Executable {unsigned error=0;bool malformed=false;unsigned api=1;};
struct Io {
 std::map<std::wstring,Node> nodes;std::map<std::wstring,Executable> exes;
 std::vector<std::wstring> metadataReads;
 Node& node(const std::wstring& path){return nodes[catalog::pathKey(path)];}
 bool config(const std::wstring& path){auto it=nodes.find(catalog::pathKey(path));return it!=nodes.end()&&it->second.config;}
 void directory(const std::wstring& path){node(path);const auto owner=parent(path);if(!owner.empty())node(owner).dirs.push_back(folder_scan::base(path));}
 void declaration(const std::wstring& path,const std::vector<preflight::GameConfigPolicy::Attributes>& entries){
  auto& n=node(path);n.config=true;n.policy.begin(L"Game",{},false);n.policy.begin(L"ExecutableList",{},false);
  for(const auto& attrs:entries)n.policy.begin(L"Executable",attrs,true);
  n.policy.end(L"ExecutableList");n.policy.end(L"Game");n.policy.finish();
 }
 std::vector<std::wstring> targets(const std::wstring& path){
  metadataReads.push_back(path);auto it=nodes.find(catalog::pathKey(path));if(it==nodes.end())return {};
  const auto& n=it->second;if(n.malformed)throw std::runtime_error("Malformed MicrosoftGame.config");
  return n.rawTargets.empty()?n.policy.x64Executables():n.rawTargets;
 }
 folder_scan::Listing list(const std::wstring& path,bool directories,std::size_t cap){
  const auto it=nodes.find(catalog::pathKey(path));if(it==nodes.end())throw preflight::FileAccessError("Missing directory",3);
  if(it->second.deny)throw preflight::FileAccessError("Cannot enumerate game folder",5);
  auto values=directories?it->second.dirs:it->second.files;std::sort(values.begin(),values.end());
  const bool limited=values.size()>cap;if(limited)values.resize(cap);return {values,limited};
 }
 preflight::Imports readPE(const std::wstring& path){
  auto it=exes.find(catalog::pathKey(path));if(it==exes.end())throw preflight::FileAccessError("File not found",2);
  const auto& e=it->second;if(e.error)throw preflight::FileAccessError("Executable read failed",e.error);
  if(e.malformed)throw std::runtime_error("Malformed PE");
  preflight::Imports imports;imports.machine=0x8664;imports.plus=true;if(e.api)imports.direct={"d3d11.dll"};return imports;
 }
 preflight::TargetInspection metadata(const std::wstring& path){
  for(auto dir=parent(path);!dir.empty();dir=parent(dir))if(config(dir)){
   const auto relative=path.substr(dir.size()+1);
   if(!node(dir).policy.identifiesX64(relative))throw std::runtime_error("Xbox metadata does not identify this EXE");
   preflight::Imports imports;imports.machine=0x8664;imports.plus=true;
   return {imports,true,join(dir,L"MicrosoftGame.config"),{1,2,3}};
  }
  throw std::runtime_error("No Xbox metadata");
 }
};
struct Found {std::wstring path;bool protectedExe=false;int rank=0;unsigned api=0;};
struct Scan {
 std::vector<Found> found;std::vector<std::wstring> failed;folder_scan::Report report;
};
Scan scan(Io& io,const std::wstring& root,folder_scan::Limits limits={}){
 Scan result;std::set<std::wstring> seen;
 result.report=folder_scan::walk(root,io,[]{return false;},[&](const std::wstring& path,bool declared){
  if(!seen.insert(catalog::pathKey(path)).second)return;
  auto relative=path.substr(root.size()+1);std::string name(relative.begin(),relative.end());
  if(catalog::auxiliary(name))return;
  try{
   const auto target=preflight::inspectTargetWith([&]{return io.readPE(path);},[&]{return io.metadata(path);});
   const auto api=discovery::apis(target.imports.direct);catalog::Evidence evidence;evidence.relative=name;evidence.title="NINJA GAIDEN- Ragebound";evidence.direct=api;evidence.launch=declared||target.metadataOnly;evidence.primary=evidence.launch;
   const auto rank=catalog::rank(evidence);if(rank<0)return;
   result.found.push_back({path,target.metadataOnly,rank,api});
  }catch(const std::exception&){result.failed.push_back(path);}
 },[](const auto&,bool){},limits);return result;
}
Io sample(){
 Io io;io.directory(xbox);io.directory(join(xbox,L"GameSave"));
 for(const auto& root:{ninja,marvel}){
  io.directory(root);const auto content=join(root,L"Content");io.directory(content);
  io.declaration(content,{{{L"Name",L"Game.exe"}}}); // documented PC/x64 defaults
  io.node(content).files={L"Game.exe",L"gamelaunchhelper.exe",L"MicrosoftGame.config"};
  io.exes[catalog::pathKey(join(content,L"Game.exe"))]={5,false,0};
 }
 return io;
}
void collections(){
 auto io=sample();auto installs=folder_scan::installations(xbox,io);
 check(installs.size()==2,"XboxGames became a single card or included GameSave");
 std::set<std::wstring> paths;
 for(const auto& install:installs){
  check(install.xbox&&install.title==folder_scan::base(install.path),"Xbox title or store identity was lost");paths.insert(install.path);
  auto result=scan(io,install.path);check(result.found.size()==1,"Protected game EXE was not detected from its declaration");
  check(result.found[0].protectedExe&&result.found[0].api==0,"Unknown protected imports were fabricated");
  check(result.found[0].rank>0&&result.failed.empty(),"Protected declared EXE lost ranking or a helper was inspected");
 }
 check(paths==std::set<std::wstring>{ninja,marvel},"Separate installation identity was lost");
 for(const auto& path:{ninja,join(ninja,L"Content")}){
  installs=folder_scan::installations(path,io);
  check(installs.size()==1&&installs[0].path==ninja&&installs[0].title==L"NINJA GAIDEN- Ragebound","Selecting game or Content folder created different game identities");
 }
 Io manual;manual.directory(L"D:\\Games\\SteamTitle");manual.node(L"D:\\Games\\SteamTitle").files={L"Game.exe"};
 installs=folder_scan::installations(L"D:\\Games\\SteamTitle",manual);
 check(installs.size()==1&&!installs[0].xbox,"Manual non-Xbox folder changed store policy");
}
void declaredBeforeAssetLimits(){
 Io io;io.directory(ninja);const auto content=join(ninja,L"Content"),assets=join(ninja,L"A_Assets");io.directory(assets);io.directory(content);
 for(unsigned i=0;i<100;++i)io.node(assets).files.push_back(L"asset"+std::to_wstring(i));
 const auto relative=L"Binaries\\Win64\\Game.exe";const auto exe=join(content,relative);
 io.declaration(content,{{{L"Name",relative}}});io.exes[catalog::pathKey(exe)]={5,false,0};
 // Not returned by wildcard enumeration: metadata must drive the real read.
 auto result=scan(io,ninja,{8,16,16,2});
 check(result.found.size()==1&&catalog::pathKey(result.found[0].path)==catalog::pathKey(exe),"Asset limit hid the declared nested executable");
 check(result.report.limited&&result.report.metadata==1,"Metadata-first bounded scan diagnostics are wrong");
 catalog::Evidence old;old.relative="Content/Binaries/Win64/Game.exe";
 check(catalog::rank(old)<0&&result.found[0].rank>0,"Declared Xbox evidence did not repair the unknown-API depth rejection");
 auto invalid=io;invalid.exes.clear();result=scan(invalid,ninja);
 check(result.found.empty()&&result.failed.size()==1,"Metadata invented a missing executable");
}
void failuresAndSafety(){
 auto io=sample();const auto content=join(ninja,L"Content"),exe=join(content,L"Game.exe");
 io.node(content).deny=true;auto result=scan(io,ninja);
 check(result.found.size()==1,"Wildcard denial prevented direct declared-file inspection");
 check(result.report.unreadable==2&&!result.report.issues.empty()&&result.report.issues[0].path==content,"Directory inspection failure was silently discarded");
 for(unsigned error:{2u,3u,32u,8u}){
  auto bad=sample();bad.exes[catalog::pathKey(exe)].error=error;result=scan(bad,ninja);
  check(result.found.empty()&&result.failed.size()==1,"Non-permission errors used metadata to manufacture a candidate");
 }
 auto malformed=sample();malformed.node(content).malformed=true;malformed.exes[catalog::pathKey(exe)]={0,false,1};result=scan(malformed,ninja);
 check(result.found.size()==1&&result.report.unreadable==1,"Bad config suppressed a readable valid PE or hid its error");
 for(const auto& attrs:std::vector<preflight::GameConfigPolicy::Attributes>{
  {{L"Name",L"Game.exe"},{L"TargetDeviceFamily",L"Scarlett"}},
  {{L"Name",L"Game.exe"},{L"Architecture",L"ARM64"}},
  {{L"Name",L"Game.exe"},{L"IsDevOnly",L"true"}},
  {{L"Name",L"Game.exe"},{L"TargetDeviceFamily",L""}}}){
  Io unsupported;unsupported.directory(ninja);unsupported.directory(content);unsupported.declaration(content,{attrs});unsupported.node(content).files={L"Game.exe"};unsupported.exes[catalog::pathKey(exe)]={5,false,0};
  result=scan(unsupported,ninja);check(result.found.empty()&&result.failed.size()==1,"Unsupported declaration enabled protected metadata fallback");
 }
 Io unsafe;unsafe.directory(ninja);unsafe.node(ninja).rawTargets={L"../Outside.exe",L"C:\\Other\\Game.exe",L"/Other.exe",L"Game.exe:stream"};
 result=scan(unsafe,ninja);check(result.found.empty()&&result.failed.empty()&&result.report.metadata==0,"Unsafe metadata path reached executable inspection");
 Io empty;empty.directory(ninja);result=scan(empty,ninja);check(result.found.empty()&&result.report.unreadable==0,"Empty folder manufactured a game");
 Io failed;failed.directory(ninja);failed.node(ninja).deny=true;result=scan(failed,ninja);
 check(result.found.empty()&&result.report.unreadable==2,"Unreadable scan was indistinguishable from an empty folder");
}
void cancellationAndLimits(){
 auto io=sample();unsigned attempts=0;
 auto report=folder_scan::walk(ninja,io,[]{return true;},[&](const auto&,bool){++attempts;},[](const auto&,bool){});
 check(report.cancelled&&attempts==0&&io.metadataReads.empty(),"Cancelled scan performed inspection");
 Io deep;deep.directory(ninja);deep.directory(join(ninja,L"Child"));
 auto result=scan(deep,ninja,{100,100,100,0});check(result.report.limited&&result.found.empty(),"Depth cutoff was not reported");
 Io excluded;excluded.directory(ninja);excluded.directory(join(ninja,L"Tools"));excluded.node(join(ninja,L"Tools")).files={L"Preview.exe"};
 result=scan(excluded,ninja);check(result.failed.empty()&&excluded.metadataReads.size()==1,"Scanner entered excluded tools directory");
 auto aliases=sample();auto installs=folder_scan::installations(L"c:\\xboxgames",aliases);
 check(installs.size()==2,"Case changed Xbox collection recognition");
}
}
int main(){collections();declaredBeforeAssetLimits();failuresAndSafety();cancellationAndLimits();std::cout<<checks<<" Xbox folder-scan checks passed; production traversal/grouping with filesystem seams, not Windows/game execution.\n";}
