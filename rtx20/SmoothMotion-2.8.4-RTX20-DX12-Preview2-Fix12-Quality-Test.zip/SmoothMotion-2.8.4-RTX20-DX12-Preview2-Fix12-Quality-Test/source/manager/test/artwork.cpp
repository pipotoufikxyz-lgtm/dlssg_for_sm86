#include "../art_policy.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace artwork;
 for(auto bad:{"","0","01","-1","../570","570/header","4294967296"," 570","5e2","1.0"})assert(appId(bad).empty());
 assert(assetFilename("abcd0123/library_600x900.jpg","library_600x900.jpg"));
 for(auto bad:{"../header.jpg","/header.jpg","https://evil/header.jpg","a\\header.jpg","header.jpg?q=1"})assert(!assetFilename(bad,"header.jpg"));
 assert(appId("570")=="570");assert(appId("4294967295")=="4294967295");
 assert(exactMatch(R"({"items":[{"type":"app","id":570,"name":"Dota 2"}]})","Dota 2")=="570");
 assert(exactMatch(R"({"items":[{"type":"app","id":1,"name":"Star Control"}]})","Control").empty());
 assert(exactMatch(R"({"items":[{"type":"app","id":1,"name":"Control"},{"type":"app","id":2,"name":"Control"}]})","Control").empty());
 assert(exactMatch(R"({"items":[{"type":"sub","id":1,"name":"Control"}]})","Control").empty());
 assert(exactMatch(R"({"items":[{"type":"app","id":-1,"name":"Control"}]})","Control").empty());
 for(auto bad:{"{} garbage","{\"items\":[],\"items\":[]}","[01]","[true,]","{\"x\":\"\\ud800\"}","{\"x\":no}","[1e]"}){bool failed=false;try{Parser(bad).parse();}catch(...){failed=true;}assert(failed);}
 bool depth=false;try{Parser(std::string(18,'[')+"0"+std::string(18,']')).parse();}catch(...){depth=true;}assert(depth);
 for(auto dims:{std::pair<unsigned,unsigned>{32,32},{64,64},{128,192},{300,300},{8192,8192}})assert(!dimensions(ImageRole::Cover,dims.first,dims.second));
 assert(dimensions(ImageRole::Cover,300,450));assert(dimensions(ImageRole::Cover,600,900));assert(dimensions(ImageRole::Cover,1200,1800));
 assert(quality(ImageRole::Cover,600,900)>quality(ImageRole::Cover,300,450));
 assert(!dimensions(ImageRole::Cover,460,215));assert(dimensions(ImageRole::Header,460,215));assert(dimensions(ImageRole::Header,920,430));
 const auto metadata=R"({"response":{"store_items":[{"id":3639070,"success":1,"assets":{"library_capsule":"hash/library_capsule.jpg","library_capsule_2x":"hash/library_capsule_2x.jpg","header":"other/header.jpg","header_2x":"other/header_2x.jpg"}},{"id":570,"success":1,"assets":{"library_capsule_2x":"wrong/library_capsule_2x.jpg"}}]}})";
 auto covers=assetChoices(metadata,"3639070",ImageRole::Cover);assert(covers[0]=="hash/library_capsule_2x.jpg"&&covers[1]=="hash/library_capsule.jpg");
 assert(std::find(covers.begin(),covers.end(),"wrong/library_capsule_2x.jpg")==covers.end());
 assert(assetChoices(metadata,"3639070",ImageRole::Header)[0]=="other/header_2x.jpg");
 assert(assetChoices("{bad}","3639070",ImageRole::Cover)[0]=="library_600x900_2x.jpg");
 assert(!sameMiss("SM86-ART-MISS-2\nhash/library_capsule.jpg\n","hash/library_capsule.jpg"));
 assert(sameMiss("SM86-ART-MISS-3\nhash/library_capsule.jpg\n","hash/library_capsule.jpg"));
 std::cout<<"Artwork identity, ambiguity, Unicode and malformed metadata checks passed.\n";
}
