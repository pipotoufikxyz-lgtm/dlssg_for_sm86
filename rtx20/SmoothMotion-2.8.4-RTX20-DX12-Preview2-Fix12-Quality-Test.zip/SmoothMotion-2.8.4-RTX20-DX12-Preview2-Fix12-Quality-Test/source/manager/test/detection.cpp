#include "../catalog.hpp"
#include "../steam_metadata.hpp"
#include "../art_policy.hpp"
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <iterator>
static int checks=0;
void require(bool ok,const char* description){++checks;if(!ok)throw std::runtime_error(description);}
std::string read(const std::string& name){std::ifstream in(name,std::ios::binary);if(!in)throw std::runtime_error("Missing fixture: "+name);return {std::istreambuf_iterator<char>(in),{}};}
struct Choice{std::wstring exe;int rank=0;};
struct Game{std::wstring title,exe,installRoot,store,storeId,steamId,steamRoot,cover,hero,pinnedExe;std::vector<Choice> choices;};
void chooseFixture(Game& g,const Choice& choice){g.exe=choice.exe;}
int main(int argc,char** argv){
 require(catalog::auxiliary("gamelaunchhelper.exe"),"Xbox launch helper is not a renderer target");
 require(!catalog::auxiliary("Game.exe"),"Xbox game EXE remains eligible");try{
 if(argc!=2)throw std::runtime_error("Pass fixture directory");std::string fixtures=argv[1];
 auto root=std::wstring(L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Amnesia The Bunker");
 std::vector<Game> games;
 for(const auto* name:{L"AmnesiaTheBunker.exe",L"MaterialEditor.exe",L"LevelEditor.exe",L"ModelEditor.exe",L"ParticleEditor.exe",L"ModelViewer.exe"}){
  Game g;g.title=L"Amnesia: The Bunker";g.exe=root+L"\\"+name;g.store=L"Steam";g.steamId=L"1944430";g.storeId=g.steamId;g.installRoot=catalog::legacySteamRoot(g.exe);catalog::merge(games,g,chooseFixture);
 }
 require(games.size()==1,"Six saved EXE records must become one installation card");
 require(catalog::pathKey(games[0].installRoot)==catalog::pathKey(root),"Legacy Steam installation root must preserve path boundaries");
 require(catalog::legacySteamRoot(L"\\\\?\\"+root+L"\\Binaries\\Win64\\Game.exe")==catalog::pathKey(root),"Extended paths migrate correctly");
 auto duplicate=games[0];duplicate.installRoot=catalog::pathKey(root)+L"/";catalog::merge(games,duplicate,chooseFixture);
 require(games.size()==1,"Case and trailing slash aliases cannot create duplicate games");
 auto other=duplicate;other.installRoot=L"D:\\Other install";other.exe=other.installRoot+L"\\AmnesiaTheBunker.exe";catalog::merge(games,other,chooseFixture);
 require(games.size()==2,"Separate physical installations with the same title stay separate");
 other=duplicate;other.title=L"Another game";other.installRoot=L"D:\\Another game";other.exe=other.installRoot+L"\\game.exe";other.steamId=L"1944430";catalog::merge(games,other,chooseFixture);
 require(games.size()==3,"Artwork ID alone cannot merge separate installations");
 require(catalog::within(root+L"\\Game.exe",root),"Path within root");
 require(!catalog::within(root+L"2\\Game.exe",root),"Sibling prefix is not inside an installation");
 for(auto name:{"MaterialEditor.exe","LevelEditor.exe","ModelEditor.exe","ParticleEditor.exe","ModelViewer.exe","GodotWorkshopUtility.exe","CrashReportClient.exe","UE4PrereqSetup_x64.exe","EasyAntiCheat_EOS_Setup.exe","Tools/Preview.exe","Game/Binaries/ThirdParty/Helper.exe"})require(catalog::auxiliary(name),"Editor or utility must be excluded");
 for(auto name:{"AmnesiaTheBunker.exe","BLACKWOOD.exe","Pathogenic.exe","PEAK.exe","CivilizationVI_DX12.exe","Project/Binaries/Win64/Project-Win64-Shipping.exe","TheToolboxGame.exe"})require(!catalog::auxiliary(name),"Real game executable must remain a candidate");
 std::vector<Choice> candidates;
 for(auto name:{"AmnesiaTheBunker.exe","MaterialEditor.exe","LevelEditor.exe","ModelEditor.exe","ParticleEditor.exe","ModelViewer.exe"}){catalog::Evidence e;e.relative=name;e.title="Amnesia: The Bunker";e.folder="Amnesia The Bunker";e.direct=8;int rank=catalog::rank(e);if(rank>=0)candidates.push_back({std::wstring(name,name+std::char_traits<char>::length(name)),rank});}
 catalog::sortCandidates(candidates);require(candidates.size()==1&&candidates[0].exe==L"AmnesiaTheBunker.exe","Amnesia editors must never compete with its OpenGL game executable");
 catalog::Evidence launch;launch.relative="Game.exe";launch.launch=launch.primary=true;catalog::Evidence shipping;shipping.relative="Game/Binaries/Win64/Game-Win64-Shipping.exe";shipping.direct=2;
 require(catalog::rank(shipping)>catalog::rank(launch),"Unreal renderer outranks its forwarding launcher");
 catalog::Evidence wardogsLauncher;wardogsLauncher.relative="WardogsLauncher-Shipping.exe";wardogsLauncher.launch=wardogsLauncher.primary=true;wardogsLauncher.direct=3;
 catalog::Evidence wardogsRenderer;wardogsRenderer.relative="Wardogs/Binaries/Win64/WardogsClient-Win64-Shipping.exe";
 require(catalog::rank(wardogsRenderer)>catalog::rank(wardogsLauncher),"Wardogs Shipping launcher with store metadata cannot outrank its renderer");
 using Target=catalog::TargetEvidence;
 std::vector<Target> wardogs{{wardogsRenderer.relative,true,0,catalog::rank(wardogsRenderer)},{wardogsLauncher.relative,true,3,catalog::rank(wardogsLauncher)}};
 auto target=catalog::resolveTarget(wardogs);require(target.index==0&&!target.needsChoice,"Automatic Wardogs selection uses actual Binaries/Win64 renderer even with dynamic API loads");
 target=catalog::resolveTarget(wardogs,1);require(target.index==0&&target.redirected&&!target.needsChoice,"Explicit or pasted Wardogs launcher redirects to unique renderer");
 target=catalog::resolveTarget(wardogs,0);require(target.index==0&&!target.redirected&&!target.needsChoice,"Explicit actual renderer is preserved");
 std::vector<Target> generic{{"Project/Binaries/Win64/Project-Win64-Shipping.exe",true,2,400},{"Game.exe",true,0,100}};
 target=catalog::resolveTarget(generic,1);require(target.index==0&&target.redirected,"Nameless Unreal bootstrap resolves using structure rather than a game-specific name");
 generic[1].api=1;target=catalog::resolveTarget(generic,1);require(target.index==1&&!target.redirected,"Explicit root game with graphics evidence is not replaced by another game in a child folder");
 generic[1].api=0;generic.push_back({"Other/Binaries/Win64/Other-Win64-Shipping.exe",true,2,390});
 target=catalog::resolveTarget(generic);require(target.needsChoice,"Multiple renderer variants are not selected by alphabetical order or rank");
 target=catalog::resolveTarget(generic,1);require(target.needsChoice&&target.index==1,"An ambiguous launcher selection waits for an actual executable choice");
 target=catalog::resolveTarget(generic,2);require(target.index==2&&!target.needsChoice,"An explicitly selected renderer resolves ambiguity");
 target=catalog::resolveTarget(wardogs,1,false);require(target.needsChoice&&!target.redirected,"A scan cutoff cannot prove a renderer is unique");
 target=catalog::resolveTarget(wardogs,0,false);require(target.index==0&&!target.needsChoice,"Explicit actual renderer does not depend on complete sibling traversal");
 target=catalog::resolveTarget({{"Launcher.exe",true,0,0}},0,false);require(target.needsChoice,"Incomplete scan cannot certify an unverified launcher when no renderer was reached");
 auto alias=wardogs;alias.push_back({"WARDOGS\\BINARIES\\WIN64\\WARDOGSCLIENT-WIN64-SHIPPING.EXE",true,0,400});
 target=catalog::resolveTarget(alias,1);require(!target.needsChoice&&target.index==0,"Case or separator aliases do not create false renderer ambiguity");
 for(auto path:{"WardogsLauncher-Shipping.exe","Binaries/Win64/GameLauncher-Win64-Shipping.exe","Engine/Binaries/Win64/CrashReportClient-Win64-Shipping.exe","Game/Binaries/Win64/GameServer-Win64-Shipping.exe","Game/Binaries/Win64/GameEditor-Win64-Shipping.exe","Game/Binaries/Win64/ShaderCompileWorker-Win64-Shipping.exe","Tools/Game/Binaries/Win64/Game-Win64-Shipping.exe","Game/Binaries/Win32/Game-Win64-Shipping.exe","Game/BinariesCopy/Win64/Game-Win64-Shipping.exe"})require(!catalog::unrealRenderer(path),"Launcher, helper, server, editor and wrong architecture location cannot become a renderer");
 require(!catalog::unrealRenderer(wardogsRenderer.relative,false),"A 32-bit PE in a Win64-named directory is never a 64-bit renderer");
 for(auto path:{"../Game/Binaries/Win64/Game-Win64-Shipping.exe","C:/Game/Binaries/Win64/Game-Win64-Shipping.exe","/Game/Binaries/Win64/Game-Win64-Shipping.exe","Game//Binaries/Win64/Game-Win64-Shipping.exe","Game/./Binaries/Win64/Game-Win64-Shipping.exe","A/B/C/D/E/F/G/Binaries/Win64/Game-Win64-Shipping.exe"}){
  require(!catalog::boundedRelative(path),"Unsafe paths and paths beyond traversal depth cannot guide redirection");
  target=catalog::resolveTarget({{path,true,2,500},{"Launcher.exe",true,0,0}},1);require(target.index==1&&!target.redirected,"Invalid renderer path is ignored by the production resolver");
 }
 require(catalog::boundedRelative("A/B/C/D/E/F/Binaries/Win64/Game-Win64-Shipping.exe"),"The final permitted traversal depth remains discoverable");
 target=catalog::resolveTarget({{"GameA.exe",true,2,120},{"GameB.exe",true,2,120}});require(target.needsChoice,"Equal generic executable evidence requires user selection");
 require(catalog::resolveTarget({}).index==std::string::npos,"An empty scan has no target");
 target=catalog::resolveTarget({{"Content/Game.exe",true,0,285,true}},0,false);
 require(target.index==0&&!target.needsChoice,"Explicit metadata-verified Xbox EXE remains selectable after an asset scan limit");
 target=catalog::resolveTarget({{"Content/Game.exe",true,0,285,false}},0,false);
 require(target.needsChoice,"Unknown imports without verified metadata cannot certify an incomplete scan");
 catalog::Evidence actual;actual.relative="bin/Actual.exe";actual.launch=actual.primary=true;catalog::Evidence random;random.relative="Unrelated.exe";random.direct=7;
 require(catalog::rank(actual)>catalog::rank(random),"Store launch evidence outranks an unrelated rendering EXE");
 actual.launch=actual.primary=false;actual.unity=true;actual.dependencies=3;
 require(catalog::rank(actual)>catalog::rank(random),"Unity data identifies the real game");
 actual.unity=false;actual.godot=true;actual.direct=4;
 require(catalog::rank(actual)>catalog::rank(random),"Godot package identifies the real game");
 actual.x64=false;require(catalog::rank(actual)>=0,"A 32-bit game is detected rather than silently discarded");
 Game dx;dx.title=L"Two APIs";dx.installRoot=L"D:\\Two APIs";dx.store=L"Steam";dx.exe=dx.installRoot+L"\\GameDX11.exe";dx.choices={{dx.exe,250},{dx.installRoot+L"\\GameDX12.exe",240}};dx.pinnedExe=dx.choices[1].exe;
 std::vector<Game> one;catalog::merge(one,dx,chooseFixture);auto updated=dx;updated.pinnedExe.clear();updated.exe=updated.choices[0].exe;catalog::merge(one,updated,chooseFixture);
 require(one.size()==1&&one[0].choices.size()==2,"Rendering variants belong to a single card");
 require(one[0].exe==dx.choices[1].exe,"Explicit EXE choice survives a fresh detection merge");
 auto manual=dx;manual.title=L"GameDX12";manual.store=L"Manual";manual.exe=dx.choices[1].exe;manual.choices={{manual.exe,100}};catalog::merge(one,manual,chooseFixture);
 require(one.size()==1&&one[0].store==L"Steam"&&one[0].title==L"Two APIs","Adding a manual EXE preserves known store identity");
 require(one[0].choices.size()==2&&one[0].choices[0].rank==250,"Automatic EXE selection remains ranked after a manual add");

 std::vector<catalog::Hidden> hidden{{one[0].installRoot,one[0].exe}};
 auto visible=one;catalog::filterHidden(visible,hidden);require(visible.empty(),"Removed game stays hidden after discovery");
 auto second=one[0];second.installRoot=L"E:\\OtherCopy";second.exe=second.installRoot+L"\\game.exe";visible={second};catalog::filterHidden(visible,hidden);require(visible.size()==1,"Removal does not hide another physical install with same title");
 catalog::reveal(hidden,one[0]);require(hidden.empty(),"Explicit add restores a removed game");
 auto fresh=one[0];fresh.pinnedExe.clear();fresh.exe=dx.exe;fresh.choices={{dx.exe,250}};catalog::merge(one,fresh,chooseFixture);
 require(one[0].choices.size()==1&&one[0].pinnedExe.empty()&&one[0].exe==dx.exe,"Rescanning cannot revive a stale pinned executable absent from fresh candidates");
 for(int version:{39,40,41}){
  auto bytes=read(fixtures+"/appinfo-v"+std::to_string(version)+".bin");auto apps=steam_metadata::parse(bytes,{1944430});
  require(apps.size()==1,"Steam cache fixture must parse");auto& app=apps.at(1944430);
  require(app.title=="Amnesia: The Bunker"&&app.type=="game","Steam app identity is correct");
  require(app.launches.size()==2,"Only Windows game launch entries are accepted");
  require(app.launches[0].path=="AmnesiaTheBunker.exe"&&app.launches[0].primary,"Default Windows launch target is retained");
  require(app.launches[1].path=="Binaries/GameDX12.exe","Alternate Windows launch target is retained");
  require(steam_metadata::parse(bytes,{999}).empty(),"Uninstalled cache entries are skipped");
  for(size_t end=0;end<bytes.size();++end){auto truncated=bytes.substr(0,end);auto result=steam_metadata::parse(truncated,{1944430});require(result.size()<=1,"Truncated cache fails without excessive output");}
  std::mt19937 rng(100+version);for(int trial=0;trial<2000;++trial){auto corrupt=bytes;for(int j=0;j<3;++j)corrupt[rng()%corrupt.size()]=char(rng()%256);auto result=steam_metadata::parse(corrupt,{1944430});require(result.size()<=1,"Malformed cache is bounded");}
 }
 for(auto type:{"tool","dlc","music","video","config","driver"})require(!steam_metadata::gameType(type),"Non-game store types are not game cards");
 for(auto type:{"game","demo","mod","application",""})require(steam_metadata::gameType(type),"Games and unknown metadata use detection");
 for(auto id:{"3639070","3808690"}){auto text=read(fixtures+"/"+id+"-assets.json");auto json=artwork::Parser(text).parse();auto& item=json.at("response").at("store_items").array.at(0);auto cover=item.at("assets").at("library_capsule").value;require(artwork::appId(item.at("id").value)==id,"Store image belongs to exact app");require(!artwork::assetFilename(cover,"library_600x900.jpg"),"Negative control reproduces old capsule rejection");require(artwork::coverAsset(cover),"BLACKWOOD and Pathogenic modern covers must be accepted");}
 require(artwork::coverAsset("hash/library_600x900.jpg"),"Legacy cover filenames still work");
 require(artwork::coverAsset("hash/library_capsule_2x.png"),"High-resolution PNG covers work");
 for(auto path:{"../library_capsule.jpg","//elsewhere/library_capsule.jpg","https://elsewhere/library_capsule.jpg","hash/../library_capsule.jpg","hash/header.jpg","hash/library_capsule.jpg?redirect=1"})require(!artwork::coverAsset(path),"Unsafe or unrelated image filenames are rejected");
 require(!artwork::sameMiss("Artwork unavailable; retry after six hours.\n","hash/library_capsule.jpg"),"Legacy negative cache cannot block corrected cover paths");
 require(!artwork::sameMiss("SM86-ART-MISS-2\nhash1/library_capsule.jpg\n","hash2/library_capsule.jpg"),"Changed image path gets a fresh download");
 require(artwork::sameMiss("SM86-ART-MISS-3\nhash/library_capsule.jpg\n","hash/library_capsule.jpg"),"Unchanged failed URL can be rate limited");
 std::cout<<checks<<" detection, migration, launch metadata and real artwork checks passed.\n";
 return 0;
}catch(const std::exception& e){std::cerr<<"FAILED after "<<checks<<" checks: "<<e.what()<<"\n";return 1;}}
