#pragma once
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <bcrypt.h>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cwchar>
#include <string>
#include <vector>
#include <stdexcept>
#include <memory>
#include "discovery.hpp"
#include "catalog.hpp"
#include "folder_scan.hpp"
#include "steam_metadata.hpp"
#include "art_policy.hpp"
#include "process.hpp"
#include "../setup/windows_pe.hpp"
#include "../setup/windows_game_target.hpp"
#include "../setup/import_graph.hpp"
#include "../setup/policy.hpp"
#include "helper_identity.hpp"
#include "../setup/payload_hashes.hpp"
#include "../motion/identity.hpp"
#include "../guard/session.hpp"
namespace manager {
struct Choice {std::wstring exe,reason;unsigned api=0;bool indirect=false,x64=true;int rank=0;bool protectedExe=false;};
struct Game {std::wstring title,exe,store,steamId,steamRoot,cover,hero,installRoot,storeId,pinnedExe,reason;std::vector<Choice> choices;unsigned api=0,directApi=0,dependencyApi=0;bool x64=true,protectedExe=false,indirect=false,nr=false,reshade=false,opti=false,antiCheat=false,installed=false,recovery=false,disabled=false,sessionActive=false,limited=false,targetChoiceRequired=false;int rank=0;};
struct ScanStats {size_t excluded=0,unreadable=0,limited=0,metadata=0,detected=0;std::vector<std::wstring> nonGameRoots;std::vector<folder_scan::Issue> issues;};
inline void scanFailure(ScanStats* stats,const std::wstring& path,const std::exception& error){if(stats){++stats->unreadable;if(stats->issues.size()<8)stats->issues.push_back({path,error.what()});}}
inline std::wstring base(const std::wstring& p){auto at=p.find_last_of(L"\\/");return at==p.npos?p:p.substr(at+1);}
inline std::wstring parent(const std::wstring& p){auto at=p.find_last_of(L"\\/");return at==p.npos?L"":p.substr(0,at+1);}
inline std::wstring lower(std::wstring s){for(auto& c:s)if(c>=L'A'&&c<=L'Z')c+=32;return s;}
inline bool equal(const std::wstring& a,const std::wstring& b){return CompareStringOrdinal(a.c_str(),-1,b.c_str(),-1,TRUE)==CSTR_EQUAL;}
inline std::wstring join(std::wstring p,const std::wstring& name){if(!p.empty()&&p.back()!=L'\\'&&p.back()!=L'/')p+=L'\\';return p+name;}
inline std::wstring full(const std::wstring& p){DWORD n=GetFullPathNameW(p.c_str(),0,nullptr,nullptr);if(!n||n>32768)throw std::runtime_error("Invalid or excessive path");std::wstring s(n,L'\0');DWORD got=GetFullPathNameW(p.c_str(),n,s.data(),nullptr);if(!got||got>=n)throw std::runtime_error("Cannot resolve path");s.resize(got);return s;}
inline std::wstring canonical(const std::wstring& p){
 auto result=full(p);HANDLE h=CreateFileW(result.c_str(),0,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,nullptr);
 if(h!=INVALID_HANDLE_VALUE){DWORD n=GetFinalPathNameByHandleW(h,nullptr,0,FILE_NAME_NORMALIZED|VOLUME_NAME_DOS);if(n&&n<32768){std::wstring value(n+1,L'\0');DWORD got=GetFinalPathNameByHandleW(h,value.data(),n+1,FILE_NAME_NORMALIZED|VOLUME_NAME_DOS);if(got&&got<=n){value.resize(got);result=value;}}CloseHandle(h);}
 if(result.rfind(L"\\\\?\\UNC\\",0)==0)result=L"\\\\"+result.substr(8);else if(result.rfind(L"\\\\?\\",0)==0)result=result.substr(4);
 while(result.size()>3&&(result.back()==L'\\'||result.back()==L'/'))result.pop_back();return result;
}
inline std::wstring fromUtf8(const std::string& s){int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),nullptr,0);if(n<=0&&!s.empty())throw std::runtime_error("Invalid manifest text");std::wstring out(n,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),static_cast<int>(s.size()),out.data(),n);return out;}
inline std::string toUtf8(const std::wstring& s){int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),nullptr,0,nullptr,nullptr);if(n<=0&&!s.empty())throw std::runtime_error("Invalid path text");std::string out(n,'\0');WideCharToMultiByte(CP_UTF8,0,s.data(),static_cast<int>(s.size()),out.data(),n,nullptr,nullptr);return out;}
inline bool ordinary(const std::wstring& p,bool dir=false){DWORD a=GetFileAttributesW(p.c_str());return a!=INVALID_FILE_ATTRIBUTES&&!(a&FILE_ATTRIBUTE_REPARSE_POINT)&&bool(a&FILE_ATTRIBUTE_DIRECTORY)==dir;}
inline std::string read(const std::wstring& p,std::uint64_t limit=8u*1024u*1024u){if(!ordinary(p))return {};HANDLE f=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);if(f==INVALID_HANDLE_VALUE)return {};LARGE_INTEGER n{};std::string s;if(GetFileSizeEx(f,&n)&&n.QuadPart>0&&static_cast<std::uint64_t>(n.QuadPart)<=limit){s.resize(static_cast<size_t>(n.QuadPart));DWORD got=0;if(!ReadFile(f,s.data(),static_cast<DWORD>(s.size()),&got,nullptr)||got!=s.size())s.clear();}CloseHandle(f);return s;}
inline void writeNew(const std::wstring& p,const std::string& data){HANDLE f=CreateFileW(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,0,nullptr);if(f==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot create data file");DWORD wrote=0;bool ok=WriteFile(f,data.data(),static_cast<DWORD>(data.size()),&wrote,nullptr)&&wrote==data.size();ok=FlushFileBuffers(f)&&ok;CloseHandle(f);if(!ok)throw std::runtime_error("Cannot save data file");}
inline std::wstring env(const wchar_t* name){DWORD n=GetEnvironmentVariableW(name,nullptr,0);if(!n||n>32768)return {};std::wstring out(n,L'\0');DWORD got=GetEnvironmentVariableW(name,out.data(),n);if(!got||got>=n)return {};out.resize(got);return out;}
inline std::wstring reg(HKEY hive,const std::wstring& key,const wchar_t* value,REGSAM view=0){HKEY h=nullptr;if(RegOpenKeyExW(hive,key.c_str(),0,KEY_QUERY_VALUE|view,&h)!=ERROR_SUCCESS)return {};DWORD type=0,n=0;RegQueryValueExW(h,value,nullptr,&type,nullptr,&n);std::wstring out;if((type==REG_SZ||type==REG_EXPAND_SZ)&&n>=2&&n<=65536){out.resize(n/2+1,L'\0');if(RegQueryValueExW(h,value,nullptr,&type,reinterpret_cast<BYTE*>(out.data()),&n)!=ERROR_SUCCESS)out.clear();else out.resize(std::wcslen(out.c_str()));}RegCloseKey(h);return out;}
struct Handle {HANDLE h=INVALID_HANDLE_VALUE;explicit Handle(HANDLE v):h(v){}~Handle(){if(h&&h!=INVALID_HANDLE_VALUE)CloseHandle(h);}Handle(const Handle&)=delete;};
inline preflight::Imports pe(const std::wstring& file,bool requireExe){return preflight::inspectFile(file,requireExe);}

inline std::vector<std::wstring> children(const std::wstring& dir,bool directories,size_t cap=4096){std::vector<std::wstring> out;if(!ordinary(dir,true))return out;WIN32_FIND_DATAW data{};HANDLE h=FindFirstFileW(join(dir,L"*").c_str(),&data);if(h==INVALID_HANDLE_VALUE)return out;do{if(data.cFileName[0]==L'.'&&(data.cFileName[1]==0||(data.cFileName[1]==L'.'&&data.cFileName[2]==0)))continue;if(data.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)continue;if(bool(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)==directories)out.push_back(data.cFileName);if(out.size()>=cap)break;}while(FindNextFileW(h,&data));FindClose(h);std::sort(out.begin(),out.end());return out;}
struct FolderIo {
 bool config(const std::wstring& dir){return ordinary(join(dir,L"MicrosoftGame.config"));}
 std::vector<std::wstring> targets(const std::wstring& dir){
  auto bytes=preflight::game_metadata::read(join(dir,L"MicrosoftGame.config"));
  return bytes.empty()?std::vector<std::wstring>{}:preflight::game_metadata::parse(bytes).x64Executables();
 }
 folder_scan::Listing list(const std::wstring& dir,bool directories,size_t cap){
  preflight::game_metadata::ordinary(dir,true);
  folder_scan::Listing result;WIN32_FIND_DATAW data{};HANDLE h=FindFirstFileW(join(dir,L"*").c_str(),&data);
  if(h==INVALID_HANDLE_VALUE){const auto error=GetLastError();if(error==ERROR_FILE_NOT_FOUND)return result;throw preflight::FileAccessError("Cannot enumerate game folder",error);}
  struct FindHandle{HANDLE h;~FindHandle(){FindClose(h);}} handle{h};
  for(;;){
   const std::wstring name=data.cFileName;
   if(name!=L"."&&name!=L".."&&!(data.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)&&bool(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)==directories){
    if(result.names.size()>=cap){result.limited=true;break;}result.names.push_back(name);
   }
   if(!FindNextFileW(h,&data)){const auto error=GetLastError();if(error!=ERROR_NO_MORE_FILES)throw preflight::FileAccessError("Game folder enumeration failed",error);break;}
  }
  std::sort(result.names.begin(),result.names.end());return result;
 }
};
inline bool ends(const std::wstring& s,const wchar_t* suffix){const auto n=std::wcslen(suffix);return s.size()>=n&&equal(s.substr(s.size()-n),suffix);}
inline HANDLE verified(const std::wstring& file,const char* expected);
inline bool matches(const std::wstring& file,const char* expected){try{Handle h(verified(file,expected));return h.h!=INVALID_HANDLE_VALUE;}catch(...){return false;}}
inline void refresh(Game& g){auto root=parent(g.exe);g.installed=ordinary(join(root,L"plugins\\SM86Bootstrap.asi"))||motion::installedPlugin(payload_hashes::motion,payload_hashes::asi,[&](const char* hash){return matches(join(root,L"new.asi"),hash);});if(!g.installed&&ordinary(join(root,L"version.dll"))){try{g.installed=motion::installedNativeProxy(payload_hashes::native_proxy,payload_hashes::standalone,[&](const char* hash){return matches(join(root,L"version.dll"),hash);});}catch(...) {}}const bool legacy=ordinary(join(root,L"plugins\\SM86Bootstrap.asi"));g.recovery=legacy&&GetFileAttributesW(join(root,L"SM86\\session.pending").c_str())!=INVALID_FILE_ATTRIBUTES;g.disabled=legacy&&GetFileAttributesW(join(root,L"SM86\\backend.disabled").c_str())!=INVALID_FILE_ATTRIBUTES;g.sessionActive=false;if(g.recovery){sm86session::Identity id;if(sm86session::parse(read(join(root,L"SM86\\session.pending"),128),id)){Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,id.pid));FILETIME start{},exit{},kernel{},user{};wchar_t image[32768];DWORD count=32768;if(process.h&&GetProcessTimes(process.h,&start,&exit,&kernel,&user)&&((std::uint64_t(start.dwHighDateTime)<<32)|start.dwLowDateTime)==id.created&&WaitForSingleObject(process.h,0)==WAIT_TIMEOUT&&QueryFullProcessImageNameW(process.h,0,image,&count)&&equal(parent(std::wstring(image,count)),root)){g.sessionActive=true;g.recovery=false;}}}for(auto folder:{root,join(root,L"streamline"),join(root,L"OptiScaler")}){g.nr=g.nr||ordinary(join(folder,L"nvngx_dlssnr.dll"))||ordinary(join(folder,L"renodx-dlss5.addon64"))||ordinary(join(folder,L"dlss5-feed.addon64"));g.reshade=g.reshade||ordinary(join(folder,L"ReShade.ini"));g.opti=g.opti||ordinary(join(folder,L"OptiScaler.ini"));}}
inline Game inspect(const std::wstring& exe,const std::wstring& title=L"",const std::wstring& store=L"Manual"){
    Game g;g.exe=canonical(exe);g.title=title.empty()?base(g.exe).substr(0,base(g.exe).size()-4):title;g.store=store;
    auto target=preflight::inspectExecutable(g.exe);g.protectedExe=target.metadataOnly;auto imports=target.imports;if(imports.machine!=0x8664&&imports.machine!=0x14c)throw std::runtime_error("Unsupported Windows executable architecture");g.x64=imports.machine==0x8664&&imports.plus;g.api=discovery::apis(imports.direct)|discovery::apis(imports.delay);g.directApi=g.api;
    auto dependencies=preflight::dependencies(imports,[&](const std::string& name){return pe(join(parent(g.exe),fromUtf8(name)),false);});
    unsigned nearby=dependencies.apis;g.limited=dependencies.limited;
    g.indirect=!(g.api&7)&&(nearby&7);g.dependencyApi=nearby;g.rank=discovery::score(toUtf8(base(g.exe)),g.api,nearby);g.api|=nearby;g.installRoot=canonical(parent(g.exe));g.reason=g.protectedExe?L"Xbox game metadata; EXE imports unavailable":L"Executable inspection";refresh(g);return g;
}
inline catalog::TargetDecision resolveChoices(Game& g,std::size_t selected=std::string::npos){
 std::vector<catalog::TargetEvidence> evidence;for(const auto& c:g.choices){auto relative=catalog::within(c.exe,g.installRoot)?c.exe.substr(g.installRoot.size()+1):base(c.exe);evidence.push_back({toUtf8(relative),c.x64,c.api,c.rank,c.protectedExe});}
 auto result=catalog::resolveTarget(evidence,selected,!g.limited);g.targetChoiceRequired=result.needsChoice;
 if(result.index>=g.choices.size())return result;const auto choice=g.choices[result.index];
 g.nr=g.reshade=g.opti=false;g.exe=choice.exe;g.reason=result.needsChoice?L"Multiple rendering executables were found. Choose EXE before installing.":result.redirected?L"Unreal rendering executable (resolved from launcher)":choice.reason;
 g.api=choice.api;g.indirect=choice.indirect;g.x64=choice.x64;g.rank=choice.rank;g.protectedExe=choice.protectedExe;refresh(g);return result;
}
inline void selectChoice(Game& g,const Choice& choice){
 auto found=std::find_if(g.choices.begin(),g.choices.end(),[&](const Choice& c){return equal(c.exe,choice.exe);});
 if(found==g.choices.end()){g.choices.push_back(choice);found=g.choices.end()-1;}
 auto selected=std::size_t(found-g.choices.begin());auto reason=choice.reason;auto result=resolveChoices(g,selected);
 if(result.index==selected&&!result.needsChoice)g.reason=reason;
 if(!g.pinnedExe.empty())g.pinnedExe=result.needsChoice?L"":g.exe;
}
inline void add(std::vector<Game>& games,Game g){
 catalog::merge(games,std::move(g),[](Game& game,const Choice& choice){selectChoice(game,choice);});
}
inline void folder(std::vector<Game>& games,const std::wstring& root,const std::wstring& title,const std::wstring& store,std::atomic_bool& cancel,const std::wstring& steamId=L"",const std::wstring& steamRoot=L"",const std::vector<steam_metadata::Launch>& launches={},const std::wstring& storeId=L"",ScanStats* stats=nullptr){
 auto resolved=canonical(root);if(resolved.size()<=3)throw std::runtime_error("Choose a game folder, not a whole drive");preflight::game_metadata::ordinary(resolved,true);
 std::vector<Game> candidates;std::set<std::wstring> inspected;bool nr=false,anti=false,reshade=false,opti=false,limited=false;
 std::vector<std::pair<std::wstring,steam_metadata::Launch>> hints;
 for(auto launch:launches)try{auto rel=fromUtf8(launch.path);if(rel.size()>1&&rel.front()==L'"'&&rel.back()==L'"')rel=rel.substr(1,rel.size()-2);if(!setup_policy::safe_relative(rel))continue;auto path=full(join(resolved,rel));if(catalog::within(path,resolved)&&ends(path,L".exe"))hints.emplace_back(path,launch);}catch(...){}
 auto candidate=[&](const std::wstring& path,bool declared=false){
  if(cancel||!inspected.insert(catalog::pathKey(path)).second)return;
  auto relative=path.substr(resolved.size()+1);if(catalog::auxiliary(toUtf8(relative))){if(stats)++stats->excluded;return;}
  if(candidates.size()>=128){limited=true;return;}
  try{auto g=inspect(path,title,store);catalog::Evidence e;e.relative=toUtf8(relative);e.title=toUtf8(title);e.folder=toUtf8(base(resolved));e.direct=g.directApi;e.dependencies=g.dependencyApi;e.x64=g.x64;
   e.launch=declared||g.protectedExe;e.primary=e.launch;
   for(auto& hint:hints)if(equal(hint.first,path)){e.launch=true;e.primary=hint.second.primary;break;}
   auto name=base(path);auto stem=name.substr(0,name.size()-4);e.unity=ordinary(join(parent(path),stem+L"_Data"),true)&&ordinary(join(parent(path),L"UnityPlayer.dll"));e.godot=ordinary(join(parent(path),stem+L".pck"));
   g.rank=catalog::rank(e);if(g.rank<0)return;
   g.reason=g.protectedExe?L"Xbox game metadata; EXE imports unavailable":catalog::unrealRenderer(e.relative,e.x64)?L"Unreal rendering executable":declared?L"Xbox game metadata":e.launch?L"Store launch metadata":e.unity?L"Unity game data":e.godot?L"Godot game data":L"Executable and installation evidence";
   g.installRoot=resolved;candidates.push_back(std::move(g));
  }catch(const std::exception& e){scanFailure(stats,path,e);}
 };
 // Explicit store targets are inspected first, even beyond the traversal cap.
 for(auto& hint:hints)candidate(hint.first);
 FolderIo io;const auto report=folder_scan::walk(resolved,io,[&]{return cancel.load();},candidate,[&](const std::wstring& name,bool directory){
  const auto lname=lower(name);if(!directory){if(lname==L"nvngx_dlssnr.dll"||lname==L"dlss5-feed.addon64"||lname==L"renodx-dlss5.addon64")nr=true;if(lname==L"reshade.ini")reshade=true;if(lname==L"optiscaler.ini")opti=true;}
  if(lname.find(L"easyanticheat")!=lname.npos||lname.find(L"battleye")!=lname.npos||(!directory&&lname.find(L"eaanticheat")!=lname.npos))anti=true;
 });
 limited|=report.limited;if(stats){stats->metadata+=report.metadata;stats->unreadable+=report.unreadable;for(const auto& issue:report.issues)if(stats->issues.size()<8)stats->issues.push_back(issue);if(limited)++stats->limited;}
 catalog::sortCandidates(candidates);
 if(candidates.empty())return;auto g=candidates.front();g.steamId=steamId;g.steamRoot=steamRoot;g.storeId=storeId.empty()?steamId:storeId;g.nr|=nr;g.antiCheat|=anti;g.reshade|=reshade;g.opti|=opti;g.limited|=limited;
 for(auto& c:candidates){if(g.choices.size()>=64){g.limited=true;break;}g.choices.push_back({c.exe,c.reason,c.api,c.indirect,c.x64,c.rank,c.protectedExe});}
 resolveChoices(g);g.nr|=nr;g.reshade|=reshade;g.opti|=opti;
 add(games,std::move(g));if(stats)++stats->detected;
}
inline void scanFolder(std::vector<Game>& games,const std::wstring& root,std::atomic_bool& cancel,ScanStats& stats){
 const auto resolved=canonical(root);if(resolved.size()<=3)throw std::runtime_error("Choose a game folder, not a whole drive");
 FolderIo io;
 for(const auto& install:folder_scan::installations(resolved,io)){
  if(cancel)return;
  try{folder(games,install.path,install.title,install.xbox?L"Xbox":L"Manual",cancel,L"",L"",{},L"",&stats);}
  catch(const std::exception& e){scanFailure(&stats,install.path,e);}
 }
}
// Browse/pasted launcher paths use the same bounded evidence as discovery.
// Selecting an actual rendering EXE remains authoritative, even if siblings
// contain alternate APIs. No game process or launcher is executed here.
inline Game inspectSelection(const std::wstring& exe,std::atomic_bool& cancel,const std::wstring& title=L"",const std::wstring& store=L"Manual"){
 auto selected=inspect(exe,title,store);if(catalog::auxiliary(toUtf8(base(selected.exe))))throw std::runtime_error("Choose the game executable, not an installer, editor or anti-cheat utility.");
 selected.reason=L"Selected by you";selected.choices.push_back({selected.exe,selected.reason,selected.api,selected.indirect,selected.x64,selected.rank,selected.protectedExe});selected.pinnedExe=selected.exe;
 if(selected.protectedExe||catalog::unrealRenderer(toUtf8(selected.exe),selected.x64)||(!catalog::launcher(toUtf8(selected.exe))&&selected.api))return selected;
 std::vector<Game> found;ScanStats stats;folder(found,parent(selected.exe),title.empty()?base(canonical(parent(selected.exe))):title,store,cancel,L"",L"",{},L"",&stats);
 if(cancel)throw std::runtime_error("Executable inspection cancelled.");if(found.empty()){selected.limited|=stats.limited!=0;selected.targetChoiceRequired=selected.limited;if(selected.targetChoiceRequired){selected.pinnedExe.clear();selected.reason=L"Scan limit reached. Choose the rendering executable.";}return selected;}
 auto result=std::move(found.front());auto choice=std::find_if(result.choices.begin(),result.choices.end(),[&](const Choice& c){return equal(c.exe,selected.exe);});
 if(choice==result.choices.end()){result.choices.push_back(selected.choices.front());choice=result.choices.end()-1;}
 const auto index=std::size_t(choice-result.choices.begin());auto decision=resolveChoices(result,index);
 if(decision.index==index&&!decision.needsChoice)result.reason=L"Selected by you";
 result.pinnedExe=decision.needsChoice?L"":result.exe;return result;
}
inline std::vector<steam_metadata::Launch> gogLaunches(const std::wstring& root,const std::wstring& id){
 std::vector<steam_metadata::Launch> out;try{auto data=read(join(root,L"goggame-"+id+L".info"),2u*1024*1024);if(data.empty())return out;auto json=artwork::Parser(data).parse();for(auto& task:json.at("playTasks").array){if(task.at("type").value!="FileTask"||task.at("path").value.empty())continue;out.push_back({task.at("path").value,task.at("name").value,task.at("isPrimary").value=="true"});if(out.size()==64)break;}}catch(...){}return out;
}
inline void stores(std::vector<Game>& games,std::atomic_bool& cancel,ScanStats* stats=nullptr){
 std::vector<std::wstring> clients;auto addClient=[&](std::wstring s){if(s.empty()||s.rfind(L"\\\\",0)==0||!ordinary(s,true))return;s=canonical(s);for(auto& old:clients)if(equal(old,s))return;clients.push_back(std::move(s));};
 addClient(reg(HKEY_CURRENT_USER,L"Software\\Valve\\Steam",L"SteamPath"));addClient(reg(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Valve\\Steam",L"InstallPath",KEY_WOW64_32KEY));auto pf=env(L"ProgramFiles(x86)");if(!pf.empty())addClient(join(pf,L"Steam"));
 std::set<std::wstring> scannedRoots;
 for(auto& client:clients){if(cancel)return;std::vector<std::wstring> libraries{client};for(auto s:discovery::values(read(join(client,L"steamapps\\libraryfolders.vdf")),"path"))try{auto path=canonical(fromUtf8(s));if(ordinary(path,true))libraries.push_back(path);}catch(...){}
  struct Install{std::wstring root,title,id;};std::vector<Install> installs;std::set<std::uint32_t> wanted;
  for(auto& library:libraries){if(cancel)return;if(!scannedRoots.insert(catalog::pathKey(library)).second)continue;auto manifests=join(library,L"steamapps");for(auto name:children(manifests,false,4096)){
   if(cancel)return;if(lower(name).rfind(L"appmanifest_",0)!=0||!ends(name,L".acf"))continue;auto text=read(join(manifests,name),2u*1024*1024);auto dirs=discovery::values(text,"installdir"),names=discovery::values(text,"name"),ids=discovery::values(text,"appid");if(dirs.size()!=1||names.size()!=1||ids.size()!=1||artwork::appId(ids[0]).empty())continue;
   try{auto rel=fromUtf8(dirs[0]);if(!setup_policy::safe_relative(rel))continue;auto root=canonical(join(join(manifests,L"common"),rel));if(!ordinary(root,true))continue;installs.push_back({root,fromUtf8(names[0]),fromUtf8(ids[0])});wanted.insert(static_cast<std::uint32_t>(std::stoull(ids[0])));}catch(...){}
  }}
  auto metadata=steam_metadata::parse(read(join(client,L"appcache\\appinfo.vdf"),256u*1024*1024),wanted);
  for(auto& install:installs){if(cancel)return;try{std::vector<steam_metadata::Launch> hints;auto i=metadata.find(static_cast<std::uint32_t>(std::stoull(install.id)));if(i!=metadata.end()){if(!steam_metadata::gameType(i->second.type)){if(stats)stats->nonGameRoots.push_back(install.root);continue;}hints=i->second.launches;if(!i->second.title.empty())install.title=fromUtf8(i->second.title);if(stats&&!hints.empty())++stats->metadata;}folder(games,install.root,install.title,L"Steam",cancel,install.id,client,hints,install.id,stats);}catch(...) {}}
 }
 auto pd=env(L"ProgramData");if(!pd.empty()){auto root=join(pd,L"Epic\\EpicGamesLauncher\\Data\\Manifests");for(auto name:children(root,false,2048)){if(cancel)return;if(!ends(name,L".item"))continue;try{auto text=read(join(root,name),2u*1024*1024);auto item=artwork::Parser(text).parse();auto path=item.at("InstallLocation").value,title=item.at("DisplayName").value;if(path.empty()||title.empty()||item.at("bIsIncompleteInstall").value=="true")continue;std::vector<steam_metadata::Launch> hints;if(!item.at("LaunchExecutable").value.empty())hints.push_back({item.at("LaunchExecutable").value,"",true});if(stats&&!hints.empty())++stats->metadata;folder(games,fromUtf8(path),fromUtf8(title),L"Epic",cancel,L"",L"",hints,fromUtf8(item.at("AppName").value),stats);}catch(...) {}}}
 for(REGSAM view:{KEY_WOW64_32KEY,KEY_WOW64_64KEY}){HKEY h=nullptr;std::wstring key=L"SOFTWARE\\GOG.com\\Games";if(RegOpenKeyExW(HKEY_LOCAL_MACHINE,key.c_str(),0,KEY_ENUMERATE_SUB_KEYS|view,&h)!=ERROR_SUCCESS)continue;for(DWORD index=0;index<2048&&!cancel;++index){wchar_t name[512];DWORD n=512;if(RegEnumKeyExW(h,index,name,&n,nullptr,nullptr,nullptr,nullptr)!=ERROR_SUCCESS)break;auto dir=reg(HKEY_LOCAL_MACHINE,key+L"\\"+name,L"path",view),title=reg(HKEY_LOCAL_MACHINE,key+L"\\"+name,L"gameName",view);if(!dir.empty())try{auto hints=gogLaunches(dir,name);if(stats&&!hints.empty())++stats->metadata;folder(games,dir,title.empty()?name:title,L"GOG",cancel,L"",L"",hints,name,stats);}catch(...) {}}RegCloseKey(h);}
 const DWORD drives=GetLogicalDrives();
 for(unsigned index=0;index<26&&!cancel;++index)if(drives&(DWORD(1)<<index)){
  const std::wstring drive=std::wstring(1,wchar_t(L'A'+index))+L":\\";
  if(GetDriveTypeW(drive.c_str())!=DRIVE_FIXED)continue;
  const auto root=join(drive,L"XboxGames");if(!ordinary(root,true))continue;
  ScanStats local;try{scanFolder(games,root,cancel,stats?*stats:local);}catch(const std::exception& e){scanFailure(stats,root,e);}
 }
}
inline std::vector<Game> rescan(const std::vector<Game>& previous,std::atomic_bool& cancel,ScanStats& stats){
 std::vector<Game> found;stores(found,cancel,&stats);if(cancel)return previous;
 std::set<std::wstring> manualRoots;
 for(auto& old:previous){if(cancel)return previous;bool matched=false;for(const auto& root:stats.nonGameRoots)if(catalog::within(old.exe,root))matched=true;if(matched)continue;
  for(auto& g:found)if(catalog::sameInstall(g,old)||catalog::within(old.exe,g.installRoot)){catalog::carryPreferences(g,old);matched=true;break;}
  if(matched)continue;
  // Old saved lists did not have an install root. Steam paths can be recovered
  // without a game profile, including entries pointing to bundled editors.
  auto root=old.installRoot.empty()?catalog::legacySteamRoot(old.exe):old.installRoot;if(root.empty())root=parent(old.exe);
  if(!ordinary(root,true)||!manualRoots.insert(catalog::pathKey(root)).second)continue;
  auto before=found.size();folder(found,root,old.title,old.store,cancel,old.steamId,old.steamRoot,{},old.storeId,&stats);
  if(found.size()>before)catalog::carryPreferences(found.back(),old);
 }
 for(auto& g:found){bool chosen=false;for(auto& c:g.choices)if(equal(c.exe,g.pinnedExe)){selectChoice(g,c);chosen=true;break;}if(!chosen)g.pinnedExe.clear();}
 std::sort(found.begin(),found.end(),[](const Game& a,const Game& b){auto x=lower(a.title),y=lower(b.title);return x!=y?x<y:lower(a.installRoot)<lower(b.installRoot);});return found;
}
inline std::wstring apiName(unsigned flags){std::wstring s;for(auto entry:{std::pair<unsigned,const wchar_t*>{1,L"DX11"},{2,L"DX12"},{4,L"Vulkan"},{8,L"Other API"}})if(flags&entry.first){if(!s.empty())s+=L" + ";s+=entry.second;}return s.empty()?L"API unknown":s;}
inline std::wstring quoted(const std::wstring& s){std::wstring r=L"\"";size_t slash=0;for(wchar_t c:s){if(c==L'\\'){++slash;continue;}r.append(slash*(c==L'"'?2:1),L'\\');slash=0;if(c==L'"')r+=L'\\';r+=c;}r.append(slash*2,L'\\');return r+L'"';}
inline HANDLE verified(const std::wstring& file,const char* expected){HANDLE h=CreateFileW(file.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);if(h==INVALID_HANDLE_VALUE){DWORD error=GetLastError();throw manager_process::failure(L"Cannot open packaged helper",file,error);}BCRYPT_ALG_HANDLE a=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;bool ok=BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0;BYTE digest[32]{};if(ok)ok=BCryptCreateHash(a,&hash,nullptr,0,nullptr,0,0)>=0;unsigned char block[65536];size_t total=0;while(ok){DWORD got=0;if(!ReadFile(h,block,sizeof block,&got,nullptr)){ok=false;break;}if(!got)break;total+=got;if(total>32u*1024*1024||BCryptHashData(hash,block,got,0)<0)ok=false;}if(ok)ok=BCryptFinishHash(hash,digest,32,0)>=0;if(hash)BCryptDestroyHash(hash);if(a)BCryptCloseAlgorithmProvider(a,0);if(ok)for(unsigned i=0;i<32;++i)if(expected[2*i]!="0123456789abcdef"[digest[i]>>4]||expected[2*i+1]!="0123456789abcdef"[digest[i]&15])ok=false;if(!ok){CloseHandle(h);throw std::runtime_error("Packaged helper could not be verified: "+toUtf8(base(file))+". Extract the complete matching release into an empty folder; do not mix release files.");}return h;}
using Result = manager_process::Result;
inline Result run(const std::wstring& exe,const char* expected,const std::vector<std::wstring>& args,bool capture=false){
    Handle file(verified(exe,expected));
    std::wstring command=quoted(exe);
    for(const auto& arg:args)command+=L" "+quoted(arg);
    // Keep the verified image locked for the whole helper operation.
    return manager_process::run(exe,std::move(command),parent(exe),capture);
}
}
