from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[1]
for kit,carrier in [('Version',None),('Dinput8','dinput8'),('Winmm','winmm'),('ASI_Only',None)]:
 p=r/'Manual'/kit
 if p.exists():shutil.rmtree(p)
 p.mkdir(parents=True)
 if kit=='Version':shutil.copy2(r/'payload/native/version.dll',p/'version.dll')
 else:shutil.copy2(r/'payload/native/normal.asi',p/'new.asi')
 if carrier:
  shutil.copy2(r/'payload/loader/version.dll',p/(carrier+'.dll'))
  shutil.copy2(r/'payload/loader/loader-template.ini',p/(carrier+'.ini'))
(r/'Manual/README.md').write_text((r/'MANUAL_INSTALL.md').read_text())
shutil.copy2(r/'payload/native/normal.asi',r/'Test/new.asi')
for original,name in [('payload/native/normal.pdb','normal.pdb'),('payload/native/version.pdb','version.pdb'),('Install.pdb','Install.pdb'),('SmoothMotion_Manager.pdb','SmoothMotion_Manager.pdb'),('source/diagnostic/Collect_Diagnostics.pdb','Collect_Diagnostics.pdb'),('Test/RTX20_SmokeTest.pdb','RTX20_SmokeTest.pdb'),('Test/ShaderCheck.pdb','ShaderCheck.pdb'),('Test/RTX20_DX12_SmokeTest.pdb','RTX20_DX12_SmokeTest.pdb'),('Test/RTX20_TransferTest.pdb','RTX20_TransferTest.pdb')]:shutil.copy2(r/original,r/'Symbols'/name)
print('Manual kits, hardware test carrier, and 9 symbol files staged')
