#pragma once
#include <windows.h>
#include <shlwapi.h>
#include <xmllite.h>
#include "windows_pe.hpp"
namespace preflight {
namespace game_metadata {
template<class T>struct Com{T* p=nullptr;~Com(){if(p)p->Release();}Com()=default;Com(const Com&)=delete;};
struct File{HANDLE value=INVALID_HANDLE_VALUE;~File(){if(value!=INVALID_HANDLE_VALUE)CloseHandle(value);}File()=default;File(const File&)=delete;};
inline void checked(HRESULT result){if(FAILED(result))throw std::runtime_error("Cannot parse MicrosoftGame.config");}
inline std::vector<unsigned char> read(const std::wstring& path){
 File file;file.value=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
 if(file.value==INVALID_HANDLE_VALUE){const auto error=GetLastError();if(error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND)return {};throw FileAccessError("Cannot read MicrosoftGame.config",error);}
 BY_HANDLE_FILE_INFORMATION info{};if(!GetFileInformationByHandle(file.value,&info)||(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)))throw std::runtime_error("Xbox metadata is not an ordinary file");
 LARGE_INTEGER size{};if(!GetFileSizeEx(file.value,&size)||size.QuadPart<=0||size.QuadPart>1024*1024)throw std::runtime_error("MicrosoftGame.config is empty or exceeds 1 MiB");
 std::vector<unsigned char> bytes(static_cast<size_t>(size.QuadPart));DWORD count=0;
 if(!ReadFile(file.value,bytes.data(),static_cast<DWORD>(bytes.size()),&count,nullptr)||count!=bytes.size())throw std::runtime_error("Cannot read complete MicrosoftGame.config");return bytes;
}
inline GameConfigPolicy parse(const std::vector<unsigned char>& bytes){
 if(bytes.empty()||bytes.size()>1024*1024)throw std::runtime_error("Invalid Xbox metadata size");
 Com<IStream> stream;stream.p=SHCreateMemStream(bytes.data(),static_cast<UINT>(bytes.size()));if(!stream.p)throw std::bad_alloc();
 Com<IXmlReader> reader;checked(CreateXmlReader(__uuidof(IXmlReader),reinterpret_cast<void**>(&reader.p),nullptr));
 checked(reader.p->SetProperty(XmlReaderProperty_DtdProcessing,DtdProcessing_Prohibit));
 checked(reader.p->SetProperty(XmlReaderProperty_MaxElementDepth,32));checked(reader.p->SetInput(stream.p));
 GameConfigPolicy policy;XmlNodeType type{};HRESULT result=S_OK;
 while((result=reader.p->Read(&type))==S_OK){
  if(type!=XmlNodeType_Element&&type!=XmlNodeType_EndElement)continue;
  const wchar_t* value=nullptr;UINT length=0;checked(reader.p->GetLocalName(&value,&length));std::wstring name(value,length);
  checked(reader.p->GetNamespaceUri(&value,&length));if(length)name=L"#"+name;
  if(type==XmlNodeType_EndElement){policy.end(name);continue;}
  const bool empty=reader.p->IsEmptyElement()!=FALSE;GameConfigPolicy::Attributes attrs;
  for(const auto* key:{L"Name",L"TargetDeviceFamily",L"Architecture",L"IsDevOnly"}){
   const auto found=reader.p->MoveToAttributeByName(key,nullptr);checked(found);
   if(found==S_OK){checked(reader.p->GetValue(&value,&length));if(length>32768)throw std::runtime_error("Xbox metadata attribute is too long");attrs.emplace(key,std::wstring(value,length));checked(reader.p->MoveToElement());}
  }
  policy.begin(name,attrs,empty);
 }
 checked(result);if(result!=S_FALSE)throw std::runtime_error("Xbox metadata parsing did not reach EOF");policy.finish();return policy;
}
inline void ordinary(const std::wstring& path,bool directory){
 const auto flags=GetFileAttributesW(path.c_str());
 if(flags==INVALID_FILE_ATTRIBUTES)throw FileAccessError("Cannot inspect selected Xbox game path",GetLastError());
 if((flags&FILE_ATTRIBUTE_REPARSE_POINT)||bool(flags&FILE_ATTRIBUTE_DIRECTORY)!=directory)throw std::runtime_error("Selected Xbox path is a directory or linked file");
}
inline TargetInspection inspect(const std::wstring& exe){
 ordinary(exe,false);auto key=configPathKey(exe);
 if(key.size()<4||key.substr(key.size()-4)!=L".exe")throw std::runtime_error("Choose a game .exe file");
 auto cut=exe.find_last_of(L"\\/");
 for(unsigned depth=0;depth<6&&cut!=std::wstring::npos&&cut>2;++depth){
  const auto root=exe.substr(0,cut+1),relative=exe.substr(cut+1);ordinary(root,true);
  // A nested declaration must not traverse a linked subdirectory.
  for(size_t i=0;i<relative.size();++i)if(relative[i]==L'\\'||relative[i]==L'/')ordinary(root+relative.substr(0,i),true);
  auto path=root+L"MicrosoftGame.config";auto bytes=read(path);
  if(!bytes.empty()){
   if(!parse(bytes).identifiesX64(relative))throw std::runtime_error("MicrosoftGame.config does not identify the selected EXE as a non-development x64 PC game. Select the actual game EXE, not gamelaunchhelper.exe.");
   Imports imports;imports.machine=0x8664;imports.plus=true;return {imports,true,path,std::move(bytes)};
  }
  cut=exe.find_last_of(L"\\/",cut-1);
 }
 throw std::runtime_error("Windows denies reading this EXE, and no readable MicrosoftGame.config identifies it as an x64 PC game. Select the actual installed game's Content folder. File permissions were not changed.");
}
}
inline TargetInspection inspectExecutable(const std::wstring& path){
 return inspectTargetWith([&]{return inspectFile(path,true);},[&]{return game_metadata::inspect(path);});
}
}
