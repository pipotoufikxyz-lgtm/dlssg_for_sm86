// Exact GP7 metadata policy; only namespace/type import/include locations differ.
#pragma once
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
#include "../policy.hpp"
#include "../pe_reader.hpp"
namespace gp7_preflight {
using preflight::Imports;
struct FileAccessError:std::runtime_error {
 unsigned code;
 FileAccessError(const char* message,unsigned value):std::runtime_error(std::string(message)+" (Windows error "+std::to_string(value)+")"),code(value){}
};
struct TargetInspection {Imports imports;bool metadataOnly=false;std::wstring metadataPath;std::vector<unsigned char> metadata;};
inline std::wstring configPathKey(std::wstring path){for(auto& c:path){if(c==L'/')c=L'\\';if(c>=L'A'&&c<=L'Z')c+=32;}return path;}
// Consumes only parsed XML events. Comments/text cannot impersonate elements.
// XmlLite must reach a clean EOF before finish() is called.
class GameConfigPolicy {
 struct Entry{std::wstring name,family,architecture,dev;};
 std::vector<std::wstring> stack;
 std::vector<Entry> entries;
 unsigned roots=0,lists=0,nodes=0;bool complete=false;
 public:
 using Attributes=std::map<std::wstring,std::wstring>;
 void begin(const std::wstring& name,const Attributes& attrs,bool empty){
  if(complete||++nodes>32768||stack.size()>=32)throw std::runtime_error("Xbox game metadata exceeds structural limits");
  if(stack.empty()&&(++roots!=1||name!=L"Game"))throw std::runtime_error("Invalid Xbox game metadata root");
  if(stack==std::vector<std::wstring>{L"Game"}&&name==L"ExecutableList"&&++lists!=1)throw std::runtime_error("Duplicate Xbox executable list");
  if(stack==std::vector<std::wstring>{L"Game",L"ExecutableList"}&&name==L"Executable"){
   const auto get=[&](const wchar_t* key){auto it=attrs.find(key);return it==attrs.end()?std::wstring{}:it->second;};
   auto path=get(L"Name");if(!setup_policy::safe_relative(path))throw std::runtime_error("Invalid relative executable in Xbox metadata");
   if(entries.size()>=256)throw std::runtime_error("Too many Xbox executable entries");
   entries.push_back({configPathKey(path),get(L"TargetDeviceFamily"),attrs.count(L"Architecture")?get(L"Architecture"):L"x64",attrs.count(L"IsDevOnly")?get(L"IsDevOnly"):L"false"});
  }
  stack.push_back(name);if(empty)end(name);
 }
 void end(const std::wstring& name){if(stack.empty()||stack.back()!=name)throw std::runtime_error("Incomplete Xbox game metadata");stack.pop_back();}
 void finish(){if(roots!=1||lists!=1||!stack.empty())throw std::runtime_error("Incomplete Xbox executable metadata");complete=true;}
 bool identifiesX64(const std::wstring& relative)const{
  if(!complete||!setup_policy::safe_relative(relative))return false;
  unsigned matches=0;bool supported=false;
  for(const auto& entry:entries)if(entry.name==configPathKey(relative)){
   ++matches;supported=entry.family==L"PC"&&entry.architecture==L"x64"&&entry.dev==L"false";
  }
  return matches==1&&supported;
 }
};
template<class ReadPE,class ReadMetadata>
TargetInspection inspectTargetWith(ReadPE readPE,ReadMetadata readMetadata){
 try{return {readPE(),false,{},{}};}catch(const FileAccessError& error){
  // Only denied reads permit metadata inspection. Corrupt PEs, missing files,
  // sharing violations and unsupported architectures keep their own errors.
  if(error.code!=5)throw;
  auto target=readMetadata();
  if(!target.metadataOnly||target.imports.machine!=0x8664||!target.imports.plus||target.imports.dll||target.metadata.empty())throw std::runtime_error("Xbox metadata did not identify this executable as x64");
  if(!target.imports.direct.empty()||!target.imports.delay.empty())throw std::runtime_error("Protected executable imports must remain unknown");
  return target;
 }
}
}
