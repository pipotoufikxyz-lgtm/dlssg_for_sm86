// Included inside install.cpp's namespace, after the original restore support.
// This journal is temporary. Only incomplete transactions retain rollback bytes.
std::wstring decodeText(const Bytes& b,const std::wstring& path){if(b.size()<2||b.size()%2||b[0]!=0xff||b[1]!=0xfe)fail(L"Invalid installer record encoding: "+path);std::wstring s((b.size()-2)/2,L'\0');std::memcpy(s.data(),b.data()+2,b.size()-2);return s;}
std::wstring readText(const std::wstring& path){return decodeText(read(path,1024*1024),path);}

std::wstring trimSlash(std::wstring p){while(!p.empty()&&(p.back()==L'\\'||p.back()==L'/'))p.pop_back();return p;}
bool isLocalJournal(const std::wstring& p){const auto folder=trimSlash(p),owner=trimSlash(parent(folder));return equal(folder.substr(parent(folder).size()),L"pending")&&equal(owner.substr(parent(owner).size()),L".smooth-motion");}
struct LocalJournal : local_journal_policy::Record {std::wstring backup;};
LocalJournal readJournal(const std::wstring& backup){
 if(!isLocalJournal(backup))fail(L"Invalid local transaction location.");ordinary(trimSlash(backup),true);
 const auto root=parent(trimSlash(parent(trimSlash(backup))));ordinary(trimSlash(root),true);checkDirectory(root,L".smooth-motion");checkDirectory(root,L".smooth-motion\\pending");ordinary(backup+L"files",true);
 const auto manifest=read(backup+L"restore.tsv",1024*1024);
 const auto parsed=local_journal_policy::parse(decodeText(manifest,backup+L"restore.tsv"),readText(backup+L"owner.tsv"),hash(manifest),root,[](const auto& a,const auto& b){return equal(absolute(a),b);});
 LocalJournal j;static_cast<local_journal_policy::Record&>(j)=parsed;j.backup=backup;
 for(const auto& c:j.changes)checkParents(root,c.path);for(const auto& d:j.directories)checkDirectory(root,d);for(const auto& s:j.stages)checkParents(root,s.path);
 return j;
}
bool removeExact(const std::wstring& p,const std::string& expected){auto current=fileHash(p);if(current=="-")return true;return current==expected&&DeleteFileW(p.c_str());}
bool cleanupJournal(const LocalJournal& j){
 const auto marker=local_journal_policy::commitMarker(j.manifestHash);
 if(!local_journal_policy::committed(j.manifestHash,exists(j.backup+L"committed.tsv")?readText(j.backup+L"committed.tsv"):L""))fail(L"Recovery must finish before journal cleanup.");
 bool ok=true;std::vector<std::wstring> dirs;
 for(size_t n=0;n<j.changes.size();++n){const auto& c=j.changes[n];if(c.before!="-"){checkParents(j.backup+L"files\\",c.path);ok=removeExact(j.backup+L"files\\"+c.path,c.before)&&ok;ok=removeExact(j.backup+L"recover-"+std::to_wstring(n)+L".tmp",c.before)&&ok;for(size_t i=0;i<c.path.size();++i)if(c.path[i]==L'\\'||c.path[i]==L'/'){auto d=c.path.substr(0,i);if(std::find(dirs.begin(),dirs.end(),d)==dirs.end())dirs.push_back(d);}}}
 for(const auto& stage:j.stages){checkParents(j.root,stage.path);ok=removeExact(j.root+stage.path,stage.digest)&&ok;}
 std::sort(dirs.begin(),dirs.end(),[](const auto& a,const auto& b){return a.size()>b.size();});for(const auto& d:dirs){checkDirectory(j.backup+L"files\\",d);RemoveDirectoryW((j.backup+L"files\\"+d).c_str());}
 RemoveDirectoryW((j.backup+L"files").c_str());
 ok=removeExact(j.backup+L"RESTORE.txt",j.instructionHash)&&ok;
 ok=removeExact(j.backup+L"Restore.exe",j.helperHash)&&ok;
 // While recovery is running from Restore.exe, Windows may retain that image.
 // Keep the authenticated journal for the next installer to finish cleanup.
 if(!ok)return false;
 // Retire the directory atomically before deleting its final metadata. A
 // crash between those deletions cannot leave an unreadable pending journal.
 auto retired=j.root+local_journal_policy::retirementDirectory(j.manifestHash);
 if(!MoveFileExW(trimSlash(j.backup).c_str(),trimSlash(retired).c_str(),MOVEFILE_WRITE_THROUGH))return false;
 auto owner=fileHash(retired+L"owner.tsv");removeExact(retired+L"owner.tsv",owner);
 removeExact(retired+L"restore.tsv",j.manifestHash);removeExact(retired+L"committed.tsv",hash(utf16(marker)));
 RemoveDirectoryW(trimSlash(retired).c_str());return true;

}
int recoverLocal(const std::wstring& backup,const std::wstring&,bool cleanupOnly){
 auto j=readJournal(backup);
 if(exists(backup+L"committed.tsv")){bool done=cleanupJournal(j);if(!cleanupOnly)show(done?L"The completed local transaction was cleaned up.":L"The game files are settled. Close this recovery tool and run the installer once more to finish removing its temporary journal.");return done?0:1;}
 if(cleanupOnly)fail(L"An interrupted installation needs recovery. Close the game, then run:\n"+backup+L"Restore.exe\nNo new installation changes were made.");
 requireClosed(j.root,j.exe);
 const auto recovery=local_journal_policy::plan(j,L"",[&](const auto& p){return fileHash(j.root+p);},[&](const auto& p){checkParents(backup+L"files\\",p);return fileHash(backup+L"files\\"+p);});
 if(!confirm(L"Recover the interrupted Smooth Motion transaction in:\n"+j.root+L"\n\nOnly recorded file identities will be restored. Continue?"))return ERROR_CANCELLED;
 for(size_t n:recovery.changes){auto& c=j.changes[n];auto current=fileHash(j.root+c.path);const auto action=local_journal_policy::recovery(c,current);if(action==local_journal_policy::Recovery::Settled)continue;if(action==local_journal_policy::Recovery::Conflict)fail(L"A file changed during recovery. It was preserved:\n"+j.root+c.path);
  if(c.before=="-"){if(!DeleteFileW((j.root+c.path).c_str()))fail(L"Cannot remove an interrupted install file.",GetLastError());}
  else{const auto stage=backup+L"recover-"+std::to_wstring(n)+L".tmp";if(exists(stage)){if(fileHash(stage)!=c.before)fail(L"Recovery staging file was modified.");}else{auto original=read(backup+L"files\\"+c.path);if(hash(original)!=c.before)fail(L"The recovery original changed before it could be restored. It was preserved.");writeNew(stage,original);}ensureParents(j.root,c.path);if(!MoveFileExW(stage.c_str(),(j.root+c.path).c_str(),MOVEFILE_WRITE_THROUGH|(c.after=="-"?0:MOVEFILE_REPLACE_EXISTING)))fail(L"Cannot restore the interrupted transaction.",GetLastError());}
 }
 publishLocalCommit(backup,utf16(local_journal_policy::commitMarker(j.manifestHash)));
 for(auto it=j.directories.rbegin();it!=j.directories.rend();++it){checkDirectory(j.root,*it);RemoveDirectoryW((j.root+*it).c_str());}
 bool cleaned=cleanupJournal(j);show(cleaned?L"The interrupted installation was rolled back.":L"The interrupted installation was rolled back. Close this recovery tool and run the installer to finish temporary journal cleanup.");return 0;
}
void settledJournal(const std::wstring& root,const std::wstring& self){
 const auto pending=root+L".smooth-motion\\pending\\";if(!exists(trimSlash(pending)))return;
 // Committed cleanup is housekeeping only; an uncommitted journal never gets
 // silently replayed during review. Its explicit recovery action remains available.
 if(recoverLocal(pending,self,true)!=0)fail(L"Close the local recovery tool, then retry setup. Its temporary journal is still in use.");
}
void appendInline(std::vector<Change>& changes,const std::wstring& root,const std::wstring& path,const Bytes& bytes,const std::string& before){
 checkParents(root,path);if(fileHash(root+path)!=before)fail(L"An installer-owned file changed during review:\n"+root+path);auto after=hash(bytes);if(after!=before)changes.push_back({path,L"",L"",before,after,false,true,bytes});
}
uninstall_policy::Receipt receiptAt(const std::wstring& root){checkParents(root,uninstall_policy::receiptPath);return uninstall_policy::parse(readText(root+uninstall_policy::receiptPath));}
void validateControls(const std::wstring& root,const uninstall_policy::Receipt& receipt){
 checkParents(root,uninstall_policy::helperPath);checkParents(root,uninstall_policy::batchPath);
 const Bytes script(uninstall_policy::batch,uninstall_policy::batch+sizeof(uninstall_policy::batch)-1);
 if(fileHash(root+uninstall_policy::helperPath)!=receipt.helper||fileHash(root+uninstall_policy::batchPath)!=hash(script))fail(L"The installed uninstaller or uninstall.bat was modified. Those files were preserved. Restore the original uninstall tools before upgrading.");
}
void prepareUninstaller(const std::wstring& root,const std::wstring& exe,const std::wstring& proxy,bool asi,const std::wstring& self,std::vector<Change>& changes){
 settledJournal(root,self);checkDirectory(root,uninstall_policy::directory);checkParents(root,uninstall_policy::receiptPath);checkParents(root,uninstall_policy::helperPath);checkParents(root,uninstall_policy::batchPath);
 const auto oldReceipt=fileHash(root+uninstall_policy::receiptPath),oldHelper=fileHash(root+uninstall_policy::helperPath),oldBatch=fileHash(root+uninstall_policy::batchPath);
 if(oldReceipt!="-"){auto old=receiptAt(root);validateControls(root,old);if(!equal(old.executable,exe.substr(root.size())))fail(L"The existing Smooth Motion receipt belongs to a different executable in this folder.");}
 else if(oldHelper!="-"||oldBatch!="-")fail(L"An existing uninstall.bat or uninstall helper belongs to another installation. It was preserved. Rename it or use its original uninstaller before installing Smooth Motion.");
 const auto helper=fileHash(self);uninstall_policy::Receipt next{exe.substr(root.size()),proxy,helper,{{proxy,asi?payload_hashes::loader:payload_hashes::native_proxy}}};
 if(asi){next.files.push_back({L"new.asi",payload_hashes::motion});next.files.push_back({proxy.substr(0,proxy.size()-4)+L".ini",payload_hashes::ini});}
 appendChange(changes,root,uninstall_policy::helperPath,self,oldHelper,helper);
 appendInline(changes,root,uninstall_policy::receiptPath,utf16(uninstall_policy::serialize(next)),oldReceipt);
 appendInline(changes,root,uninstall_policy::batchPath,Bytes(uninstall_policy::batch,uninstall_policy::batch+sizeof(uninstall_policy::batch)-1),oldBatch);
}
void finishLocal(const std::wstring& backup){if(!backup.empty())cleanupJournal(readJournal(backup));}
int uninstallGame(const std::wstring& root,const std::wstring& requestedExe,const std::wstring& self){
 ordinary(trimSlash(root),true);settledJournal(root,self);checkParents(root,uninstall_policy::receiptPath);
 const bool recorded=exists(root+uninstall_policy::receiptPath);
 std::wstring exe=requestedExe;std::string receiptDigest="-",helperDigest="-",batchDigest="-";
 uninstall_policy::Removal removal;
 std::vector<Found> consumers;for(const auto& f:scan(root))if(f.asi&&!equal(f.relative,L"new.asi"))consumers.push_back(f);
 std::sort(consumers.begin(),consumers.end(),[](const auto& a,const auto& b){return lower(a.relative)<lower(b.relative);});
 const bool otherConsumers=!consumers.empty();
 std::map<std::wstring,std::string> observed;
 const auto current=[&](const std::wstring& p){auto found=observed.find(p);if(found!=observed.end())return found->second;checkParents(root,p);auto value=fileHash(root+p);observed[p]=value;return value;};
 bool incompleteLegacy=false;
 if(recorded){
  const auto bytes=read(root+uninstall_policy::receiptPath,1024*1024);receiptDigest=hash(bytes);
  const auto r=uninstall_policy::parse(decodeText(bytes,root+uninstall_policy::receiptPath));exe=root+r.executable;
  if(!requestedExe.empty()&&!equal(requestedExe,exe))fail(L"Select the game executable recorded by this Smooth Motion installation.");
  validateControls(root,r);helperDigest=current(uninstall_policy::helperPath);batchDigest=current(uninstall_policy::batchPath);
  removal=uninstall_policy::plan(r,current,otherConsumers);
 }else{
  if(requestedExe.empty()||!equal(parent(requestedExe),root)||!setup_policy::safe_relative(requestedExe.substr(root.size())))fail(L"Select the original game or launcher executable to review an older installation.");
  const auto legacy=uninstall_policy::legacy(current,otherConsumers);incompleteLegacy=legacy.incompleteLoader;removal.loaderPreserved=legacy.loaderPreserved;
  // Every entry was proven by the whole legacy group. Use its observed digest
  // as the ownership identity; appendChange and transaction recheck it later.
  removal.remove=legacy.files;
 }
 requireClosed(root,exe);std::vector<Change> changes;
 for(const auto& f:removal.remove)appendChange(changes,root,f.path,L"",f.digest,"-");
 std::wstring fingerprint=L"SM86-UNINSTALL-2\n"+root+L"\n"+exe+L"\n"+(recorded?L"receipt\n":L"recognized-legacy\n")+wide(receiptDigest)+L"\n"+wide(helperDigest)+L"\n"+wide(batchDigest)+L"\n";
 for(const auto& [path,digest]:observed)fingerprint+=path+L"\t"+wide(digest)+L"\n";
 for(const auto& f:consumers)fingerprint+=L"consumer:"+f.relative+L"\t"+wide(f.digest)+L"\n";
 for(const auto& f:removal.remove)fingerprint+=L"remove:"+f.path+L"\t"+wide(f.digest)+L"\n";
 for(const auto& f:removal.preserved)fingerprint+=L"preserve:"+f.path+L"\n";
 const auto token=hash(utf16(fingerprint));
 std::string warning=recorded?"Only unchanged Smooth Motion files are removed. Logs, other mods, and older restore folders are preserved. The small uninstall tools remain available for repeat use.":"Older installation without a receipt: only complete groups with exact recognized Smooth Motion identities are removed. Logs, other mods, and older restore folders are preserved.";
 if(removal.loaderPreserved)warning+=" The ASI carrier and its INI are retained because another plugin may depend on them.";
 if(incompleteLegacy)warning+=" An ASI loader has an unknown, modified or missing renderer/configuration. That loader and configuration were preserved.";
 if(!removal.preserved.empty()){warning+=" Files kept:";for(const auto& f:removal.preserved)warning+=" "+utf8(f.path);}
 if(!recorded&&removal.remove.empty())warning+=" No complete recognized Smooth Motion installation was found at this executable's original folder.";
 if(machineMode&&planOnly){std::string out="{\"schema\":1,\"status\":\"ready\",\"target\":"+setup_protocol::quote(utf8(exe))+",\"proxy\":\"\",\"token\":"+setup_protocol::quote(token)+",\"fallback\":false,\"api_confirmed\":true,\"legacy_uninstall\":"+(recorded?"false":"true")+",\"warning\":"+setup_protocol::quote(warning)+",\"choices\":[],\"changes\":[";bool first=true;for(const auto& c:changes){if(!first)out+=',';first=false;out+="{\"path\":"+setup_protocol::quote(utf8(c.relative))+",\"action\":\"Remove installed file\"}";}emit(out+"]}\n");return 0;}
 if(machineMode&&(!setup_protocol::validToken(reviewedToken)||reviewedToken!=token))fail(L"Files changed after the uninstall review. Nothing was removed. Refresh the review.");
 std::wstring preservedReview;if(!removal.preserved.empty()){preservedReview=L"\n\n"+tr(L"Files kept:");for(const auto& f:removal.preserved)preservedReview+=L"\n"+f.path;}
 if(!machineMode&&!changes.empty()&&!confirm(tr(L"Uninstall Smooth Motion from:\n")+root+L"\n\n"+tr(wide(warning))+preservedReview+L"\n\n"+tr(L"Continue?")))return ERROR_CANCELLED;
 // Recheck dependencies after the interactive review, before allowing the
 // carrier to be removed. The apply token also binds this complete inventory.
 std::vector<Found> latestConsumers;for(const auto& f:scan(root))if(f.asi&&!equal(f.relative,L"new.asi"))latestConsumers.push_back(f);
 std::sort(latestConsumers.begin(),latestConsumers.end(),[](const auto& a,const auto& b){return lower(a.relative)<lower(b.relative);});
 auto sameConsumers=[&]{if(latestConsumers.size()!=consumers.size())return false;for(size_t n=0;n<consumers.size();++n)if(!equal(consumers[n].relative,latestConsumers[n].relative)||consumers[n].digest!=latestConsumers[n].digest)return false;return true;};
 if(!sameConsumers())fail(L"The other ASI plugins changed after review. No uninstall files were changed. Refresh the review.");
 auto backup=transaction(root,exe,self,changes,true);finishLocal(backup);
 if(!recorded){checkDirectory(root,uninstall_policy::directory);RemoveDirectoryW((root+uninstall_policy::directory).c_str());}
 const auto message=!recorded&&changes.empty()?"No complete recognized Smooth Motion installation was found. Other files were preserved.":removal.loaderPreserved&&changes.empty()?"Files were kept because this ASI installation has changed or is shared with other plugins.":removal.loaderPreserved?"The owned Smooth Motion backend was removed where unchanged. Its ASI carrier was retained for other or modified plugins.":!removal.preserved.empty()?"Unchanged Smooth Motion files removed. Modified files were preserved; see the uninstall review.":incompleteLegacy?"Recognized Smooth Motion files removed. Incomplete or modified loader groups were preserved.":"Smooth Motion files removed. Logs and other mods were preserved.";
 if(machineMode)emit(setup_protocol::result("uninstalled",message));else show(tr(wide(message)));return 0;
}
