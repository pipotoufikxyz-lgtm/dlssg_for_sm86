#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include <algorithm>
namespace preflight {
struct Imports { unsigned machine=0; bool plus=false, dll=false; std::vector<std::string> direct, delay; };
class PE {
 const unsigned char* b; size_t n; size_t opt,sec; uint16_t count; uint32_t headers; uint64_t base; bool plus;
 void need(size_t o,size_t s) const { if(o>n||s>n-o) throw std::runtime_error("Truncated or malformed PE file"); }
 uint16_t u16(size_t o) const {need(o,2);return uint16_t(b[o])|(uint16_t(b[o+1])<<8);}
 uint32_t u32(size_t o) const {need(o,4);return uint32_t(u16(o))|(uint32_t(u16(o+2))<<16);}
 uint64_t u64(size_t o) const {return uint64_t(u32(o))|(uint64_t(u32(o+4))<<32);}
 size_t file(uint32_t r,size_t len) const {
  if(r<headers){need(r,len);if(len>headers-r)throw std::runtime_error("PE header RVA crosses boundary");return r;}
  for(unsigned i=0;i<count;++i){size_t s=sec+40*i;uint32_t va=u32(s+12),raw=u32(s+16),off=u32(s+20);if(r>=va&&uint64_t(r)-va<raw){uint64_t delta=uint64_t(r)-va;if(len>raw-delta)throw std::runtime_error("PE RVA crosses section boundary");uint64_t pos=uint64_t(off)+delta;if(pos>SIZE_MAX)throw std::runtime_error("PE offset overflow");need(size_t(pos),len);return size_t(pos);}}
  throw std::runtime_error("PE RVA is outside stored sections");
 }
 std::string name(uint32_t r) const {std::string s;for(unsigned i=0;i<512;++i){if(uint64_t(r)+i>UINT32_MAX)break;unsigned c=b[file(r+i,1)];if(!c){if(s.empty())throw std::runtime_error("Empty DLL import name");return s;}if(c<32||c>126)throw std::runtime_error("Invalid DLL import name");s.push_back(char(c));}throw std::runtime_error("Unterminated DLL import name");}
 void directory(unsigned ix,bool delay,std::vector<std::string>& out,size_t optSize)const{
  size_t numOff=plus?108:92,dirOff=plus?112:96;if(optSize<numOff+4)throw std::runtime_error("PE optional header too small");if(u32(opt+numOff)<=ix)return;if(optSize<dirOff+8*(ix+1))throw std::runtime_error("Missing declared PE data directory");uint32_t r=u32(opt+dirOff+ix*8),sz=u32(opt+dirOff+ix*8+4);if(!r&&!sz)return;if(!r||!sz)throw std::runtime_error("Invalid PE import directory");size_t step=delay?32:20;
  for(unsigned i=0;i<4096&&uint64_t(i)*step+step<=sz;++i){uint64_t rr=uint64_t(r)+uint64_t(i)*step;if(rr>UINT32_MAX)throw std::runtime_error("PE directory overflow");size_t p=file(uint32_t(rr),step);bool empty=true;for(size_t j=0;j<step;j+=4)empty&=u32(p+j)==0;if(empty)return;uint64_t nr=u32(p+(delay?4:12));if(delay&&!(u32(p)&1)){if(nr<base)throw std::runtime_error("Invalid delay import address");nr-=base;}if(nr>UINT32_MAX)throw std::runtime_error("Delay import RVA overflow");out.push_back(name(uint32_t(nr)));}
  throw std::runtime_error("Unterminated or oversized PE import directory");
 }
 public:
 PE(const unsigned char* bytes,size_t size):b(bytes),n(size){}
 Imports parse(){need(0,64);if(u16(0)!=0x5a4d)throw std::runtime_error("Not a Windows PE executable (MZ missing)");size_t p=u32(60);need(p,24);if(u32(p)!=0x4550)throw std::runtime_error("Invalid PE signature");Imports result;result.machine=u16(p+4);result.dll=(u16(p+22)&0x2000)!=0;count=u16(p+6);if(!count||count>96)throw std::runtime_error("Invalid PE section count");size_t optSize=u16(p+20);opt=size_t(p)+24;need(opt,optSize);unsigned magic=u16(opt);if(magic!=0x20b&&magic!=0x10b)throw std::runtime_error("Unsupported optional header");plus=magic==0x20b;result.plus=plus;if(optSize<(plus?112u:96u))throw std::runtime_error("Incomplete optional header");base=plus?u64(opt+24):u32(opt+28);headers=u32(opt+60);sec=opt+optSize;need(sec,40*count);directory(1,false,result.direct,optSize);directory(13,true,result.delay,optSize);return result;}
};
inline bool named(const std::vector<std::string>& list,const char* match){for(auto s:list){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return c>='A'&&c<='Z'?char(c+32):char(c);});if(s==match)return true;}return false;}
}
