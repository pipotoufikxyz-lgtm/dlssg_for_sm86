#pragma once
#include <array>
#include <string>
namespace install_modes {
// Official v9.7.4 Win64 carrier table. One universal binary, one chosen name.
inline constexpr std::array<const char*,19> carriers={
 "version.dll","dinput8.dll","winmm.dll","winhttp.dll","wininet.dll",
 "dsound.dll","xinput1_1.dll","xinput1_2.dll","xinput1_3.dll",
 "xinput1_4.dll","xinput9_1_0.dll","xinputuap.dll",
 "d3d9.dll","d3d10.dll","d3d11.dll","d3d12.dll","dxgi.dll",
 "binkw64.dll","bink2w64.dll"};
inline constexpr std::array<const char*,9> win32Only={
 "d3d8.dll","ddraw.dll","dinput.dll","msacm32.dll","msvfw32.dll",
 "xlive.dll","binkw32.dll","bink2w32.dll","vorbisFile.dll"};
inline bool valid(const std::string& mode){return mode=="version"||mode=="asi";}
inline bool carrier(const std::string& name){for(auto n:carriers)if(name==n)return true;return false;}
inline bool needsOriginal(const std::string& name){return name=="binkw64.dll"||name=="bink2w64.dll";}
inline std::string original(const std::string& name){return name.substr(0,name.size()-4)+"Hooked.dll";}
}
