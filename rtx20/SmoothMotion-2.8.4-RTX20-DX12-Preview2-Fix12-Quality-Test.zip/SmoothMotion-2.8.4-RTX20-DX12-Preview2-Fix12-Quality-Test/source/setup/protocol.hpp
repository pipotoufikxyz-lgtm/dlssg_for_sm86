#pragma once
#include <string>
namespace setup_protocol {
constexpr unsigned schema=1;
inline std::string quote(const std::string& text){
 std::string out="\"";
 for(unsigned char c:text){
  if(c=='"'||c=='\\'){out+='\\';out+=c;}
  else if(c<32){out+="\\u00";out+="0123456789abcdef"[c>>4];out+="0123456789abcdef"[c&15];}
  else out+=c;
 }
 return out+'"';
}
inline bool validToken(const std::string& token){
 if(token.size()!=64)return false;
 for(char c:token)if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')))return false;
 return true;
}
inline std::string result(const std::string& status,const std::string& message,const std::string& backup="",unsigned error=0){
 return "{\"schema\":1,\"status\":"+quote(status)+",\"message\":"+quote(message)+",\"backup\":"+quote(backup)+",\"win32\":"+std::to_string(error)+"}\n";
}
}
