#pragma once

#include <string>
#include <vector>

namespace setup_policy {

// The caller supplies only supported carrier names, normalized to lowercase,
// in its preferred order. Occupied files are usable only with proven ownership.
struct Candidate {
    std::string name;
    bool direct = false;
    bool delay = false;
    bool dllOccupied = false;
    bool dllKnown = false;
    bool iniOccupied = false;
    bool iniOwned = false;
    bool dependencyDirect = false;
    bool dependencyDelay = false;
};
inline bool imported(const Candidate& c){return c.direct||c.delay||c.dependencyDirect||c.dependencyDelay;}

struct Selection {
    int index = -1;
    bool fallback = false;
};

inline Selection select(const std::vector<Candidate>& candidates) {
    const auto usable = [](const Candidate& candidate) {
        return (!candidate.dllOccupied || candidate.dllKnown) &&
               (!candidate.iniOccupied || candidate.iniOwned);
    };

    for (int evidence = 0; evidence != 4; ++evidence) {
        for (std::size_t i = 0; i != candidates.size(); ++i) {
            const auto& candidate = candidates[i];
            if ((evidence == 0 ? candidate.direct : evidence == 1 ? candidate.dependencyDirect : evidence == 2 ? candidate.delay : candidate.dependencyDelay) &&
                usable(candidate)) {
                return {static_cast<int>(i), false};
            }
        }
    }

    for (std::size_t i = 0; i != candidates.size(); ++i) {
        const auto& candidate = candidates[i];
        if (candidate.name == "version.dll" && usable(candidate)) {
            return {static_cast<int>(i), true};
        }
    }
    return {};
}

struct InstallationHashes {
    std::string loader, ini, bootstrap, backend;
};

inline bool recognized_bootstrap(const std::string& actual,
                                 const std::string& current) {
    if (actual.empty() || actual == "-" || current.empty() || current == "-") {
        return false;
    }
    return actual == current ||
           actual == "db050154d553db126221e91682c583e8edc55640b5f53e5205061cdf8fccac04" ||
           actual == "ea3a5c0331e49f3d58759a4906a1b6819d7bcfb590e2596cf431f5d4ac63d2ca" ||
           actual == "a9a6e488bf37afc7681e19c0e9032f83d4fe3ed2f33c119fae46463479f4b40e" ||
           actual == "25b90eb1f1eb134933218ced4d177fad9d1aa078fdab82be4e43dd84b8236d6b" ||
           actual == "2b44c41d60038213a369beaef3255fb7778b4e3ea5aefcf09506ff0b33a5a345" ||
           actual == "cf29183207a3660a6a454af5a940271dfdc684da8fc3b49e403c40d730d27018";
}
inline bool recognized_menu(const std::string& actual,const std::string& current){
    return actual==current||actual=="93086eee000e2ea2ce060a9b270861142eda04d00b1613cf752090fb8b67d24f"||actual=="8704d9c7b2ceb6b1a424796f4918d16bbc54e78205de3b356d00bf34f4579632";
}
inline bool recognized_backend(const std::string& actual,const std::string& current){
    if(actual.empty()||actual=="-"||current.empty()||current=="-")return false;
    return actual==current||actual=="b28de6d6f2f624fa826b58fb5213f00d9c707a5cba8fd8d8fcc3518217a376cc";
}

inline bool owned_layout(bool supportedCarrier,
                         const InstallationHashes& installed,
                         const InstallationHashes& expected) {
    const auto exact_present = [](const std::string& actual,
                                  const std::string& wanted) {
        return !wanted.empty() && wanted != "-" && actual == wanted;
    };
    return supportedCarrier &&
           exact_present(installed.loader, expected.loader) &&
           exact_present(installed.ini, expected.ini) &&
           recognized_bootstrap(installed.bootstrap, expected.bootstrap) &&
           recognized_backend(installed.backend, expected.backend);
}

// Accept only nonempty relative file paths whose components have no Windows
// device or dot/space aliases. Empty components and reserved characters fail too.
inline bool safe_relative(const std::wstring& path) {
    if (path.empty()) {
        return false;
    }

    std::size_t component_start = 0;
    for (std::size_t i = 0; i <= path.size(); ++i) {
        if (i < path.size()) {
            const wchar_t ch = path[i];
            if (static_cast<unsigned int>(ch) < 0x20U || ch == L':' || ch == L'<' ||
                ch == L'>' || ch == L'"' || ch == L'|' ||
                ch == L'?' || ch == L'*') {
                return false;
            }
            if (ch != L'/' && ch != L'\\') {
                continue;
            }
        }

        // This also rejects absolute paths and components equal to . or .. .
        if (i == component_start || path[i - 1] == L'.' ||
            path[i - 1] == L' ') {
            return false;
        }

        // Windows resolves device names even when followed by an extension.
        // Trim spaces before that extension as well (for example, "NUL .ini").
        std::size_t base_end = component_start;
        while (base_end < i && path[base_end] != L'.') {
            ++base_end;
        }
        while (base_end > component_start && path[base_end - 1] == L' ') {
            --base_end;
        }
        std::wstring base = path.substr(component_start, base_end - component_start);
        for (auto& ch : base) {
            if (ch >= L'a' && ch <= L'z') {
                ch = static_cast<wchar_t>(ch - L'a' + L'A');
            }
        }
        if (base == L"CON" || base == L"PRN" || base == L"AUX" ||
            base == L"NUL" ||
            (base.size() == 4 && (base.compare(0, 3, L"COM") == 0 ||
                                  base.compare(0, 3, L"LPT") == 0) &&
             ((base[3] >= L'1' && base[3] <= L'9') ||
              base[3] == L'\u00b9' || base[3] == L'\u00b2' ||
              base[3] == L'\u00b3'))) {
            return false;
        }
        component_start = i + 1;
    }
    return true;
}

}  // namespace setup_policy
