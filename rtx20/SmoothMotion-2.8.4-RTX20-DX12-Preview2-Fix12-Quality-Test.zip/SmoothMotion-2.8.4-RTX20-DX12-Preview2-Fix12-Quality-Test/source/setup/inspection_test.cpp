#include "pe_reader.hpp"
#include "import_graph.hpp"
#include <cassert>
#include <cstdio>
#include <map>
#include <iostream>
#include <sys/mman.h>
#include <unistd.h>
#include <cstdlib>
#include <string>
void put16(unsigned char* b,size_t p,uint16_t x){b[p]=x;b[p+1]=x>>8;}
void put32(unsigned char* b,size_t p,uint32_t x){for(unsigned i=0;i<4;++i)b[p+i]=x>>(8*i);}
int main(){
 // A real sparse 5 GiB file with import data above 512 MiB; no huge allocation.
 // Honor the test runner's writable temporary directory. libc tmpfile() can
 // ignore TMPDIR and fail in a sandbox before the PE parser is ever exercised.
 const char* temp=std::getenv("TMPDIR");std::string path=(temp&&*temp?temp:"/tmp");path+="/sm20-pe-XXXXXX";
 const int fd=mkstemp(path.data());assert(fd>=0);assert(unlink(path.c_str())==0);
 FILE* file=fdopen(fd,"w+b");assert(file);const size_t size=5ull*1024*1024*1024,raw=512u*1024*1024+4096;
 assert(ftruncate(fileno(file),size)==0);
 auto b=static_cast<unsigned char*>(mmap(nullptr,size,PROT_READ|PROT_WRITE,MAP_SHARED,fileno(file),0));assert(b!=MAP_FAILED);
 put16(b,0,0x5a4d);put32(b,60,0x80);put32(b,0x80,0x4550);put16(b,0x84,0x8664);put16(b,0x86,1);put16(b,0x94,240);
 size_t opt=0x98,section=opt+240;put16(b,opt,0x20b);put32(b,opt+60,512);put32(b,opt+108,16);
 put32(b,section+12,0x1000);put32(b,section+16,1536);put32(b,section+20,raw);
 put32(b,opt+112+8,0x1000);put32(b,opt+112+12,40);put32(b,raw+12,0x1080);memcpy(b+raw+128,"d3d11.dll",10);
 assert(mprotect(b,size,PROT_READ)==0);
 auto info=preflight::PE(b,size).parse();assert(info.machine==0x8664&&info.plus&&!info.dll&&preflight::renderingAPIs(info)==1);
 bool failed=false;try{preflight::PE(b,raw+16).parse();}catch(const std::exception&){failed=true;}assert(failed);
 munmap(b,size);fclose(file);
 preflight::Imports exe;exe.machine=0x8664;exe.plus=true;exe.direct={"opengl32.dll"};exe.delay={"Engine.dll"};
 auto engine=exe;engine.dll=true;engine.direct={"Renderer.dll"};engine.delay={};
 auto renderer=engine;renderer.direct={"d3d11.dll","Engine.dll","winmm.dll"};renderer.delay={"vulkan-1.dll"};
 std::map<std::string,preflight::Imports> files{{"engine.dll",engine},{"renderer.dll",renderer}};
 size_t calls=0;auto read=[&](const std::string& name){++calls;return files.at(name);};
 auto deps=preflight::dependencies(exe,read);assert(deps.apis==5&&deps.inspected==2&&calls<9);assert(preflight::named(deps.direct,"winmm.dll")&&preflight::named(deps.delay,"vulkan-1.dll"));
 assert((preflight::renderingAPIs(exe)|deps.apis)==13); // Other imports cannot hide DX11/Vulkan.
 files["engine.dll"].machine=0x14c;deps=preflight::dependencies(exe,read);assert(deps.apis==0&&deps.inspected==0);
 files["engine.dll"]=engine;files["engine.dll"].dll=false;deps=preflight::dependencies(exe,read);assert(deps.inspected==0);
 exe.direct={"../engine.dll","C:\\engine.dll","sub/engine.dll","NUL.dll",".."};exe.delay.clear();calls=0;
 deps=preflight::dependencies(exe,read);assert(calls==0&&deps.inspected==0);
 exe.direct.clear();for(int i=0;i<1000;++i)exe.direct.push_back(std::to_string(i)+".dll");calls=0;
 deps=preflight::dependencies(exe,[&](const std::string&){++calls;return engine;});assert(deps.limited&&calls==64);
 calls=0;deps=preflight::dependencies(exe,read);assert(deps.limited&&calls==256);
 std::cout<<"PASS: sparse 5 GiB EXE, >512 MiB import offset, truncation, delayed/transitive/cyclic imports, architecture, DLL, unsafe names, graph limits\n";
}
