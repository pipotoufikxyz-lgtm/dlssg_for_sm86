#include "loader_plan.hpp"
#include "protocol.hpp"
#include "../manager/art_policy.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace setup_policy;
 std::vector<Candidate> c={{"version.dll"},{"dinput8.dll"},{"dxgi.dll"}};
 auto chosen=reviewSelect(c);assert(chosen.index==0&&chosen.fallback);
 c[2].direct=true;chosen=reviewSelect(c);assert(chosen.index==2&&!chosen.fallback);
 c[2].dllOccupied=true;chosen=reviewSelect(c);assert(chosen.index==0&&chosen.fallback);
 c[0].dllOccupied=true;assert(reviewSelect(c).index==1); // Screenshot failure: no imported slot, version occupied.
 assert(reviewSelect(c,"version.dll").index<0);assert(!collision(c[0]).empty());
 assert(reviewSelect(c,"dinput8.dll").index==1);assert(reviewSelect(c,"../version.dll").index<0);
 c[1].iniOccupied=true;assert(reviewSelect(c).index<0);assert(!collision(c[1]).empty());
 c[1].iniOwned=true;assert(reviewSelect(c).index==1);
 c[0].dllKnown=true;assert(reviewSelect(c,"",1).index==1); // Reinstall reuses the owned slot.
 assert(reviewSelect(c,"version.dll",1).index<0); // Switching requires restore, cannot leave two loaders.
 c[1].delay=true;assert(!reviewSelect(c,"dinput8.dll").fallback);
 assert(recognized_bootstrap("db050154d553db126221e91682c583e8edc55640b5f53e5205061cdf8fccac04", "e8851f6f9fe9a39bc72466bd77a62b0f067f24c56d106eb9b1ddd85d480dd0bb"));
 using namespace setup_protocol;
 auto response=result("error",u8"C:\\ゲーム\\A\"B\n\t\r",u8"D:\\Jeux é",5);
 auto json=artwork::Parser(response).parse();
 assert(json.at("schema").value=="1"&&json.at("status").value=="error");
 assert(json.at("message").value==u8"C:\\ゲーム\\A\"B\n\t\r"&&json.at("backup").value==u8"D:\\Jeux é");
 assert(json.at("win32").value=="5");
 for(char ch=1;ch<32;++ch){auto encoded=quote(std::string(1,ch));assert(artwork::Parser(encoded).parse().value==std::string(1,ch));}
 assert(validToken(std::string(64,'a')));assert(validToken(std::string(64,'0')));
 for(auto bad:{std::string(),std::string(63,'a'),std::string(65,'a'),std::string(64,'A'),std::string(64,'g')})assert(!validToken(bad));
 std::cout<<"Reviewed imported/fallback slots, ownership, conflict refusal, Unicode/control-character JSON and token validation passed.\n";
}
