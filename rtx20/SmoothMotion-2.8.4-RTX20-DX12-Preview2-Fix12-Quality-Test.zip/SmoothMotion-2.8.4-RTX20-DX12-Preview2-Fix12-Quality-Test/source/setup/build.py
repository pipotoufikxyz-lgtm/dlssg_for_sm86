import sys
from pathlib import Path as _ToolPath
sys.path.insert(0,str(_ToolPath(__file__).resolve().parents[1]))
import build_toolchain
#!/usr/bin/env python3
"""Cross-compile the local installer. Does not run Windows executables."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
build_toolchain.arguments(parser)
parser.add_argument('--output')
parser.add_argument('--package-root', help='Folder containing payload/; defaults to the parent of setup/')
args = parser.parse_args()
root = Path(__file__).resolve().parent
package = Path(args.package_root).resolve() if args.package_root else root.parent.parent
output = Path(args.output) if args.output else package / 'Install.exe'
assets = {'native_proxy':'payload/native/version.dll','motion':'payload/native/normal.asi','loader': 'payload/loader/version.dll',
          'ini': 'payload/loader/loader-template.ini'}
hashes = {key: hashlib.sha256((package / relative).read_bytes()).hexdigest()
          for key, relative in assets.items()}
legacy = json.loads((package / 'source/release-inputs.json').read_text())
# Old engines are ownership identities, not installable payloads in this release.
for key, relative in [('standalone','payload/standalone/version.dll'),('asi','payload/asi/new.asi')]:
    digest = legacy[relative]
    assert len(digest)==64 and all(c in '0123456789abcdef' for c in digest)
    if (package / relative).exists():
        assert hashlib.sha256((package / relative).read_bytes()).hexdigest()==digest,relative
    hashes[key] = digest
(root / 'payload_hashes.hpp').write_text(
    '// Generated from current payloads and pinned legacy ownership identities.\n#pragma once\n'
    'namespace payload_hashes {\n' + ''.join(
        f'inline constexpr const char {key}[] = "{value}";\n' for key, value in hashes.items()) + '}\n')
command = [*build_toolchain.command(args,output), '-std=c++17', '-O2',
           '-DUNICODE', '-D_UNICODE', '-municode', '-Wl,--subsystem,windows', '-static',
           str(root / 'install.cpp'), '-o', str(output), '-lxmllite','-lshlwapi','-lole32','-luuid','-lcomdlg32', '-lbcrypt', '-lshell32']
subprocess.run(command, check=True)
report = {'compiler':build_toolchain.identity(args),'file': str(output), 'bytes': output.stat().st_size,
          'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_sha256': hashes, 'native_windows_executed': False,
          'source_sha256': {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in
                           ['../release-inputs.json','../ui/localization.hpp','../normal_policy.hpp','../motion/dx12_policy.hpp','../motion/identity.hpp','../build_toolchain.py','build.py','install.cpp','file_plan.hpp','uninstall_policy.hpp','local_uninstall.hpp','local_journal_policy.hpp','simple_install.hpp','install_modes.hpp','legacy_hashes.hpp','policy.hpp','loader_plan.hpp','protocol.hpp','payload_hashes.hpp','pe_reader.hpp','windows_pe.hpp','windows_game_target.hpp','game_config_policy.hpp','../ui/file_picker.hpp','import_graph.hpp','../guard/session.hpp']}}
(root / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
