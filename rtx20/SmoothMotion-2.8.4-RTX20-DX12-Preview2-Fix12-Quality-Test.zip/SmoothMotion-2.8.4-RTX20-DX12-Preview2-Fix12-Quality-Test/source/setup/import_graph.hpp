#pragma once
#include "pe_reader.hpp"
#include "policy.hpp"
#include <set>
namespace preflight {
inline unsigned renderingAPIs(const Imports& imports){
 unsigned flags=0;
 for(auto list:{&imports.direct,&imports.delay})for(auto name:*list){
  for(auto& c:name)if(c>='A'&&c<='Z')c+=32;
  if(name=="d3d11.dll")flags|=1;
  if(name=="d3d12.dll")flags|=2;
  if(name=="vulkan-1.dll")flags|=4;
  if(name=="d3d9.dll"||name=="d3d10.dll"||name=="opengl32.dll")flags|=8;
 }
 return flags;
}
struct DependencyEvidence{unsigned apis=0;size_t inspected=0;bool limited=false;std::vector<std::string> direct,delay;};
// Inspect only imported local DLLs, including delay imports and engine chains.
// Caller reads bytes, never LoadLibrary. Cycles, malicious names and huge graphs
// cannot trigger an unbounded directory scan or load executable code.
template<class Read>DependencyEvidence dependencies(const Imports& initial,Read read){
 struct Pending{Imports imports;unsigned depth;};
 std::vector<Pending> queue{{initial,0}};std::set<std::string> seen;
 DependencyEvidence result;size_t attempts=0;
 for(size_t at=0;at<queue.size();++at){
  auto current=queue[at];
  if(current.depth==4){result.limited|=!current.imports.direct.empty()||!current.imports.delay.empty();continue;}
  for(auto list:{&current.imports.direct,&current.imports.delay})for(auto name:*list){
   for(auto& c:name)if(c>='A'&&c<='Z')c+=32;
   if(name.find_first_of("\\/:")!=name.npos||!setup_policy::safe_relative(std::wstring(name.begin(),name.end()))||!seen.insert(name).second)continue;
   if(attempts++>=256||result.inspected>=64){result.limited=true;return result;}
   try{
    auto info=read(name);
    if(info.machine!=0x8664||!info.plus||!info.dll)continue;
    ++result.inspected;result.apis|=renderingAPIs(info);
    // A renderer DLL frequently imports the carrier while the EXE imports
    // only that renderer. Preserve this evidence for loader selection.
    for(auto pair:{std::make_pair(&info.direct,&result.direct),std::make_pair(&info.delay,&result.delay)})
     for(auto imported:*pair.first){for(auto& c:imported)if(c>='A'&&c<='Z')c+=32;
      if(std::find(pair.second->begin(),pair.second->end(),imported)==pair.second->end())pair.second->push_back(imported);}
    queue.push_back({std::move(info),current.depth+1});
   }catch(const std::exception&){} // Absent system DLLs are not searched elsewhere.
  }
 }
 return result;
}
}
