#pragma once
#include <algorithm>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
#include "install_modes.hpp"
#include "loader_plan.hpp"
#include "payload_hashes.hpp"
#include "legacy_hashes.hpp"
#include "../motion/identity.hpp"
namespace file_plan {
struct File {std::string path,digest;bool asi=false,loader=false;};
struct Inventory {
 std::vector<File> scanned;
 std::map<std::string,std::string> files;
 std::vector<std::string> direct,delay,dependencyDirect,dependencyDelay;
 std::map<std::string,bool> originals;
 std::vector<std::string> legacyModHashes;
};
struct Change {std::string path,source,before,after;};
struct Choice {setup_policy::Candidate candidate;bool original=true;};
struct Plan {std::string mode,proxy;bool fallback=false;std::vector<Change> changes;std::vector<Choice> choices;std::vector<std::string> otherPlugins;};
inline std::string lower(std::string s){for(auto& c:s)if(c>='A'&&c<='Z')c+=32;return s;}
inline std::string digest(const Inventory& in,const std::string& path){auto i=in.files.find(lower(path));return i==in.files.end()?"-":i->second;}
inline bool has(const std::vector<std::string>& names,const std::string& name){return std::any_of(names.begin(),names.end(),[&](const auto& value){return lower(value)==name;});}
inline bool oldMod(const Inventory& in,const std::string& hash){return std::find(in.legacyModHashes.begin(),in.legacyModHashes.end(),hash)!=in.legacyModHashes.end();}
inline bool ownIni(const std::string& hash){return hash==payload_hashes::ini||hash==legacy_hashes::ini;}
inline Plan make(const Inventory& in,const std::string& mode,const std::string& requested,unsigned multiplier=2){
 if(!install_modes::valid(mode))throw std::runtime_error("Choose version.dll or new.asi.");
 if(multiplier!=2)throw std::runtime_error("Only normal Smooth Motion is available.");
 const bool asi=mode=="asi";
 const auto selectedPlugin=payload_hashes::motion;
 const auto plugin=digest(in,"new.asi"),boot=digest(in,"plugins\\SM86Bootstrap.asi"),backend=digest(in,"SM86\\backend.asi");
 const bool legacy=setup_policy::recognized_bootstrap(boot,legacy_hashes::bootstrap)&&setup_policy::recognized_backend(backend,legacy_hashes::backend);
 Plan out;out.mode=mode;std::vector<setup_policy::Candidate> candidates;std::vector<bool> owns;
 for(const auto* name:install_modes::carriers){
  auto h=digest(in,name),ih=digest(in,std::string(name).substr(0,std::string(name).size()-4)+".ini");
  const bool owned=h==payload_hashes::loader&&ownIni(ih)&&(((plugin==payload_hashes::asi||motion::ownedPlugin(plugin,payload_hashes::motion))&&ih==payload_hashes::ini)||legacy);
  auto found=in.originals.find(name);bool original=!install_modes::needsOriginal(name)||(found!=in.originals.end()&&found->second);
  const bool known=motion::ownedNativeProxy(h,payload_hashes::native_proxy)||h==payload_hashes::standalone||motion::ownedPlugin(h,payload_hashes::motion)||oldMod(in,h)||owned;
  setup_policy::Candidate c{name,has(in.direct,name),has(in.delay,name),h!="-"||!original,known&&original,ih!="-",ownIni(ih)};
  c.dependencyDirect=has(in.dependencyDirect,name);c.dependencyDelay=has(in.dependencyDelay,name);
  candidates.push_back(c);out.choices.push_back({c,original});owns.push_back(owned);
 }
 for(const auto& f:in.scanned)if(f.loader||f.digest==payload_hashes::loader){
  bool owned=false;for(size_t i=0;i<candidates.size();++i)if(lower(f.path)==candidates[i].name&&owns[i])owned=true;
  if(!owned)throw std::runtime_error("An existing ASI loader is not owned by this installer: "+f.path+". Restore that loader using its original package first. No files changed.");
 }
 // A carrier is shared infrastructure once other ASIs consume it. Replacing
 // it with the standalone backend, or switching carrier names, would disable
 // those plugins even if their own files were preserved.
 const bool otherASI=std::any_of(in.scanned.begin(),in.scanned.end(),[&](const auto& f){return f.asi&&lower(f.path)!="new.asi"&&!oldMod(in,f.digest)&&f.digest!=payload_hashes::standalone&&!motion::ownedNativeProxy(f.digest,payload_hashes::native_proxy)&&!motion::ownedPlugin(f.digest,payload_hashes::motion)&&!setup_policy::recognized_bootstrap(f.digest,legacy_hashes::bootstrap)&&f.digest!=legacy_hashes::backend;});
 if(otherASI)for(size_t i=0;i<owns.size();++i)if(owns[i]&&(!asi||(!requested.empty()&&lower(requested)!=candidates[i].name)))throw std::runtime_error("Other ASI plugins use this loader. Keep the existing ASI carrier or remove those plugins with their original packages before switching to the standalone DLL or another loader. No files changed.");
 setup_policy::Selection selected;
 if(!asi){selected={0,!setup_policy::imported(candidates[0])};if(!setup_policy::usable(candidates[0]))throw std::runtime_error("version.dll or version.ini belongs to the game or another mod. It was preserved. Choose new.asi with an available alternative loader.");}
 else{
  int existing=-1;for(size_t i=0;i<owns.size();++i)if(owns[i])existing=int(i);
  selected=setup_policy::reviewSelect(candidates,lower(requested),requested.empty()?existing:-1);
  if(selected.index<0)throw std::runtime_error("The chosen loader is occupied or unavailable. Bink loaders require their matching original Hooked.dll. Choose another loader; existing files were preserved.");
 }
 out.proxy=candidates[size_t(selected.index)].name;out.fallback=selected.fallback;
 if(otherASI)for(size_t i=0;i<owns.size();++i)if(owns[i]&&candidates[i].name!=out.proxy)throw std::runtime_error("Other ASI plugins use the existing loader. Select that same carrier before upgrading. No files changed.");
 auto append=[&](std::string path,const std::string& source,const std::string& after){
  for(const auto& c:out.changes)if(lower(c.path)==lower(path))return;
  auto before=digest(in,path);if(before!=after)out.changes.push_back({std::move(path),source,before,after});
 };
 // The native proxy and ASI are alternative carriers of one backend. Never
 // leave both copies installed; a duplicated hook engine can recurse/crash.
 const auto selectedIni=out.proxy.substr(0,out.proxy.size()-4)+".ini";
 if(asi){
  append(out.proxy,"loader",payload_hashes::loader);
  if(plugin!="-"&&plugin!=payload_hashes::asi&&!motion::ownedPlugin(plugin,payload_hashes::motion)&&!oldMod(in,plugin))throw std::runtime_error("An unknown new.asi already exists and was preserved. Identify and back up that plugin first.");
  append("new.asi","motion",selectedPlugin);append(selectedIni,"ini",payload_hashes::ini);
 }else{
  append(out.proxy,"native_proxy",payload_hashes::native_proxy);
  if(plugin!="-"){
   if(plugin!=payload_hashes::asi&&!motion::ownedPlugin(plugin,payload_hashes::motion)&&!oldMod(in,plugin))throw std::runtime_error("An unknown new.asi already exists and was preserved. Remove or identify that plugin before using the standalone DLL.");
   append("new.asi","","-");
  }
  if(ownIni(digest(in,selectedIni)))append(selectedIni,"","-");
 }
 for(size_t i=0;i<owns.size();++i)if(owns[i]){
  const auto& name=candidates[i].name;if(name!=out.proxy)append(name,"","-");
  if(name!=out.proxy||!asi)append(name.substr(0,name.size()-4)+".ini","","-");
 }
 for(const auto& f:in.scanned){
  if(lower(f.path)==out.proxy||lower(f.path)=="new.asi")continue;
  const bool old=oldMod(in,f.digest)||motion::ownedNativeProxy(f.digest,payload_hashes::native_proxy)||f.digest==payload_hashes::standalone||motion::ownedPlugin(f.digest,payload_hashes::motion)||setup_policy::recognized_bootstrap(f.digest,legacy_hashes::bootstrap)||f.digest==legacy_hashes::backend;
  if(old)append(f.path,"","-");
  else if(f.asi&&(lower(f.path).rfind("scripts\\",0)==0||lower(f.path).rfind("plugins\\",0)==0))out.otherPlugins.push_back(f.path);
 }
 for(const auto& item:std::vector<std::pair<std::string,std::string>>{{"SM86\\SM86_Menu.exe",legacy_hashes::menu},{"SM86\\SM86_Guard.exe",legacy_hashes::guard}})
  if(digest(in,item.first)==item.second)append(item.first,"","-");
 return out;
}
}
