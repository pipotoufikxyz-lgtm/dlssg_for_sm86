#pragma once
#include "policy.hpp"
#include <algorithm>
namespace setup_policy {
inline bool usable(const Candidate& c){return (!c.dllOccupied||c.dllKnown)&&(!c.iniOccupied||c.iniOwned);}
inline std::string collision(const Candidate& c){
 if(c.dllOccupied&&!c.dllKnown)return "Existing DLL belongs to the game or another mod";
 if(c.iniOccupied&&!c.iniOwned)return "Existing loader configuration is not owned by Smooth Motion";
 return {};
}
// Imported names are preferred. A free fallback is a reviewable choice, not
// proof that the game loads it. Unknown files are never overwrite candidates.
inline Selection reviewSelect(const std::vector<Candidate>& candidates,const std::string& requested="",int existing=-1){
 if(!requested.empty()){
  for(size_t i=0;i<candidates.size();++i)if(candidates[i].name==requested){
   if(!usable(candidates[i])||(existing>=0&&size_t(existing)!=i))return {};
   return {int(i),!imported(candidates[i])};
  }
  return {};
 }
 if(existing>=0&&size_t(existing)<candidates.size()&&usable(candidates[existing])&&imported(candidates[existing]))return {existing,false};
 auto selected=select(candidates);if(selected.index>=0&&!selected.fallback)return selected;
 if(existing>=0&&size_t(existing)<candidates.size()&&usable(candidates[existing]))return {existing,true};
 if(selected.index>=0)return selected;
 for(size_t i=0;i<candidates.size();++i)if(usable(candidates[i]))return {int(i),true};
 return {};
}
}
