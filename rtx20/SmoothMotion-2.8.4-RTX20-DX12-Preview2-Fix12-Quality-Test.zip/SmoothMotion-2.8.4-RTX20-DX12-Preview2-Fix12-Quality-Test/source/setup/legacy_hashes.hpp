// Exact identities of the supplied 1.5 package, retained for reversible migration.
#pragma once
namespace legacy_hashes {
inline constexpr const char loader[] = "031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
inline constexpr const char bootstrap[] = "e8851f6f9fe9a39bc72466bd77a62b0f067f24c56d106eb9b1ddd85d480dd0bb";
inline constexpr const char backend[] = "b28e5c17a85b5cbc3c50da1a87ad854e572ca1c10903293b218fed2d132e0149";
inline constexpr const char menu[] = "15d4a952b507b2412eea02ddecd7350d85bb184122d6c460c44f2bbbb40610fd";
inline constexpr const char guard[] = "6194915a162d52acf4bbd45988c5996876e4e138ab6d07683ded53fe30a0b429";
inline constexpr const char config[] = "b0273a006a9b0d62743f9df99ede85436651fc4e597c02fdd8e14d1cb9a5c589";
inline constexpr const char ini[] = "a41889a3dad38451880294ec24eb061adbde4ea1a053e61241105f67c983dd23";
}
