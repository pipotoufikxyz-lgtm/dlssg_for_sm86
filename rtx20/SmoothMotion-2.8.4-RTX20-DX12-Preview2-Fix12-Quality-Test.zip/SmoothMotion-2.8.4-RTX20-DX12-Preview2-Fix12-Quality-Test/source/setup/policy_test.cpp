#include "policy.hpp"

#include <cassert>
#include <iostream>

namespace {

using setup_policy::Candidate;

void expect_selection(const std::vector<Candidate>& candidates,
                      int index, bool fallback = false) {
    const auto result = setup_policy::select(candidates);
    assert(result.index == index);
    assert(result.fallback == fallback);
}

void test_selection() {
    expect_selection({}, -1);
    // The installer now offers version.dll first within the evidence class.
    expect_selection({{"version.dll", true}, {"dinput8.dll", true}}, 0);
    expect_selection({{"version.dll", true, false, true, false}, {"dinput8.dll", true}}, 1);
    expect_selection({{"version.dll", false, true}, {"dinput8.dll", true}}, 1);
    expect_selection({{"dinput8.dll"}, {"dxgi.dll"}}, -1);
    expect_selection({{"dinput8.dll"}, {"version.dll"}}, 1, true);

    // Direct import evidence outranks an earlier delay import or fallback.
    expect_selection({{"dinput8.dll", false, true}, {"version.dll"},
                      {"dxgi.dll", true}}, 2);
    // Vector order breaks ties within each evidence class.
    expect_selection({{"dinput8.dll", true}, {"version.dll", true}}, 0);
    expect_selection({{"dinput8.dll", false, true},
                      {"version.dll", false, true}}, 0);
    expect_selection({{"version.dll", true, true}}, 0);
    expect_selection({{"version.dll", false, true}}, 0);
    expect_selection({{"dinput8.dll", false, true}, {"version.dll"}}, 0);

    // An unknown occupied DLL cannot hide a later usable imported carrier.
    expect_selection({{"dinput8.dll", true, false, true, false},
                      {"version.dll", true}}, 1);
    expect_selection({{"dinput8.dll", true, false, true, false},
                      {"version.dll", false, true}}, 1);
    expect_selection({{"dinput8.dll", true, false, true, false},
                      {"version.dll"}}, 1, true);
    // INI ownership is required independently of known DLL contents.
    expect_selection({{"dinput8.dll", true, false, true, true, true, false},
                      {"version.dll"}}, 1, true);
    expect_selection({{"dinput8.dll", true, false, true, true, true, true},
                      {"version.dll", true}}, 0);

    // Exhaust every occupancy/ownership combination for both import classes
    // and for the sole fallback. Flags on an absent file do not block it.
    for (unsigned flags = 0; flags != 16; ++flags) {
        Candidate candidate{"version.dll"};
        candidate.dllOccupied = (flags & 1) != 0;
        candidate.dllKnown = (flags & 2) != 0;
        candidate.iniOccupied = (flags & 4) != 0;
        candidate.iniOwned = (flags & 8) != 0;
        const bool usable = (!candidate.dllOccupied || candidate.dllKnown) &&
                            (!candidate.iniOccupied || candidate.iniOwned);
        expect_selection({candidate}, usable ? 0 : -1, usable);
        candidate.direct = true;
        expect_selection({candidate}, usable ? 0 : -1);
        candidate.direct = false;
        candidate.delay = true;
        expect_selection({candidate}, usable ? 0 : -1);
    }

    // Free non-version carriers must never become speculative fallbacks.
    expect_selection({{"dinput8.dll"},
                      {"version.dll", false, false, true, false},
                      {"winmm.dll"}, {"dxgi.dll"}}, -1);
    expect_selection({{"version.dll", false, false, false, false, true, false},
                      {"winmm.dll"}}, -1);
}

void test_owned_layout() {
    using setup_policy::InstallationHashes;
    const InstallationHashes expected{
        std::string(64, 'a'), std::string(64, 'b'),
        std::string(64, 'c'), std::string(64, 'd')};
    const std::string legacy =
        "cf29183207a3660a6a454af5a940271dfdc684da8fc3b49e403c40d730d27018";
    const std::string unknown(64, 'e');

    assert(setup_policy::recognized_bootstrap(expected.bootstrap, expected.bootstrap));
    assert(setup_policy::recognized_bootstrap(legacy, expected.bootstrap));
    assert(!setup_policy::recognized_bootstrap(unknown, expected.bootstrap));
    assert(setup_policy::owned_layout(true, expected, expected));
    assert(!setup_policy::owned_layout(false, expected, expected));

    auto old_install = expected;
    old_install.bootstrap = legacy;
    assert(setup_policy::owned_layout(true, old_install, expected));
    assert(!setup_policy::owned_layout(false, old_install, expected));
    auto manager_install=expected;
    manager_install.bootstrap="25b90eb1f1eb134933218ced4d177fad9d1aa078fdab82be4e43dd84b8236d6b";
    manager_install.backend="b28de6d6f2f624fa826b58fb5213f00d9c707a5cba8fd8d8fcc3518217a376cc";
    assert(setup_policy::owned_layout(true,manager_install,expected));
    manager_install.bootstrap="a9a6e488bf37afc7681e19c0e9032f83d4fe3ed2f33c119fae46463479f4b40e";
    assert(setup_policy::owned_layout(true,manager_install,expected));
    assert(setup_policy::recognized_menu("93086eee000e2ea2ce060a9b270861142eda04d00b1613cf752090fb8b67d24f", "current-waterglass-menu"));
    assert(!setup_policy::recognized_menu(unknown,"current-waterglass-menu"));
    manager_install.backend=unknown;
    assert(!setup_policy::owned_layout(true,manager_install,expected));

    const std::vector<std::string InstallationHashes::*> members{
        &InstallationHashes::loader, &InstallationHashes::ini,
        &InstallationHashes::bootstrap, &InstallationHashes::backend};
    for (const auto member : members) {
        auto installed = expected;
        installed.*member = unknown;
        assert(!setup_policy::owned_layout(true, installed, expected));

        for (const auto& missing : {std::string(), std::string("-")}) {
            installed = expected;
            installed.*member = missing;
            assert(!setup_policy::owned_layout(true, installed, expected));

            auto missing_expected = expected;
            missing_expected.*member = missing;
            assert(!setup_policy::owned_layout(true, expected, missing_expected));
            // Matching absent values never establish ownership.
            assert(!setup_policy::owned_layout(true, installed, missing_expected));
            assert(!setup_policy::owned_layout(true, old_install, missing_expected));
        }
    }

    for (const auto& missing : {std::string(), std::string("-")}) {
        assert(!setup_policy::recognized_bootstrap(missing, expected.bootstrap));
        assert(!setup_policy::recognized_bootstrap(expected.bootstrap, missing));
        assert(!setup_policy::recognized_bootstrap(legacy, missing));
        assert(!setup_policy::recognized_bootstrap(missing, missing));
    }
    assert(!setup_policy::owned_layout(true, {}, {}));
}

void test_safe_relative() {
    const std::vector<std::wstring> valid{
        L"version.dll", L"scripts\\mod.asi", L"backup/version.dll",
        L"backup\\nested/file.ini", L"folder with spaces/file.ini",
        L".config/name..ini", L"unicode_\u03a9/\u6587\u4ef6.ini",
        L"COM0.ini", L"LPT0", L"COM10.ini", L"LPT10.ini",
        L"conifer.ini", L"null.txt", L"auxiliary.dll", L"backup/printer.ini",
    };
    for (const auto& path : valid) {
        assert(setup_policy::safe_relative(path));
    }

    const std::vector<std::wstring> invalid{
        L"", L".", L"..", L"./file", L"../file", L"folder/./file",
        L"folder/../file", L"folder\\..\\file", L"folder/..\\file",
        L"/file", L"\\file", L"//server/share/file", L"\\\\server\\file",
        L"C:file", L"C:\\file", L"folder/name:stream", L"folder/C:/file",
        L"file\r", L"file\n", L"file\t", L"folder\n/file",
        L"file.", L"file ", L"folder./file", L"folder /file",
        L"folder/.../file", L"folder/.. /file", L"folder/ /file",
        L"folder/", L"folder\\", L"folder//file", L"folder\\\\file",
        std::wstring(L"file\0.ini", 9),
    };
    for (const auto& path : invalid) {
        assert(!setup_policy::safe_relative(path));
    }

    // Every C0 control is rejected, including embedded NUL and less common
    // controls such as vertical tab that can survive an edited manifest.
    for (wchar_t ch = 0; ch < 0x20; ++ch) {
        const std::wstring path = L"backup/a" + std::wstring(1, ch) + L"b.ini";
        assert(!setup_policy::safe_relative(path));
    }
    for (wchar_t ch : std::wstring(L"<>\"|?*")) {
        const std::wstring path = L"backup/a" + std::wstring(1, ch) + L"b.ini";
        assert(!setup_policy::safe_relative(path));
    }

    const std::vector<std::wstring> devices{L"CON", L"pRn", L"AuX", L"nul"};
    for (const auto& device : devices) {
        assert(!setup_policy::safe_relative(device));
        assert(!setup_policy::safe_relative(device + L".txt"));
        assert(!setup_policy::safe_relative(L"backup/" + device + L".txt"));
        assert(!setup_policy::safe_relative(device + L"/file.ini"));
        assert(!setup_policy::safe_relative(device + L" .txt"));
        assert(!setup_policy::safe_relative(device + L"   .more.txt"));
    }
    for (wchar_t number = L'1'; number <= L'9'; ++number) {
        for (const auto& prefix : {L"cOm", L"LpT"}) {
            const std::wstring device = std::wstring(prefix) + number;
            assert(!setup_policy::safe_relative(device));
            assert(!setup_policy::safe_relative(device + L".ini"));
            assert(!setup_policy::safe_relative(L"backup/" + device + L".txt"));
            assert(!setup_policy::safe_relative(device + L"/file.ini"));
            assert(!setup_policy::safe_relative(device + L"  .ini"));
        }
    }
    // Windows also reserves these superscript digits in COM/LPT device names.
    for (wchar_t number : {L'\u00b9', L'\u00b2', L'\u00b3'}) {
        for (const auto& prefix : {L"cOm", L"LpT"}) {
            const std::wstring device = std::wstring(prefix) + number;
            assert(!setup_policy::safe_relative(device));
            assert(!setup_policy::safe_relative(device + L".ini"));
            assert(!setup_policy::safe_relative(L"backup/" + device + L".txt"));
            assert(!setup_policy::safe_relative(device + L"/file.ini"));
            assert(!setup_policy::safe_relative(device + L"  .ini"));
            assert(setup_policy::safe_relative(device + L"_backup.ini"));
        }
    }
}

}  // namespace

int main() {
    test_selection();
    test_owned_layout();
    test_safe_relative();
    std::cout << "All installer policy tests passed.\n";
}
