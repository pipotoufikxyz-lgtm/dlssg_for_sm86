#pragma once
#include "policy.hpp"
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>
namespace local_journal_policy {
struct Change {std::wstring path;std::string before,after;};
struct Stage {std::wstring path;std::string digest;};
struct Record {std::wstring root,exe;std::string manifestHash,helperHash,instructionHash;std::vector<Change> changes;std::vector<std::wstring> directories;std::vector<Stage> stages;};
inline bool digest(const std::string& s){return s.size()==64&&std::all_of(s.begin(),s.end(),[](char c){return(c>='0'&&c<='9')||(c>='a'&&c<='f');});}
inline std::wstring wide(const std::string& s){return {s.begin(),s.end()};}
inline std::string ascii(const std::wstring& s){std::string r;for(auto c:s){if(c<0||c>127)throw std::runtime_error("Non-ASCII journal identity");r+=char(c);}return r;}
inline std::wstring canonical(std::wstring s){for(auto& c:s){if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A';if(c==L'/')c=L'\\';}return s;}
inline std::vector<std::wstring> rows(const std::wstring& s){if(s.size()>512*1024||s.find(L'\0')!=s.npos)throw std::runtime_error("Invalid journal size");std::vector<std::wstring> out;size_t p=0;while(p<s.size()){auto n=s.find(L'\n',p);if(n==s.npos)throw std::runtime_error("Truncated journal");auto line=s.substr(p,n-p);if(!line.empty()&&line.back()==L'\r')line.pop_back();out.push_back(line);p=n+1;}return out;}
inline std::wstring commitMarker(const std::string& manifestHash){if(!digest(manifestHash))throw std::runtime_error("Invalid journal digest");return L"SM86-COMMITTED-1\r\n"+wide(manifestHash)+L"\r\n";}
inline bool committed(const std::string& manifestHash,const std::wstring& marker){if(marker.empty())return false;if(marker!=commitMarker(manifestHash))throw std::runtime_error("Modified commit marker");return true;}
inline std::wstring retirementDirectory(const std::string& manifestHash){if(!digest(manifestHash))throw std::runtime_error("Invalid retired journal identity");return L".smooth-motion\\done-"+wide(manifestHash.substr(0,24))+L"\\";}
template<class SameLocation> Record parse(const std::wstring& manifest,const std::wstring& owner,const std::string& manifestHash,const std::wstring& expectedRoot,SameLocation same){
 const auto m=rows(manifest),o=rows(owner);if(!digest(manifestHash)||o.size()!=4||o[0]!=L"SM86-JOURNAL-1"||o[3]!=wide(manifestHash)||!digest(ascii(o[1]))||!digest(ascii(o[2])))throw std::runtime_error("Incomplete or modified journal identity");
 if(m.size()<3||m[0]!=L"SM86-RESTORE-1"||!same(m[1],expectedRoot))throw std::runtime_error("Journal belongs to another game root");
 Record r{expectedRoot,m[2],manifestHash,ascii(o[1]),ascii(o[2]),{},{},{}};auto split=r.exe.find_last_of(L"\\/");if(split==r.exe.npos||!same(r.exe.substr(0,split+1),expectedRoot)||!setup_policy::safe_relative(r.exe.substr(split+1)))throw std::runtime_error("Journal executable is outside its game root");
 for(size_t n=3;n<m.size();++n){const auto& row=m[n];
  if(row.rfind(L"D\t",0)==0){auto d=row.substr(2);if(!setup_policy::safe_relative(d))throw std::runtime_error("Unsafe journal directory");r.directories.push_back(d);continue;}
  if(row.rfind(L"S\t",0)==0){auto t=row.find(L'\t',2);if(t==row.npos||row.find(L'\t',t+1)!=row.npos)throw std::runtime_error("Malformed journal stage");auto p=row.substr(2,t-2),h=row.substr(t+1);if(!setup_policy::safe_relative(p)||!digest(ascii(h)))throw std::runtime_error("Unsafe journal stage");r.stages.push_back({p,ascii(h)});continue;}
  auto a=row.find(L'\t',2),b=a==row.npos?row.npos:row.find(L'\t',a+1);if(row.rfind(L"F\t",0)!=0||a==row.npos||b==row.npos||row.find(L'\t',b+1)!=row.npos)throw std::runtime_error("Malformed journal destination");
  Change c{row.substr(2,a-2),ascii(row.substr(a+1,b-a-1)),ascii(row.substr(b+1))};if(!setup_policy::safe_relative(c.path)||(c.before!="-"&&!digest(c.before))||(c.after!="-"&&!digest(c.after))||c.before==c.after)throw std::runtime_error("Invalid journal destination identity");
  for(const auto& prior:r.changes)if(canonical(prior.path)==canonical(c.path))throw std::runtime_error("Duplicate journal destination");r.changes.push_back(c);
 }
 if(r.changes.empty())throw std::runtime_error("Empty pending journal");
 for(const auto& stage:r.stages){bool matches=false;for(const auto& c:r.changes)if(stage.digest==c.after&&stage.path.rfind(c.path+L".sm86-stage-",0)==0){const auto tail=stage.path.substr(c.path.size()+12);matches=!tail.empty()&&std::all_of(tail.begin(),tail.end(),[](wchar_t c){return(c>=L'0'&&c<=L'9')||c==L'-';});}if(!matches)throw std::runtime_error("Unrelated journal stage");}
 for(const auto& d:r.directories){bool matches=false;for(const auto& c:r.changes)matches|=canonical(c.path).rfind(canonical(d)+L"\\",0)==0;if(!matches)throw std::runtime_error("Unrelated journal directory");}
 return r;
}
enum class Recovery {Settled,Remove,Restore,Conflict};
inline Recovery recovery(const Change& c,const std::string& current){if(current==c.before)return Recovery::Settled;if(current!=c.after)return Recovery::Conflict;return c.before=="-"?Recovery::Remove:Recovery::Restore;}
struct RecoveryPlan {bool cleanupOnly=false;std::vector<size_t> changes;};
template<class Current,class Original> RecoveryPlan plan(const Record& record,const std::wstring& marker,Current current,Original original){
 if(committed(record.manifestHash,marker))return {true,{}};
 RecoveryPlan result;
 // The complete preflight precedes any write. One foreign file blocks the whole
 // rollback, including earlier entries that would otherwise be removable.
 for(size_t n=record.changes.size();n-->0;){const auto& c=record.changes[n];auto action=recovery(c,current(c.path));if(action==Recovery::Conflict)throw std::runtime_error("A recovery destination was modified; all files preserved");if(c.before!="-"&&original(c.path)!=c.before)throw std::runtime_error("A recovery original is missing or modified; all files preserved");if(action!=Recovery::Settled)result.changes.push_back(n);}
 return result;
}
}
