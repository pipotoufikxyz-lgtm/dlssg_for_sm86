#include "file_plan.hpp"
#include <cassert>
#include <functional>
#include <iostream>
#include <set>
using namespace file_plan;
void put(Inventory& in,std::string path,const std::string& hash,bool loader=false){
 in.files[lower(path)]=hash;
 auto extension=lower(path).substr(path.size()-4);
 if(extension==".dll"||extension==".asi"){
  in.scanned.erase(std::remove_if(in.scanned.begin(),in.scanned.end(),[&](const auto& f){return lower(f.path)==lower(path);}),in.scanned.end());
  in.scanned.push_back({path,hash,extension==".asi",loader});
 }
}
Inventory applied(Inventory in,const Plan& plan){
 for(const auto& c:plan.changes){assert(digest(in,c.path)==c.before);in.files.erase(lower(c.path));in.scanned.erase(std::remove_if(in.scanned.begin(),in.scanned.end(),[&](const auto& f){return lower(f.path)==lower(c.path);}),in.scanned.end());if(c.after!="-")put(in,c.path,c.after,c.after==payload_hashes::loader);}
 return in;
}
bool fails(const std::function<void()>& call){try{call();return false;}catch(const std::runtime_error&){return true;}}
int main(){
 int checks=0;auto check=[&](bool condition){if(!condition)throw std::runtime_error("Scenario "+std::to_string(checks+1)+" failed");++checks;};
 Inventory clean;clean.legacyModHashes.push_back(payload_hashes::asi);
 auto direct=make(clean,"version","");check(direct.proxy=="version.dll"&&direct.changes.size()==1&&direct.changes[0].after==payload_hashes::native_proxy);
 auto asi=make(clean,"asi","");check(asi.proxy=="version.dll"&&asi.changes.size()==3&&asi.fallback&&asi.choices.size()==19);
 auto installed=applied(clean,asi);check(make(installed,"asi","").changes.empty());
 for(unsigned n=2;n<=2;++n){
  auto custom=make(clean,"asi","version.dll",n);
  auto generated=applied(clean,custom);
  check(digest(generated,"new.asi")==payload_hashes::motion&&custom.changes.size()==3);
  check(make(generated,"asi","version.dll",n).changes.empty());
  auto native=applied(generated,make(generated,"asi","version.dll"));
  check(digest(native,"new.asi")==payload_hashes::motion);
  auto directCustom=applied(generated,make(generated,"version",""));
  check(digest(directCustom,"new.asi")=="-"&&digest(directCustom,"version.dll")==payload_hashes::native_proxy);
  auto changedCarrier=applied(generated,make(generated,"asi","winhttp.dll",n));
  check(digest(changedCarrier,"version.dll")=="-"&&digest(changedCarrier,"winhttp.dll")==payload_hashes::loader&&digest(changedCarrier,"new.asi")==payload_hashes::motion);
  check(make(clean,"version","",n).changes.size()==1);
 }
 check(fails([&]{make(clean,"asi","",3);}));check(fails([&]{make(clean,"asi","",4);}));
 // Exact Preview 2 binaries (the reported Blackwood install) upgrade in place.
 auto preview2Asi=installed;put(preview2Asi,"new.asi",motion::releaseRTX20Preview2Native);
 auto preview2AsiPlan=make(preview2Asi,"asi","version.dll");
 check(preview2AsiPlan.changes.size()==1&&preview2AsiPlan.changes[0].before==motion::releaseRTX20Preview2Native&&preview2AsiPlan.changes[0].after==payload_hashes::motion);
 auto preview2Proxy=clean;put(preview2Proxy,"version.dll",motion::releaseRTX20Preview2NativeProxy);
 auto preview2ProxyPlan=make(preview2Proxy,"version","");
 check(preview2ProxyPlan.changes.size()==1&&preview2ProxyPlan.changes[0].after==payload_hashes::native_proxy);
 // Exact Preview 1 binaries upgrade without displacing unrelated files.
 auto previewProxy=clean;put(previewProxy,"version.dll",motion::releaseRTX20Preview1NativeProxy);put(previewProxy,"settings.ini","keep");
 auto previewProxyPlan=make(previewProxy,"version","");
 check(previewProxyPlan.changes.size()==1&&previewProxyPlan.changes[0].before==motion::releaseRTX20Preview1NativeProxy&&previewProxyPlan.changes[0].after==payload_hashes::native_proxy);
 check(digest(applied(previewProxy,previewProxyPlan),"settings.ini")=="keep");
 auto previewAsi=installed;put(previewAsi,"new.asi",motion::releaseRTX20Preview1Native);
 auto previewAsiPlan=make(previewAsi,"asi","version.dll");
 check(previewAsiPlan.changes.size()==1&&previewAsiPlan.changes[0].before==motion::releaseRTX20Preview1Native&&previewAsiPlan.changes[0].after==payload_hashes::motion);
 // The reported GP9 files must upgrade through the installer without mixing backends.
 auto gp9proxy=clean;put(gp9proxy,"version.dll",motion::release282GP9NativeProxy);
 put(gp9proxy,"user-settings.ini","user-content");put(gp9proxy,"nvsmooth30.log","evidence");
 const auto newProxy=applied(gp9proxy,make(gp9proxy,"version",""));
 check(digest(newProxy,"version.dll")==payload_hashes::native_proxy&&digest(newProxy,"user-settings.ini")=="user-content");
 for(const auto* carrier:{"version.dll","winmm.dll","dinput8.dll"}){
  const auto migrated=applied(gp9proxy,make(gp9proxy,"asi",carrier));
  check(digest(migrated,carrier)==payload_hashes::loader&&digest(migrated,"new.asi")==payload_hashes::motion);
  check(std::string(carrier)=="version.dll"||digest(migrated,"version.dll")=="-");
  check(digest(migrated,"nvsmooth30.log")=="evidence");
 }
 auto gp9asi=installed;put(gp9asi,"new.asi",motion::release282GP9Native);
 const auto newAsi=applied(gp9asi,make(gp9asi,"asi","version.dll"));
 check(digest(newAsi,"new.asi")==payload_hashes::motion&&digest(newAsi,"version.dll")==payload_hashes::loader);
 const auto switchProxy=applied(gp9asi,make(gp9asi,"version",""));
 check(digest(switchProxy,"new.asi")=="-"&&digest(switchProxy,"version.dll")==payload_hashes::native_proxy);
 auto release20=installed;put(release20,"new.asi",motion::release20Renderer);
 auto plan20=make(release20,"asi","winmm.dll");auto fixed20=applied(release20,plan20);
 check(digest(fixed20,"new.asi")==payload_hashes::motion&&digest(fixed20,"version.dll")=="-");
 // Exact 2.1 identity from the reported Haydee 2 installation. Keep its
 // functioning winmm carrier, update only the owned ASI, preserve other files.
 auto release21=clean;put(release21,"new.asi",motion::release21Native);
 put(release21,"winmm.dll",payload_hashes::loader,true);put(release21,"winmm.ini",payload_hashes::ini);
 put(release21,"nvsmooth30.log","existing-evidence");put(release21,"unrelated.ini","user-config");
 auto plan21=make(release21,"asi","winmm.dll");auto fixed21=applied(release21,plan21);
 check(plan21.changes.size()==1&&plan21.changes[0].before==motion::release21Native&&plan21.changes[0].after==payload_hashes::motion);
 check(digest(fixed21,"new.asi")==payload_hashes::motion&&digest(fixed21,"winmm.dll")==payload_hashes::loader);
 check(digest(fixed21,"nvsmooth30.log")=="existing-evidence"&&digest(fixed21,"unrelated.ini")=="user-config");
 check(make(fixed21,"asi","winmm.dll").changes.empty());
 auto release22=release21;put(release22,"new.asi",motion::release22Native);
 auto plan22=make(release22,"asi","winmm.dll");auto fixed22=applied(release22,plan22);
 check(plan22.changes.size()==1&&plan22.changes[0].before==motion::release22Native&&plan22.changes[0].after==payload_hashes::motion);
 check(digest(fixed22,"winmm.dll")==payload_hashes::loader&&digest(fixed22,"nvsmooth30.log")=="existing-evidence");
 auto release23=release21;put(release23,"new.asi",motion::release23Native);
 auto plan23=make(release23,"asi","winmm.dll");auto fixed23=applied(release23,plan23);
 check(plan23.changes.size()==1&&plan23.changes[0].before==motion::release23Native&&plan23.changes[0].after==payload_hashes::motion);
 check(digest(fixed23,"winmm.dll")==payload_hashes::loader&&digest(fixed23,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed23,"asi","winmm.dll").changes.empty());
 auto release24=release21;put(release24,"new.asi",motion::release24Native);
 auto plan24=make(release24,"asi","winmm.dll");auto fixed24=applied(release24,plan24);
 check(plan24.changes.size()==1&&plan24.changes[0].before==motion::release24Native&&plan24.changes[0].after==payload_hashes::motion);
 check(digest(fixed24,"winmm.dll")==payload_hashes::loader&&digest(fixed24,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed24,"asi","winmm.dll").changes.empty());
 auto release25=release21;put(release25,"new.asi",motion::release25Native);
 auto plan25=make(release25,"asi","winmm.dll");auto fixed25=applied(release25,plan25);
 check(plan25.changes.size()==1&&plan25.changes[0].before==motion::release25Native&&plan25.changes[0].after==payload_hashes::motion);
 check(digest(fixed25,"winmm.dll")==payload_hashes::loader&&digest(fixed25,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed25,"asi","winmm.dll").changes.empty());
 auto release26=release21;put(release26,"new.asi",motion::release26Native);
 auto plan26=make(release26,"asi","winmm.dll");auto fixed26=applied(release26,plan26);
 check(plan26.changes.size()==1&&plan26.changes[0].before==motion::release26Native&&plan26.changes[0].after==payload_hashes::motion);
 check(digest(fixed26,"winmm.dll")==payload_hashes::loader&&digest(fixed26,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed26,"asi","winmm.dll").changes.empty());
 auto single26=applied(release26,make(release26,"version",""));
 check(digest(single26,"version.dll")==payload_hashes::native_proxy&&digest(single26,"new.asi")=="-"&&digest(single26,"winmm.dll")=="-"&&digest(single26,"winmm.ini")=="-");
 check(make(single26,"version","").changes.empty());
 // Released 2.7 identities must remain recognized after 2.8 rebuilds both
 // binaries. Keep ASI and native-proxy ownership separate from one another.
 auto release27=release21;put(release27,"new.asi",motion::release27Native);
 auto plan27=make(release27,"asi","winmm.dll");auto fixed27=applied(release27,plan27);
 const bool asi27Changes=std::string(motion::release27Native)!=payload_hashes::motion;
 check(plan27.changes.size()==(asi27Changes?1u:0u));
 check(!asi27Changes||(plan27.changes[0].before==motion::release27Native&&plan27.changes[0].after==payload_hashes::motion));
 check(digest(fixed27,"new.asi")==payload_hashes::motion&&digest(fixed27,"winmm.dll")==payload_hashes::loader&&digest(fixed27,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed27,"asi","winmm.dll").changes.empty());
 auto proxy27=clean;put(proxy27,"version.dll",motion::release27NativeProxy);put(proxy27,"nvsmooth30.log","existing-evidence");put(proxy27,"other-mod.dll","user-owned");
 const auto proxyPlan27=make(proxy27,"version","");const auto proxyFixed27=applied(proxy27,proxyPlan27);
 const bool proxy27Changes=std::string(motion::release27NativeProxy)!=payload_hashes::native_proxy;
 check(proxyPlan27.changes.size()==(proxy27Changes?1u:0u));
 check(!proxy27Changes||(proxyPlan27.changes[0].before==motion::release27NativeProxy&&proxyPlan27.changes[0].after==payload_hashes::native_proxy));
 check(digest(proxyFixed27,"version.dll")==payload_hashes::native_proxy&&digest(proxyFixed27,"new.asi")=="-"&&digest(proxyFixed27,"nvsmooth30.log")=="existing-evidence"&&digest(proxyFixed27,"other-mod.dll")=="user-owned");
 check(make(proxyFixed27,"version","").changes.empty());
 for(const auto* carrier:{"version.dll","winmm.dll","dinput8.dll"}){
  const auto switched27=applied(proxy27,make(proxy27,"asi",carrier));
  check(digest(switched27,carrier)==payload_hashes::loader&&digest(switched27,"new.asi")==payload_hashes::motion);
  check(std::string(carrier)=="version.dll"||digest(switched27,"version.dll")=="-");
  check(make(switched27,"asi",carrier).changes.empty());
 }
 const auto toStandalone27=applied(release27,make(release27,"version",""));
 check(digest(toStandalone27,"version.dll")==payload_hashes::native_proxy&&digest(toStandalone27,"new.asi")=="-"&&digest(toStandalone27,"winmm.dll")=="-"&&digest(toStandalone27,"winmm.ini")=="-");
 const std::string futureProxy(64,'a');
 check(motion::ownedNativeProxy(motion::release27NativeProxy,futureProxy));
 check(motion::installedNativeProxy(futureProxy.c_str(),payload_hashes::standalone,[](const char* h){return std::string(h)==motion::release27NativeProxy;}));
 check(!motion::ownedNativeProxy("-","-")&&!motion::ownedNativeProxy("","")&&!motion::ownedNativeProxy(motion::release27Native,futureProxy));
 auto modifiedProxy=proxy27;auto foreignHash=std::string(motion::release27NativeProxy);foreignHash[0]=foreignHash[0]=='0'?'1':'0';put(modifiedProxy,"version.dll",foreignHash);
 check(fails([&]{make(modifiedProxy,"version","");}));check(fails([&]{make(modifiedProxy,"asi","version.dll");}));
 const auto preserveForeign=applied(modifiedProxy,make(modifiedProxy,"asi","winmm.dll"));check(digest(preserveForeign,"version.dll")==foreignHash);
 // Diagnostic update: retain exact ownership of released 2.8 files while
 // replacing only the renderer for the already working carrier choice.
 auto release28=release21;put(release28,"new.asi",motion::release28Native);
 const auto plan28=make(release28,"asi","winmm.dll");const auto fixed28=applied(release28,plan28);
 const bool asi28Changes=std::string(motion::release28Native)!=payload_hashes::motion;
 check(plan28.changes.size()==(asi28Changes?1u:0u));
 check(!asi28Changes||(plan28.changes[0].path=="new.asi"&&plan28.changes[0].before==motion::release28Native&&plan28.changes[0].after==payload_hashes::motion));
 check(digest(fixed28,"new.asi")==payload_hashes::motion&&digest(fixed28,"winmm.dll")==payload_hashes::loader&&digest(fixed28,"winmm.ini")==payload_hashes::ini&&digest(fixed28,"nvsmooth30.log")=="existing-evidence");
 check(make(fixed28,"asi","winmm.dll").changes.empty());
 auto proxy28=clean;put(proxy28,"version.dll",motion::release28NativeProxy);put(proxy28,"nvsmooth30.log","existing-evidence");put(proxy28,"other-mod.dll","user-owned");
 const auto proxyPlan28=make(proxy28,"version","");const auto proxyFixed28=applied(proxy28,proxyPlan28);
 const bool proxy28Changes=std::string(motion::release28NativeProxy)!=payload_hashes::native_proxy;
 check(proxyPlan28.changes.size()==(proxy28Changes?1u:0u));
 check(!proxy28Changes||(proxyPlan28.changes[0].path=="version.dll"&&proxyPlan28.changes[0].before==motion::release28NativeProxy&&proxyPlan28.changes[0].after==payload_hashes::native_proxy));
 check(digest(proxyFixed28,"version.dll")==payload_hashes::native_proxy&&digest(proxyFixed28,"new.asi")=="-"&&digest(proxyFixed28,"nvsmooth30.log")=="existing-evidence"&&digest(proxyFixed28,"other-mod.dll")=="user-owned");
 check(make(proxyFixed28,"version","").changes.empty());
 check(motion::ownedPlugin(motion::release28Native,std::string(64,'a')));
 check(motion::ownedNativeProxy(motion::release28NativeProxy,std::string(64,'a')));
 check(motion::installedNativeProxy(futureProxy.c_str(),payload_hashes::standalone,[](const char* h){return std::string(h)==motion::release28NativeProxy;}));
 const auto proxyToAsi28=applied(proxy28,make(proxy28,"asi","winmm.dll"));
 check(digest(proxyToAsi28,"version.dll")=="-"&&digest(proxyToAsi28,"winmm.dll")==payload_hashes::loader&&digest(proxyToAsi28,"new.asi")==payload_hashes::motion);
 const auto asiToProxy28=applied(release28,make(release28,"version",""));
 check(digest(asiToProxy28,"version.dll")==payload_hashes::native_proxy&&digest(asiToProxy28,"new.asi")=="-"&&digest(asiToProxy28,"winmm.dll")=="-");
 // Keep diagnostic 2.8.1 owned across the targeted 2.8.2 repair. These
 // checks use a different current digest to exercise the prior-release list.
 check(motion::ownedPlugin(motion::release281Native,std::string(64,'a')));
 for(const char* priorProxy:motion::previousNativeProxies){
  check(motion::ownedNativeProxy(priorProxy,futureProxy));
  check(motion::installedNativeProxy(futureProxy.c_str(),payload_hashes::standalone,[&](const char* h){return std::string(h)==priorProxy;}));
 }
 auto release281=release21;put(release281,"new.asi",motion::release281Native);
 const auto fixed281=applied(release281,make(release281,"asi","winmm.dll"));
 check(digest(fixed281,"new.asi")==payload_hashes::motion&&digest(fixed281,"winmm.dll")==payload_hashes::loader&&digest(fixed281,"nvsmooth30.log")=="existing-evidence");
 auto proxy281=clean;put(proxy281,"version.dll",motion::release281NativeProxy);
 check(digest(applied(proxy281,make(proxy281,"version","")),"version.dll")==payload_hashes::native_proxy);
 const auto switch281=applied(proxy281,make(proxy281,"asi","winmm.dll"));check(digest(switch281,"version.dll")=="-"&&digest(switch281,"new.asi")==payload_hashes::motion);
 auto modified281=proxy281;std::string edited281=motion::release281NativeProxy;edited281[0]='d';put(modified281,"version.dll",edited281);check(fails([&]{make(modified281,"version","");}));
 put(release281,"plugins\\Other.asi","other-plugin");check(fails([&]{make(release281,"version","");}));
 // Exact attached/R1/R2/experimental release identities can be upgraded or
 // switched to either current route without leaving a second backend behind.
 for(auto prior:{std::pair{motion::releaseRTX20Preview2Fix2Native,motion::releaseRTX20Preview2Fix2NativeProxy},std::pair{motion::releaseRTX20Preview2Fix1Native,motion::releaseRTX20Preview2Fix1NativeProxy},std::pair{motion::release282GP7Native,motion::release282GP7NativeProxy},std::pair{motion::release282GP6Native,motion::release282GP6NativeProxy},std::pair{motion::release282GP1Native,motion::release282GP1NativeProxy},{motion::release282GP3Native,motion::release282GP3NativeProxy},{motion::release282GP5Native,motion::release282GP5NativeProxy},{motion::release282GP4Native,motion::release282GP4NativeProxy},
                 std::pair{motion::release282R3Native,motion::release282R3NativeProxy},
                 std::pair{motion::release282R4Native,motion::release282R4NativeProxy},
                 std::pair{motion::release282Native,motion::release282NativeProxy},
                 std::pair{motion::release283Native,motion::release283NativeProxy},
                 std::pair{motion::release282R1Native,motion::release282R1NativeProxy},
                 std::pair{motion::release282R2Native,motion::release282R2NativeProxy},
                 std::pair{motion::release30Native,motion::release30NativeProxy}}){
  auto oldAsi=release21;put(oldAsi,"new.asi",prior.first);
  auto oldProxy=clean;put(oldProxy,"version.dll",prior.second);
  for(auto original:{oldAsi,oldProxy}){
   put(original,"user.dll","unrelated");put(original,"nvsmooth30.log","evidence");
   const auto single=applied(original,make(original,"version",""));
   check(digest(single,"version.dll")==payload_hashes::native_proxy&&digest(single,"new.asi")=="-"&&digest(single,"winmm.dll")=="-");
   check(digest(single,"user.dll")=="unrelated"&&digest(single,"nvsmooth30.log")=="evidence");
   check(make(single,"version","").changes.empty());
   for(const auto* carrier:{"version.dll","dinput8.dll","winmm.dll"}){
    const auto alternate=applied(original,make(original,"asi",carrier));
    check(digest(alternate,carrier)==payload_hashes::loader&&digest(alternate,"new.asi")==payload_hashes::motion);
    check(std::string(carrier)=="version.dll"||digest(alternate,"version.dll")=="-");
    check(make(alternate,"asi",carrier).changes.empty());
   }
  }
  auto mixed=oldProxy;put(mixed,"plugins\\old.asi",prior.first);
  check(digest(applied(mixed,make(mixed,"version","")),"plugins\\old.asi")=="-");
  auto modified=oldProxy;std::string changed=prior.second;changed[0]=changed[0]=='0'?'1':'0';put(modified,"version.dll",changed);
  check(fails([&]{make(modified,"version","");}));
  check(digest(applied(modified,make(modified,"asi","winmm.dll")),"version.dll")==changed);
  put(oldAsi,"plugins\\Other.asi","unrelated");check(fails([&]{make(oldAsi,"version","");}));
  check(digest(applied(oldAsi,make(oldAsi,"asi","winmm.dll")),"plugins\\Other.asi")=="unrelated");
 }
 for(const char* known:motion::previousPlugins){
  check(motion::ownedPlugin(known,payload_hashes::motion));
  check(motion::installedPlugin(payload_hashes::motion,payload_hashes::asi,[&](const char* hash){return std::string(hash)==known;}));
 }
 check(!motion::installedPlugin(payload_hashes::motion,payload_hashes::asi,[](const char* hash){return std::string(hash)=="unknown-user-file";}));
 check(!motion::ownedPlugin("",""));
 auto release18=installed;put(release18,"new.asi",motion::release18Renderer);
 auto fix18=make(release18,"asi","version.dll",2);check(fix18.changes.size()==1&&fix18.changes[0].before==motion::release18Renderer&&fix18.changes[0].after==payload_hashes::motion);
 auto fixed18=applied(release18,fix18);check(make(fixed18,"asi","version.dll",2).changes.empty());
 check(digest(applied(release18,make(release18,"version","")),"new.asi")=="-");
 auto previous=installed;put(previous,"new.asi",motion::previousRenderer);
 auto upgradeMotion=make(previous,"asi","version.dll",2);check(upgradeMotion.changes.size()==1&&upgradeMotion.changes[0].path=="new.asi"&&upgradeMotion.changes[0].before==motion::previousRenderer&&upgradeMotion.changes[0].after==payload_hashes::motion);
 auto upgradedMotion=applied(previous,upgradeMotion);check(make(upgradedMotion,"asi","version.dll",2).changes.empty());
 check(digest(applied(previous,make(previous,"version","")),"new.asi")=="-");
 check(digest(applied(previous,make(previous,"asi","winhttp.dll",2)),"new.asi")==payload_hashes::motion);
 auto alone=applied(installed,make(installed,"version",""));check(digest(alone,"version.dll")==payload_hashes::native_proxy&&digest(alone,"new.asi")=="-"&&digest(alone,"version.ini")=="-");
 check(make(alone,"version","").changes.empty());
 auto again=applied(alone,make(alone,"asi","winhttp.dll"));check(digest(again,"version.dll")=="-"&&digest(again,"winhttp.dll")==payload_hashes::loader&&digest(again,"new.asi")==payload_hashes::motion);
 auto switched=applied(again,make(again,"asi","dinput8.dll"));check(digest(switched,"winhttp.dll")=="-"&&digest(switched,"winhttp.ini")=="-"&&digest(switched,"dinput8.dll")==payload_hashes::loader);
 auto collision=clean;put(collision,"version.dll","game-owned");check(make(collision,"asi","").proxy=="dinput8.dll");check(fails([&]{make(collision,"version","");}));check(fails([&]{make(collision,"asi","version.dll");}));
 put(collision,"dinput8.ini","custom-config");check(make(collision,"asi","").proxy=="winmm.dll");
 auto foreign=clean;put(foreign,"dxgi.dll",payload_hashes::loader,true);check(fails([&]{make(foreign,"asi","");}));check(fails([&]{make(foreign,"version","");}));
 auto edited=installed;put(edited,"new.asi","modified-by-user");check(fails([&]{make(edited,"asi","");}));
 auto editedIni=installed;put(editedIni,"version.ini","user-options");check(fails([&]{make(editedIni,"asi","winmm.dll");}));
 auto early=clean;early.direct={"VERSION.dll","dinput8.dll"};check(make(early,"asi","").proxy=="version.dll"&&!make(early,"asi","").fallback);
 auto late=clean;late.delay={"WINMM.dll"};check(make(late,"asi","").proxy=="winmm.dll"&&!make(late,"asi","").fallback);
 for(const auto* carrier:install_modes::carriers){auto inv=clean;if(install_modes::needsOriginal(carrier))inv.originals[carrier]=true;auto plan=make(inv,"asi",carrier);check(plan.proxy==carrier&&plan.changes.size()==3);}
 check(fails([&]{make(clean,"asi","binkw64.dll");}));check(fails([&]{make(clean,"asi","bink2w64.dll");}));
 for(const auto* carrier:install_modes::win32Only)check(fails([&]{make(clean,"asi",carrier);}));
 check(fails([&]{make(clean,"unknown","");}));check(fails([&]{make(clean,"asi","..\\evil.dll");}));
 auto legacy=clean;put(legacy,"winmm.dll",payload_hashes::loader,true);put(legacy,"winmm.ini",legacy_hashes::ini);put(legacy,"plugins\\SM86Bootstrap.asi",legacy_hashes::bootstrap);put(legacy,"SM86\\backend.asi",legacy_hashes::backend);put(legacy,"SM86\\SM86_Menu.exe",legacy_hashes::menu);put(legacy,"SM86\\SM86_Guard.exe",legacy_hashes::guard);put(legacy,"SM86\\backend_config.json","user-config");
 auto upgrade=make(legacy,"asi","dinput8.dll");auto upgraded=applied(legacy,upgrade);check(digest(upgraded,"winmm.dll")=="-"&&digest(upgraded,"plugins\\SM86Bootstrap.asi")=="-"&&digest(upgraded,"SM86\\backend.asi")=="-");check(digest(upgraded,"SM86\\SM86_Menu.exe")=="-"&&digest(upgraded,"SM86\\SM86_Guard.exe")=="-"&&digest(upgraded,"SM86\\backend_config.json")=="user-config");
 auto customized=legacy;put(customized,"SM86\\SM86_Menu.exe","custom-helper");check(digest(applied(customized,make(customized,"version","")),"SM86\\SM86_Menu.exe")=="custom-helper");
 auto unrelated=clean;put(unrelated,"scripts\\Other.asi","other-plugin");put(unrelated,"root-other.asi","root-plugin");auto coexist=make(unrelated,"asi","");check(coexist.otherPlugins.size()==1&&coexist.changes.size()==3);check(digest(applied(unrelated,coexist),"scripts\\Other.asi")=="other-plugin");
 auto casing=installed;casing.scanned[0].path="VERSION.DLL";check(make(casing,"asi","").changes.empty());

 auto release181=installed;put(release181,"new.asi",motion::release181Renderer);
 auto fix181=make(release181,"version","",2);check(digest(applied(release181,fix181),"new.asi")=="-");
 auto nativeStandalone=clean;put(nativeStandalone,"version.dll",payload_hashes::standalone);
 auto nativeUpgrade=applied(nativeStandalone,make(nativeStandalone,"version","",2));
 check(digest(nativeUpgrade,"version.dll")==payload_hashes::native_proxy&&digest(nativeUpgrade,"new.asi")=="-");
 auto nativeAsi=installed;put(nativeAsi,"new.asi",payload_hashes::asi);
 check(digest(applied(nativeAsi,make(nativeAsi,"asi","",2)),"new.asi")==payload_hashes::motion);
 auto badIni=clean;put(badIni,"version.ini","game-owned-ini");check(fails([&]{make(badIni,"version","");}));
 auto engine=clean;engine.dependencyDirect={"WINMM.dll"};auto enginePlan=make(engine,"asi","");
 check(enginePlan.proxy=="winmm.dll"&&!enginePlan.fallback&&enginePlan.choices[2].candidate.dependencyDirect);
 engine.delay={"version.dll"};check(make(engine,"asi","").proxy=="winmm.dll");
 engine.direct={"dinput8.dll"};check(make(engine,"asi","").proxy=="dinput8.dll");
 auto engineLate=clean;engineLate.dependencyDelay={"dinput8.dll"};check(make(engineLate,"asi","").proxy=="dinput8.dll");
 auto staleFallback=installed;staleFallback.dependencyDirect={"winmm.dll"};
 check(make(staleFallback,"asi","").proxy=="winmm.dll");
 check(fails([&]{make(clean,"asi","",0);}));
 std::cout<<checks<<" installation policy scenarios passed\n";
}
