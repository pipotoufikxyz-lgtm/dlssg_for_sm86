#pragma once
#include <windows.h>
#include <limits>
#include "pe_reader.hpp"
#include "game_config_policy.hpp"
namespace preflight {
// Read-only, demand-paged mapping: file length does not determine heap use.
// The PE parser bounds every access and caps section/import/name traversal.
// In particular, a large overlay on a valid EXE is not a reason to reject it.
class MappedPE {
 HANDLE file=INVALID_HANDLE_VALUE, mapping=nullptr;
 const unsigned char* view=nullptr;
 size_t length=0;
 void close(){if(view)UnmapViewOfFile(view);if(mapping)CloseHandle(mapping);if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);}
 public:
 explicit MappedPE(const std::wstring& path){
  try{
   file=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
   if(file==INVALID_HANDLE_VALUE)throw FileAccessError("Cannot open executable for inspection",GetLastError());
   BY_HANDLE_FILE_INFORMATION info{};
   if(!GetFileInformationByHandle(file,&info)||(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)))throw std::runtime_error("Executable is a directory or linked file");
   LARGE_INTEGER size{};
   if(!GetFileSizeEx(file,&size)||size.QuadPart<64)throw std::runtime_error("Executable is unreadable or truncated");
   if(static_cast<unsigned long long>(size.QuadPart)>std::numeric_limits<size_t>::max())throw std::runtime_error("Executable exceeds the address space of this build; use the x64 Manager");
   length=static_cast<size_t>(size.QuadPart);
   mapping=CreateFileMappingW(file,nullptr,PAGE_READONLY,0,0,nullptr);
   if(!mapping)throw FileAccessError("Cannot map executable for read-only inspection",GetLastError());
   view=static_cast<const unsigned char*>(MapViewOfFile(mapping,FILE_MAP_READ,0,0,0));
   if(!view)throw std::runtime_error("Not enough virtual address space to inspect executable");
  }catch(...){close();throw;}
 }
 ~MappedPE(){close();}
 MappedPE(const MappedPE&)=delete;
 MappedPE& operator=(const MappedPE&)=delete;
 Imports parse(bool requireExe=false)const{
  auto result=PE(view,length).parse();
  if(requireExe&&result.dll)throw std::runtime_error("This file is a DLL, not a game executable");
  return result;
 }
};
inline Imports inspectFile(const std::wstring& path,bool requireExe=false){return MappedPE(path).parse(requireExe);}
}
