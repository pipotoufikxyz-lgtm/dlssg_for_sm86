// Reversible local installer. Never loads a game/mod DLL or changes a driver profile.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cwchar>
#include <string>
#include <vector>
#include <stdexcept>
#include <exception>
#include "windows_pe.hpp"
#include "windows_game_target.hpp"
#include "../ui/file_picker.hpp"
#include "import_graph.hpp"
#include "policy.hpp"
#include "loader_plan.hpp"
#include "protocol.hpp"
#include "payload_hashes.hpp"
#include "legacy_hashes.hpp"
#include "install_modes.hpp"
#include "file_plan.hpp"
#include "uninstall_policy.hpp"
#include "local_journal_policy.hpp"
#include "../ui/localization.hpp"
#include "../normal_policy.hpp"
#include "../guard/session.hpp"

namespace {
using Bytes = std::vector<unsigned char>;
bool machineMode=false,planOnly=false;
std::wstring requestedProxy,requestedMode=L"asi";
std::string reviewedToken;
std::string requestedFG="native";
manager_localization::Language preferredLanguage=manager_localization::Language::Automatic;
std::wstring tr(std::wstring_view text){return manager_localization::tr(text,manager_localization::resolve(preferredLanguage,GetUserDefaultUILanguage()));}
std::string utf8(const std::wstring& s){int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,s.data(),int(s.size()),nullptr,0,nullptr,nullptr);if(n<=0&&!s.empty())throw std::runtime_error("Invalid Unicode path");std::string text(n,0);WideCharToMultiByte(CP_UTF8,0,s.data(),int(s.size()),text.data(),n,nullptr,nullptr);return text;}
void emit(const std::string& data){DWORD wrote=0;HANDLE output=GetStdHandle(STD_OUTPUT_HANDLE);if(data.size()>120000)throw std::runtime_error("The installation plan is too large to display; inspect a smaller game folder");if(!WriteFile(output,data.data(),DWORD(data.size()),&wrote,nullptr)||wrote!=data.size())throw std::runtime_error("Cannot return installer result to the Manager");}

struct Failure { std::wstring text; DWORD code; };
[[noreturn]] void fail(const std::wstring& s, DWORD e=0) { throw Failure{s,e}; }
std::wstring parent(const std::wstring& p) { auto n=p.find_last_of(L"\\/"); return n==p.npos?L"":p.substr(0,n+1); }
std::wstring wide(const std::string& s) { int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),int(s.size()),nullptr,0);if(n<=0&&!s.empty())fail(L"Invalid UTF-8 path");std::wstring out(n,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),int(s.size()),out.data(),n);return out; }
std::wstring lower(std::wstring s) { for(auto& c:s) if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A'; return s; }
bool equal(const std::wstring& a,const std::wstring& b) { return _wcsicmp(a.c_str(),b.c_str())==0; }
DWORD attributes(const std::wstring& p) { DWORD a=GetFileAttributesW(p.c_str()); if(a==INVALID_FILE_ATTRIBUTES) { DWORD e=GetLastError(); if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND)fail(L"Cannot inspect "+p,e); } return a; }
bool exists(const std::wstring& p) { return attributes(p)!=INVALID_FILE_ATTRIBUTES; }
void ordinary(const std::wstring& p,bool directory=false) { DWORD a=attributes(p); if(a==INVALID_FILE_ATTRIBUTES)return; if((a&FILE_ATTRIBUTE_REPARSE_POINT)||bool(a&FILE_ATTRIBUTE_DIRECTORY)!=directory)fail(L"A file/directory collision or link prevents a safe installation:\n"+p); }
std::wstring absolute(const std::wstring& p) { wchar_t out[32768]; DWORD n=GetFullPathNameW(p.c_str(),32768,out,nullptr); if(!n||n>=32768)fail(L"Path is too long or invalid: "+p,GetLastError()); return {out,n}; }
void show(const std::wstring& s,UINT icon=MB_ICONINFORMATION) { MessageBoxW(nullptr,tr(s).c_str(),tr(L"Smooth Motion compatibility setup").c_str(),MB_OK|icon); }
bool confirm(const std::wstring& s) { return MessageBoxW(nullptr,tr(s).c_str(),tr(L"Review local file changes").c_str(),MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)==IDYES; }

Bytes read(const std::wstring& p, std::uint64_t limit=512ull*1024*1024) {
    ordinary(p); HANDLE h=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE)fail(L"Cannot read "+p,GetLastError());
    LARGE_INTEGER size{}; if(!GetFileSizeEx(h,&size)||size.QuadPart<0||std::uint64_t(size.QuadPart)>limit){CloseHandle(h);fail(L"File is unreadable or exceeds the inspection limit:\n"+p);}
    Bytes b(static_cast<size_t>(size.QuadPart)); size_t at=0; DWORD error=0;
    while(at<b.size()){DWORD got=0,want=static_cast<DWORD>(std::min<size_t>(b.size()-at,1024*1024));if(!ReadFile(h,b.data()+at,want,&got,nullptr)||got!=want){error=GetLastError();if(!error)error=ERROR_READ_FAULT;break;}at+=got;}
    CloseHandle(h);if(error)fail(L"Reading failed: "+p,error);return b;
}
std::string hash(const Bytes& bytes) {
    BCRYPT_ALG_HANDLE a=nullptr; unsigned char digest[32]{};
    if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)fail(L"Windows SHA-256 provider is unavailable.");
    NTSTATUS result=BCryptHash(a,nullptr,0,const_cast<PUCHAR>(bytes.data()),static_cast<ULONG>(bytes.size()),digest,32); BCryptCloseAlgorithmProvider(a,0);
    if(result<0)fail(L"SHA-256 hashing failed."); char text[65]; for(unsigned i=0;i<32;++i)std::snprintf(text+i*2,3,"%02x",digest[i]);return text;
}
std::string fileHash(const std::wstring& p) { return exists(p)?hash(read(p)):"-"; }
bool known(const std::string& value) {
    static const char* hashes[]={
        "16b7b560d100f9f26d3d0454617a128337374320c468f4a5ec46b99dcc6c594e",
        "2fa6de23b1b87392b94d666ddce3eeab4034ff1781d9cee49c2b40c64aa2989f",
        "60b49314a1e16105945840ea0a903f9bf416de48843e2fc1a5f2afd0c82b2255",
        "ca7e06a62e5517e8440bd6361106dbc9a70b84ead88d2ea3afb7f552757e7305",
        "299104f5f3f55d90146fdaf85cdac355290be10f27048b9cd34b4618423a5288",
        "37891ea2d815f42c922df1d9de66f3b9302c40d2c2c25fcba6f9e04ddc78c161",
        "10e1e46d6f2dea67ab976e82f7dd4b19ea9eed1d707b9def8a5c65de76aaa3fc",
        "1919801fbd49221b675095754413707fed088b66094fda9f5fd59bb65a60aeb9",
        "12f0fe046524989bf39be6d54fcc6f15e27ad8d673d462c0e2a0989b3cf08030",
        "1dbfcf67b0bd97ef9deef46efc3db0d00ad492a902da9931cfb8d8d8ccc33391",
        "b28de6d6f2f624fa826b58fb5213f00d9c707a5cba8fd8d8fcc3518217a376cc"
    };
    for(auto h:hashes)if(value==h)return true;return false;
}
void writeNew(const std::wstring& p,const Bytes& b) {
    HANDLE h=CreateFileW(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)fail(L"Cannot create "+p,GetLastError());
    size_t at=0;DWORD error=0;while(at<b.size()){DWORD n=0,want=static_cast<DWORD>(std::min<size_t>(b.size()-at,1024*1024));if(!WriteFile(h,b.data()+at,want,&n,nullptr)||n!=want){error=GetLastError();if(!error)error=ERROR_WRITE_FAULT;break;}at+=n;}
    if(!error&&!FlushFileBuffers(h))error=GetLastError();CloseHandle(h);if(error){DeleteFileW(p.c_str());fail(L"Writing failed: "+p,error);}
}
Bytes utf16(const std::wstring& s) { Bytes b{0xff,0xfe};const auto p=reinterpret_cast<const unsigned char*>(s.data());b.insert(b.end(),p,p+s.size()*sizeof(wchar_t));return b; }
void makeDirectory(const std::wstring& p) { if(exists(p)){ordinary(p,true);return;}if(!CreateDirectoryW(p.c_str(),nullptr))fail(L"Cannot create folder "+p,GetLastError()); }
// Relative components are validated before this function is called.
void ensureParents(const std::wstring& root,const std::wstring& relative) {
    for(size_t i=0;i<relative.size();++i)if(relative[i]==L'\\'||relative[i]==L'/')makeDirectory(root+relative.substr(0,i));
}
void checkParents(const std::wstring& root,const std::wstring& relative) {
    if(!setup_policy::safe_relative(relative))fail(L"Unsafe relative destination: "+relative);
    for(size_t i=0;i<relative.size();++i)if(relative[i]==L'\\'||relative[i]==L'/')ordinary(root+relative.substr(0,i),true);
    ordinary(root+relative);
}
void checkDirectory(const std::wstring& root,const std::wstring& relative) {
    if(!setup_policy::safe_relative(relative))fail(L"Unsafe relative directory: "+relative);
    for(size_t i=0;i<relative.size();++i)if(relative[i]==L'\\'||relative[i]==L'/')ordinary(root+relative.substr(0,i),true);
    ordinary(root+relative,true);
}
bool running(const std::wstring& executable) {
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)fail(L"Cannot inspect running processes. Close the game and retry.",GetLastError());
    PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);bool found=false;
    if(Process32FirstW(snap,&entry))do{HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,entry.th32ProcessID);if(!process){if(equal(entry.szExeFile,executable.substr(executable.find_last_of(L"\\/")+1)))found=true;continue;}wchar_t p[32768];DWORD n=32768;if(QueryFullProcessImageNameW(process,0,p,&n)){if(equal(executable,std::wstring(p,n)))found=true;}else if(equal(entry.szExeFile,executable.substr(executable.find_last_of(L"\\/")+1)))found=true;CloseHandle(process);if(found)break;}while(Process32NextW(snap,&entry));
    DWORD enumerationError=GetLastError();CloseHandle(snap);if(!found&&enumerationError!=ERROR_NO_MORE_FILES)fail(L"Process enumeration was incomplete.",enumerationError);return found;
}
void requireClosed(const std::wstring& root,const std::wstring& exe) {
    if(running(exe))fail(L"Close the selected game before installing or restoring:\n"+exe);
    if(running(root+L"SM86\\SM86_Guard.exe"))fail(L"Wait for the previous game session guard to exit before changing files.");
    if(running(root+L"SM86\\SM86_Menu.exe"))fail(L"Exit the Smooth Motion menu before installing or restoring:\n"+root+L"SM86\\SM86_Menu.exe\n\nSetup does not close running programs.");
}
struct Change { std::wstring relative,source,stage; std::string before,after; bool applied=false; bool inlineData=false; Bytes data{}; };
void appendChange(std::vector<Change>& changes,const std::wstring& root,const std::wstring& rel,const std::wstring& source,const std::string& expectedBefore,const std::string& expectedAfter) {
    checkParents(root,rel);for(auto& c:changes)if(equal(c.relative,rel))return;
    std::string before=fileHash(root+rel),after=source.empty()?"-":fileHash(source);if(!source.empty()&&after=="-")fail(L"Missing payload file: "+source);
    if(before!=expectedBefore||after!=expectedAfter)fail(L"A file changed after its ownership/hash was checked. Nothing further will be changed:\n"+root+rel);
    if(before==after)return;changes.push_back({rel,source,L"",before,after,false});
}
void appendConfiguration(std::vector<Change>& changes,const std::wstring& root,const std::string& text,const std::string& expectedBefore){
    const std::wstring rel=normal_motion::oldConfigPath;checkParents(root,rel);
    Bytes bytes(text.begin(),text.end());auto before=fileHash(root+rel),after=hash(bytes);
    if(before!=expectedBefore)fail(L"Frame-generation settings changed while reviewing. Refresh the plan.");
    if(before!=after)changes.push_back({rel,L"",L"",before,after,false,true,std::move(bytes)});
}
std::vector<std::wstring> missingParents(const std::wstring& root,const std::vector<Change>& changes) {
    std::vector<std::wstring> result;
    for(auto& c:changes)if(c.after!="-")for(size_t i=0;i<c.relative.size();++i)if(c.relative[i]==L'\\'||c.relative[i]==L'/'){
        auto p=c.relative.substr(0,i);if(!exists(root+p)&&std::find(result.begin(),result.end(),p)==result.end())result.push_back(p);
    }
    return result;
}
void publishLocalCommit(const std::wstring& backup,const Bytes& marker){
    const auto committed=backup+L"committed.tsv";
    if(exists(committed)){if(fileHash(committed)!=hash(marker))fail(L"The local commit record was modified. Recovery files were preserved.");return;}
    const auto staged=backup+L"commit-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".tmp";
    writeNew(staged,marker);
    if(!MoveFileExW(staged.c_str(),committed.c_str(),MOVEFILE_WRITE_THROUGH)){const auto error=GetLastError();DeleteFileW(staged.c_str());fail(L"Cannot publish the local transaction commit. Recovery originals were preserved.",error);}
}
std::wstring transaction(const std::wstring& root,const std::wstring& exe,const std::wstring& self,std::vector<Change>& changes,bool local=false) {
    if(changes.empty())return L"";
    requireClosed(root,exe);
    SYSTEMTIME t{};GetLocalTime(&t);wchar_t name[128];std::swprintf(name,128,L"SM86-backup-%04u%02u%02u-%02u%02u%02u-%lu-%llu",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,GetCurrentProcessId(),GetTickCount64());
    std::wstring backup=local?root+L".smooth-motion\\preparing-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L"\\":root+name+L"\\";if(local)makeDirectory(root+L".smooth-motion");if(!CreateDirectoryW(backup.c_str(),nullptr))fail(L"Cannot create backup folder "+backup,GetLastError());
    makeDirectory(backup+L"files"); auto created=missingParents(root,changes);
    // Save and flush every original before touching any final destination.
    for(auto& c:changes){if(fileHash(root+c.relative)!=c.before)fail(L"A file changed while setup was open. Nothing was installed:\n"+root+c.relative);if(c.before!="-"){ensureParents(backup+L"files\\",c.relative);auto bytes=read(root+c.relative);if(hash(bytes)!=c.before)fail(L"A file changed during backup: "+root+c.relative);writeNew(backup+L"files\\"+c.relative,bytes);}}
    std::wstring manifest=L"SM86-RESTORE-1\r\n"+root+L"\r\n"+exe+L"\r\n";
    for(auto& c:changes)manifest+=L"F\t"+c.relative+L"\t"+wide(c.before)+L"\t"+wide(c.after)+L"\r\n";
    for(auto& d:created)manifest+=L"D\t"+d+L"\r\n";
    if(local)for(size_t i=0;i<changes.size();++i)if(changes[i].after!="-")manifest+=L"S\t"+changes[i].relative+L".sm86-stage-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(i)+L"\t"+wide(changes[i].after)+L"\r\n";
    writeNew(backup+L"restore.tsv",utf16(manifest));
    std::wstring instructions=L"Close the game and exit the Smooth Motion menu before restoring. Double-click Restore.exe in this folder.\r\n\r\nSetup verifies backup hashes and refuses to overwrite later modifications.\r\nManual fallback: files\\ contains originals with their original relative paths; restore.tsv lists both old/new SHA-256 hashes. Entries with old hash '-' were newly installed. Entries with new hash '-' were removed known builds.\r\n\r\nGame: "+exe+L"\r\nTarget: "+root+L"\r\n";
    for(auto& c:changes)instructions+=(c.after=="-"?L"REMOVE ":L"WRITE ")+c.relative+L"\r\n";
    writeNew(backup+L"RESTORE.txt",utf16(instructions));writeNew(backup+L"Restore.exe",read(self));
    if(local)writeNew(backup+L"owner.tsv",utf16(L"SM86-JOURNAL-1\r\n"+wide(fileHash(self))+L"\r\n"+wide(hash(utf16(instructions)))+L"\r\n"+wide(hash(utf16(manifest)))+L"\r\n"));
    if(local){
        const auto pending=root+L".smooth-motion\\pending\\";
        // Publish a complete journal before the first destination write. A
        // failed preparation cannot block or masquerade as a recoverable commit.
        if(!MoveFileExW(backup.substr(0,backup.size()-1).c_str(),pending.substr(0,pending.size()-1).c_str(),MOVEFILE_WRITE_THROUGH))fail(L"Another local transaction or recovery is pending. No game files were changed.",GetLastError());
        backup=pending;
    }
    try {
        // Stage complete flushed files, on the destination volume, before commit.
        for(size_t i=0;i<changes.size();++i){auto& c=changes[i];if(c.after=="-")continue;ensureParents(root,c.relative);auto stage=root+c.relative+L".sm86-stage-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(i);auto bytes=c.inlineData?c.data:read(c.source);if(hash(bytes)!=c.after)fail(L"Payload changed during setup: "+c.source);writeNew(stage,bytes);c.stage=std::move(stage);}
        requireClosed(root,exe);
        for(auto& c:changes){if(fileHash(root+c.relative)!=c.before)fail(L"A destination changed during setup: "+root+c.relative);if(c.after=="-"){if(!DeleteFileW((root+c.relative).c_str()))fail(L"Cannot remove the backed-up known build: "+root+c.relative+L"\nClose the game and exit the Smooth Motion menu before retrying.",GetLastError());}else{DWORD flags=MOVEFILE_WRITE_THROUGH|(c.before=="-"?0:MOVEFILE_REPLACE_EXISTING);if(!MoveFileExW(c.stage.c_str(),(root+c.relative).c_str(),flags))fail(L"Cannot install "+root+c.relative+L"\nClose the game and exit the Smooth Motion menu before retrying.",GetLastError());c.stage.clear();}c.applied=true;}
    } catch(...) {
        auto pending=std::current_exception();
        bool restored=true;
        for(size_t i=changes.size();i-->0;){auto& c=changes[i];if(!c.stage.empty())try{if(fileHash(c.stage)==c.after)DeleteFileW(c.stage.c_str());else restored=false;}catch(...){restored=false;}if(!c.applied)continue;
            try {if(fileHash(root+c.relative)!=c.after){restored=false;continue;}if(c.before=="-"){if(!DeleteFileW((root+c.relative).c_str()))restored=false;}else{auto temp=root+c.relative+L".sm86-rollback-"+std::to_wstring(GetCurrentProcessId());auto original=read(backup+L"files\\"+c.relative);if(hash(original)!=c.before){restored=false;continue;}writeNew(temp,original);if(!MoveFileExW(temp.c_str(),(root+c.relative).c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(temp.c_str());restored=false;}}}catch(...){restored=false;}
        }
        for(auto it=created.rbegin();it!=created.rend();++it)try{checkDirectory(root,*it);RemoveDirectoryW((root+*it).c_str());}catch(...){}
        std::wstring reason=L"Unexpected error during installation.";DWORD code=0;try{std::rethrow_exception(pending);}catch(const Failure& original){reason=original.text;code=original.code;}catch(...){}
        fail(reason+L"\n\n"+(restored?L"All committed file changes were rolled back.":L"Some files could not be restored automatically. Use the complete backup mapping.")+L"\nBackup: "+backup,code);
    }
    if(local){
        // A durable commit record precedes cleanup. A crash during cleanup must
        // never attempt rollback after some original bytes have been removed.
        const auto marker=utf16(L"SM86-COMMITTED-1\r\n"+wide(hash(utf16(manifest)))+L"\r\n");
        publishLocalCommit(backup,marker);
    }
    return backup;
}
std::vector<std::wstring> lines(const std::wstring& s) { std::vector<std::wstring> out;size_t p=0;while(p<s.size()){auto end=s.find(L'\n',p);if(end==s.npos)end=s.size();auto line=s.substr(p,end-p);if(!line.empty()&&line.back()==L'\r')line.pop_back();out.push_back(line);p=end+1;}return out; }
bool hashText(const std::wstring& text) { return text==L"-"||(text.size()==64&&std::all_of(text.begin(),text.end(),[](wchar_t c){return(c>=L'0'&&c<=L'9')||(c>=L'a'&&c<=L'f');})); }
int restore(const std::wstring& manifestPath,const std::wstring& self) {
    auto raw=read(manifestPath,1024*1024);if(raw.size()<2||raw.size()%2||raw[0]!=0xff||raw[1]!=0xfe)fail(L"Invalid restore manifest encoding.");
    std::wstring content((raw.size()-2)/2,L'\0');std::memcpy(content.data(),raw.data()+2,raw.size()-2);auto rows=lines(content);if(rows.size()<3||rows[0]!=L"SM86-RESTORE-1")fail(L"Not an SM86 restore manifest.");
    std::wstring root=absolute(rows[1]);if(root.empty()||(root.back()!=L'\\'&&root.back()!=L'/'))root+=L"\\";ordinary(root,true);std::wstring exe=absolute(rows[2]);if(!equal(parent(exe),root))fail(L"Restore manifest game path does not match its target folder.");
    requireClosed(root,exe);
    std::vector<Change> changes;std::vector<std::wstring> directories,recordedFiles;
    for(size_t i=3;i<rows.size();++i){auto row=rows[i];if(row.empty())continue;if(row.rfind(L"D\t",0)==0){auto d=row.substr(2);checkDirectory(root,d);directories.push_back(d);continue;}
        if(row.rfind(L"F\t",0)!=0)fail(L"Unknown restore manifest entry.");auto a=row.find(L'\t',2),b=a==row.npos?row.npos:row.find(L'\t',a+1);if(a==row.npos||b==row.npos||row.find(L'\t',b+1)!=row.npos)fail(L"Malformed restore entry.");auto rel=row.substr(2,a-2),before=row.substr(a+1,b-a-1),after=row.substr(b+1);checkParents(root,rel);if(!hashText(before)||!hashText(after))fail(L"Invalid restore hash.");
        for(auto& recorded:recordedFiles)if(equal(recorded,rel))fail(L"Duplicate destination in restore manifest.");recordedFiles.push_back(rel);
        auto current=wide(fileHash(root+rel));if(current==before)continue;if(current!=after)fail(L"Restore stopped to preserve a file changed since installation:\n"+root+rel+L"\nBack up your changes and restore it manually if needed.");
        std::wstring source;if(before!=L"-"){source=parent(manifestPath)+L"files\\"+rel;if(wide(fileHash(source))!=before)fail(L"Backup is missing or changed: "+source);}appendChange(changes,root,rel,source,std::string(after.begin(),after.end()),std::string(before.begin(),before.end()));
    }
    for(auto& d:directories){bool used=false;auto prefix=lower(d)+L"\\";for(auto rel:recordedFiles){std::replace(rel.begin(),rel.end(),L'/',L'\\');if(lower(rel).rfind(prefix,0)==0)used=true;}if(!used)fail(L"Restore manifest lists an unrelated directory.");}
    std::wstring fingerprint=manifestPath+L"\n"+wide(fileHash(manifestPath))+L"\n"+root+L"\n"+exe+L"\n";
    for(const auto& c:changes)fingerprint+=c.relative+L"\t"+wide(c.before)+L"\t"+wide(c.after)+L"\n";
    auto token=hash(utf16(fingerprint));
    if(machineMode&&planOnly){
        std::string out="{\"schema\":1,\"status\":\"ready\",\"target\":"+setup_protocol::quote(utf8(exe))+",\"proxy\":\"\",\"token\":"+setup_protocol::quote(token)+",\"fallback\":false,\"api_confirmed\":true,\"config_preserved\":false,\"choices\":[],\"changes\":[";
        bool first=true;for(const auto& c:changes){if(!first)out+=',';first=false;out+="{\"path\":"+setup_protocol::quote(utf8(c.relative))+",\"action\":"+setup_protocol::quote(c.after=="-"?"Remove installed file":"Restore original")+"}";}
        emit(out+"]}\n");return 0;
    }
    if(machineMode&&(!setup_protocol::validToken(reviewedToken)||reviewedToken!=token))fail(L"Files changed after the restore was reviewed. No files were restored. Refresh the review and try again.");
    if(changes.empty()){if(machineMode)emit(setup_protocol::result("restored","The recorded files are already restored."));else show(L"The recorded files are already restored. No file was changed.");return 0;}
    std::wstring review=L"Close the game and exit the Smooth Motion menu. Restore these files in:\n"+root+L"\n\n";for(auto& c:changes)review+=(c.after=="-"?L"Remove installed: ":L"Restore original: ")+c.relative+L"\n";review+=L"\nCurrent files will also be backed up so this restore is reversible. Continue?";
    if(!machineMode&&!confirm(review))return ERROR_CANCELLED;
    auto backup=transaction(root,exe,self,changes);
    for(auto it=directories.rbegin();it!=directories.rend();++it)try{checkDirectory(root,*it);RemoveDirectoryW((root+*it).c_str());}catch(...){}
    if(machineMode)emit(setup_protocol::result("restored","Recorded game files restored.",utf8(backup)));
    else show(L"Recorded files restored. Logs and nonempty folders are preserved.\n\nBackup of the previous state:\n"+backup);
    return 0;
}
struct Found {std::wstring relative;std::string digest;bool asi=false,loader=false;};
std::vector<Found> scan(const std::wstring& root) {
    std::vector<Found> result;size_t seen=0;
    for(const wchar_t* sub:{L"",L"plugins\\",L"scripts\\",L"update\\",L"SM86\\"}){
        if(*sub){if(!exists(root+sub))continue;ordinary(root+sub,true);}WIN32_FIND_DATAW d{};HANDLE h=FindFirstFileW((root+sub+L"*").c_str(),&d);if(h==INVALID_HANDLE_VALUE){DWORD e=GetLastError();if(e!=ERROR_FILE_NOT_FOUND)fail(L"Cannot scan "+root+sub,e);continue;}
        do{if(d.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)continue;std::wstring name=d.cFileName;auto dot=name.find_last_of(L'.');if(dot==name.npos)continue;auto ext=lower(name.substr(dot));if(ext!=L".dll"&&ext!=L".asi")continue;if(++seen>4096){FindClose(h);fail(L"Too many DLL/ASI files to inspect safely.");}
            if(d.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT){FindClose(h);fail(L"A linked DLL/ASI requires manual review:\n"+root+sub+name);}std::uint64_t size=(std::uint64_t(d.nFileSizeHigh)<<32)|d.nFileSizeLow;if(size>64ull*1024*1024){result.push_back({std::wstring(sub)+name,"",ext==L".asi",false});continue;}
            try{auto bytes=read(root+sub+name,64ull*1024*1024);const char symbol[]="IsUltimateASILoader";bool loader=std::search(bytes.begin(),bytes.end(),symbol,symbol+sizeof(symbol))!=bytes.end();result.push_back({std::wstring(sub)+name,hash(bytes),ext==L".asi",loader});}catch(...){FindClose(h);throw;}
        }while(FindNextFileW(h,&d));DWORD error=GetLastError();FindClose(h);if(error!=ERROR_NO_MORE_FILES)fail(L"Folder enumeration failed.",error);
    }
    return result;
}
#include "local_uninstall.hpp"
#include "simple_install.hpp"

}
int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int) {
    try {wchar_t module[32768];DWORD n=GetModuleFileNameW(nullptr,module,32768);if(!n||n>=32768)fail(L"Cannot locate this installer.",GetLastError());std::wstring self(module,n),package=parent(self);int argc=0;wchar_t** argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(!argv)fail(L"Cannot read command line.",GetLastError());std::wstring manifest,exe,action;
        for(int i=1;i<argc;){
            if(equal(argv[i],L"--language")){
                if(i+1>=argc||!manager_localization::commandLanguage(argv[i+1],preferredLanguage)){LocalFree(argv);fail(L"Use --language auto, en-US, or zh-CN.");}
                for(int n=i;n+2<argc;++n)argv[n]=argv[n+2];argc-=2;
            }else ++i;
        }
        if(argc>=2&&(equal(argv[1],L"--uninstall-plan")||equal(argv[1],L"--uninstall-apply"))){
            machineMode=true;planOnly=equal(argv[1],L"--uninstall-plan");
            if((planOnly&&argc==3)||(!planOnly&&argc==4)){
                exe=absolute(argv[2]);if(!planOnly)reviewedToken=utf8(argv[3]);LocalFree(argv);return uninstallGame(parent(exe),exe,self);
            }
            LocalFree(argv);fail(L"Usage: --uninstall-plan <game.exe> | --uninstall-apply <game.exe> <review-token>");
        }
        if(argc==2&&equal(argv[1],L"--uninstall")){
            LocalFree(argv);const auto base=parent(package.substr(0,package.size()-1));
            if(!equal(package,base+L".smooth-motion\\"))fail(L"Run uninstall.bat beside the installed game executable.");
            return uninstallGame(base,L"",self);
        }
        if(argc==1&&isLocalJournal(package)&&exists(package+L"restore.tsv")){
            LocalFree(argv);return recoverLocal(package,self,false);
        }
        if(argc>=2&&(equal(argv[1],L"--restore-plan")||equal(argv[1],L"--restore-apply"))){
            machineMode=true;planOnly=equal(argv[1],L"--restore-plan");
            if((planOnly&&argc==3)||(!planOnly&&argc==4)){
                manifest=absolute(argv[2]);if(!planOnly)reviewedToken=utf8(argv[3]);LocalFree(argv);return restore(manifest,self);
            }
            LocalFree(argv);fail(L"Usage: Install.exe --restore-plan <restore.tsv> | --restore-apply <restore.tsv> <review-token>");
        }
        if(argc>=2&&(equal(argv[1],L"--plan")||equal(argv[1],L"--apply"))){
            machineMode=true;planOnly=equal(argv[1],L"--plan");
            if((planOnly&&(argc>=4&&argc<=6))||(!planOnly&&(argc==6||argc==7))){
                exe=absolute(argv[2]);requestedMode=lower(argv[3]);if(argc>=5)requestedProxy=argv[4];if(!planOnly)reviewedToken=utf8(argv[5]);if(planOnly&&argc==6)requestedFG=utf8(lower(argv[5]));if(!planOnly&&argc==7)requestedFG=utf8(lower(argv[6]));LocalFree(argv);
                return install(self,package,exe,true,true);
            }
            LocalFree(argv);fail(L"Usage: --plan <game.exe> version|asi [loader.dll] [native] | --apply <game.exe> version|asi <loader.dll> <review-token> [native]");
        }
        if(argc==1&&!exists(package+L"restore.tsv")&&exists(package+L"SmoothMotion_Manager.exe")){
            std::wstring application=package+L"SmoothMotion_Manager.exe",command=L"\""+application+L"\"";
            STARTUPINFOW startup{};startup.cb=sizeof startup;PROCESS_INFORMATION child{};
            BOOL started=CreateProcessW(application.c_str(),command.data(),nullptr,nullptr,FALSE,0,nullptr,package.c_str(),&startup,&child);DWORD error=GetLastError();LocalFree(argv);
            if(!started)fail(L"Cannot open the installation wizard. Run SmoothMotion_Manager.exe from the fully extracted package.",error);
            CloseHandle(child.hThread);CloseHandle(child.hProcess);return 0;
        }
        if(argc==3&&equal(argv[1],L"--restore")){manifest=absolute(argv[2]);}
        else if(argc!=1){LocalFree(argv);fail(L"Use the Manager to choose version.dll or new.asi, or use --plan / --apply.");}
        LocalFree(argv);
        if(manifest.empty()&&exe.empty()&&exists(package+L"restore.tsv"))manifest=package+L"restore.tsv";
        return manifest.empty()?install(self,package,exe,!exe.empty(),equal(action,L"--install-reviewed")):restore(manifest,self);
    } catch(const Failure& e){if(machineMode)emit(setup_protocol::result("error",utf8(e.text),"",e.code));else show(e.text+(e.code?L"\nWindows error "+std::to_wstring(e.code):L""),MB_ICONERROR);return 1;}catch(const std::exception& e){if(machineMode)emit(setup_protocol::result("error",e.what()));else show(L"Setup stopped before continuing: "+wide(e.what()),MB_ICONERROR);return 2;}catch(...){if(machineMode)emit(setup_protocol::result("error","Setup stopped because of an unexpected error."));else show(L"Setup stopped because of an unexpected error.",MB_ICONERROR);return 3;}
}
