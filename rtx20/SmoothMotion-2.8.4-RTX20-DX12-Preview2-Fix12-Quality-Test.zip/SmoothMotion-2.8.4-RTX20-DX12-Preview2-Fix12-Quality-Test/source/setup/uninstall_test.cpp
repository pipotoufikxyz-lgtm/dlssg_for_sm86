#include "uninstall_policy.hpp"
#include "file_plan.hpp"
#include "local_journal_policy.hpp"
#include <functional>
#include <iostream>
#include <map>
#include <stdexcept>
using namespace uninstall_policy;
static unsigned checks=0;
void check(bool value){if(!value)throw std::runtime_error("Uninstall scenario "+std::to_string(checks+1)+" failed");++checks;}
bool rejects(const std::function<void()>& run){try{run();return false;}catch(const std::exception&){return true;}}
Receipt asi(std::wstring exe=L"Game.exe",std::wstring carrier=L"version.dll"){
 return {exe,carrier,std::string(64,'a'),{{carrier,payload_hashes::loader},{L"new.asi",payload_hashes::motion},{carrier.substr(0,carrier.size()-4)+L".ini",payload_hashes::ini}}};
}
int main(){
 auto r=asi();auto text=serialize(r);auto roundtrip=parse(text);check(serialize(roundtrip)==text);
 std::map<std::wstring,std::string> files;for(const auto& f:r.files)files[f.path]=f.digest;files[L"unrelated.dll"]=std::string(64,'b');files[L"nvsmooth30.log"]="evidence";
 auto current=[&](const std::wstring& p){auto i=files.find(p);return i==files.end()?std::string("-"):i->second;};
 auto clean=plan(r,current);check(clean.remove.size()==3&&clean.preserved.empty());for(const auto& f:clean.remove)files.erase(f.path);
 check(plan(r,current).remove.empty()&&plan(r,current).preserved.empty());check(files.size()==2&&files[L"nvsmooth30.log"]=="evidence");
 for(const auto& f:r.files)files[f.path]=f.digest;
 files[L"new.asi"]=std::string(64,'c');auto edited=plan(r,current);check(edited.remove.empty()&&edited.preserved.size()==3&&edited.loaderPreserved);
 files.erase(L"version.dll");check(plan(r,current).remove.empty()&&plan(r,current).preserved.size()==2);
 files[L"version.ini"]=std::string(64,'d');check(plan(r,current).remove.empty()&&plan(r,current).preserved.size()==2);
 files[L"new.asi"]=payload_hashes::motion;files[L"version.ini"]=payload_hashes::ini;check(plan(r,current).remove.size()==2);
 // Relative receipts bind one game's exact filenames without embedding a drive
 // or shell command. A complete move resolves to the new root; the old root is
 // never referenced. Metacharacters are opaque data, not script fragments.
 for(const auto& exe:{L"Game & Company!.exe",L"100% Action ^ Name (2026).exe",L"游戏 世界.exe",L"Haydee 2.exe"}){
  auto named=asi(exe);auto moved=parse(serialize(named));check(moved.executable==exe);
  const std::wstring old=L"C:\\Old & Games!\\",now=L"D:\\新游戏 100%\\";
  check(now+moved.executable!=old+moved.executable&&serialize(moved).find(old)==std::wstring::npos);
  check(plan(moved,[&](const std::wstring& p){return p==L"new.asi"?std::string(payload_hashes::motion):std::string("-");}).remove.size()==1);
 }
 const std::string command=batch;check(command.find("setlocal DisableDelayedExpansion\r\n")!=command.npos);
 check(command.find("\"%~dp0.smooth-motion\\Uninstall.exe\" --uninstall\r\n")!=command.npos);
 for(const auto* dangerous:{"call ","del ","rmdir ","powershell","%*"})check(command.find(dangerous)==command.npos);
 // A forged/edited receipt cannot broaden removal beyond the supported owned
 // carrier, its matching INI and the exact renderer plugin.
 for(const auto& path:{L"..\\new.asi",L"C:\\game\\version.dll",L"\\\\server\\share\\new.asi",L"version.dll:stream",L"new.asi.",L"new.asi ",L"NUL.dll",L"other-mod.dll",L"plugins\\new.asi",L"uninstall.bat",L".smooth-motion\\Uninstall.exe"}){
  auto bad=r;bad.files[0].path=path;check(rejects([&]{serialize(bad);}));
 }
 for(const auto& exe:{L"..\\Game.exe",L"folder\\Game.exe",L"C:\\Game.exe",L"Game.dll",L"NUL.exe",L"game.exe\tother",L"",L"game.exe\nF\tother"}){auto bad=r;bad.executable=exe;check(rejects([&]{serialize(bad);}));}
 for(const auto& hash:{std::string("-"),std::string(64,'g'),std::string(63,'a'),std::string(64,'A'),std::string(64,'b')}){auto bad=r;bad.files[0].digest=hash;check(rejects([&]{serialize(bad);}));}
 auto bad=r;bad.files.push_back(bad.files.front());check(rejects([&]{serialize(bad);}));bad=r;bad.files[1].path=L"VERSION.DLL";check(rejects([&]{serialize(bad);}));
 bad=r;bad.files.pop_back();check(rejects([&]{serialize(bad);}));bad=r;bad.helper="-";check(rejects([&]{serialize(bad);}));
 check(rejects([&]{parse(text.substr(0,text.size()-1));}));check(rejects([&]{parse(text+L"F\tother.dll\t"+std::wstring(64,'a')+L"\r\n");}));check(rejects([&]{parse(text+std::wstring(40000,L'x'));}));
 auto nullText=text;nullText.insert(3,1,L'\0');check(rejects([&]{parse(nullText);}));
 for(const auto* carrier:install_modes::carriers){auto variant=asi(L"Game.exe",wide(carrier));check(parse(serialize(variant)).proxy==wide(carrier));check(plan(variant,[&](const auto& p){for(const auto& f:variant.files)if(p==f.path)return f.digest;return std::string("-");}).remove.size()==3);}
 Receipt standalone{L"Game.exe",L"version.dll",std::string(64,'a'),{{L"version.dll",payload_hashes::native_proxy}}};
 check(parse(serialize(standalone)).files.size()==1);check(plan(standalone,[&](const auto&){return std::string(payload_hashes::native_proxy);}).remove.size()==1);
 standalone.files.push_back({L"new.asi",payload_hashes::motion});check(rejects([&]{serialize(standalone);}));
 // Upgrades from 2.6 remove the old known ASI; uninstall tracks the final build,
 // not the previous broken mod. No unknown/game-owned original is displaced.
 file_plan::Inventory prior;prior.files={{"winmm.dll",payload_hashes::loader},{"winmm.ini",payload_hashes::ini},{"new.asi",motion::release26Native}};
 prior.scanned={{"winmm.dll",payload_hashes::loader,false,true},{"new.asi",motion::release26Native,true,false}};
 const auto upgraded=file_plan::make(prior,"asi","winmm.dll");check(upgraded.changes.size()==1&&upgraded.changes[0].before==motion::release26Native&&upgraded.changes[0].after==payload_hashes::motion);
 auto upgradedReceipt=asi(L"Game.exe",L"winmm.dll");check(serialize(upgradedReceipt).find(wide(motion::release26Native))==std::wstring::npos);
 auto stale=upgradedReceipt;stale.files[1].digest=motion::release26Native;check(plan(stale,[&](const auto& p){return p==L"new.asi"?std::string(payload_hashes::motion):std::string("-");}).preserved.size()==1);
 prior.files["version.dll"]=std::string(64,'b');check(rejects([&]{file_plan::make(prior,"version","");}));
 // A loader is shared infrastructure: changed ASI/INI or additional ASIs
 // must not lose their carrier simply because its own bytes are unchanged.
 for(const auto& f:r.files)files[f.path]=f.digest;
 auto shared=plan(r,current,true);check(shared.remove.size()==1&&shared.remove[0].path==L"new.asi"&&shared.preserved.size()==2&&shared.loaderPreserved);
 files[L"version.ini"]=std::string(64,'b');auto configChanged=plan(r,current);check(configChanged.remove.size()==1&&configChanged.preserved.size()==2&&configChanged.loaderPreserved);
 files[L"version.ini"]=payload_hashes::ini;files[L"version.dll"]=std::string(64,'b');auto carrierChanged=plan(r,current);check(carrierChanged.remove.size()==1&&carrierChanged.preserved.size()==2);
 files[L"version.dll"]=payload_hashes::loader;files.erase(L"new.asi");check(plan(r,current).remove.size()==2);check(plan(r,current,true).remove.empty());
 // Legacy no-receipt fallback recognizes complete identities at the selected
 // original EXE folder. An unknown ASI never authorizes generic loader removal.
 using LegacyFS=std::map<std::wstring,std::string>;
 LegacyFS old{{L"version.dll",payload_hashes::loader},{L"version.ini",payload_hashes::ini},{L"new.asi",motion::release26Native},{L"user.dll",std::string(64,'b')}};
 auto oldCurrent=[&](const std::wstring& path){auto it=old.find(path);return it==old.end()?std::string("-"):it->second;};
 auto recognized=legacy(oldCurrent);check(recognized.files.size()==3&&!recognized.incompleteLoader);for(const auto& f:recognized.files)check(f.path!=L"user.dll");
 auto sharedOld=legacy(oldCurrent,true);check(sharedOld.files.size()==1&&sharedOld.files[0].path==L"new.asi"&&sharedOld.loaderPreserved);
 for(const auto& renderer:{std::string("-"),std::string(64,'b')}){old[L"new.asi"]=renderer;auto refused=legacy(oldCurrent);check(refused.files.empty()&&refused.incompleteLoader);}
 old[L"new.asi"]=motion::release26Native;old[L"version.ini"]=std::string(64,'b');check(legacy(oldCurrent).files.empty());
 old[L"version.ini"]=payload_hashes::ini;old[L"version.dll"]=std::string(64,'b');check(legacy(oldCurrent).files.empty());
 old[L"version.dll"]=payload_hashes::loader;old[L"winmm.dll"]=payload_hashes::loader;old[L"winmm.ini"]=payload_hashes::ini;check(legacy(oldCurrent).files.size()==5);check(legacy(oldCurrent,true).files.size()==1);
 for(const auto& f:legacy(oldCurrent).files)old.erase(f.path);check(legacy(oldCurrent).files.empty()&&old.count(L"user.dll")==1);
 for(const auto* hash:{payload_hashes::native_proxy,payload_hashes::standalone}){old[L"version.dll"]=hash;old[L"new.asi"]=std::string(64,'b');auto single=legacy(oldCurrent,true);check(single.files.size()==1&&single.files[0].path==L"version.dll"&&old[L"new.asi"]==std::string(64,'b'));}
 file_plan::Inventory sharedInstall;sharedInstall.files={{"version.dll",payload_hashes::loader},{"version.ini",payload_hashes::ini},{"new.asi",motion::release26Native}};sharedInstall.scanned={{"version.dll",payload_hashes::loader,false,true},{"new.asi",motion::release26Native,true,false},{"plugins\\Other.asi",std::string(64,'b'),true,false}};
 check(rejects([&]{file_plan::make(sharedInstall,"version","");}));check(rejects([&]{file_plan::make(sharedInstall,"asi","winmm.dll");}));check(file_plan::make(sharedInstall,"asi","version.dll").changes.size()==1);
 // Old receipts are validated by the new installer before any update of
 // their helper or ownership record. A released 2.7 native proxy must parse
 // and uninstall cleanly even when the packaged current proxy has changed.
 Receipt proxyReceipt27{L"Game.exe",L"version.dll",std::string(64,'a'),{{L"version.dll",motion::release27NativeProxy}}};
 const auto parsedProxy27=parse(serialize(proxyReceipt27));
 check(parsedProxy27.files.size()==1&&parsedProxy27.files[0].digest==motion::release27NativeProxy);
 auto oldProxyPlan=plan(parsedProxy27,[](const auto&){return std::string(motion::release27NativeProxy);});check(oldProxyPlan.remove.size()==1&&oldProxyPlan.preserved.empty());
 auto changedProxyPlan=plan(parsedProxy27,[](const auto&){return std::string(64,'c');});check(changedProxyPlan.remove.empty()&&changedProxyPlan.preserved.size()==1);
 auto absentProxyPlan=plan(parsedProxy27,[](const auto&){return std::string("-");});check(absentProxyPlan.remove.empty()&&absentProxyPlan.preserved.empty());
 const auto legacyProxy27=legacy([](const std::wstring& p){return p==L"version.dll"?std::string(motion::release27NativeProxy):std::string("-");});check(legacyProxy27.files.size()==1&&legacyProxy27.files[0].digest==motion::release27NativeProxy);
 auto asiReceipt27=asi(L"Game.exe",L"winmm.dll");asiReceipt27.files[1].digest=motion::release27Native;
 const auto parsedAsi27=parse(serialize(asiReceipt27));check(parsedAsi27.files[1].digest==motion::release27Native);
 auto oldAsiPlan=plan(parsedAsi27,[&](const std::wstring& p){for(const auto& f:asiReceipt27.files)if(f.path==p)return f.digest;return std::string("-");});check(oldAsiPlan.remove.size()==3&&oldAsiPlan.preserved.empty());
 const auto legacyAsi27=legacy([&](const std::wstring& p){for(const auto& f:asiReceipt27.files)if(f.path==p)return f.digest;return std::string("-");});check(legacyAsi27.files.size()==3&&!legacyAsi27.incompleteLoader);
 auto forgedProxy27=proxyReceipt27;forgedProxy27.files[0].digest[0]=forgedProxy27.files[0].digest[0]=='0'?'1':'0';check(rejects([&]{serialize(forgedProxy27);}));
 const auto foreignOld=legacy([&](const std::wstring& p){return p==L"version.dll"?forgedProxy27.files[0].digest:std::string("-");});check(foreignOld.files.empty());
 // Released 2.8 ownership receipts remain valid for the diagnostic update.
 Receipt proxyReceipt28{L"Game.exe",L"version.dll",std::string(64,'a'),{{L"version.dll",motion::release28NativeProxy}}};
 const auto parsedProxy28=parse(serialize(proxyReceipt28));check(parsedProxy28.files[0].digest==motion::release28NativeProxy);
 const auto proxyRemoval28=plan(parsedProxy28,[](const auto&){return std::string(motion::release28NativeProxy);});check(proxyRemoval28.remove.size()==1&&proxyRemoval28.preserved.empty());
 const auto changedProxy28=plan(parsedProxy28,[](const auto&){return std::string(64,'c');});check(changedProxy28.remove.empty()&&changedProxy28.preserved.size()==1);
 const auto legacyProxy28=legacy([](const std::wstring& p){return p==L"version.dll"?std::string(motion::release28NativeProxy):std::string("-");});check(legacyProxy28.files.size()==1&&legacyProxy28.files[0].digest==motion::release28NativeProxy);
 auto asiReceipt28=asi(L"Game.exe",L"winmm.dll");asiReceipt28.files[1].digest=motion::release28Native;
 const auto parsedAsi28=parse(serialize(asiReceipt28));check(parsedAsi28.files[1].digest==motion::release28Native);
 const auto oldAsi28=[&](const std::wstring& p){for(const auto& f:asiReceipt28.files)if(f.path==p)return f.digest;return std::string("-");};
 const auto asiRemoval28=plan(parsedAsi28,oldAsi28);check(asiRemoval28.remove.size()==3&&asiRemoval28.preserved.empty());
 const auto sharedAsi28=plan(parsedAsi28,oldAsi28,true);check(sharedAsi28.remove.size()==1&&sharedAsi28.remove[0].path==L"new.asi"&&sharedAsi28.preserved.size()==2);
 const auto legacyAsi28=legacy(oldAsi28);check(legacyAsi28.files.size()==3&&!legacyAsi28.incompleteLoader);
 auto modifiedReceipt28=proxyReceipt28;modifiedReceipt28.files[0].digest[0]='e';check(rejects([&]{serialize(modifiedReceipt28);}));
 // 2.8.1 receipts and modified/shared cases still use exact released bytes.
 Receipt receipt281{L"Game.exe",L"version.dll",std::string(64,'a'),{{L"version.dll",motion::release281NativeProxy}}};
 const auto parsed281=parse(serialize(receipt281));check(parsed281.files[0].digest==motion::release281NativeProxy);
 check(plan(parsed281,[](const auto&){return std::string(motion::release281NativeProxy);}).remove.size()==1);
 check(plan(parsed281,[](const auto&){return std::string(64,'d');}).remove.empty());
 auto asi281=asi(L"Game.exe",L"winmm.dll");asi281.files[1].digest=motion::release281Native;check(parse(serialize(asi281)).files[1].digest==motion::release281Native);
 const auto shared281=plan(asi281,[&](const std::wstring& p){for(const auto& f:asi281.files)if(f.path==p)return f.digest;return std::string("-");},true);
 check(shared281.remove.size()==1&&shared281.remove[0].path==L"new.asi"&&shared281.loaderPreserved&&shared281.preserved.size()==2);
 // Every known standalone receipt remains parseable; only exact owned bytes
 // are removable. Missing/modified versions never become deletion targets.
 for(const char* known:motion::previousNativeProxies){
  Receipt prior{L"Game.exe",L"version.dll",std::string(64,'a'),{{L"version.dll",known}}};
  const auto parsed=parse(serialize(prior));
  check(plan(parsed,[&](const auto&){return std::string(known);}).remove.size()==1);
  check(plan(parsed,[](const auto&){return std::string(64,'d');}).preserved.size()==1);
  check(plan(parsed,[](const auto&){return std::string("-");}).remove.empty());
  check(legacy([&](const auto& p){return p==L"version.dll"?std::string(known):std::string("-");}).files.size()==1);
 }
 for(const char* known:motion::previousPlugins){
  auto prior=asi(L"Game.exe",L"winmm.dll");prior.files[1].digest=known;
  const auto parsed=parse(serialize(prior));
  const auto current=[&](const auto& p){for(const auto& f:prior.files)if(p==f.path)return f.digest;return std::string("-");};
  check(plan(parsed,current).remove.size()==3);
  const auto shared=plan(parsed,current,true);
  check(shared.remove.size()==1&&shared.remove[0].path==L"new.asi"&&shared.preserved.size()==2&&shared.loaderPreserved);
  check(legacy(current).files.size()==3);
  auto changed=plan(parsed,[&](const auto& p){return p==L"new.asi"?std::string(64,'d'):current(p);});
  check(changed.preserved.size()>=1);for(const auto& f:changed.remove)check(f.path!=L"new.asi");
 }
 // Exercise the production persistent-journal codec and recovery planner.
 // The fake filesystem injects crashes at each commit and rollback boundary;
 // Windows file sharing, FlushFileBuffers and MoveFileEx still need Windows QA.
 namespace journal=local_journal_policy;
 const std::wstring gameRoot=L"C:\\Games & Stuff!\\";
 const std::string before(64,'b'),after(64,'c'),identity(64,'f');
 const auto owner=L"SM86-JOURNAL-1\r\n"+wide(std::string(64,'a'))+L"\r\n"+wide(std::string(64,'b'))+L"\r\n"+wide(identity)+L"\r\n";
 const auto prefix=L"SM86-RESTORE-1\r\n"+gameRoot+L"\r\n"+gameRoot+L"Game.exe\r\n";
 const auto body=L"F\tnew.asi\t-\t"+wide(after)+L"\r\nF\tversion.dll\t"+wide(before)+L"\t"+wide(after)+L"\r\nF\tplugins\\old.asi\t"+wide(before)+L"\t-\r\nF\t.smooth-motion\\installed.tsv\t-\t"+wide(after)+L"\r\nD\t.smooth-motion\r\nS\tnew.asi.sm86-stage-123-0\t"+wide(after)+L"\r\nS\t.smooth-motion\\installed.tsv.sm86-stage-123-3\t"+wide(after)+L"\r\n";
 const auto same=[](const auto& a,const auto& b){return journal::canonical(a)==journal::canonical(b);};
 const auto record=journal::parse(prefix+body,owner,identity,gameRoot,same);check(record.changes.size()==4&&record.stages.size()==2&&record.directories.size()==1);
 using FS=std::map<std::wstring,std::string>;
 const auto get=[](const FS& fs,const std::wstring& path){auto i=fs.find(path);return i==fs.end()?std::string("-"):i->second;};
 FS originals;for(const auto& c:record.changes)if(c.before!="-")originals[c.path]=c.before;
 const auto restoreOne=[&](FS& fs,size_t n){const auto& c=record.changes[n];auto action=journal::recovery(c,get(fs,c.path));check(action!=journal::Recovery::Conflict);if(action==journal::Recovery::Remove)fs.erase(c.path);else if(action==journal::Recovery::Restore)fs[c.path]=originals[c.path];};
 const auto recovery=[&](const FS& fs,const FS& backup,const std::wstring& marker=L""){return journal::plan(record,marker,[&](const auto& path){return get(fs,path);},[&](const auto& path){return get(backup,path);});};
 for(size_t cut=0;cut<=record.changes.size();++cut){
  FS interrupted=originals;for(size_t n=0;n<cut;++n){auto c=record.changes[n];if(c.after=="-")interrupted.erase(c.path);else interrupted[c.path]=c.after;}
  // Staged outputs have not touched their destinations yet.
  const auto first=recovery(interrupted,originals);check(!first.cleanupOnly&&first.changes.size()==cut);
  for(size_t restored=0;restored<=first.changes.size();++restored){
   FS again=interrupted;for(size_t n=0;n<restored;++n)restoreOne(again,first.changes[n]);
   auto remainder=recovery(again,originals);check(remainder.changes.size()==cut-restored);
   for(auto n:remainder.changes)restoreOne(again,n);check(again==originals);check(recovery(again,originals).changes.empty());
  }
  if(cut){auto modified=interrupted;modified[record.changes[0].path]=std::string(64,'d');auto untouched=modified;check(rejects([&]{recovery(modified,originals);}));check(modified==untouched);}
 }
 auto corruptBackup=originals;corruptBackup.erase(L"version.dll");check(rejects([&]{recovery(originals,corruptBackup);}));
 // A durable commit marker selects cleanup without consulting originals that
 // may already have been deleted. It must never roll back a committed game.
 const auto marker=journal::commitMarker(identity);unsigned readCalls=0;
 auto committed=journal::plan(record,marker,[&](const auto&){++readCalls;return std::string(64,'d');},[&](const auto&){++readCalls;return std::string("-");});
 check(committed.cleanupOnly&&committed.changes.empty()&&readCalls==0);
 check(rejects([&]{recovery(originals,originals,marker+L"changed");}));
 check(!journal::committed(identity,L"")&&journal::committed(identity,marker));
 check(journal::retirementDirectory(identity)==L".smooth-motion\\done-ffffffffffffffffffffffff\\");
 check(rejects([&]{journal::retirementDirectory("..\\other");}));
 check(rejects([&]{journal::parse(prefix+body,owner,identity,L"D:\\Moved Game\\",same);}));
 check(rejects([&]{journal::parse(prefix+body,owner,std::string(64,'e'),gameRoot,same);}));
 check(rejects([&]{journal::parse(prefix+body,owner.substr(0,owner.size()-1),identity,gameRoot,same);}));
 for(const auto& hostile:{L"F\t..\\save.dat\t-\t",L"F\tC:\\save.dat\t-\t",L"F\tnew.asi:stream\t-\t",L"F\tNEW.ASI\t-\t"})check(rejects([&]{journal::parse(prefix+body+hostile+wide(after)+L"\r\n",owner,identity,gameRoot,same);}));
 check(rejects([&]{journal::parse(prefix+body+L"D\tsaves\r\n",owner,identity,gameRoot,same);}));
 for(const auto& stage:{L"save.dat",L"new.asi.sm86-stage-../save",L"new.asi.sm86-stage-foo"})check(rejects([&]{journal::parse(prefix+body+L"S\t"+stage+L"\t"+wide(after)+L"\r\n",owner,identity,gameRoot,same);}));
 check(rejects([&]{journal::parse(prefix+body+L"S\tnew.asi.sm86-stage-99-0\t"+wide(before)+L"\r\n",owner,identity,gameRoot,same);}));
 std::cout<<checks<<" uninstall ownership, upgrade, interrupted journal and recovery scenarios passed\n";
}
