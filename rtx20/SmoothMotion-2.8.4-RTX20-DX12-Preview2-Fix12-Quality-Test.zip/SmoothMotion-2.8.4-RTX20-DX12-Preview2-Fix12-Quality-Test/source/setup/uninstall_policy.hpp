#pragma once
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>
#include "policy.hpp"
#include "install_modes.hpp"
#include "payload_hashes.hpp"
#include "legacy_hashes.hpp"
#include "../motion/identity.hpp"
namespace uninstall_policy {
inline constexpr wchar_t directory[]=L".smooth-motion";
inline constexpr wchar_t receiptPath[]=L".smooth-motion\\installed.tsv";
inline constexpr wchar_t helperPath[]=L".smooth-motion\\Uninstall.exe";
inline constexpr wchar_t batchPath[]=L"uninstall.bat";
// Only a quoted, expansion-once %~dp0 is used. No game names or receipt paths
// are injected into command text. Delayed expansion remains disabled for !.
inline constexpr char batch[]="@echo off\r\nsetlocal DisableDelayedExpansion\r\n\"%~dp0.smooth-motion\\Uninstall.exe\" --uninstall\r\nset \"SM86_UNINSTALL_RESULT=%errorlevel%\"\r\nif not \"%SM86_UNINSTALL_RESULT%\"==\"0\" pause\r\nexit /b %SM86_UNINSTALL_RESULT%\r\n";
struct Entry {std::wstring path;std::string digest;};
struct Receipt {std::wstring executable,proxy;std::string helper;std::vector<Entry> files;};
struct Removal {std::vector<Entry> remove,preserved;bool loaderPreserved=false;};
inline std::wstring lower(std::wstring s){for(auto& c:s)if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A';return s;}
inline bool digest(const std::string& s){return s.size()==64&&std::all_of(s.begin(),s.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');});}
inline std::string ascii(const std::wstring& s){std::string out;for(auto c:s){if(c<0||c>127)throw std::runtime_error("Non-ASCII receipt identity");out+=char(c);}return out;}
inline std::wstring wide(const std::string& s){return {s.begin(),s.end()};}
inline bool plugin(const std::string& s){return s==payload_hashes::asi||motion::ownedPlugin(s,payload_hashes::motion);}
inline bool native(const std::string& s){return motion::ownedNativeProxy(s,payload_hashes::native_proxy)||s==payload_hashes::standalone;}
inline void validate(const Receipt& r){
 if(!setup_policy::safe_relative(r.executable)||r.executable.find_first_of(L"\\/")!=r.executable.npos||r.executable.size()<5||lower(r.executable.substr(r.executable.size()-4))!=L".exe")throw std::runtime_error("Invalid game filename in uninstall receipt");
 bool carrier=false;for(const auto* n:install_modes::carriers)carrier|=r.proxy==wide(n);
 if(!carrier||!digest(r.helper)||r.files.empty()||r.files.size()>3)throw std::runtime_error("Invalid uninstall ownership receipt");
 const auto ini=r.proxy.substr(0,r.proxy.size()-4)+L".ini";bool p=false,a=false,i=false,loader=false;
 std::vector<std::wstring> seen;
 for(const auto& f:r.files){
  if(!setup_policy::safe_relative(f.path)||!digest(f.digest)||std::find(seen.begin(),seen.end(),lower(f.path))!=seen.end())throw std::runtime_error("Invalid or duplicate uninstall file");seen.push_back(lower(f.path));
  if(f.path==r.proxy){p=true;loader=f.digest==payload_hashes::loader;if(!loader&&!native(f.digest))throw std::runtime_error("Unknown carrier identity in uninstall receipt");}
  else if(f.path==L"new.asi"){a=true;if(!plugin(f.digest))throw std::runtime_error("Unknown ASI identity in uninstall receipt");}
  else if(f.path==ini){i=true;if(f.digest!=payload_hashes::ini&&f.digest!=legacy_hashes::ini)throw std::runtime_error("Unknown loader INI identity in uninstall receipt");}
  else throw std::runtime_error("Uninstall receipt names an unrelated file");
 }
 if(!p||(loader&&(!a||!i))||(!loader&&(a||i)))throw std::runtime_error("Incomplete uninstall ownership group");
}
inline std::wstring serialize(const Receipt& r){validate(r);std::wstring s=L"SM86-UNINSTALL-1\r\n"+r.executable+L"\r\n"+r.proxy+L"\r\n"+wide(r.helper)+L"\r\n";for(const auto& f:r.files)s+=L"F\t"+f.path+L"\t"+wide(f.digest)+L"\r\n";return s;}
inline Receipt parse(const std::wstring& s){
 if(s.size()>32768||s.find(L'\0')!=s.npos)throw std::runtime_error("Invalid uninstall receipt size");
 std::vector<std::wstring> lines;size_t at=0;while(at<s.size()){auto end=s.find(L'\n',at);if(end==s.npos)throw std::runtime_error("Truncated uninstall receipt");auto row=s.substr(at,end-at);if(!row.empty()&&row.back()==L'\r')row.pop_back();lines.push_back(row);at=end+1;}
 if(lines.size()<5||lines[0]!=L"SM86-UNINSTALL-1")throw std::runtime_error("Invalid uninstall receipt header");
 Receipt r{lines[1],lines[2],ascii(lines[3]),{}};
 for(size_t n=4;n<lines.size();++n){const auto& l=lines[n];auto tab=l.find(L'\t',2);if(l.rfind(L"F\t",0)!=0||tab==l.npos||l.find(L'\t',tab+1)!=l.npos)throw std::runtime_error("Malformed uninstall ownership entry");r.files.push_back({l.substr(2,tab-2),ascii(l.substr(tab+1))});}
 validate(r);return r;
}
template<class Current> Removal plan(const Receipt& r,Current current,bool otherConsumers=false){
 validate(r);Removal out;const auto ini=r.proxy.substr(0,r.proxy.size()-4)+L".ini";
 bool loader=false,shared=otherConsumers;
 for(const auto& f:r.files)if(f.path==r.proxy)loader=f.digest==payload_hashes::loader;
 if(loader)for(const auto& f:r.files){const auto h=current(f.path);if(h!="-"&&h!=f.digest)shared=true;}
 for(const auto& f:r.files){const auto h=current(f.path);if(h=="-")continue;
  if(loader&&shared&&(f.path==r.proxy||f.path==ini)){out.preserved.push_back(f);out.loaderPreserved=true;}
  else if(h==f.digest)out.remove.push_back(f);else out.preserved.push_back(f);
 }
 return out;
}
struct Legacy {std::vector<Entry> files;bool incompleteLoader=false,loaderPreserved=false;};
template<class Current> Legacy legacy(Current current,bool otherConsumers=false){
 Legacy out;const auto asi=current(L"new.asi");
 const auto append=[&](const std::wstring& p,const std::string& h){for(const auto& f:out.files)if(f.path==p)return;out.files.push_back({p,h});};
 for(const auto* name:install_modes::carriers){
  const auto carrier=wide(name),ini=carrier.substr(0,carrier.size()-4)+L".ini";
  const auto dll=current(carrier),config=current(ini);
  if(dll==payload_hashes::loader){
   // The generic ASI loader also belongs to other mods. Neither its hash nor
   // an INI alone proves this is our installation: the known renderer must
   // complete the group before any of its three files can be removed.
   if(plugin(asi)&&(config==payload_hashes::ini||config==legacy_hashes::ini)){
    if(!otherConsumers){append(carrier,dll);append(ini,config);}else out.loaderPreserved=true;append(L"new.asi",asi);
   }else out.incompleteLoader=true;
  }else if(native(dll))append(carrier,dll);
 }
 return out;
}

}
