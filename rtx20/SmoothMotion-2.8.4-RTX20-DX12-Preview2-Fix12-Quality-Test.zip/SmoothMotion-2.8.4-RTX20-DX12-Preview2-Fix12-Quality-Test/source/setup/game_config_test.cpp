#include "game_config_policy.hpp"
#include "test_reference/gp7_game_config_policy.hpp"
#include <cstdlib>
#include <iostream>
using namespace preflight;
unsigned checks=0;
void check(bool value){++checks;if(!value)std::abort();}
template<class F>bool rejects(F f){try{f();return false;}catch(const std::exception&){return true;}}
GameConfigPolicy config(const GameConfigPolicy::Attributes& attrs){GameConfigPolicy p;p.begin(L"Game",{},false);p.begin(L"ExecutableList",{},false);p.begin(L"Executable",attrs,true);p.end(L"ExecutableList");p.end(L"Game");p.finish();return p;}
int main(){
 const GameConfigPolicy::Attributes valid{{L"Name",L"Game.exe"},{L"TargetDeviceFamily",L"PC"}};
 auto p=config(valid);check(p.identifiesX64(L"GAME.EXE"));check(!p.identifiesX64(L"gamelaunchhelper.exe"));check(!p.identifiesX64(L"Other\\Game.exe"));check(!p.identifiesX64(L"..\\Game.exe"));
 auto defaults=valid;defaults.erase(L"TargetDeviceFamily");
 gp7_preflight::GameConfigPolicy old;old.begin(L"Game",{},false);old.begin(L"ExecutableList",{},false);old.begin(L"Executable",defaults,true);old.end(L"ExecutableList");old.end(L"Game");old.finish();
 check(!old.identifiesX64(L"Game.exe"));check(config(defaults).identifiesX64(L"Game.exe"));
 check(config(defaults).x64Executables()==std::vector<std::wstring>{L"game.exe"});
 for(const auto* arch:{L"x64",L"ARM64",L"x86",L"bogus",L""}){auto a=valid;a[L"Architecture"]=arch;check(config(a).identifiesX64(L"Game.exe")== (std::wstring(arch)==L"x64"));}
 for(const auto* family:{L"XboxOne",L"Scarlett",L"",L"PC"}){auto a=valid;a[L"TargetDeviceFamily"]=family;check(config(a).identifiesX64(L"Game.exe")== (std::wstring(family)==L"PC"));}
 for(const auto* dev:{L"true",L"false",L"invalid"}){auto a=valid;a[L"IsDevOnly"]=dev;check(config(a).identifiesX64(L"Game.exe")== (std::wstring(dev)==L"false"));}
 auto nested=valid;nested[L"Name"]=L"Binaries/Win64/\u6e38\u620f.exe";check(config(nested).identifiesX64(L"binaries\\win64\\\u6e38\u620f.exe"));
 for(const auto* bad:{L"",L"../Game.exe",L"C:\\Game.exe",L"\\Game.exe",L"Game.exe:stream",L"folder/../Game.exe"}){auto a=valid;a[L"Name"]=bad;check(rejects([&]{config(a);}));}
 check(rejects([]{GameConfigPolicy p;p.begin(L"Fake",{},false);}));
 check(rejects([]{GameConfigPolicy p;p.begin(L"Game",{},false);p.finish();}));
 check(rejects([]{GameConfigPolicy p;p.begin(L"Game",{},false);p.begin(L"ExecutableList",{},true);p.begin(L"ExecutableList",{},true);}));
 GameConfigPolicy duplicate;duplicate.begin(L"Game",{},false);duplicate.begin(L"ExecutableList",{},false);duplicate.begin(L"Executable",valid,true);duplicate.begin(L"Executable",valid,true);duplicate.end(L"ExecutableList");duplicate.end(L"Game");duplicate.finish();check(!duplicate.identifiesX64(L"Game.exe"));
 check(duplicate.x64Executables().empty());
 GameConfigPolicy decoy;decoy.begin(L"Game",{},false);decoy.begin(L"ExecutableList",{},true);decoy.begin(L"Other",{},false);decoy.begin(L"Executable",valid,true);decoy.end(L"Other");decoy.end(L"Game");decoy.finish();check(!decoy.identifiesX64(L"Game.exe"));
 GameConfigPolicy incomplete;incomplete.begin(L"Game",{},false);incomplete.begin(L"ExecutableList",{},false);incomplete.begin(L"Executable",valid,true);check(!incomplete.identifiesX64(L"Game.exe"));
 check(incomplete.x64Executables().empty());
 check(rejects([]{GameConfigPolicy p;p.begin(L"Game",{},false);for(unsigned i=0;i<32;++i)p.begin(L"Node",{},false);}));
 unsigned reads=0,metadataReads=0;
 Imports pe;pe.machine=0x8664;pe.plus=true;pe.direct={"version.dll","dxgi.dll"};
 const auto metadata=[&]{++metadataReads;Imports declared;declared.machine=0x8664;declared.plus=true;return TargetInspection{declared,true,L"D:\\XboxGames\\Game\\Content\\MicrosoftGame.config",{1,2,3}};};
 auto direct=inspectTargetWith([&]{++reads;return pe;},metadata);check(reads==1&&metadataReads==0&&!direct.metadataOnly&&direct.imports.direct==pe.direct);
 auto protectedTarget=inspectTargetWith([]()->Imports{throw FileAccessError("denied",5);},metadata);check(protectedTarget.metadataOnly&&metadataReads==1&&protectedTarget.imports.direct.empty()&&protectedTarget.imports.delay.empty());check(protectedTarget.metadata.size()==3&&!protectedTarget.metadataPath.empty());
 for(unsigned error:{2u,3u,32u,8u}){auto before=metadataReads;check(rejects([&]{inspectTargetWith([&]()->Imports{throw FileAccessError("other",error);},metadata);}));check(metadataReads==before);}
 auto before=metadataReads;check(rejects([&]{inspectTargetWith([]()->Imports{throw std::runtime_error("Invalid PE");},metadata);}));check(metadataReads==before);
 for(unsigned machine:{0x14cu,0xaa64u,0u}){pe.machine=machine;auto t=inspectTargetWith([&]{return pe;},metadata);check(t.imports.machine==machine&&!t.metadataOnly&&metadataReads==before);}
 check(rejects([&]{inspectTargetWith([]()->Imports{throw FileAccessError("denied",5);},[]()->TargetInspection{throw std::runtime_error("no metadata");});}));
 check(rejects([&]{inspectTargetWith([]()->Imports{throw FileAccessError("denied",5);},[]{TargetInspection t;t.imports.machine=0x14c;return t;});}));
 auto forged=protectedTarget;forged.imports.direct={"version.dll"};check(rejects([&]{inspectTargetWith([]()->Imports{throw FileAccessError("denied",5);},[&]{return forged;});}));
 std::cout<<"PASS: "<<checks<<" protected-target/metadata decisions; exact path, architecture, structure, ambiguity and error handling. XmlLite/Windows APIs not executed.\n";
}
