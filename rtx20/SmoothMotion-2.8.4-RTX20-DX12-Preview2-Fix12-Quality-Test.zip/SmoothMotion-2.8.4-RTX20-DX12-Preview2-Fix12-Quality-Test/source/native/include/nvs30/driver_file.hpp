#pragma once
#include <windows.h>
#include <bcrypt.h>
#include "driver_layout.hpp"
namespace nvs30::driver_file {
inline std::string sha256(const unsigned char* bytes,std::size_t size) {
    BCRYPT_ALG_HANDLE algorithm{};BCRYPT_HASH_HANDLE hash{};unsigned char digest[32]{};
    bool ok=size<=driver_layout::limit && BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0;
    if(ok)ok=BCryptCreateHash(algorithm,&hash,nullptr,0,nullptr,0,0)>=0;
    if(ok)ok=BCryptHashData(hash,const_cast<PUCHAR>(bytes),static_cast<ULONG>(size),0)>=0;
    if(ok)ok=BCryptFinishHash(hash,digest,sizeof digest,0)>=0;
    if(hash)BCryptDestroyHash(hash);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);
    if(!ok)return {};
    constexpr char hex[]="0123456789abcdef";std::string result;
    for(auto byte:digest){result+=hex[byte>>4];result+=hex[byte&15];}return result;
}
struct File {
    HANDLE handle=INVALID_HANDLE_VALUE;
    std::vector<unsigned char> bytes;
    driver_layout::Image image;
    driver_layout::Verdict verdict;
    std::string digest,codeDigest;
    const char* error="not opened";DWORD win32Error{};
    File()=default;File(const File&)=delete;File& operator=(const File&)=delete;
    ~File(){if(handle!=INVALID_HANDLE_VALUE)CloseHandle(handle);}
    bool inspect(const std::wstring& path) {
        // Deny writes/deletion until LoadLibraryEx has completed, so validation
        // and loading cannot silently observe different files.
        handle=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(handle==INVALID_HANDLE_VALUE){win32Error=GetLastError();error="file open failed";return false;}
        LARGE_INTEGER size{};
        if(!GetFileSizeEx(handle,&size)||size.QuadPart<64||static_cast<unsigned long long>(size.QuadPart)>driver_layout::limit){error="file size outside validation bounds";return false;}
        bytes.resize(static_cast<std::size_t>(size.QuadPart));std::size_t at=0;
        while(at<bytes.size()) {
            DWORD got{};
            if(!ReadFile(handle,bytes.data()+at,static_cast<DWORD>(bytes.size()-at),&got,nullptr)||!got){win32Error=GetLastError();error="file read failed";return false;}
            at+=got;
        }
        digest=sha256(bytes.data(),bytes.size());
        if(digest.empty()){error="SHA256 unavailable";return false;}
        if(!driver_layout::parse(bytes,image)){error="invalid or unsupported AMD64 PE file";return false;}
        for(const auto& s:image.sections)if(s.name==".text")codeDigest=sha256(bytes.data()+s.raw,std::min(s.size,s.bytes));
        verdict=driver_layout::validate(image,bytes,digest,sha256);error=verdict.reason;
        return verdict.accepted;
    }
};
}
