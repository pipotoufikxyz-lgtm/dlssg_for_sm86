#pragma once
#include <string_view>
namespace import_identity {
inline bool equal(std::string_view a,std::string_view b){
 if(a.size()!=b.size())return false;
 for(std::size_t i=0;i<a.size();++i){char c=a[i];if(c>='A'&&c<='Z')c+=32;if(c!=b[i])return false;}
 return true;
}
inline bool prefix(std::string_view a,std::string_view b){return a.size()>=b.size()&&equal(a.substr(0,b.size()),b);}
inline bool dll(std::string_view a){return a.size()>4&&equal(a.substr(a.size()-4),".dll")&&a.find_first_of("\\/:")==a.npos;}
inline bool graphics(std::string_view name,std::size_t api){
 if(equal(name,"sl.interposer.dll"))return api<6;
 if(equal(name,"dxgi.dll")||prefix(name,"api-ms-win-dx-dxgi-"))return api<3&&dll(name);
 if(equal(name,"d3d12.dll")||prefix(name,"api-ms-win-dx-d3d12-"))return api==3&&dll(name);
 if(equal(name,"d3d11.dll")||prefix(name,"api-ms-win-dx-d3d11-"))return (api==4||api==5)&&dll(name);
 return false;
}
inline bool loader(std::string_view name){
 return equal(name,"kernel32.dll")||equal(name,"kernelbase.dll")||equal(name,"kernel32legacy.dll")||
  (dll(name)&&(prefix(name,"api-ms-win-core-libraryloader-")||prefix(name,"api-ms-win-core-kernel32-legacy-")||prefix(name,"api-ms-win-downlevel-kernel32-")));
}
}
