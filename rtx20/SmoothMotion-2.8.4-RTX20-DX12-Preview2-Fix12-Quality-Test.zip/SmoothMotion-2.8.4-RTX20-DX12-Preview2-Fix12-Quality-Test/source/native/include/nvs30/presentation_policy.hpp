#pragma once
#include <cstdint>
namespace nvs30::presentation {
constexpr std::uint32_t test_flag=1;
constexpr std::uint32_t still_drawing=0x887a000a;
constexpr std::uint32_t occluded=0x087a0001;
enum class Request { frame, probe, original };
inline Request request(unsigned sync,unsigned flags,bool partial_update) {
    if(sync>4||partial_update)return Request::original;
    if(flags==test_flag)return Request::probe;
    return flags==0?Request::frame:Request::original;
}
inline bool fatal(std::int32_t result) {
    return result<0 && static_cast<std::uint32_t>(result)!=still_drawing;
}
// Used by the live Present hook and host fault-injection tests. The fallback
// runs exactly once on a fatal failure, after bridge resources retire.
template<class Shadow,class Accepted,class Retire,class Original>
std::int32_t submit(bool probe,Shadow&& shadow,Accepted&& accepted,Retire&& retire,Original&& original) {
    const auto result=static_cast<std::int32_t>(shadow());
    if(fatal(result)){retire(result);return static_cast<std::int32_t>(original());}
    if(result==0&&!probe)accepted();
    return result;
}
enum class Activity { within_window, unobserved, retire_unconfirmed };
class ProgressWindow {
public:
    static constexpr unsigned limit=64;
    void start(std::uint64_t current) noexcept {baseline_=current;frames_=0;}
    bool accepted(std::uint64_t current) noexcept {
        if(current>baseline_){baseline_=current;frames_=0;return true;}
        if(frames_<limit)++frames_;
        return frames_<limit;
    }
    Activity assess(std::uint64_t current,bool native_wrapper) noexcept {
        if(accepted(current))return Activity::within_window;
        // CUDA interception is incomplete. Silence is not evidence that an
        // independently identified NvPresent wrapper stopped generating frames.
        return native_wrapper?Activity::unobserved:Activity::retire_unconfirmed;
    }
private:
    std::uint64_t baseline_{};
    unsigned frames_{};
};
}
