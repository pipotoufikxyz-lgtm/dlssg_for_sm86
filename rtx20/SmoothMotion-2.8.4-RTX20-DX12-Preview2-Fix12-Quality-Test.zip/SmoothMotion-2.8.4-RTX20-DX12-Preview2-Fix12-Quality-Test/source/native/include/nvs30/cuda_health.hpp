#pragma once
#include <atomic>
#include <cstdint>
namespace nvs30::cuda_health {
enum class Operation {ModuleLoad,Execution};
class Failures {
    std::atomic<std::uint64_t> modules_{0},execution_{0};
public:
    void record(Operation operation,int result) noexcept {
        if(!result)return;
        (operation==Operation::ModuleLoad?modules_:execution_).fetch_add(1,std::memory_order_relaxed);
    }
    std::uint64_t modules() const noexcept{return modules_.load(std::memory_order_relaxed);}
    std::uint64_t execution() const noexcept{return execution_.load(std::memory_order_relaxed);}
    std::uint64_t total() const noexcept{return modules()+execution();}
};
}
