#pragma once
namespace nvs30::slot_patch {
struct Result {bool installed=false;bool protection_restored=true;};
// Compare/exchange only pointer data. If restoring page protection fails,
// undo our own value without overwriting a pointer installed by a later owner.
template<class Read,class Acquire,class Exchange,class Restore>
Result apply(void* expected,void* replacement,Read&& read,Acquire&& acquire,
             Exchange&& exchange,Restore&& restore) {
    void* current{};
    if(!expected||!replacement||!read(current))return {};
    if(current==replacement)return {true,true};
    if(current!=expected||!acquire())return {};
    const auto observed=exchange(expected,replacement);
    const bool changed=observed==expected;
    if(restore())return {changed||observed==replacement,true};
    if(changed)exchange(replacement,expected);
    return {false,restore()};
}
}
