#include <utility>
// Included after the ordinary graphics dispatch helpers. Each thunk is bound
// to one immutable provider row and forwards to that exact export, preserving
// Streamline's own device/factory wrappers and the caller's API arguments.
template<std::size_t Slot,graphics_provider::Api Api,class Fn,bool Named=false> Fn providerTarget(){
 if constexpr(Named)return reinterpret_cast<Fn>(imports::named::graphics.target(Slot,Api));
 else return reinterpret_cast<Fn>(imports::providers.target(Slot,Api));
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderFactory(REFIID iid,void** result){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::factory,decltype(&CreateDXGIFactory),Named>();
 if(!real)return E_UNEXPECTED;
 return createFactory((Named?"Named!CreateDXGIFactory":"Streamline!CreateDXGIFactory"),caller,real,iid,result);
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderFactory1(REFIID iid,void** result){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::factory1,decltype(&CreateDXGIFactory1),Named>();
 if(!real)return E_UNEXPECTED;
 return createFactory((Named?"Named!CreateDXGIFactory1":"Streamline!CreateDXGIFactory1"),caller,real,iid,result);
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderFactory2(UINT flags,REFIID iid,void** result){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::factory2,decltype(&CreateDXGIFactory2),Named>();
 if(!real)return E_UNEXPECTED;
 return createFactory((Named?"Named!CreateDXGIFactory2":"Streamline!CreateDXGIFactory2"),caller,[&](REFIID id,void** out){return real(flags,id,out);},iid,result);
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderDevice12(IUnknown* adapter,D3D_FEATURE_LEVEL level,REFIID iid,void** result){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::device12,decltype(&D3D12CreateDevice),Named>();
 if(!real)return E_UNEXPECTED;
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime((Named?"Named!D3D12CreateDevice":"Streamline!D3D12CreateDevice"),caller);},
  [&]{return real(adapter,level,iid,result);},[](HRESULT){});
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderDevice11(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::device11,decltype(&D3D11CreateDevice),Named>();
 if(!real)return E_UNEXPECTED;
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime((Named?"Named!D3D11CreateDevice":"Streamline!D3D11CreateDevice"),caller);},
  [&]{return real(adapter,type,software,flags,levels,count,sdk,device,level,context);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&observeGraphicsObjects()){if(device&&*device)observeDevice(*device);else if(context&&*context){Com<ID3D11Device> actual;(*context)->GetDevice(actual.put());observeDevice(actual.p);}}});
}
template<std::size_t Slot,bool Named=false> HRESULT WINAPI onProviderDevice11Swap(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,const DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** swap,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 const void* caller=NVS30_CALLER_ADDRESS();
 auto real=providerTarget<Slot,graphics_provider::device11Swap,decltype(&D3D11CreateDeviceAndSwapChain),Named>();
 if(!real)return E_UNEXPECTED;
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime((Named?"Named!D3D11CreateDeviceAndSwapChain":"Streamline!D3D11CreateDeviceAndSwapChain"),caller);if(desc)beforeSwapchain(desc->OutputWindow);},
  [&]{return real(adapter,type,software,flags,levels,count,sdk,desc,swap,device,level,context);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&device&&*device)observeDevice(*device);if(SUCCEEDED(hr)&&swap&&*swap)registerSwapchain(*swap);});
}
template<std::size_t Slot,bool Named=false> std::array<void*,graphics_provider::apiCount> providerRow(){
 return {{reinterpret_cast<void*>(&onProviderFactory<Slot,Named>),reinterpret_cast<void*>(&onProviderFactory1<Slot,Named>),
  reinterpret_cast<void*>(&onProviderFactory2<Slot,Named>),reinterpret_cast<void*>(&onProviderDevice12<Slot,Named>),
  reinterpret_cast<void*>(&onProviderDevice11<Slot,Named>),reinterpret_cast<void*>(&onProviderDevice11Swap<Slot,Named>)}};
}
namespace imports {
const std::array<std::array<void*,graphics_provider::apiCount>,graphics_provider::capacity> providerWrappers{{
 providerRow<0>(),providerRow<1>(),providerRow<2>(),providerRow<3>()}};
}

namespace imports::named {
template<std::size_t... I> auto graphicsRows(std::index_sequence<I...>){return std::array<std::array<void*,graphics_provider::apiCount>,sizeof...(I)>{{providerRow<I,true>()...}};}
const std::array<std::array<void*,graphics_provider::apiCount>,graphicsCapacity> graphicsWrappers=graphicsRows(std::make_index_sequence<graphicsCapacity>{});
}
