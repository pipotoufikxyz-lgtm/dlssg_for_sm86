#pragma once
#include <string>
#include <string_view>
#include "module_origin.hpp"
#include "presentation_profile.hpp"

namespace nvs30::startup_bootstrap {
enum class Profile { graphics_call, dead_space, genshin, kingdom_come_2 };
enum class MarkerKind { unavailable, file, directory };
constexpr const char* policyName(Profile profile) noexcept {
 switch(profile){
  case Profile::dead_space:return "dead_space_early";
  case Profile::genshin:return "genshin_early";
  case Profile::kingdom_come_2:return "kcd2_early";
  default:return "graphics_call";
 }
}
constexpr const char* title(Profile profile) noexcept {
 switch(profile){
  case Profile::dead_space:return "Dead Space";
  case Profile::genshin:return "Genshin Impact";
  case Profile::kingdom_come_2:return "Kingdom Come II";
  default:return "Unselected game";
 }
}
// Probe only the reported executable and its adjacent game marker. Filename
// alone, storefront, engine or a similarly named launcher cannot select early
// initialization. The caller must establish a safe loader context first.
template<class Inspect>
Profile selectProfile(std::wstring_view executable,Inspect inspect) {
 if(presentation_profile::kcd2_layout(executable)){
  const auto directory=executable.substr(0,executable.find_last_of(L"\\/"));
  const auto bin=directory.substr(0,directory.find_last_of(L"\\/")+1);
  const auto engine=std::wstring(bin)+L"Win64Shared\\WHGame.dll";
  return inspect(engine.c_str())==MarkerKind::file?Profile::kingdom_come_2:Profile::graphics_call;
 }
 const auto name=module_origin::filename(executable);
 Profile profile;const wchar_t* marker;MarkerKind kind;
 if(module_origin::equal(name,L"Dead Space.exe")){
  profile=Profile::dead_space;marker=L"Engine.Render.Core2.PlatformPcDx12.dll";kind=MarkerKind::file;
 }else if(module_origin::equal(name,L"GenshinImpact.exe")){
  profile=Profile::genshin;marker=L"GenshinImpact_Data";kind=MarkerKind::directory;
 }else return Profile::graphics_call;
 const auto slash=executable.find_last_of(L"\\/");
 if(slash==std::wstring_view::npos)return Profile::graphics_call;
 const auto adjacent=std::wstring(executable.substr(0,slash+1))+marker;
 return inspect(adjacent.c_str())==kind?profile:Profile::graphics_call;
}
}
