#pragma once
#include <array>
#include <cstddef>
namespace nvs30 {
// No allocation after installing an executable callback. Each record retains
// its exact original (including a delay-loader thunk), not a guessed export.
template<std::size_t Capacity> class PointerJournal {
public:
    template<class Write> bool install(void** slot, void* replacement, Write&& write) {
        if (!slot || !*slot || !replacement) return false;
        for (const auto& entry : entries_)
            if (entry.slot == slot) return entry.replacement == replacement && *slot == replacement;
        // A pointer already redirected by somebody else has no recoverable
        // original in this journal. Never manufacture an ownership record.
        if (*slot == replacement) return false;
        for (auto& entry : entries_) if (!entry.slot) {
            entry = {slot, *slot, replacement};
            if (write(slot, replacement)) return true;
            entry = {}; return false;
        }
        return false;
    }
    template<class Write> bool restore(Write&& write) {
        bool complete = true;
        for (auto& entry : entries_) {
            if (!entry.slot) continue;
            if (*entry.slot != entry.replacement) { entry = {}; continue; }
            if (write(entry.slot, entry.original)) entry = {};
            else complete = false; // Retain ownership so a later rollback can retry.
        }
        return complete;
    }
    std::size_t size() const {
        std::size_t count = 0; for (const auto& entry : entries_) count += entry.slot != nullptr; return count;
    }
private:
    struct Entry { void** slot{}; void* original{}; void* replacement{}; };
    std::array<Entry, Capacity> entries_{};
};
}
