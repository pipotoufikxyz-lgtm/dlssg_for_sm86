#pragma once
#include <cstdint>
#include <limits>

namespace nvs30::gpu_wait {
constexpr auto removed = std::numeric_limits<std::uint64_t>::max();
constexpr auto device_removed = static_cast<std::int32_t>(0x887a0005u);
constexpr auto timeout = static_cast<std::int32_t>(0x80070102u);

// The fence value is authoritative. An event can still carry a notification
// from an earlier target; consuming it must not imply GPU completion. Register
// once, recheck after every wake, and share one deadline across all waits.
template<class Completed, class Arm, class Wait, class Clock>
std::int32_t fence(std::uint64_t target, unsigned budget_ms,
                   Completed&& completed, Arm&& arm, Wait&& wait, Clock&& clock) {
    if (!target) return 0;
    const auto start = clock();
    auto value = completed();
    if (value == removed) return device_removed;
    if (value >= target) return 0;
    const auto armed = static_cast<std::int32_t>(arm(target));
    if (armed < 0) return armed;
    for (;;) {
        value = completed();
        if (value == removed) return device_removed;
        if (value >= target) return 0;
        const auto elapsed = clock() - start;
        if (elapsed >= budget_ms) return timeout;
        const auto result = static_cast<std::int32_t>(wait(budget_ms - static_cast<unsigned>(elapsed)));
        if (result == timeout) {
            // Completion may race the timeout return. Keep the real fence
            // state, including device removal, rather than fabricate a hang.
            value = completed();
            if (value == removed) return device_removed;
            return value >= target ? 0 : timeout;
        }
        if (result < 0) return result;
    }
}
}
