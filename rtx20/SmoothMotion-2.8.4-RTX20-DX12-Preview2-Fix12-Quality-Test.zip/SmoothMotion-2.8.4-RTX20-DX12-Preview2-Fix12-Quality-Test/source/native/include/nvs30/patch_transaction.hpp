#pragma once
#include <array>
#include <cstddef>
#include <cstring>
namespace nvs30::patch_transaction {
// Small validated instruction/config/import patches only. Retain original
// bytes even if restoring page protection fails after the replacement write.
template<class Acquire,class Store,class Flush,class Restore>
bool apply(const void* destination,const void* replacement,std::size_t size,
           Acquire&& acquire,Store&& store,Flush&& flush,Restore&& restore) {
    if(!destination||!replacement||!size||size>64)return false;
    std::array<unsigned char,64> before{};
    std::memcpy(before.data(),destination,size);
    if(!acquire())return false;
    store(replacement,size);
    if(flush()){
        if(restore())return true;
    }
    // Neither a failed cache flush nor a failed protection restore may leave
    // new bytes behind while the caller believes the operation never happened.
    store(before.data(),size);
    flush();restore();return false;
}
}
