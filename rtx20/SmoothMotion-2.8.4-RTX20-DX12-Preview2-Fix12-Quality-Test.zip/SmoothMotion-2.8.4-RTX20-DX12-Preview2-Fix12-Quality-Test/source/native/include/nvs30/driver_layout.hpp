#pragma once
// Read-only PE validation. No Windows dependencies: exercised on the host under
// ASan/UBSan and shared by the injected runtime and diagnostics collector.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>
#include "driver_profile.hpp"

namespace nvs30::driver_layout {
constexpr std::size_t limit = 64u * 1024 * 1024;
struct Section {
    std::string name;
    std::uint32_t rva{}, size{}, raw{}, bytes{}, flags{};
};
struct Image {
    std::uint32_t size{}, entry{};
    std::array<std::pair<std::uint32_t, std::uint32_t>, 16> directories{};
    std::vector<Section> sections;
};
inline bool range(std::size_t at, std::size_t bytes, std::size_t size) {
    return at <= size && bytes <= size - at;
}
template<class T> inline T read(const std::vector<unsigned char>& b, std::size_t at) {
    T value{}; if (range(at, sizeof value, b.size())) std::memcpy(&value, b.data()+at, sizeof value);
    return value;
}
inline std::size_t offset(const Image& pe, std::uint32_t rva, std::size_t count) {
    for (const auto& s : pe.sections) {
        if (rva >= s.rva && range(rva-s.rva, count, std::min(s.size,s.bytes)))
            return std::size_t(s.raw) + rva-s.rva;
    }
    return std::numeric_limits<std::size_t>::max();
}
inline bool parse(const std::vector<unsigned char>& b, Image& result) {
    result={}; Image pe;
    if(b.size()<64 || b.size()>limit || read<std::uint16_t>(b,0)!=0x5a4d) return false;
    const std::size_t nt=read<std::uint32_t>(b,60);
    if(nt<64 || !range(nt,24,b.size()) || read<std::uint32_t>(b,nt)!=0x4550 ||
       read<std::uint16_t>(b,nt+4)!=0x8664 || !(read<std::uint16_t>(b,nt+22)&0x2000)) return false;
    const auto count=read<std::uint16_t>(b,nt+6), optional=read<std::uint16_t>(b,nt+20);
    if(!count || count>96 || optional<240 || !range(nt+24,optional,b.size())) return false;
    const auto opt=nt+24, table=opt+optional;
    if(read<std::uint16_t>(b,opt)!=0x20b || read<std::uint32_t>(b,opt+108)!=16 ||
       !range(table,std::size_t(count)*40,b.size())) return false;
    const auto headers=read<std::uint32_t>(b,opt+60);
    pe.size=read<std::uint32_t>(b,opt+56);pe.entry=read<std::uint32_t>(b,opt+16);
    if(pe.size>limit || headers<table+std::size_t(count)*40 || headers>b.size() || pe.entry>=pe.size) return false;
    for(unsigned i=0;i<count;++i) {
        const auto at=table+i*40;
        Section s;std::size_t nameLength=0;while(nameLength<8 && b[at+nameLength])++nameLength;
        s.name.assign(reinterpret_cast<const char*>(b.data()+at),nameLength);
        s.size=read<std::uint32_t>(b,at+8);s.rva=read<std::uint32_t>(b,at+12);
        s.bytes=read<std::uint32_t>(b,at+16);s.raw=read<std::uint32_t>(b,at+20);s.flags=read<std::uint32_t>(b,at+36);
        const auto mapped=std::max(s.size,s.bytes);
        if(!mapped || s.rva<headers || !range(s.rva,mapped,pe.size) ||
           (s.bytes && (s.raw<headers || !range(s.raw,s.bytes,b.size())))) return false;
        for(const auto& previous:pe.sections) {
            if(s.name==previous.name ||
               (s.rva<previous.rva+std::max(previous.size,previous.bytes) && previous.rva<s.rva+mapped) ||
               (s.bytes && previous.bytes && s.raw<previous.raw+previous.bytes && previous.raw<s.raw+s.bytes)) return false;
        }
        pe.sections.push_back(s);
    }
    for(unsigned i=0;i<16;++i) {
        auto& d=pe.directories[i];d={read<std::uint32_t>(b,opt+112+i*8),read<std::uint32_t>(b,opt+116+i*8)};
        if(!d.first&&!d.second)continue;
        if(!d.first||!d.second)return false;
        if(i==4) { // Authenticode uses a FILE OFFSET, not an RVA.
            if(!range(d.first,d.second,b.size()))return false;
            for(const auto& s:pe.sections)if(s.bytes && d.first<s.raw+s.bytes && s.raw<d.first+d.second)return false;
        } else if(offset(pe,d.first,d.second)==std::numeric_limits<std::size_t>::max())return false;
    }
    result=std::move(pe);return true;
}
inline std::uint32_t export_rva(const Image& pe,const std::vector<unsigned char>& b,const char* symbol) {
    const auto d=pe.directories[0];const auto at=offset(pe,d.first,40);
    if(d.second<40 || !range(at,40,b.size()))return 0;
    const auto functions=read<std::uint32_t>(b,at+20), count=read<std::uint32_t>(b,at+24);
    if(!count || count>4096 || !functions || functions>4096)return 0;
    const auto names=offset(pe,read<std::uint32_t>(b,at+32),count*4);
    const auto ordinals=offset(pe,read<std::uint32_t>(b,at+36),count*2);
    const auto addresses=offset(pe,read<std::uint32_t>(b,at+28),functions*4);
    if(!range(names,count*4,b.size()) || !range(ordinals,count*2,b.size()) || !range(addresses,functions*4,b.size()))return 0;
    std::uint32_t result=0;
    for(unsigned i=0;i<count;++i) {
        const auto name=offset(pe,read<std::uint32_t>(b,names+i*4),std::strlen(symbol)+1);
        if(!range(name,std::strlen(symbol)+1,b.size()) || std::memcmp(b.data()+name,symbol,std::strlen(symbol)+1))continue;
        const auto ordinal=read<std::uint16_t>(b,ordinals+i*2);
        if(ordinal>=functions || result)return 0;
        result=read<std::uint32_t>(b,addresses+ordinal*4);
        if(result>=d.first && result-d.first<d.second)return 0; // forwarded export
    }
    return result;
}
inline bool reference_layout(const Image& pe,const std::vector<unsigned char>& b) {
    // This describes the supplied reference's CPU ABI, not a driver version
    // string. Certificate/timestamp/raw placement changes do not change it.
    const std::array<Section,8> expected{{
        {".text",0x1000,0x1d082c,0,0x1d0a00,0x60000020},
        {".rdata",0x1d2000,0x5bb60,0,0x5bc00,0x40000040},
        {".data",0x22e000,0x5b36e4,0,0x5a9a00,0xc0000040},
        {".pdata",0x7e2000,0x27a38,0,0x27c00,0x40000040},
        {".detourc",0x80a000,0x2230,0,0x2400,0x40000040},
        {".detourd",0x80d000,0x18,0,0x200,0xc0000040},
        {"_RDATA",0x80e000,0x15c,0,0x200,0x40000040},
        {".reloc",0x80f000,0x195c,0,0x1a00,0x42000040}
    }};
    if(pe.size!=0x811000 || pe.entry!=0x11b07c || pe.sections.size()!=expected.size())return false;
    for(std::size_t i=0;i<expected.size();++i) {
        const auto& a=expected[i];const auto& s=pe.sections[i];
        if(s.name!=a.name || s.rva!=a.rva || s.size!=a.size || s.bytes!=a.bytes || s.flags!=a.flags)return false;
    }
    // Keep CPU-facing directory locations and extents fixed; signing and
    // debug metadata can differ between distributions of identical code.
    const std::array<std::pair<std::uint32_t,std::uint32_t>,16> dirs{{
        {0x22b990,0x108},{0x22ba98,0xb4},{0,0},{0x7e2000,0x27a38},{0,0},{0x80f000,0x195c},{0,0},{0,0},
        {0,0},{0x1e7400,0x28},{0x1e7160,0x140},{0,0},{0x1d2000,0x920},{0,0},{0,0},{0,0}
    }};
    for(unsigned i=0;i<16;++i)if(i!=4 && i!=6 && pe.directories[i]!=dirs[i])return false;
    return export_rva(pe,b,"NVP_Init_D3D")==0x59e0;
}
// Exact 617.14 layout: this route also requires the full input/output hashes.
inline bool layout61714(const Image& pe,const std::vector<unsigned char>& b){
    const std::array<Section,8> expected{{
        {".text",0x1000,0x1ee1ec,0x400,0x1ee200,0x60000020},
        {".rdata",0x1f0000,0x6311e,0x1ee600,0x63200,0x40000040},
        {".data",0x254000,0x5a83dc,0x251800,0x59ce00,0xc0000040},
        {".pdata",0x7fd000,0x29ef8,0x7ee600,0x2a000,0x40000040},
        {".detourc",0x827000,0x2230,0x818600,0x2400,0x40000040},
        {".detourd",0x82a000,0x18,0x81aa00,0x200,0xc0000040},
        {"_RDATA",0x82b000,0x15c,0x81ac00,0x200,0x40000040},
        {".reloc",0x82c000,0x196c,0x81ae00,0x1a00,0x42000040},
    }};
    if(pe.size!=0x82e000||pe.entry!=0x138a4c||pe.sections.size()!=expected.size())return false;
    for(std::size_t i=0;i<expected.size();++i){const auto& a=expected[i];const auto& s=pe.sections[i];
        if(s.name!=a.name||s.rva!=a.rva||s.size!=a.size||s.raw!=a.raw||s.bytes!=a.bytes||s.flags!=a.flags)return false;}
    return export_rva(pe,b,"NVP_Init_D3D")==driver_profile::init_rva;
}
struct Verdict {bool accepted{};bool reference{};const char* reason="unrecognized executable layout";driver_profile::Kind profile=driver_profile::Kind::none;};
inline bool reference_loader_header(const std::vector<unsigned char>& b){
    // Section hashes cannot protect PE header controls. In particular, a new
    // preferred base changes relocation results even with identical sections.
    // Only non-loading metadata (timestamp/checksum/certificate/debug details)
    // may differ on the normalized reference route.
    const auto nt=read<std::uint32_t>(b,60);const std::size_t opt=std::size_t(nt)+24;
    if(!range(nt,24,b.size())||!range(opt,240,b.size()))return false;
    if(read<std::uint16_t>(b,nt+20)!=240||read<std::uint16_t>(b,nt+22)!=0x2022)return false;
    if(read<std::uint64_t>(b,opt+24)!=0x180000000ull||
       read<std::uint32_t>(b,opt+32)!=0x1000||read<std::uint32_t>(b,opt+36)!=0x200||
       read<std::uint32_t>(b,opt+60)!=0x400)return false;
    if(read<std::uint16_t>(b,opt+40)!=6||read<std::uint16_t>(b,opt+42)!=0||
       read<std::uint16_t>(b,opt+48)!=6||read<std::uint16_t>(b,opt+50)!=0||
       read<std::uint32_t>(b,opt+52)!=0||read<std::uint16_t>(b,opt+68)!=2||
       read<std::uint16_t>(b,opt+70)!=0x160)return false;
    return read<std::uint64_t>(b,opt+72)==0x100000&&read<std::uint64_t>(b,opt+80)==0x1000&&
           read<std::uint64_t>(b,opt+88)==0x100000&&read<std::uint64_t>(b,opt+96)==0x1000&&
           read<std::uint32_t>(b,opt+104)==0;
}
// Complete initialized section bytes in their validated table order. Layout
// comparison independently fixes RVA/size/flags. COFF timestamp, checksum,
// certificates and raw alignment padding are deliberately outside this hash.
// CUDA objects and all their bytes remain inside it, unlike code-only hashes.
template<class Hash> inline std::string section_fingerprint(const Image& pe,const std::vector<unsigned char>& b,Hash hash){
    std::vector<unsigned char> initialized;initialized.reserve(b.size());
    for(const auto& s:pe.sections){const auto n=std::min(s.size,s.bytes);if(!range(s.raw,n,b.size()))return {};
        initialized.insert(initialized.end(),b.begin()+s.raw,b.begin()+s.raw+n);}
    return hash(initialized.data(),initialized.size());
}
template<class Hash> inline Verdict validate(const Image& pe,const std::vector<unsigned char>& b,
                                             const std::string& fileHash,Hash hash) {
    const auto profile=driver_profile::identify(fileHash,b.size());
    if(profile!=driver_profile::Kind::none){
        if(!(profile==driver_profile::Kind::nvidia61714?layout61714(pe,b):reference_layout(pe,b)))
            return {false,false,"exact profile CPU ABI differs"};
        const auto& code=pe.sections.front();
        if(hash(b.data()+code.raw,code.size)!=driver_profile::expected_code(profile))return {false,false,"exact profile CPU code fingerprint differs"};
        std::vector<unsigned char> transformed;const char* reason{};
        if(!driver_profile::prepare(b,hash,transformed,reason))return {false,false,reason};
        return {true,true,profile==driver_profile::Kind::nvidia61714?"exact 617.14 profile; 61-site ELF ABI 8 transform oracle verified":profile==driver_profile::Kind::golden61664?"exact 616.64 profile; 41-site transform oracle verified":"supplied reference; 41-site transform oracle verified",profile};
    }
    if(fileHash=="cd395d58f41c6e393c31a9898f2be3da83f7bc109a2228935c23e8c89b944c15")return {true,false,"upstream reference file"};
    if(!reference_layout(pe,b))return {};
    if(!reference_loader_header(b))return {false,false,"reference loader header controls differ"};
    // The reviewed edits use file offsets. Require the patch-bearing sections
    // to retain their known file placement rather than guessing a translation.
    if(pe.sections[0].raw!=0x400||pe.sections[2].raw!=0x22ca00)return {false,false,"reference patch section file placement differs"};
    if(section_fingerprint(pe,b,hash)!=driver_profile::reference_sections_sha256)
        return {false,false,"complete CPU/CUDA initialized-section fingerprint differs"};
    std::vector<unsigned char> transformed;
    if(!driver_profile::apply_sites_for_validation(b,transformed)||
       section_fingerprint(pe,transformed,hash)!=driver_profile::reference_output_sections_sha256)
        return {false,false,"reference metadata variant transform oracle differs"};
    return {true,true,"complete reference CPU/CUDA sections and transform verified; different file metadata",driver_profile::Kind::suppliedReference};
}
}
