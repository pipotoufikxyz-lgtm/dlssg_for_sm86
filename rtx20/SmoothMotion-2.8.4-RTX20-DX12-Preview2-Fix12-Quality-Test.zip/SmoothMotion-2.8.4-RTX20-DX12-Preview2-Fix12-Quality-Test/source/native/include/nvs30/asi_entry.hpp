// Shared by the exported ASI entry and its host regression. The loader calls
// this after loading the plugin. The early-start helper checks loader context.
inline void initializeAsiEntry() {
 nvs30::dxgi::asi_startup();
 start();
}
