#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <span>
#include <vector>
namespace nvs30::fatbin {
struct RewriteStats {std::uint32_t entries{},cubins{},sm89_to_sm86{},sm120_left{},elf_headers{};};
struct RewrittenImage {std::vector<std::byte> bytes;RewriteStats stats;bool valid{};};
template<class T> inline T read(const std::byte* p){T v{};std::memcpy(&v,p,sizeof v);return v;}
template<class T> inline void write(std::byte* p,T v){std::memcpy(p,&v,sizeof v);}
inline RewrittenImage rewrite(std::span<const std::byte> input){
 RewrittenImage out;
 if(input.size()<16||read<std::uint32_t>(input.data())!=0xba55ed50||read<std::uint16_t>(input.data()+4)!=1)return out;
 auto header=read<std::uint16_t>(input.data()+6);auto payload=read<std::uint64_t>(input.data()+8);
 if(header<16||header>256||header>input.size()||payload>64u*1024*1024||payload>input.size()-header)return out;
 const auto total=header+std::size_t(payload);out.bytes.assign(input.begin(),input.begin()+total);
 for(std::size_t pos=header;pos<total;){
  if(total-pos<32)return {};
  auto* e=out.bytes.data()+pos;auto eh=read<std::uint32_t>(e+4);auto ds=read<std::uint64_t>(e+8);
  auto kind=read<std::uint16_t>(e),version=read<std::uint16_t>(e+2);auto arch=read<std::uint32_t>(e+28);
  if(version!=0x101||eh<32||eh>1024||eh>total-pos||ds>total-pos-eh)return {};
  auto* elf=e+eh;++out.stats.entries;if(kind==2)++out.stats.cubins;if(arch==120)++out.stats.sm120_left;
  if(kind==2&&arch==89){
   // Only uncompressed little-endian ELF64 CUDA objects. Changing metadata
   // is experimental retargeting, NOT instruction translation or ISA proof.
   if(ds<64||std::memcmp(elf,"\177ELF",4)||elf[4]!=std::byte{2}||elf[5]!=std::byte{1}||
      read<std::uint16_t>(elf+18)!=190||read<std::uint16_t>(elf+52)!=64)return {};
   const auto flags=read<std::uint32_t>(elf+48);
   if((flags&255)!=89||((flags>>16)&255)!=89)return {};
   write<std::uint32_t>(e+28,86);write<std::uint32_t>(elf+48,(flags&~0x00ff00ffu)|0x00560056u);
   ++out.stats.sm89_to_sm86;++out.stats.elf_headers;
  }
  std::size_t next=pos+eh+std::size_t(ds);if(next>total||total-next<(8-next%8)%8)return {};
  next=(next+7)&~std::size_t(7);if(next<=pos||next>total)return {};pos=next;
 }
 out.valid=out.stats.entries!=0;return out;
}
}
