#pragma once

#include <cstddef>
#include <cstdint>

namespace nvs30::init_trace {

// Arms passive first-chance diagnostics only around the first explicit driver
// initializer. Construct outside DllMain, after the module's size was validated.
// The handler's own DLL is pinned, and its append handle remains open until
// process exit: disarming never frees resources an in-flight handler may use.
// This does not catch, recover from, or prove a terminal crash. Fail-fast paths
// and exhausted stacks may bypass the handler entirely.
class Scope {
public:
    Scope(const void* nvPresent, std::size_t imageBytes) noexcept;
    ~Scope() noexcept;
    Scope(const Scope&) = delete;
    Scope& operator=(const Scope&) = delete;
    bool active() const noexcept { return active_; }
private:
    bool active_{};
};

namespace detail {
// Deliberately exclude language exceptions, single-step, guard-page faults and
// other routine notifications. Breakpoint is relevant to NvPresent's explicit
// INT3 on a failed factory-hook transaction; it is observed, never skipped.
constexpr bool accepted(std::uint32_t code) noexcept {
    return code == 0xc0000005u || code == 0xc0000006u ||
           code == 0xc000001du || code == 0xc00000fdu ||
           code == 0x80000003u;
}

struct Fault {
    std::uint32_t code{}, process{}, thread{}, initThread{}, parameterCount{};
    std::uint64_t address{}, moduleBase{}, moduleBytes{}, rip{}, rsp{};
    std::uint64_t rax{}, rcx{}, rdx{}, r8{}, r9{};
    std::uint64_t access{}, target{}, inPageStatus{};
};

// Bounded formatting shared by the handler and host regression. No allocation,
// locale, printf, recursion or buffer-size-dependent stack storage.
struct Writer {
    char* data;
    std::size_t capacity, used{};
    void character(char c) noexcept {
        if (used < capacity) data[used++] = c;
    }
    void text(const char* value) noexcept {
        while (*value) character(*value++);
    }
    void hex(std::uint64_t value) noexcept {
        text("0x");
        for (int shift = 60; shift >= 0; shift -= 4)
            character("0123456789abcdef"[(value >> shift) & 15u]);
    }
};

inline std::size_t format(char* out, std::size_t capacity, const Fault& f) noexcept {
    Writer w{out, capacity};
    w.text("event=first-chance-exception terminal=unknown phase=NVP_Init_D3D code=");
    w.hex(f.code);
    w.text(" address="); w.hex(f.address);
    w.text(" nvp_base="); w.hex(f.moduleBase);
    w.text(" nvp_rva=");
    if (f.address >= f.moduleBase && f.address - f.moduleBase < f.moduleBytes)
        w.hex(f.address - f.moduleBase);
    else
        w.text("outside");
    w.text(" pid="); w.hex(f.process);
    w.text(" tid="); w.hex(f.thread);
    w.text(" init_tid="); w.hex(f.initThread);
    w.text(" rip="); w.hex(f.rip);
    w.text(" rsp="); w.hex(f.rsp);
    w.text(" rax="); w.hex(f.rax);
    w.text(" rcx="); w.hex(f.rcx);
    w.text(" rdx="); w.hex(f.rdx);
    w.text(" r8="); w.hex(f.r8);
    w.text(" r9="); w.hex(f.r9);
    if ((f.code == 0xc0000005u || f.code == 0xc0000006u) && f.parameterCount >= 2) {
        w.text(" access=");
        w.text(f.access == 0 ? "read" : f.access == 1 ? "write" : f.access == 8 ? "execute" : "unknown");
        w.text(" access_raw="); w.hex(f.access);
        w.text(" target="); w.hex(f.target);
        if (f.code == 0xc0000006u && f.parameterCount >= 3) {
            w.text(" inpage_status="); w.hex(f.inPageStatus);
        }
    }
    w.character('\r'); w.character('\n');
    return w.used;
}

enum class Boundary { Begin, End };
inline std::size_t format_boundary(char* out, std::size_t capacity, Boundary event,
    std::uint32_t process, std::uint32_t thread, std::uint64_t base,
    std::uint64_t imageBytes) noexcept {
    Writer w{out, capacity};
    w.text(event == Boundary::Begin ? "event=init-trace-begin" : "event=init-trace-end");
    w.text(" phase=NVP_Init_D3D pid="); w.hex(process);
    w.text(" init_tid="); w.hex(thread);
    w.text(" nvp_base="); w.hex(base);
    w.text(" nvp_bytes="); w.hex(imageBytes);
    w.text(" first-chance-is-not-terminal-proof\r\n");
    return w.used;
}
}
}
