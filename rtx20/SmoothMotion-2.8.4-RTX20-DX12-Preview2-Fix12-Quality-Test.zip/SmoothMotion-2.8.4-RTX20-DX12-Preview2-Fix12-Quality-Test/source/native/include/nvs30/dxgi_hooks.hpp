#pragma once
#include "common.hpp"

namespace nvs30::dxgi {
bool install_hooks();
void asi_startup() noexcept;
void service_startup(bool standalone) noexcept;
void shutdown();
void set_internal_creation(bool value);
bool internal_creation();
bool native_wrapper(IUnknown* swapchain) noexcept;
}
