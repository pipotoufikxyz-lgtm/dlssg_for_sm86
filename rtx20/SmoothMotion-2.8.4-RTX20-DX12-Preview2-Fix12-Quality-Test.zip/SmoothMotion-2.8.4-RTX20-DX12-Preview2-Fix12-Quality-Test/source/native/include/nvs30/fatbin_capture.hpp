#pragma once
#include "fatbin_core.hpp"
#include <array>
#include <limits>

namespace nvs30::fatbin {
inline bool address_range(std::uintptr_t base,std::size_t offset,std::size_t bytes) noexcept {
    const auto last=std::numeric_limits<std::uintptr_t>::max();
    return base&&offset<=last-base&&(!bytes||bytes-1<=last-base-offset);
}

// Snapshot bytes through an exact-copy reader before parsing. A readable CUDA
// image can span several VirtualQuery regions with different page protections.
// The native adapter uses ReadProcessMemory, not raw pointer dereferences.
template<class Read> RewrittenImage capture_and_rewrite(Read&& copy) {
    std::array<std::byte,16> header{};
    if(!copy(0,header.data(),header.size())||
       read<std::uint32_t>(header.data())!=0xba55ed50||
       read<std::uint16_t>(header.data()+4)!=1)return {};
    const auto prefix=read<std::uint16_t>(header.data()+6);
    const auto payload=read<std::uint64_t>(header.data()+8);
    if(prefix<16||prefix>256||!payload||payload>64u*1024*1024)return {};
    std::vector<std::byte> image(std::size_t(prefix)+std::size_t(payload));
    if(!copy(0,image.data(),image.size())||
       std::memcmp(header.data(),image.data(),header.size()))return {};
    // The production parser validates every copied descriptor and ELF field.
    // Changing metadata remains experimental, not GPU instruction translation.
    return rewrite(image);
}
}
