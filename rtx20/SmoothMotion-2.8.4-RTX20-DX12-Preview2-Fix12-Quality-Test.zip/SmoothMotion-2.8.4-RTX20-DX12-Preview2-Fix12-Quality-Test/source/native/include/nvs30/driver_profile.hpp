#pragma once
// Exact binary-profile facts recovered from the public 0.5.0 distribution.
// Only offsets, byte values, hashes and API-layout facts are represented here;
// no archived Python code is used or executed by this implementation.
// 616.64 is an upstream reported validated profile, not a local GPU test result.
// 617.14 facts come from the official NVIDIA installer; see validation/driver-61714-gp9.json.
// Static CPU/CUDA inspection does not establish displayed frame generation.
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace nvs30::driver_profile {
enum class Kind { none, golden61664, suppliedReference, nvidia61714 };
inline constexpr const char source_sha256[]="f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e";
inline constexpr const char output_sha256[]="e6e578af927495084021cb7dfe9e008d066e1504f602a0b678caf35a5466887c";
inline constexpr const char reference_sha256[]="bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68";
// Independently calculated from the supplied reference by applying only the
// same 41 reviewed sites; this is static validation, not a live-GPU claim.
inline constexpr const char reference_output_sha256[]="b9387d39a872e2d6f9a6be7d8af572d10e8030697349b1f0127d00c6c6f1bfb8";
inline constexpr const char reference_code_sha256[]="148ed6f41d36b9c68d136a73c3d36be02d9cdd97dee3da550ab16b17c710d9cb";
inline constexpr const char reference_sections_sha256[]="2d19d8e11aa4fe0088e4ba413af8566242b0751f714d9d6f1146b5eec7cbaa74";
inline constexpr const char reference_output_sections_sha256[]="f6330bedc847d829e2fe6a63d766d9691d8678afcec7e32f0ca100203addfbeb";
// Independently reported by the affected system's read-only 2.7 diagnostics.
inline constexpr const char reported_code_sha256[]="d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0";
inline constexpr std::size_t source_size=8417512;
inline constexpr std::size_t source61714_size=8525544;
inline constexpr const char source61714_sha256[]="1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f";
inline constexpr const char output61714_sha256[]="bcdc615f9492070c7a9ba31addd910373766ad293e777abdcbface28ad493c49";
inline constexpr const char code61714_sha256[]="915c621dcf00abd740f8d6fcd5754040880e157e7eccd9f943dbc283a349aebe";
inline constexpr std::uint32_t init_rva=0x59e0, config_rva=0x7d7810;
inline constexpr std::uint32_t gate_file_offset=0xb81c, gate_rva=0xc41c;
inline constexpr std::size_t expected_changed_bytes=61, expected_sites=41, maximum_sites=61;
struct KernelSite {const char* name;std::uint32_t tag_offset,flags_offset,note_offset=0;};
inline constexpr std::array<KernelSite,20> non_fp8_kernels{{
    {"depth_to_space",0x484d1c,0x484d70},
    {"downscale_kernel",0x48c3ec,0x48c440},
    {"warp_coarse_kernel",0x4940ac,0x494100},
    {"attn1",0x4c8e14,0x4c8e68},
    {"attn2",0x50af54,0x50afa8},
    {"conv1",0x52366c,0x5236c0},
    {"conv2",0x52cc0c,0x52cc60},
    {"conv3",0x533a9c,0x533af0},
    {"conv4",0x53c02c,0x53c080},
    {"conv5",0x546e7c,0x546ed0},
    {"conv6",0x55617c,0x5561d0},
    {"conv7",0x570bd4,0x570c28},
    {"conv8",0x591aa4,0x591af8},
    {"conv_fused",0x5d9d7c,0x5d9dd0},
    {"conv_proj1",0x5f15a4,0x5f15f8},
    {"conv_proj2",0x623d24,0x623d78},
    {"conv_out1",0x641104,0x641158},
    {"conv_out2",0x648794,0x6487e8},
    {"conv_out3",0x64fa74,0x64fac8},
    {"main_kernel",0x7d2d04,0x7d2d58}
}};
// CUDA ELF ABI 8 stores SM in bits 8..15. Preserve every other flag bit.
inline constexpr std::array<KernelSite,20> non_fp8_kernels61714{{
    {"depth_to_space",0x4aa274,0x4aa2c8,0x4aacbc},
    {"downscale_kernel",0x4b246c,0x4b24c0,0x4b2f94},
    {"warp_coarse_kernel",0x4bae54,0x4baea8,0x4bb8dc},
    {"attn1",0x4ea444,0x4ea498,0x4ead8c},
    {"attn2",0x529564,0x5295b8,0x529ec4},
    {"conv1",0x542b8c,0x542be0,0x5434ec},
    {"conv2",0x54cf3c,0x54cf90,0x54d89c},
    {"conv3",0x554a54,0x554aa8,0x55539c},
    {"conv4",0x55e064,0x55e0b8,0x55e9c4},
    {"conv5",0x569f34,0x569f88,0x56a894},
    {"conv6",0x579c3c,0x579c90,0x57a584},
    {"conv7",0x594e6c,0x594ec0,0x5957b4},
    {"conv8",0x5b651c,0x5b6570,0x5b6e64},
    {"conv_fused",0x5eb594,0x5eb5e8,0x5ebf6c},
    {"conv_proj1",0x6045c4,0x604618,0x604fb4},
    {"conv_proj2",0x636f8c,0x636fe0,0x637964},
    {"conv_out1",0x6551c4,0x655218,0x655b9c},
    {"conv_out2",0x65d5e4,0x65d638,0x65dfbc},
    {"conv_out3",0x665664,0x6656b8,0x66603c},
    {"main_kernel",0x7eadcc,0x7eae20,0x7eb2a4},
}};
inline constexpr std::array<unsigned char,4> flags61714_before{{0x04,0x59,0x00,0x06}},flags61714_after{{0x04,0x56,0x00,0x06}};
inline constexpr std::size_t changed_bytes(Kind kind){return kind==Kind::none?0:expected_changed_bytes;}
inline constexpr std::array<unsigned char,4> note61714_before{{2,0,89,0}},note61714_after{{2,0,86,0}};
inline constexpr std::uint32_t config_rva_for(Kind kind){return kind==Kind::nvidia61714?0x7f0cd0:config_rva;}
inline constexpr bool runtime_sites_match(Kind kind,std::uintptr_t init,std::uintptr_t config,
                                         std::uintptr_t immediate,std::uintptr_t setge,std::size_t setge_size){
    return kind!=Kind::none && init==init_rva && config==config_rva_for(kind) &&
           immediate==gate_rva+3 && setge==0xc437 && setge_size==4;
}
inline constexpr std::array<unsigned char,4> gate_before{{0x83,0x79,0x14,0x03}},gate_after{{0x83,0x79,0x14,0x02}};
inline constexpr std::array<unsigned char,4> tag_before{{0x59,0,0,0}},tag_after{{0x56,0,0,0}};
inline constexpr std::array<unsigned char,4> flags_before{{0x59,0x05,0x59,0}},flags_after{{0x56,0x05,0x56,0}};
struct Edit {std::size_t offset;std::array<unsigned char,4> before,after;};
inline std::vector<Edit> edits(Kind kind=Kind::suppliedReference){
    if(kind==Kind::none)return {};
    std::vector<Edit> out;out.reserve(maximum_sites);
    out.push_back({gate_file_offset,gate_before,gate_after});
    const auto& kernels=kind==Kind::nvidia61714?non_fp8_kernels61714:non_fp8_kernels;
    for(const auto& k:kernels){
        out.push_back({k.tag_offset,tag_before,tag_after});
        out.push_back({k.flags_offset,kind==Kind::nvidia61714?flags61714_before:flags_before,
                                      kind==Kind::nvidia61714?flags61714_after:flags_after});
        if(kind==Kind::nvidia61714)out.push_back({k.note_offset,note61714_before,note61714_after});
    }
    return out;
}
inline bool source_identity(std::string_view hash,std::size_t bytes){return hash==source_sha256&&bytes==source_size;}
inline Kind identify(std::string_view hash,std::size_t bytes){
    if(hash==source61714_sha256&&bytes==source61714_size)return Kind::nvidia61714;
    if(bytes!=source_size)return Kind::none;
    return hash==source_sha256?Kind::golden61664:hash==reference_sha256?Kind::suppliedReference:Kind::none;
}
inline const char* expected_output(Kind kind){return kind==Kind::nvidia61714?output61714_sha256:kind==Kind::golden61664?output_sha256:kind==Kind::suppliedReference?reference_output_sha256:"";}
inline const char* expected_code(Kind kind){return kind==Kind::nvidia61714?code61714_sha256:kind==Kind::golden61664?reported_code_sha256:kind==Kind::suppliedReference?reference_code_sha256:"";}
inline bool original_sites(const std::vector<unsigned char>& source,Kind kind=Kind::suppliedReference){
    const auto plan=edits(kind);if(plan.empty())return false;
    for(std::size_t i=0;i<plan.size();++i){const auto& e=plan[i];
        if(e.offset>source.size()||e.before.size()>source.size()-e.offset||
           std::memcmp(source.data()+e.offset,e.before.data(),e.before.size()))return false;
        for(std::size_t j=0;j<i;++j)if(e.offset<plan[j].offset+plan[j].before.size()&&plan[j].offset<e.offset+e.before.size())return false;
    }
    return true;
}
// This helper makes only a candidate for hash validation, never an authorized
// runtime patch. Callers must check a full or reviewed complete-sections input identity
// and independently verify the matching output oracle before using it.
inline bool apply_sites_for_validation(const std::vector<unsigned char>& source,std::vector<unsigned char>& output,Kind kind=Kind::suppliedReference){
    if(&source==&output)return false;
    output.clear();if(!original_sites(source,kind))return false;
    auto candidate=source;
    for(const auto& e:edits(kind))std::memcpy(candidate.data()+e.offset,e.after.data(),e.after.size());
    std::size_t changed=0;for(std::size_t i=0;i<source.size();++i)changed+=source[i]!=candidate[i];
    if(changed!=changed_bytes(kind))return false;
    output=std::move(candidate);return true;
}
// Compute an independently checked candidate in memory. Does not modify a
// driver file, load a DLL, patch process memory or accept user manifests.
// The full output oracle ensures that all code/data outside the reviewed changed
// bytes—including all 17 FP8 objects and SM120 objects—remain untouched.
template<class Hash> inline bool prepare(const std::vector<unsigned char>& source,Hash hash,
                                         std::vector<unsigned char>& output,const char*& reason){
    if(&source==&output){reason="source/output alias is not allowed";return false;}
    output.clear();reason="unrecognized exact driver source";
    const auto kind=identify(hash(source.data(),source.size()),source.size());
    if(kind==Kind::none)return false;
    reason="exact driver original patch bytes differ";
    std::vector<unsigned char> candidate;if(!apply_sites_for_validation(source,candidate,kind))return false;
    reason="exact driver transformation output differs from reviewed oracle";
    if(hash(candidate.data(),candidate.size())!=expected_output(kind))return false;
    output=std::move(candidate);reason=kind==Kind::nvidia61714?"exact 617.14 source and 61-site/61-byte ELF ABI 8 transform verified":"exact 616.64 source and 41-site/61-byte transform verified";return true;
}
}
