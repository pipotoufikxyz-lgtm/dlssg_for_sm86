#pragma once
#include "initialization_gate.hpp"
#include <utility>

namespace nvs30 {
// Configuration and native initialization have one owner: an admitted graphics
// call or a selected early startup entry. Background import discovery does not
// own this gate. The winner runs both callbacks synchronously.
// Concurrent/reentrant callers retain InitializationGate's nonblocking path.
class GraphicsInitialization {
    InitializationGate gate;
public:
    template<class Configure,class Initialize>
    bool run(Configure&& configure,Initialize&& initialize) {
        return gate.run([&]{
            if(!std::forward<Configure>(configure)())return false;
            return std::forward<Initialize>(initialize)();
        });
    }
};
}
