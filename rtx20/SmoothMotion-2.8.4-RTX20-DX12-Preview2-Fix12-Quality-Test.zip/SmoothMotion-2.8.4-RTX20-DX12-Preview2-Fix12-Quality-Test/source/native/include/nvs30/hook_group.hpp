#pragma once
#include <array>
#include <cstddef>
namespace nvs30::hook_group {
struct Slot {void** address{};void* original{};void* replacement{};};
// Originals are published by the caller before installing callbacks. Validate
// the complete group first, and roll back only pointers changed by this attempt.
// Previously installed hooks remain available when a larger interface fails.
template<size_t N,class Read,class Patch>
bool install(const std::array<Slot,N>& slots,Read&& read,Patch&& patch){
 std::array<bool,N> already{},changed{};bool any=false;
 for(size_t i=0;i<N;++i){
  const auto& s=slots[i];if(!s.address)continue;any=true;
  if(!s.original||!s.replacement||s.original==s.replacement)return false;
  void* value{};if(!read(s.address,value))return false;
  if(value!=s.original&&value!=s.replacement)return false;
  already[i]=value==s.replacement;
 }
 if(!any)return false;
 for(size_t i=0;i<N;++i){
  const auto& s=slots[i];if(!s.address||already[i])continue;
  if(patch(s.address,s.original,s.replacement)){changed[i]=true;continue;}
  for(size_t j=i;j>0;--j)if(changed[j-1]){
   const auto& previous=slots[j-1];
   patch(previous.address,previous.replacement,previous.original);
  }
  return false;
 }
 return true;
}
}
