// Included after import discovery; never starts graphics initialization from a loader callback.
template<class Load> HMODULE loadAndRefresh(Load load,bool scan=true){
 auto loaded=load();const DWORD error=GetLastError();
 if(loaded&&scan){try{imports::refresh();}catch(...){}}
 SetLastError(error);return loaded;
}
HMODULE WINAPI onLoadLibraryA(LPCSTR path){return loadAndRefresh([&]{return LoadLibraryA(path);});}
HMODULE WINAPI onLoadLibraryW(LPCWSTR path){return loadAndRefresh([&]{return LoadLibraryW(path);});}
static_assert(LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE==0x40);
HMODULE WINAPI onLoadLibraryExA(LPCSTR path,HANDLE file,DWORD flags){return loadAndRefresh([&]{return LoadLibraryExA(path,file,flags);},module_watch::executable_load(flags));}
HMODULE WINAPI onLoadLibraryExW(LPCWSTR path,HANDLE file,DWORD flags){return loadAndRefresh([&]{return LoadLibraryExW(path,file,flags);},module_watch::executable_load(flags));}
HMODULE WINAPI onLoadPackagedLibrary(LPCWSTR path,DWORD reserved){return loadAndRefresh([&]{return LoadPackagedLibrary(path,reserved);});}
