#pragma once
#include "common.hpp"

namespace nvs30::nvpresent {
bool initialize();
void shutdown();
HMODULE module();
bool contains_address(const void* address);
bool wrapper_active(IDXGISwapChain* swapchain, void** wrapper = nullptr);
bool wrapper_active(IDXGISwapChain* swapchain, void** wrapper, std::size_t* offset);
bool initialized();
const char* initialization_status();
std::uint64_t cuda_success_count();
std::uint64_t cuda_activity_count();
std::uint64_t cuda_failure_count();
std::uint64_t cuda_module_failure_count();
std::uint64_t cuda_execution_failure_count();
std::uint64_t cuda_intercept_count();
}
