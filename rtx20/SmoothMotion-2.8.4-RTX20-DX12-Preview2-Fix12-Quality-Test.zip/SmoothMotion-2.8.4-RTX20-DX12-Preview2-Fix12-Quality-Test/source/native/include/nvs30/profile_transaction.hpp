#pragma once
#include "driver_profile.hpp"
namespace nvs30::profile_transaction {
enum class Result {Applied,PreflightRejected,RolledBack,RollbackIncomplete};
// The entire loaded-image contract is checked before mutation. Read/apply
// adapters also check each site's original bytes at the moment of its write.
template<class Read,class Apply,class Restore>
Result run(const std::vector<driver_profile::Edit>& edits,Read read,Apply apply,Restore restore){
    if(edits.empty()||edits.size()>driver_profile::maximum_sites)return Result::PreflightRejected;
    for(std::size_t i=0;i<edits.size();++i){
        std::array<unsigned char,4> bytes{};
        if(!read(i,bytes)||bytes!=edits[i].before)return Result::PreflightRejected;
    }
    for(std::size_t i=0;i<edits.size();++i){
        std::array<unsigned char,4> bytes{};
        if(!read(i,bytes)||bytes!=edits[i].before||!apply(i,edits[i].after)){
            bool restored=restore(i); // May have failed after changing bytes.
            for(std::size_t j=i;j-->0;)restored=restore(j)&&restored;
            return restored?Result::RolledBack:Result::RollbackIncomplete;
        }
    }
    return Result::Applied;
}
}
