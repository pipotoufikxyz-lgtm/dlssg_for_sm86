#pragma once
#include <atomic>
#include <utility>

namespace nvs30 {
// A hook must never wait for another thread that may be acquiring the Windows
// loader lock. The first caller initializes synchronously; concurrent callers
// retain the original API path. Reentry also returns immediately.
class InitializationGate {
    static_assert(std::atomic<unsigned>::is_always_lock_free);
    enum State:unsigned {Pending,Running,Ready,Rejected};
    std::atomic<unsigned> state{Pending};
public:
    template<class Initialize> bool run(Initialize&& initialize) {
        auto current=state.load(std::memory_order_acquire);
        if(current==Ready)return true;
        if(current!=Pending)return false;
        if(!state.compare_exchange_strong(current,Running,std::memory_order_acq_rel,std::memory_order_acquire))return current==Ready;
        try {
            const bool success=std::forward<Initialize>(initialize)();
            state.store(success?Ready:Rejected,std::memory_order_release);
            return success;
        } catch(...) {
            // Matching call_once exception semantics, an initializer that did
            // not publish its result can be retried by a later API call.
            state.store(Pending,std::memory_order_release);throw;
        }
    }
};
}
