#pragma once
#include <cstdint>
#include <optional>
namespace nvs30::bridge_retry {
struct Shape {
    std::uintptr_t window{};
    unsigned width{}, height{}, format{}, buffers{}, effect{}, samples{}, quality{}, flags{};
    bool windowed{};
    bool operator==(const Shape&) const = default;
};
// Owned by the swapchain, not by its replaceable GPU resources. Successful
// resize calls that leave the descriptor unchanged do not erase a failure.
class Attempts {
public:
    bool blocked(const Shape& shape) const { return failed_ && *failed_ == shape; }
    void failed(const Shape& shape) { failed_ = shape; }
    void succeeded() { failed_.reset(); }
private:
    std::optional<Shape> failed_;
};
}
