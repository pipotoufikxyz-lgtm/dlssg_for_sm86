#pragma once
#include "startup_bootstrap.hpp"

namespace nvs30::startup_bootstrap {
inline Context loaderContext() noexcept {
 const DWORD saved=GetLastError();
 // Resolve a resident ntdll export, without acquiring the loader lock or
 // reading undocumented PEB offsets. A missing API defers early startup.
 using InCallout=BOOLEAN(NTAPI*)();
 const auto ntdll=GetModuleHandleW(L"ntdll.dll");
 const auto probe=ntdll?reinterpret_cast<InCallout>(GetProcAddress(ntdll,"RtlIsThreadWithinLoaderCallout")):nullptr;
 const auto result=!probe?Context::unavailable:probe()?Context::loader_callout:Context::outside_loader;
 SetLastError(saved);return result;
}
}
