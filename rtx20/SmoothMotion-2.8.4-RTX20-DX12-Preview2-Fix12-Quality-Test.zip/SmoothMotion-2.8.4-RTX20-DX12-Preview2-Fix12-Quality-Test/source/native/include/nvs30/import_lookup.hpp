#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string_view>
namespace nvs30::import_lookup {
// A mapped image, not an on-disk PE. Zero means no validated named slot.
inline std::size_t find(const unsigned char* image,std::size_t available,
                        std::string_view dll,std::string_view symbol,bool delay=false) {
    auto range=[&](std::size_t at,std::size_t n){return at<=available&&n<=available-at;};
    auto u16=[&](std::size_t at){std::uint16_t v{};if(range(at,2))std::memcpy(&v,image+at,2);return v;};
    auto u32=[&](std::size_t at){std::uint32_t v{};if(range(at,4))std::memcpy(&v,image+at,4);return v;};
    auto u64=[&](std::size_t at){std::uint64_t v{};if(range(at,8))std::memcpy(&v,image+at,8);return v;};
    auto equals=[&](std::size_t at,std::string_view text,bool lower){
        if(!range(at,text.size()+1)||image[at+text.size()])return false;
        for(std::size_t i=0;i<text.size();++i){unsigned a=image[at+i],b=static_cast<unsigned char>(text[i]);
            if(lower){if(a>='A'&&a<='Z')a+='a'-'A';if(b>='A'&&b<='Z')b+='a'-'A';}if(a!=b)return false;}
        return true;
    };
    if(!image||available<64||u16(0)!=0x5a4d)return 0;
    const std::size_t nt=u32(60),opt=nt+24;
    if(!range(nt,24)||u32(nt)!=0x4550||u16(nt+4)!=0x8664||!range(opt,u16(nt+20))||u16(nt+20)<240||u16(opt)!=0x20b)return 0;
    const auto size=u32(opt+56);if(size>available||size<opt+240||u32(opt+108)<16)return 0;available=size;
    const std::size_t d=opt+112+(delay?13:1)*8, table=u32(d), bytes=u32(d+4), stride=delay?32:20;
    if(!table||bytes<stride||!range(table,bytes))return 0;
    for(std::size_t i=0;i<bytes/stride;++i) {
        const auto at=table+i*stride;
        const std::size_t name=u32(at+(delay?4:12));if(!name)break;
        if(delay&&u32(at)!=1)continue;
        if(!equals(name,dll,true))continue;
        const std::size_t names=u32(at+(delay?16:0)),slots=u32(at+(delay?12:16));
        if(!names||!slots||names%8||slots%8)return 0;
        for(std::size_t j=0;range(names+j*8,8)&&range(slots+j*8,8);++j) {
            const auto entry=u64(names+j*8);if(!entry)break;
            if(entry&(std::uint64_t{1}<<63))continue;
            if(entry>available||!range(static_cast<std::size_t>(entry),2))return 0;
            if(equals(static_cast<std::size_t>(entry)+2,symbol,false)&&u64(slots+j*8))return slots+j*8;
        }
    }
    return 0;
}
}
