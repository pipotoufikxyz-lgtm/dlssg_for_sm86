#pragma once
#include <atomic>
#include <cstdint>

namespace nvs30::module_watch {
// The loader notification touches only this lock-free counter. It must not
// allocate, log, signal an event, inspect a module, or call another DLL.
inline std::atomic<std::uint64_t> generation{0};
inline std::atomic_bool registered{false};
static_assert(std::atomic<std::uint64_t>::is_always_lock_free);

struct Schedule {
    std::uint64_t started=0,last_scan=0,observed=0;
    bool initialized=false;
    bool due(std::uint64_t now,std::uint64_t current,bool notifications) const noexcept {
        if(!initialized||now<last_scan||current!=observed)return true;
        const std::uint64_t interval=now-started<30000?500:(notifications?30000:5000);
        return now-last_scan>=interval;
    }
    void scanned(std::uint64_t now,std::uint64_t before_scan) noexcept {
        if(!initialized||now<last_scan){started=now;initialized=true;}
        last_scan=now;
        // Capture BEFORE scanning: a load that races the scan stays pending.
        observed=before_scan;
    }
};

// Resource mappings and modules whose imports were intentionally not linked
// are not executable-load triggers (including DATAFILE_EXCLUSIVE).
inline constexpr bool executable_load(unsigned flags) noexcept {
    return !(flags&(0x00000001u|0x00000002u|0x00000020u|0x00000040u));
}
}
