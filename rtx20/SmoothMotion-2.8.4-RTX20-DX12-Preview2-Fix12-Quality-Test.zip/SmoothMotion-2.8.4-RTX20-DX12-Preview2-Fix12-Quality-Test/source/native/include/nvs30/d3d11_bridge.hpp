#pragma once
#include "common.hpp"
#include "presentation_policy.hpp"
#include "bridge_retry.hpp"

namespace nvs30 {
class D3D11Bridge {
public:
    ~D3D11Bridge();
    HRESULT prepare(IDXGISwapChain* source, HWND hwnd, ComPtr<IDXGISwapChain3>& output);
    bool active() const noexcept { return active_; }
    bool wrapper_active() const noexcept;
    void reset();
    // Caller holds its per-chain lock. probe() never allocates or copies.
    ComPtr<IDXGISwapChain3> probe() const {return active_?shadow_:ComPtr<IDXGISwapChain3>{};}
    bool retire_if_idle();
    void accepted_present();
    HRESULT stop(const char* operation,HRESULT result,bool unsafe=false);

private:
    bool initialize(IDXGISwapChain* source, HWND hwnd);
    bool build_shared_resources(IDXGISwapChain* source, DXGI_FORMAT source_format,
                                UINT width, UINT height);
    HRESULT wait_for_gpu(std::uint64_t value);
    HRESULT wait_for_d3d11_copy();
    void initialize_copy_fence();
    static DXGI_FORMAT linear_format(DXGI_FORMAT format);

    bool active_{};
    bool unsafe_inflight_{},permanently_failed_{};
    bridge_retry::Attempts attempts_;
    bool wrapper_confirmed_{};
    bool activity_warning_{};
    presentation::ProgressWindow progress_;
    HWND hwnd_{};
    UINT width_{};
    UINT height_{};
    DXGI_FORMAT source_format_{DXGI_FORMAT_UNKNOWN};

    ComPtr<ID3D11Device> device11_;
    ComPtr<ID3D11DeviceContext> context11_;
    ComPtr<ID3D11Texture2D> shared11_;
    ComPtr<ID3D11Query> copy_query_;
    ComPtr<ID3D11DeviceContext4> fence_context11_;
    ComPtr<ID3D11Fence> copy_fence11_;
    HANDLE copy_event_{};
    std::uint64_t copy_value_{};

    ComPtr<ID3D12Device> device12_;
    ComPtr<ID3D12CommandQueue> queue12_;
    ComPtr<ID3D12CommandAllocator> allocator12_;
    ComPtr<ID3D12GraphicsCommandList> list12_;
    ComPtr<ID3D12Resource> shared12_;
    ComPtr<ID3D12Fence> completion_fence_;
    ComPtr<IDXGISwapChain3> shadow_;
    HANDLE completion_event_{};
    std::uint64_t completion_value_{};
};
}
