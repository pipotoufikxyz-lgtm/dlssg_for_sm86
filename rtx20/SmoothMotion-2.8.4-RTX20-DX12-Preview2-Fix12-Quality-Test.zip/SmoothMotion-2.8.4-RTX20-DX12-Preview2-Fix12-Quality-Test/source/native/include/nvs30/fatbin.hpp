#pragma once
#include "common.hpp"
#include "fatbin_core.hpp"
namespace nvs30::fatbin {RewrittenImage rewrite_sm89_to_sm86(const void*);}
