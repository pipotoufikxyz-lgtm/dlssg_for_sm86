#pragma once
// Import interception never overwrites executable instructions or guesses a
// trampoline length. Only exact PE import slots owned by non-system modules
// are changed. Modules are pinned while their import descriptors are examined.
#include <tlhelp32.h>
#include <cwchar>
#include "import_slots.hpp"
#include "module_origin.hpp"
#include "provider_table.hpp"
#include "target_bindings.hpp"
#include "import_identity.hpp"
namespace imports {
struct Hook {const char* name;void* original;void* replacement;};
// The resolved import addresses and replacement pointers are initialised by
// the CRT before DllMain. Readers never wait for a bootstrap owner.
extern const std::array<Hook,12> hooks;
inline graphics_provider::Table<> providers;
extern const std::array<std::array<void*,graphics_provider::apiCount>,graphics_provider::capacity> providerWrappers;
inline std::atomic_ulong providerPatches{0},providerResolutions{0};
namespace loader_api {
enum Api:std::size_t {getProc,loadA,loadW,loadExA,loadExW,loadPackage,count};
inline constexpr std::array<const char*,count> names{{"GetProcAddress","LoadLibraryA","LoadLibraryW","LoadLibraryExA","LoadLibraryExW","LoadPackagedLibrary"}};
inline graphics_provider::Table<3,count> providers;
extern const std::array<std::array<void*,count>,3> wrappers;
inline std::atomic_ulong patches{0},resolutions{0};
}
namespace named {
inline constexpr std::size_t graphicsCapacity=32,loaderCapacity=16;
inline target_binding::Table<graphicsCapacity,graphics_provider::apiCount> graphics;
inline target_binding::Table<loaderCapacity,loader_api::count> loaders;
extern const std::array<std::array<void*,graphics_provider::apiCount>,graphicsCapacity> graphicsWrappers;
extern const std::array<std::array<void*,loader_api::count>,loaderCapacity> loaderWrappers;
inline std::atomic_ulong graphicsPatches{0},loaderPatches{0},delayPatches{0},resolutions{0},bindFailures{0};
}
inline std::atomic_ullong scanFailures{0};
inline std::atomic_ulong graphicsPatches{0};
inline std::atomic_ullong graphicsEntries{0},graphicsAdmitted{0},graphicsExcluded{0},resolverEntries{0};
void reportScan(const std::wstring&,bool,unsigned,unsigned);
void reportNamed(const std::wstring&,const char*,const char*,bool);
inline thread_local unsigned suppressedGraphics=0;
inline std::atomic_ulong patched{0};
inline std::atomic_ullong scans{0};
inline std::atomic<HMODULE> owner{nullptr};
inline constexpr const char* excludedExports[]={"IsUltimateASILoader","SmoothMotionGetStatus","NVP_Init_D3D","SM_Prepare","SM_ProviderPath"};
struct LastErrorScope {
 DWORD value=GetLastError();
 ~LastErrorScope(){SetLastError(value);}
};
inline void discoverProvider(HMODULE image) noexcept {
 LastErrorScope error;
 if(!image||image==owner.load()||providers.find(reinterpret_cast<std::uintptr_t>(image))!=decltype(providers)::missing)return;
 try{
  std::wstring path(32768,L'\0');
  const auto n=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
  if(!n||n>=path.size()||!module_origin::equal(module_origin::filename(std::wstring_view(path.data(),n)),L"sl.interposer.dll"))return;
  std::wstring windows(32768,L'\0');const auto wn=GetWindowsDirectoryW(windows.data(),static_cast<UINT>(windows.size()));
  if(!wn||wn>=windows.size()||module_origin::excludedPath(std::wstring_view(path.data(),n),std::wstring_view(windows.data(),wn)))return;
  // Acquire before resolving exports. A successful publication owns this one
  // reference for process lifetime, including after the game's FreeLibrary.
  HMODULE held{};
  if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(image),&held))return;
  struct Release {HMODULE value;~Release(){if(value)FreeLibrary(value);}} release{held};
  // Revalidate after acquiring the reference: an unload/reload can reuse the
  // snapshot address between the initial filename check and this pin.
  std::wstring pinned(32768,L'\0');const auto pn=GetModuleFileNameW(held,pinned.data(),static_cast<DWORD>(pinned.size()));
  if(pn!=n||!module_origin::equal(std::wstring_view(path.data(),n),std::wstring_view(pinned.data(),pn)))return;
  for(const auto* name:excludedExports)if(GetProcAddress(held,name))return;
  std::array<void*,graphics_provider::apiCount> targets{};
  for(std::size_t i=0;i<targets.size();++i)targets[i]=reinterpret_cast<void*>(GetProcAddress(held,graphics_provider::names[i]));
  if(providers.publish(reinterpret_cast<std::uintptr_t>(held),targets)==graphics_provider::Publish::added)release.value=nullptr;
 }catch(...){}
}
// API-set imports can bind directly to KernelBase instead of the Kernel32
// export linked by this DLL. Address equality to Kernel32 alone misses those
// GetProcAddress/LoadLibrary calls and then misses the entire renderer startup.
inline void discoverLoader(HMODULE image) noexcept {
 LastErrorScope error;
 if(!image||image==owner.load()||loader_api::providers.find(reinterpret_cast<std::uintptr_t>(image))!=decltype(loader_api::providers)::missing)return;
 try{
  std::wstring path(32768,L'\0'),windows(32768,L'\0');
  const auto n=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
  const auto wn=GetWindowsDirectoryW(windows.data(),static_cast<UINT>(windows.size()));
  if(!n||n>=path.size()||!wn||wn>=windows.size())return;
  const auto file=module_origin::filename(std::wstring_view(path.data(),n));
  if(!module_origin::equal(file,L"kernelbase.dll")&&!module_origin::equal(file,L"kernel32.dll")&&!module_origin::equal(file,L"kernel32legacy.dll"))return;
  if(!module_origin::excludedPath(std::wstring_view(path.data(),n),std::wstring_view(windows.data(),wn)))return;
  HMODULE held{};
  if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(image),&held))return;
  struct Release {HMODULE value;~Release(){if(value)FreeLibrary(value);}} release{held};
  std::wstring pinned(32768,L'\0');const auto pn=GetModuleFileNameW(held,pinned.data(),static_cast<DWORD>(pinned.size()));
  if(pn!=n||!module_origin::equal(std::wstring_view(path.data(),n),std::wstring_view(pinned.data(),pn)))return;
  std::array<void*,loader_api::count> targets{};
  for(std::size_t i=0;i<targets.size();++i)targets[i]=reinterpret_cast<void*>(GetProcAddress(held,loader_api::names[i]));
  if(loader_api::providers.publish(reinterpret_cast<std::uintptr_t>(held),targets)==graphics_provider::Publish::added)release.value=nullptr;
 }catch(...){}
}
inline module_origin::Origin callerOrigin(const void* caller) noexcept {
 LastErrorScope error;
 if(!caller)return module_origin::Origin::unknown;
 try{
  HMODULE image{};
  // The caller is executing inside this module. Do not acquire/release a
  // reference or retain a module/address cache across unloads; in particular,
  // never hold one of our locks while calling into the Windows loader.
  if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
      reinterpret_cast<LPCWSTR>(caller),&image))return module_origin::Origin::unknown;
  if(image==owner.load())return module_origin::Origin::excluded;
  std::wstring path(32768,L'\0'),system(32768,L'\0');
  const auto length=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
  const auto systemLength=GetWindowsDirectoryW(system.data(),static_cast<UINT>(system.size()));
  if(!length||length>=path.size())return module_origin::Origin::unknown;
  if(module_origin::excludedPath(std::wstring_view(path.data(),length),
      systemLength&&systemLength<system.size()?std::wstring_view(system.data(),systemLength):std::wstring_view{}))return module_origin::Origin::excluded;
  // Our own IAT is never patched, so this is the real API and cannot recurse
  // through onGetProcAddress. Match the scanner's established loader/backend
  // exclusions even when it did not supply this caller's function pointer.
  for(const auto* name:excludedExports)if(GetProcAddress(image,name))return module_origin::Origin::excluded;
  return module_origin::Origin::eligible;
 }catch(...){return module_origin::Origin::unknown;}
}
inline FARPROC replacement(FARPROC original){
 auto address=reinterpret_cast<void*>(original);
 for(const auto& hook:hooks)if(address==hook.original)return reinterpret_cast<FARPROC>(hook.replacement);
 auto graphics=providers.replacement(address,providerWrappers);
 if(graphics!=address)return reinterpret_cast<FARPROC>(graphics);
 return reinterpret_cast<FARPROC>(loader_api::providers.replacement(address,loader_api::wrappers));
}
inline FARPROC replacement(FARPROC original,const void* caller) noexcept {
 const auto candidate=replacement(original);
 // Avoid any module lookup for unrelated or missing exports. Unknown dynamic
 // callers retain the exact resolved API instead of receiving a new hook.
 return candidate!=original&&callerOrigin(caller)==module_origin::Origin::eligible?candidate:original;
}
template<class Rows> inline bool containsCallback(const Rows& rows,void* address){
 for(const auto& row:rows)for(const auto callback:row)if(callback==address)return true;
 return false;
}
inline bool ownCallback(void* address){
 for(const auto& hook:hooks)if(hook.replacement==address)return true;
 return containsCallback(providerWrappers,address)||containsCallback(loader_api::wrappers,address)||
        containsCallback(named::graphicsWrappers,address)||containsCallback(named::loaderWrappers,address);
}
template<class Table,class Rows> void* bindTarget(void* original,std::size_t api,Table& table,const Rows& callbacks) noexcept {
 LastErrorScope error;
 const auto existing=table.find(original,api);
 if(existing!=Table::missing)return callbacks[existing][api];
 if(!original||ownCallback(original))return original;
 // A callback may point into a proxy, overlay, or the importing module's
 // unresolved delay thunk. Retain that actual code owner, not just a DLL name.
 HMODULE held{};
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(original),&held)){
  ++named::bindFailures;return original;
 }
 struct Release {HMODULE value;~Release(){if(value)FreeLibrary(value);}} release{held};
 if(held==owner.load())return original;
 const auto binding=table.publish(original,api);
 if(binding.added)release.value=nullptr;
 if(binding.slot==Table::missing){++named::bindFailures;return original;}
 return callbacks[binding.slot][api];
}
inline std::string moduleFilename(HMODULE image){
 std::wstring path(32768,L'\0');const auto count=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
 if(!count||count>=path.size())return {};
 const auto name=module_origin::filename(std::wstring_view(path.data(),count));
 std::string narrow;for(auto c:name){if(c>127)return {};narrow.push_back(static_cast<char>(c));}return narrow;
}
inline FARPROC resolved(HMODULE image,LPCSTR name,FARPROC original,const void* caller) noexcept {
 LastErrorScope error;
 ++resolverEntries;
 if(!original)return original;
 try{
  // Ordinals cannot supply an ABI/name. The established address-only path
  // still handles any known target without dereferencing the ordinal.
  if(reinterpret_cast<std::uintptr_t>(name)<=0xffff)return replacement(original,caller);
  std::size_t graphics=graphics_provider::apiCount,loader=loader_api::count;
  for(std::size_t i=0;i<graphics_provider::apiCount;++i)if(!std::strcmp(name,graphics_provider::names[i]))graphics=i;
  for(std::size_t i=0;i<loader_api::count;++i)if(!std::strcmp(name,loader_api::names[i]))loader=i;
  if(graphics==graphics_provider::apiCount&&loader==loader_api::count)return replacement(original,caller);
  if(callerOrigin(caller)!=module_origin::Origin::eligible)return original;
  if(graphics<graphics_provider::apiCount)discoverProvider(image);
  if(loader<loader_api::count)discoverLoader(image);
  auto result=replacement(original);
  if(result==original&&!ownCallback(reinterpret_cast<void*>(original))){
   const auto source=moduleFilename(image);
   void* destination=reinterpret_cast<void*>(original);
   if(graphics<graphics_provider::apiCount&&import_identity::graphics(source,graphics))
    destination=bindTarget(destination,graphics,named::graphics,named::graphicsWrappers);
   else if(loader<loader_api::count&&import_identity::loader(source))
    destination=bindTarget(destination,loader,named::loaders,named::loaderWrappers);
   result=reinterpret_cast<FARPROC>(destination);
   if(result!=original)++named::resolutions;
  }
  if(result!=original&&providers.replacement(reinterpret_cast<void*>(original),providerWrappers)!=reinterpret_cast<void*>(original))++providerResolutions;
  if(result!=original&&loader_api::providers.replacement(reinterpret_cast<void*>(original),loader_api::wrappers)!=reinterpret_cast<void*>(original))++loader_api::resolutions;
  return result;
 }catch(...){return original;}
}
template<class Start,class Create,class Observe>
auto graphicsCall(const void* caller,bool internal,Start start,Create forward,Observe observe){
 LastErrorScope error;
 ++graphicsEntries;
 const bool admitted=!internal&&!suppressedGraphics&&callerOrigin(caller)!=module_origin::Origin::excluded;
 if(admitted)++graphicsAdmitted;else ++graphicsExcluded;
 // A protected caller may enter an interposer which calls an eligible helper.
 // Propagate exclusion down that synchronous graphics call; the helper must
 // not turn an overlay probe into the first game initialization.
 struct Suppress {bool active;explicit Suppress(bool value):active(value){if(active)++suppressedGraphics;}~Suppress(){if(active)--suppressedGraphics;}} suppress(!admitted);
 // An already handed-out graphics entry may be called through a shared hook
 // or JIT trampoline. Unknown origins keep ordinary graphics creation working;
 // positively identified protected origins cannot initialize or attach us.
 if(admitted)start();
 SetLastError(error.value);
 auto result=forward();error.value=GetLastError();
 if(admitted)observe(result);
 return result;
}
inline void module(HMODULE image,size_t available){
 if(!image||image==owner)return;
 HMODULE held=nullptr;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(image),&held))return;
 struct Release{HMODULE module;~Release(){FreeLibrary(module);}} release{held};
 // This path also runs synchronously after a game's LoadLibrary call. Large
 // automatic path arrays consumed over 128 KiB of the caller's Windows stack.
 // Heap allocation failures are caught by refresh(), preserving the API call.
 std::wstring path(32768,L'\0'),system(32768,L'\0');
 const auto length=GetModuleFileNameW(held,path.data(),static_cast<DWORD>(path.size()));
 const auto systemLength=GetWindowsDirectoryW(system.data(),static_cast<UINT>(system.size()));
 if(!length||length>=32768)return;
 // Do not patch Windows components or the confirmed crashing Steam overlay.
 // Its own startup graphics probes must not initialize the native backend.
 if(module_origin::excludedPath(std::wstring_view(path.data(),length),
    systemLength&&systemLength<system.size()?std::wstring_view(system.data(),systemLength):std::wstring_view{}))return;
 auto base=reinterpret_cast<unsigned char*>(held);
 auto copy=[&](size_t offset,void* out,size_t bytes){
  SIZE_T received{};
  return ReadProcessMemory(GetCurrentProcess(),base+offset,out,bytes,&received)&&received==bytes;
 };
 motion::ImportPageReader reader(available,copy);
 unsigned changed=0,graphics=0;
 const bool valid=motion::visitImportSlotsReader(available,reader,[&](const motion::ImportSlot& slot){
   auto location=reinterpret_cast<void**>(base+slot.offset);
   auto original=reinterpret_cast<void*>(static_cast<std::uintptr_t>(slot.value));
   auto target=reinterpret_cast<void*>(replacement(reinterpret_cast<FARPROC>(original)));
   const bool provider=providers.replacement(original,providerWrappers)!=original;
   bool directGraphics=false;
   for(const auto& hook:hooks)if(hook.original==original)
    for(const auto* api:graphics_provider::names)directGraphics|=std::strcmp(hook.name,api)==0;
   bool namedGraphics=false,namedLoader=false;
   motion::ImportIdentity identity;
   if(target==original){
    if(motion::readImportIdentity(slot,reader,identity)){
     for(std::size_t api=0;api<graphics_provider::apiCount;++api)
      if(!std::strcmp(identity.symbol.data(),graphics_provider::names[api])&&import_identity::graphics(identity.dll.data(),api)){
       target=bindTarget(original,api,named::graphics,named::graphicsWrappers);namedGraphics=target!=original;break;
      }
     if(target==original&&import_identity::loader(identity.dll.data()))
      for(std::size_t api=0;api<loader_api::count;++api)if(!std::strcmp(identity.symbol.data(),loader_api::names[api])){
       target=bindTarget(original,api,named::loaders,named::loaderWrappers);namedLoader=target!=original;break;
      }
    }
   }
   if(target!=original&&patch(location,original,target)){
    ++patched;++changed;
    if(provider)++providerPatches;
    if(provider||directGraphics||namedGraphics){++graphics;++graphicsPatches;}
    if(namedGraphics)++named::graphicsPatches;
    if(namedLoader)++named::loaderPatches;
    if((namedGraphics||namedLoader)&&slot.delayed)++named::delayPatches;
    if(namedGraphics||namedLoader)reportNamed(path,identity.dll.data(),identity.symbol.data(),slot.delayed);
    if(loader_api::providers.replacement(original,loader_api::wrappers)!=original)++loader_api::patches;
   }
 },{"IsUltimateASILoader","SmoothMotionGetStatus","NVP_Init_D3D","SM_Prepare","SM_ProviderPath"});
 if(!valid)++scanFailures;
 path.resize(length);reportScan(path,valid,changed,graphics);
}
inline bool refresh(){
 // No scan mutex: a loader callback must not wait for a worker which may
 // itself be acquiring the loader lock. patch() alone serialises page edits.
 static thread_local bool scanning=false;if(scanning)return false;
 struct ScanScope{bool& active;explicit ScanScope(bool& value):active(value){active=true;}~ScanScope(){active=false;}} scope(scanning);
 // A module list changing during the snapshot is a documented transient
 // failure. Retry briefly on this caller so a newly loaded renderer need not
 // wait for the background scan. No sleeping or unbounded loop under loaders.
 HANDLE snapshot=INVALID_HANDLE_VALUE;
 for(unsigned attempt=0;attempt<3;++attempt){
  snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());
  if(snapshot!=INVALID_HANDLE_VALUE||GetLastError()!=ERROR_BAD_LENGTH)break;
 }
 if(snapshot==INVALID_HANDLE_VALUE)return false;
 struct CloseSnapshot{HANDLE value;~CloseSnapshot(){CloseHandle(value);}} close{snapshot};
 MODULEENTRY32W entry{};entry.dwSize=sizeof entry;
 if(!Module32FirstW(snapshot,&entry))return false;
 // Bind providers before scanning consumers. Snapshot order commonly puts
 // the game's EXE/renderer before sl.interposer; a single pass misses their
 // static imports until the next timer scan, after graphics may be created.
 do{discoverLoader(entry.hModule);discoverProvider(entry.hModule);}while(Module32NextW(snapshot,&entry));
 if(GetLastError()!=ERROR_NO_MORE_FILES||!Module32FirstW(snapshot,&entry))return false;
 do{try{module(entry.hModule,entry.modBaseSize);}catch(...){}}
 while(Module32NextW(snapshot,&entry));
 if(GetLastError()!=ERROR_NO_MORE_FILES)return false;
 ++scans;return true;
}
}
