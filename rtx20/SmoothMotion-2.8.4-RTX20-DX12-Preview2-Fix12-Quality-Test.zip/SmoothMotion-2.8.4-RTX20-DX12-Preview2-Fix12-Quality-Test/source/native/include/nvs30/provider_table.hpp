#pragma once
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace graphics_provider {
enum Api:std::size_t {factory,factory1,factory2,device12,device11,device11Swap,apiCount};
inline constexpr std::array<const char*,apiCount> names{{"CreateDXGIFactory","CreateDXGIFactory1","CreateDXGIFactory2","D3D12CreateDevice","D3D11CreateDevice","D3D11CreateDeviceAndSwapChain"}};
inline constexpr std::size_t capacity=4;
enum class Publish {added,existing,busy,full,invalid};
// Every published row is immutable. Its owning module reference must be kept
// until process exit by the caller. Never recycle a row: games cache exports.
// Publication does not allocate, block, or call the Windows loader.
template<std::size_t N=capacity,std::size_t Width=apiCount> class Table {
 struct Row {std::atomic<std::uintptr_t> module{0};std::array<void*,Width> targets{};};
 std::array<Row,N> rows_{};
 std::atomic_flag writing_=ATOMIC_FLAG_INIT;
public:
 static constexpr std::size_t missing=N;
 std::size_t find(std::uintptr_t module)const noexcept {
  if(module)for(std::size_t i=0;i<N;++i)if(rows_[i].module.load(std::memory_order_acquire)==module)return i;
  return missing;
 }
 Publish publish(std::uintptr_t module,const std::array<void*,Width>& targets)noexcept {
  if(!module)return Publish::invalid;
  bool any=false;for(auto target:targets)any|=target!=nullptr;
  if(!any)return Publish::invalid;
  if(find(module)!=missing)return Publish::existing;
  if(writing_.test_and_set(std::memory_order_acquire))return Publish::busy;
  struct Unlock {std::atomic_flag& value;~Unlock(){value.clear(std::memory_order_release);}} unlock{writing_};
  if(find(module)!=missing)return Publish::existing;
  for(auto& row:rows_)if(!row.module.load(std::memory_order_relaxed)){
   row.targets=targets;row.module.store(module,std::memory_order_release);return Publish::added;
  }
  return Publish::full;
 }
 void* target(std::size_t slot,std::size_t api)const noexcept {
  if(slot>=N||api>=Width||!rows_[slot].module.load(std::memory_order_acquire))return nullptr;
  return rows_[slot].targets[api];
 }
 template<class Wrappers> void* replacement(void* original,const Wrappers& wrappers)const noexcept {
  if(!original)return nullptr;
  for(std::size_t i=0;i<N;++i)if(rows_[i].module.load(std::memory_order_acquire))
   for(std::size_t j=0;j<Width;++j)if(rows_[i].targets[j]==original)return wrappers[i][j];
  return original;
 }
 std::size_t count()const noexcept {
  std::size_t n=0;for(const auto& row:rows_)n+=row.module.load(std::memory_order_acquire)!=0;return n;
 }
};
}
