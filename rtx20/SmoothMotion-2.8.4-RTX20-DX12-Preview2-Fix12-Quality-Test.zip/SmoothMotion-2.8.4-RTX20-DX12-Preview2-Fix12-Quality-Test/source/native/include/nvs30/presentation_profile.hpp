#pragma once
#include <string_view>

namespace nvs30::presentation_profile {
enum class Profile { standard, trails_native, kcd2_native };
constexpr bool equal(std::wstring_view a,std::wstring_view b) noexcept {
    if(a.size()!=b.size())return false;
    for(std::size_t i=0;i<a.size();++i){
        auto c=a[i];if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A';
        auto d=b[i];if(d>=L'A'&&d<=L'Z')d+=L'a'-L'A';
        if(c!=d)return false;
    }
    return true;
}
constexpr bool kcd2_layout(std::wstring_view path) noexcept {
    const auto slash=path.find_last_of(L"\\/");
    if(slash==std::wstring_view::npos||!equal(path.substr(slash+1),L"KingdomCome.exe"))return false;
    path=path.substr(0,slash);const auto parent=path.find_last_of(L"\\/");
    return parent!=std::wstring_view::npos&&equal(path.substr(parent+1),L"Win64MasterMasterSteamPGO");
}

// This is a presentation compatibility exception, not a different driver
// initialization policy. Match the executable basename exactly: neither the
// installation directory nor a launcher's command line selects this profile.
constexpr Profile select(std::wstring_view executable) noexcept {
    // Kingdom Come I has the same executable name. Restrict this exception to
    // the KCD II engine directory in the supplied diagnostic report.
    if(kcd2_layout(executable))return Profile::kcd2_native;
    const auto slash=executable.find_last_of(L"\\/");
    if(slash!=std::wstring_view::npos)executable.remove_prefix(slash+1);
    return equal(executable,L"sora_2nd.exe")?Profile::trails_native:Profile::standard;
}
constexpr bool object_hooks(Profile profile) noexcept {
    return profile==Profile::standard;
}
constexpr const char* name(Profile profile) noexcept {
    return profile==Profile::trails_native?"trails_native_presentation":profile==Profile::kcd2_native?"kcd2_native_presentation":"standard";
}
constexpr const char* counter_kind(Profile profile) noexcept {
    return object_hooks(profile)?"raw_intercepted_calls":"disabled_native_presentation";
}
}
