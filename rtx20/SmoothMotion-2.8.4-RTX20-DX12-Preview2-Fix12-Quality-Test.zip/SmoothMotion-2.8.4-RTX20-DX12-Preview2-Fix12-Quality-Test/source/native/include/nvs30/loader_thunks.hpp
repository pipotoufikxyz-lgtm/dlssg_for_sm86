#pragma once
// Preserve the exact resolved Windows implementation, including KernelBase
// API-set targets. These thunks do not call through a patched consumer IAT.
template<std::size_t Slot,std::size_t Api,class Function,bool Named=false> Function loaderTarget(){
 if constexpr(Named)return reinterpret_cast<Function>(imports::named::loaders.target(Slot,Api));
 else return reinterpret_cast<Function>(imports::loader_api::providers.target(Slot,Api));
}
template<std::size_t Slot,bool Named=false> FARPROC WINAPI onLoaderGetProcAddress(HMODULE image,LPCSTR name){
 const void* caller=NVS30_CALLER_ADDRESS();
 const auto forward=loaderTarget<Slot,imports::loader_api::getProc,decltype(&GetProcAddress),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return imports::resolved(image,name,forward(image,name),caller);
}
template<std::size_t Slot,bool Named=false> HMODULE WINAPI onLoaderLoadA(LPCSTR path){
 const auto forward=loaderTarget<Slot,imports::loader_api::loadA,decltype(&LoadLibraryA),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return loadAndRefresh([&]{return forward(path);});
}
template<std::size_t Slot,bool Named=false> HMODULE WINAPI onLoaderLoadW(LPCWSTR path){
 const auto forward=loaderTarget<Slot,imports::loader_api::loadW,decltype(&LoadLibraryW),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return loadAndRefresh([&]{return forward(path);});
}
template<std::size_t Slot,bool Named=false> HMODULE WINAPI onLoaderLoadExA(LPCSTR path,HANDLE file,DWORD flags){
 const auto forward=loaderTarget<Slot,imports::loader_api::loadExA,decltype(&LoadLibraryExA),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return loadAndRefresh([&]{return forward(path,file,flags);},module_watch::executable_load(flags));
}
template<std::size_t Slot,bool Named=false> HMODULE WINAPI onLoaderLoadExW(LPCWSTR path,HANDLE file,DWORD flags){
 const auto forward=loaderTarget<Slot,imports::loader_api::loadExW,decltype(&LoadLibraryExW),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return loadAndRefresh([&]{return forward(path,file,flags);},module_watch::executable_load(flags));
}
template<std::size_t Slot,bool Named=false> HMODULE WINAPI onLoaderLoadPackage(LPCWSTR path,DWORD reserved){
 const auto forward=loaderTarget<Slot,imports::loader_api::loadPackage,decltype(&LoadPackagedLibrary),Named>();
 if(!forward){SetLastError(127);return nullptr;}
 return loadAndRefresh([&]{return forward(path,reserved);});
}
namespace imports::loader_api {
template<std::size_t Slot,bool Named=false> std::array<void*,count> row(){
 return {{reinterpret_cast<void*>(&onLoaderGetProcAddress<Slot,Named>),reinterpret_cast<void*>(&onLoaderLoadA<Slot,Named>),
          reinterpret_cast<void*>(&onLoaderLoadW<Slot,Named>),reinterpret_cast<void*>(&onLoaderLoadExA<Slot,Named>),
          reinterpret_cast<void*>(&onLoaderLoadExW<Slot,Named>),reinterpret_cast<void*>(&onLoaderLoadPackage<Slot,Named>)}};
}
const std::array<std::array<void*,count>,3> wrappers{{row<0>(),row<1>(),row<2>()}};
}

namespace imports::named {
template<std::size_t... I> auto loaderRows(std::index_sequence<I...>){return std::array<std::array<void*,loader_api::count>,sizeof...(I)>{{loader_api::row<I,true>()...}};}
const std::array<std::array<void*,loader_api::count>,loaderCapacity> loaderWrappers=loaderRows(std::make_index_sequence<loaderCapacity>{});
}
