#pragma once
#include <array>
#include <atomic>
#include <cstddef>

namespace target_binding {
// One immutable ABI + actual destination per callback slot. A resolver or
// overlay may return several different addresses for the same export name.
// Never replace a published destination: games can cache any older callback.
template<std::size_t N,std::size_t Width> class Table {
 struct Row {std::atomic_bool ready{false};void* original{};std::size_t api{};};
 std::array<Row,N> rows_{};std::atomic_flag writing_=ATOMIC_FLAG_INIT;
public:
 static constexpr std::size_t missing=N;
 struct Result {std::size_t slot=missing;bool added=false;};
 std::size_t find(void* original,std::size_t api)const noexcept {
  if(original&&api<Width)for(std::size_t i=0;i<N;++i)
   if(rows_[i].ready.load(std::memory_order_acquire)&&rows_[i].original==original&&rows_[i].api==api)return i;
  return missing;
 }
 Result publish(void* original,std::size_t api)noexcept {
  if(!original||api>=Width)return {};
  auto at=find(original,api);if(at!=missing)return {at,false};
  if(writing_.test_and_set(std::memory_order_acquire))return {};
  struct Unlock {std::atomic_flag& flag;~Unlock(){flag.clear(std::memory_order_release);}} unlock{writing_};
  at=find(original,api);if(at!=missing)return {at,false};
  for(std::size_t i=0;i<N;++i)if(!rows_[i].ready.load(std::memory_order_relaxed)){
   rows_[i].original=original;rows_[i].api=api;rows_[i].ready.store(true,std::memory_order_release);return {i,true};
  }
  return {};
 }
 void* target(std::size_t slot,std::size_t api)const noexcept {
  if(slot>=N||!rows_[slot].ready.load(std::memory_order_acquire)||rows_[slot].api!=api)return nullptr;
  return rows_[slot].original;
 }
 std::size_t count()const noexcept {
  std::size_t n=0;for(const auto& row:rows_)n+=row.ready.load(std::memory_order_acquire);return n;
 }
};
}
