#pragma once
#include <string_view>

// These names are established by the supplied crash reports. Keep this policy
// exact: a Steam directory may also contain the game or an emulator renderer.
namespace module_origin {
enum class Origin {unknown,eligible,excluded};
constexpr wchar_t lower(wchar_t value) noexcept {
 return value>=L'A'&&value<=L'Z'?value+(L'a'-L'A'):value;
}
constexpr bool equal(std::wstring_view a,std::wstring_view b) noexcept {
 if(a.size()!=b.size())return false;
 for(size_t i=0;i<a.size();++i)if(lower(a[i])!=lower(b[i]))return false;
 return true;
}
constexpr std::wstring_view filename(std::wstring_view path) noexcept {
 const auto separator=path.find_last_of(L"\\/");
 return separator==std::wstring_view::npos?path:path.substr(separator+1);
}
constexpr bool separator(wchar_t c) noexcept {return c==L'\\'||c==L'/';}
constexpr std::wstring_view dosPath(std::wstring_view path) noexcept {
 // GetModuleFileName preserves the loaded path spelling, including \\?\.
 // Strip only an extended DOS drive prefix; do not reinterpret device/UNC names.
 if(path.size()>=7&&path.substr(0,4)==L"\\\\?\\"&&path[5]==L':'&&separator(path[6])&&
    ((lower(path[4])>=L'a')&&(lower(path[4])<=L'z')))path.remove_prefix(4);
 return path;
}
constexpr bool pathPrefix(std::wstring_view path,std::wstring_view prefix) noexcept {
 if(path.size()<prefix.size())return false;
 for(size_t i=0;i<prefix.size();++i)
  if(!(separator(path[i])&&separator(prefix[i]))&&lower(path[i])!=lower(prefix[i]))return false;
 return true;
}
constexpr bool excludedPath(std::wstring_view path,std::wstring_view windows) noexcept {
 const auto name=filename(path);
 path=dosPath(path);windows=dosPath(windows);
 while(windows.size()>3&&separator(windows.back()))windows.remove_suffix(1);
 if(equal(name,L"gameoverlayrenderer.dll")||equal(name,L"gameoverlayrenderer64.dll"))return true;
 // Require a directory boundary, so C:\WindowsGames remains eligible.
 return !windows.empty()&&path.size()>windows.size()&&
        pathPrefix(path,windows)&&
        separator(path[windows.size()]);
}
}
