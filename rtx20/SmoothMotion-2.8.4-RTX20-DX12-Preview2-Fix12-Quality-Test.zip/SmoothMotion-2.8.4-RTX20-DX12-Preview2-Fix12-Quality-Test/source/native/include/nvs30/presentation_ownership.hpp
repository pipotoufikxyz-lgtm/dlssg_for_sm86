#pragma once

namespace nvs30::presentation_ownership {
// Evidence belongs to the observed COM interfaces, not to the mere presence of
// an initialized driver. Preserve originals observed before shared-table hooks.
struct Evidence {
 bool live_method=false;
 bool saved_present=false;
 bool saved_present1=false;
 void observe(bool live,bool present,bool present1) noexcept {
  live_method|=live;saved_present|=present;saved_present1|=present1;
 }
 bool native() const noexcept {return live_method||saved_present||saved_present1;}
};

// Shared COM tables can already contain our interceptors when a second chain
// is created. Inspect saved originals as well as the current public methods.
template<class Contains>
Evidence inspect(const void* present,const void* present1,
                 const void* saved_present,const void* saved_present1,Contains contains) noexcept {
 return {contains(present)||contains(present1),contains(saved_present),contains(saved_present1)};
}

template<class Attach>
void attach_context(Evidence evidence,bool d3d11,bool bridge_enabled,Attach attach){
 // A wrapper may forward private-data operations to its inner chain. Neither
 // attach nor clear our key through a native wrapper: that can mutate the
 // lifetime of a different COM object's bridge state.
 if(d3d11&&bridge_enabled&&!evidence.native())attach();
}

template<class Forward,class Managed>
auto entry(bool& in_native_forward,bool native_caller,bool native_original,Forward forward,Managed managed){
 // The interception remains installed for diagnostics, but NvPresent owns
 // presentation and transitions for its wrapper and its internal DXGI calls.
 // Do not read private Context data or perform bridge work on these entries.
 // A native wrapper may tail-call an inner DXGI method. Its return address
 // can then identify this module rather than NvPresent; retain ownership for
 // the complete forwarding stack, independently of managed-bridge recursion.
 if(in_native_forward||native_caller||native_original){
  struct NativeScope {
   bool& active;const bool previous;
   explicit NativeScope(bool& value) noexcept:active(value),previous(value){active=true;}
   ~NativeScope(){active=previous;}
  } scope(in_native_forward);
  return forward();
 }
 return managed();
}
}
