#include "include/nvs30/fatbin_core.hpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
#include <random>
using namespace nvs30::fatbin;
std::vector<std::byte> fixture(){
 std::vector<std::byte>b(16+32+64);auto*p=b.data();write<std::uint32_t>(p,0xba55ed50);write<std::uint16_t>(p+4,1);write<std::uint16_t>(p+6,16);write<std::uint64_t>(p+8,96);
 p+=16;write<std::uint16_t>(p,2);write<std::uint16_t>(p+2,0x101);write<std::uint32_t>(p+4,32);write<std::uint64_t>(p+8,64);write<std::uint32_t>(p+28,89);
 p+=32;std::memcpy(p,"\177ELF",4);p[4]=std::byte{2};p[5]=std::byte{1};write<std::uint16_t>(p+18,190);write<std::uint16_t>(p+52,64);write<std::uint32_t>(p+48,0x00590559);return b;
}
int main(int argc,char** argv){
 auto b=fixture(),copy=b;auto out=rewrite(b);assert(out.valid&&out.stats.sm89_to_sm86==1&&b==copy);
 assert(read<std::uint32_t>(out.bytes.data()+16+28)==86);assert(read<std::uint32_t>(out.bytes.data()+48+48)==0x00560556);
 for(std::size_t n=0;n<b.size();++n)assert(!rewrite(std::span(b).first(n)).valid);
 auto bad=b;write<std::uint16_t>(bad.data()+6,255);assert(!rewrite(bad).valid);
 bad=b;write<std::uint64_t>(bad.data()+8,UINT64_MAX);assert(!rewrite(bad).valid);
 bad=b;write<std::uint64_t>(bad.data()+16+8,UINT64_MAX);assert(!rewrite(bad).valid);
 bad=b;bad[48+4]=std::byte{1};assert(!rewrite(bad).valid);
 bad=b;write<std::uint32_t>(bad.data()+48+48,0x06005904);assert(!rewrite(bad).valid);
 bad=b;write<std::uint32_t>(bad.data()+16+28,120);auto unchanged=rewrite(bad);assert(unchanged.valid&&unchanged.bytes==bad&&unchanged.stats.sm120_left==1);
 // Deterministic hostile headers under ASan/UBSan exercise arithmetic, widths
 // and every truncation, not GPU execution or instruction compatibility.
 std::mt19937 rng(86);for(unsigned i=0;i<10000;++i){bad=b;for(unsigned j=0;j<4;++j)bad[rng()%bad.size()]=std::byte(rng()%256);auto x=rewrite(bad);if(x.valid)assert(x.bytes.size()<=bad.size());}
 unsigned real=0;
 if(argc==2){std::ifstream f(argv[1],std::ios::binary);std::vector<char> raw((std::istreambuf_iterator<char>(f)),{});assert(!raw.empty());
  auto data=std::span(reinterpret_cast<const std::byte*>(raw.data()),raw.size());
  for(std::size_t i=0;i+16<data.size();++i)if(read<std::uint32_t>(data.data()+i)==0xba55ed50){auto result=rewrite(data.subspan(i));if(!result.valid)continue;
   assert(result.stats.sm89_to_sm86==1&&result.stats.elf_headers==1&&result.stats.sm120_left==1);
   unsigned changed=0;for(std::size_t j=0;j<result.bytes.size();++j)changed+=result.bytes[j]!=data[i+j];assert(changed==3);++real;
  }
  assert(real==37);
 }
 std::cout<<"PASS: truncated/hostile CUDA containers, preserved ELF flags; real payloads="<<real<<". CUDA execution NOT tested.\n";
}
