// Execute production IAT scanning/dispatch with callable API targets and mapped
// PE images. Win32 enumeration/memory reads are deterministic seams; this is
// host execution, not evidence of Windows, CUDA, or game compatibility.
#include <array>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <pthread.h>
#include <tlhelp32.h>
bool patch(void**,void*,void*);
#ifndef NVS30_IMPORT_HOOKS_HEADER
#define NVS30_IMPORT_HOOKS_HEADER "include/nvs30/import_hooks.hpp"
#endif
#include NVS30_IMPORT_HOOKS_HEADER
#include "test_reference/gp4_module.hpp"
#include "include/nvs30/module_watch.hpp"
namespace module_watch=nvs30::module_watch;
#include "include/nvs30/library_hooks.hpp"

// ABI-shaped host types for executing the six production provider thunks.
// These are test seams only; the Windows build uses the real DirectX SDK.
using HRESULT=std::int32_t;using REFIID=int;using D3D_FEATURE_LEVEL=unsigned;using D3D_DRIVER_TYPE=unsigned;
constexpr HRESULT E_UNEXPECTED=static_cast<HRESULT>(0x8000ffffu);
inline bool SUCCEEDED(HRESULT result){return result>=0;}
struct IUnknown {};struct IDXGIAdapter {};struct IDXGISwapChain {};struct ID3D11Device {};
struct ID3D11DeviceContext {ID3D11Device* actual{};void GetDevice(ID3D11Device** out){*out=actual;}};
struct DXGI_SWAP_CHAIN_DESC {void* OutputWindow{};};
template<class T>struct Com {T* p{};T** put(){return &p;}};
HRESULT CreateDXGIFactory(REFIID,void**);HRESULT CreateDXGIFactory1(REFIID,void**);HRESULT CreateDXGIFactory2(UINT,REFIID,void**);
HRESULT D3D12CreateDevice(IUnknown*,D3D_FEATURE_LEVEL,REFIID,void**);
HRESULT D3D11CreateDevice(IDXGIAdapter*,D3D_DRIVER_TYPE,HMODULE,UINT,const D3D_FEATURE_LEVEL*,UINT,UINT,ID3D11Device**,D3D_FEATURE_LEVEL*,ID3D11DeviceContext**);
HRESULT D3D11CreateDeviceAndSwapChain(IDXGIAdapter*,D3D_DRIVER_TYPE,HMODULE,UINT,const D3D_FEATURE_LEVEL*,UINT,UINT,const DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**,ID3D11Device**,D3D_FEATURE_LEVEL*,ID3D11DeviceContext**);

namespace {
bool observeGraphicsObjects(){return true;}
unsigned checks=0,patches=0,providerCalls=0,systemCalls=0,hookCalls=0,unrelatedCalls=0,originQueries=0;
thread_local DWORD lastError=0;
void check(bool value,const char* why){++checks;if(!value){std::fprintf(stderr,"Import dispatch check failed: %s\n",why);std::abort();}}
struct Image {
 std::vector<unsigned char> bytes=std::vector<unsigned char>(16384);
 std::vector<void*> code;
 std::wstring path;std::string exportName;bool inaccessible=false;unsigned references=0;
 std::array<void*,graphics_provider::apiCount> graphics{};
 std::array<void*,imports::loader_api::count> loaders{};
 explicit Image(const wchar_t* p):path(p){
  put<std::uint16_t>(0,0x5a4d);put<std::uint32_t>(60,128);put<std::uint32_t>(128,0x4550);put<std::uint16_t>(132,0x8664);put<std::uint16_t>(148,240);
  const unsigned opt=152;put<std::uint16_t>(opt,0x20b);put<std::uint32_t>(opt+56,unsigned(bytes.size()));put<std::uint32_t>(opt+108,16);
  put<std::uint32_t>(opt+112+8,512);put<std::uint32_t>(opt+112+12,40);put<std::uint32_t>(512+12,896);put<std::uint32_t>(512+16,1024);std::memcpy(bytes.data()+896,"dxgi.dll",9);
 }
 template<class T>void put(std::size_t at,T value){std::memcpy(bytes.data()+at,&value,sizeof value);}
 void slot(unsigned index,void* target){put<std::uintptr_t>(1024+index*sizeof(void*),reinterpret_cast<std::uintptr_t>(target));}
 void* slot(unsigned index)const{void* target{};std::memcpy(&target,bytes.data()+1024+index*sizeof(void*),sizeof target);return target;}
 void exported(const char* name){exportName=name;put<std::uint32_t>(152+112,2048);put<std::uint32_t>(152+116,128);put<std::uint32_t>(2048+24,1);put<std::uint32_t>(2048+32,2112);put<std::uint32_t>(2112,2176);std::memcpy(bytes.data()+2176,name,std::strlen(name)+1);}
 void names(const char* dll,const std::vector<const char*>& symbols){
  put<std::uint32_t>(512,1280);std::memset(bytes.data()+896,0,128);std::strcpy(reinterpret_cast<char*>(bytes.data()+896),dll);
  for(std::size_t i=0;i<symbols.size();++i){const auto at=2304+i*128;put<std::uint64_t>(1280+i*8,at);std::strcpy(reinterpret_cast<char*>(bytes.data()+at+2),symbols[i]);}
 }
 void delay(const char* dll,const char* symbol,void* target){
  put<std::uint32_t>(152+112+8,0);put<std::uint32_t>(152+112+12,0);
  put<std::uint32_t>(152+112+13*8,600);put<std::uint32_t>(152+116+13*8,64);
  put<std::uint32_t>(600,1);put<std::uint32_t>(604,2016);put<std::uint32_t>(608,1472);
  put<std::uint32_t>(612,1408);put<std::uint32_t>(616,1536);put<std::uint32_t>(620,1600);put<std::uint32_t>(624,1664);
  std::strcpy(reinterpret_cast<char*>(bytes.data()+2016),dll);put<std::uint64_t>(1536,2560);std::strcpy(reinterpret_cast<char*>(bytes.data()+2562),symbol);
  for(auto at:{1408,1600,1664})put<std::uintptr_t>(at,reinterpret_cast<std::uintptr_t>(target));
 }
 HMODULE handle(){return bytes.data();}
 const void* caller()const{return bytes.data()+4096;}
};
std::vector<Image*> images;std::size_t enumeration=0;int snapshotHandle=0;
unsigned snapshotCalls=0,snapshotFailures=0,snapshotCloses=0,loadCalls=0;
DWORD snapshotError=ERROR_BAD_LENGTH;
bool snapshotThrows=false,snapshotReenters=false;
Image* nextLoaded=nullptr;
const void* expectedLoadPath=nullptr;HANDLE expectedLoadFile=nullptr;
DWORD expectedLoadFlags=0,loadError=0x7821;
unsigned expectedLoader=0;
const void* simulatedCaller=nullptr;
Image* imageFor(HMODULE h){for(auto* image:images)if(image->handle()==h)return image;return nullptr;}
Image* imageContaining(const void* at){const auto address=reinterpret_cast<std::uintptr_t>(at);for(auto* image:images){for(auto code:image->code)if(code==at)return image;const auto base=reinterpret_cast<std::uintptr_t>(image->bytes.data());if(address>=base&&address-base<image->bytes.size())return image;}return nullptr;}
int realSystemFactory(int cookie,void** output){++systemCalls;check(cookie==0x1234,"System factory ABI argument changed");*output=&systemCalls;lastError=0x4567;return 111;}
int proxyFactory(int cookie,void** output){++providerCalls;return realSystemFactory(cookie,output)+1;}
using Factory=int(*)(int,void**);
int hookFactory(int cookie,void** output){++hookCalls;return proxyFactory(cookie,output);}
void unrelated(){++unrelatedCalls;}
template<unsigned N> void distinct(){lastError=N;}
FARPROC realGetProcAddress(HMODULE module,const char* name){
 // Distinct module resolutions model a local graphics carrier and System32.
 lastError=0xbaa1;
 if(auto* image=imageFor(module))for(std::size_t i=0;i<image->graphics.size();++i)
  if(!std::strcmp(name,graphics_provider::names[i]))return reinterpret_cast<FARPROC>(image->graphics[i]);
 if(!std::strcmp(name,"CreateDXGIFactory"))return reinterpret_cast<FARPROC>(module==&snapshotHandle?&realSystemFactory:&proxyFactory);
 if(!std::strcmp(name,"Unrelated"))return &unrelated;
 if(!std::strcmp(name,"LoadPackagedLibrary"))return reinterpret_cast<FARPROC>(&LoadPackagedLibrary);
 lastError=0xbaa2;
 return nullptr;
}
FARPROC hookGetProcAddress(HMODULE module,const char* name){
#ifdef NVS30_SKIP_ORIGIN_TESTS
 return imports::replacement(realGetProcAddress(module,name));
#else
 return imports::resolved(module,name,realGetProcAddress(module,name),simulatedCaller);
#endif
}
bool internalCreation=false;
unsigned graphicsStarts=0,deviceObservations=0,swapObservations=0;
bool ensureRuntime(const char*,const void*){++graphicsStarts;lastError=0xface;return true;}
void observeDevice(ID3D11Device*){++deviceObservations;lastError=0xabcd;}
void registerSwapchain(IDXGISwapChain*){++swapObservations;lastError=0xabce;}
void beforeSwapchain(void*){lastError=0xabcf;}
template<class Create>HRESULT createFactory(const char* trigger,const void* caller,Create create,REFIID iid,void** result){
 return imports::graphicsCall(caller,internalCreation,[&]{ensureRuntime(trigger,caller);},[&]{return create(iid,result);},[](HRESULT){});
}
#define NVS30_CALLER_ADDRESS() simulatedCaller
}
#include "include/nvs30/provider_thunks.hpp"
#include "include/nvs30/loader_thunks.hpp"
namespace imports {void reportScan(const std::wstring&,bool,unsigned,unsigned){} void reportNamed(const std::wstring&,const char*,const char*,bool){}}
namespace {
template<class T>void* address(T value){return reinterpret_cast<void*>(value);}
void callFactory(void* addressToCall){
 auto fn=reinterpret_cast<Factory>(addressToCall);void* output=nullptr;check(fn(0x1234,&output)==112,"Hook did not preserve proxy result");check(output==&systemCalls&&lastError==0x4567,"Hook did not preserve factory outputs or LastError");
}
void exerciseModule(Image& game){imports::module(game.handle(),game.bytes.size());}
void* smallStackScan(void* input){exerciseModule(*static_cast<Image*>(input));return nullptr;}
#ifndef NVS30_SKIP_ORIGIN_TESTS
void originAndDynamicResolution(const void* caller,module_origin::Origin expected){
 lastError=0xbeef;check(imports::callerOrigin(caller)==expected,"Production caller origin classification changed");check(lastError==0xbeef,"Origin lookup changed the caller's LastError");
 const auto original=reinterpret_cast<FARPROC>(&proxyFactory),hook=reinterpret_cast<FARPROC>(&hookFactory);
 lastError=0xcafe;check(imports::replacement(original,caller)==(expected==module_origin::Origin::eligible?hook:original),"Origin-aware GPA returned a hook or provider for the wrong caller");check(lastError==0xcafe,"Origin-aware GPA changed LastError");
 const auto previousCaller=simulatedCaller;simulatedCaller=caller;lastError=0x1111;
 check(hookGetProcAddress(nullptr,"CreateDXGIFactory")== (expected==module_origin::Origin::eligible?hook:original),"GPA forwarding used the wrong origin policy");check(lastError==0xbaa1,"GPA forwarding lost the real resolver's successful LastError");
 check(hookGetProcAddress(nullptr,"Missing")==nullptr&&lastError==0xbaa2,"GPA forwarding changed the real resolver's failure result or LastError");simulatedCaller=previousCaller;
 // These resolutions must avoid even an origin query and retain the exact
 // OS-resolved address, including a distinct System32 graphics target.
 const auto queries=originQueries;lastError=0x1234;
 check(imports::replacement(nullptr,caller)==nullptr,"Origin-aware GPA replaced a missing export");
 check(imports::replacement(&unrelated,caller)==&unrelated,"Origin-aware GPA replaced an unrelated export");
 check(imports::replacement(reinterpret_cast<FARPROC>(&realSystemFactory),caller)==reinterpret_cast<FARPROC>(&realSystemFactory),"Origin-aware GPA rerouted a distinct System32 provider");
 check(lastError==0x1234&&originQueries==queries,"Unmatched GPA lookup performed caller inspection or changed LastError");
}
void cachedGraphicsEntry(const void* caller,bool internal,bool admitted){
 for(const std::int32_t expectedResult:{std::int32_t{321},std::int32_t{-31}}){
  unsigned starts=0,forwards=0,observes=0;const auto queries=originQueries;lastError=0x2468;
  const auto result=imports::graphicsCall(caller,internal,
   [&]{++starts;check(forwards==0&&observes==0,"Graphics startup ran after forwarding");lastError=0xaabb;},
   [&]{++forwards;check(starts==unsigned(admitted)&&observes==0,"Cached graphics entry ran excluded initialization or repeated creation");check(lastError==0x2468,"Origin/startup checks changed the API's incoming LastError");lastError=0x1357;return expectedResult;},
   [&](std::int32_t actual){++observes;check(forwards==1&&starts==1&&actual==expectedResult,"Graphics observation saw the wrong creation result/order");lastError=0xccdd;});
  check(result==expectedResult&&forwards==1,"Cached graphics entry changed or repeated the original API call");
  check(starts==unsigned(admitted)&&observes==unsigned(admitted),"Excluded graphics origin initialized the backend or observed COM output");
  check(lastError==0x1357,"Graphics observer changed the original API's outgoing LastError");
  if(internal)check(originQueries==queries,"Internal forwarding performed caller-origin inspection");
 }
}
#endif
}
namespace imports {
#ifdef NVS30_LEGACY_IMPORT_FIXTURE
const std::array<Hook,11> hooks{{
#else
const std::array<Hook,12> hooks{{
#endif
 {"CreateDXGIFactory",address(&proxyFactory),address(&hookFactory)},
 {"GetProcAddress",address(&realGetProcAddress),address(&hookGetProcAddress)},
 {"unused2",address(&distinct<2>),address(&distinct<12>)},
 {"unused3",address(&distinct<3>),address(&distinct<13>)},
 {"unused4",address(&distinct<4>),address(&distinct<14>)},
 {"unused5",address(&distinct<5>),address(&distinct<15>)},
 {"unused6",address(&distinct<6>),address(&distinct<16>)},
 {"unused7",address(&distinct<7>),address(&distinct<17>)},
 {"unused8",address(&distinct<8>),address(&distinct<18>)},
 {"unused9",address(&distinct<9>),address(&distinct<19>)},
 {"unused10",address(&distinct<10>),address(&distinct<20>)}
#ifndef NVS30_LEGACY_IMPORT_FIXTURE
 ,{"LoadPackagedLibrary",address(&LoadPackagedLibrary),address(&onLoadPackagedLibrary)}
#endif
 }};
}
bool patch(void** location,void* expected,void* replacement){void* current{};std::memcpy(&current,location,sizeof current);if(current!=expected)return false;std::memcpy(location,&replacement,sizeof replacement);++patches;return true;}
BOOL GetModuleHandleExW(DWORD flags,LPCWSTR from,HMODULE* out){
 const bool unchanged=(flags&GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT)!=0;
 check(flags==(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|(unchanged?GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT:0)),"Unexpected module lookup flags");if(unchanged)++originQueries;lastError=0xa10;
 auto* image=imageContaining(from);if(!image)return 0;if(!unchanged)++image->references;*out=image->handle();return 1;
}
BOOL FreeLibrary(HMODULE h){auto* image=imageFor(h);check(image&&image->references,"Unbalanced module release");--image->references;return 1;}
DWORD GetModuleFileNameW(HMODULE h,wchar_t* out,DWORD capacity){lastError=0xa11;auto* image=imageFor(h);if(!image||image->path.size()+1>capacity)return capacity;std::wmemcpy(out,image->path.c_str(),image->path.size()+1);return DWORD(image->path.size());}
DWORD GetWindowsDirectoryW(wchar_t* out,DWORD capacity){lastError=0xa12;constexpr wchar_t value[]=L"C:\\Windows";if(capacity<std::size(value))return DWORD(std::size(value));std::wmemcpy(out,value,std::size(value));return DWORD(std::size(value)-1);}
HANDLE GetCurrentProcess(){return &snapshotHandle;}
DWORD GetCurrentProcessId(){return 91;}
BOOL ReadProcessMemory(HANDLE process,const void* from,void* out,SIZE_T size,SIZE_T* copied){
 check(process==&snapshotHandle,"Unexpected process memory handle");*copied=0;const auto start=reinterpret_cast<std::uintptr_t>(from);
 for(const auto* image:images){const auto base=reinterpret_cast<std::uintptr_t>(image->bytes.data());if(start>=base&&start-base<=image->bytes.size()&&size<=image->bytes.size()-(start-base)){if(image->inaccessible)return 0;std::memcpy(out,from,size);*copied=size;return 1;}}
 return 0;
}
HANDLE CreateToolhelp32Snapshot(DWORD flags,DWORD pid){
 check(flags==TH32CS_SNAPMODULE&&pid==91,"Unexpected snapshot request");++snapshotCalls;
 if(snapshotThrows)throw 7;
 if(snapshotReenters){const auto before=snapshotCalls;check(!imports::refresh()&&snapshotCalls==before,"Reentrant scan was not rejected");}
 if(snapshotFailures){--snapshotFailures;lastError=snapshotError;return INVALID_HANDLE_VALUE;}
 enumeration=0;return &snapshotHandle;
}
BOOL CloseHandle(HANDLE h){check(h==&snapshotHandle,"Unexpected snapshot handle release");++snapshotCloses;return 1;}
BOOL Module32FirstW(HANDLE h,MODULEENTRY32W* out){check(h==&snapshotHandle,"Unexpected enumeration handle");enumeration=0;return Module32NextW(h,out);}
BOOL Module32NextW(HANDLE h,MODULEENTRY32W* out){check(h==&snapshotHandle&&out->dwSize==sizeof(*out),"Invalid enumeration ABI");if(enumeration==images.size()){lastError=ERROR_NO_MORE_FILES;return 0;}auto* image=images[enumeration++];out->hModule=image->handle();out->modBaseSize=DWORD(image->bytes.size());return 1;}
DWORD GetLastError(){return lastError;}
void SetLastError(DWORD value){lastError=value;}
FARPROC GetProcAddress(HMODULE h,const char* name){lastError=0xa13;auto* image=imageFor(h);if(image&&image->exportName==name)return &unrelated;
 if(image)for(std::size_t i=0;i<image->loaders.size();++i)if(!std::strcmp(name,imports::loader_api::names[i]))return reinterpret_cast<FARPROC>(image->loaders[i]);
 if(image)for(std::size_t i=0;i<image->graphics.size();++i)if(!std::strcmp(name,graphics_provider::names[i]))return reinterpret_cast<FARPROC>(image->graphics[i]);
 return nullptr;}

HMODULE fakeLoad(unsigned kind,const void* path,HANDLE file,DWORD flags){
 ++loadCalls;check(kind==expectedLoader&&path==expectedLoadPath&&file==expectedLoadFile&&flags==expectedLoadFlags,"Loader changed API, filename, handle or flags");
 if(nextLoaded&&!imageFor(nextLoaded->handle()))images.push_back(nextLoaded);
 lastError=loadError;return nextLoaded?nextLoaded->handle():nullptr;
}
HMODULE LoadLibraryA(LPCSTR path){return fakeLoad(0,path,nullptr,0);}
HMODULE LoadLibraryW(LPCWSTR path){return fakeLoad(1,path,nullptr,0);}
HMODULE LoadLibraryExA(LPCSTR path,HANDLE file,DWORD flags){return fakeLoad(2,path,file,flags);}
HMODULE LoadLibraryExW(LPCWSTR path,HANDLE file,DWORD flags){return fakeLoad(3,path,file,flags);}
HMODULE LoadPackagedLibrary(LPCWSTR path,DWORD reserved){return fakeLoad(4,path,nullptr,reserved);}

void packagedLoadingRegression(){
 Image game(L"D:\\XboxGames\\Fixture\\Content\\Game.exe"),renderer(L"C:\\Program Files\\WindowsApps\\Fixture_x64\\render.dll");
 game.slot(0,address(&LoadPackagedLibrary));game.slot(1,address(&realGetProcAddress));renderer.slot(0,address(&proxyFactory));
 images={&game};simulatedCaller=game.caller();exerciseModule(game);
 using PackageLoad=HMODULE(*)(LPCWSTR,DWORD);
 const wchar_t path[]=L"render-\u6e32\u67d3.dll";expectedLoader=4;expectedLoadPath=path;expectedLoadFile=nullptr;expectedLoadFlags=0;nextLoaded=&renderer;
 auto loaded=reinterpret_cast<PackageLoad>(game.slot(0))(path,0);
 check(loaded==renderer.handle()&&lastError==loadError,"Package load result or LastError changed");
 check(renderer.slot(0)==address(&hookFactory),"Packaged renderer escaped synchronous interception before first graphics call");
 const auto before=hookCalls;callFactory(renderer.slot(0));check(hookCalls==before+1,"Packaged renderer's first graphics call bypassed the hook");
 auto gpa=reinterpret_cast<FARPROC(*)(HMODULE,const char*)>(game.slot(1));
 auto dynamic=reinterpret_cast<PackageLoad>(gpa(nullptr,"LoadPackagedLibrary"));
 check(address(dynamic)==address(&onLoadPackagedLibrary),"Dynamic package loading bypassed production hook dispatch");
 const auto calls=loadCalls,patchedBefore=patches;
 check(dynamic(path,0)==renderer.handle()&&lastError==loadError&&loadCalls==calls+1,"Repeated packaged load changed forwarding");
 check(patches==patchedBefore,"Repeated package loading stacked hooks");
 for(DWORD reserved:{DWORD{0},DWORD{73}}){
  expectedLoadFlags=reserved;nextLoaded=nullptr;loadError=reserved?87:15700;const auto scans=snapshotCalls;
  check(!dynamic(path,reserved)&&lastError==loadError,"Failed packaged load did not preserve native result and error");
  check(snapshotCalls==scans,"Failed package load scanned modules");
 }
 nextLoaded=nullptr;images.clear();simulatedCaller=nullptr;
}
void snapshotRegression(){
 Image renderer(L"D:\\XboxGames\\Fixture\\Content\\renderer.dll");images={&renderer};
 for(unsigned failures:{1u,2u}){
  renderer.slot(0,address(&proxyFactory));snapshotFailures=failures;snapshotError=ERROR_BAD_LENGTH;
  const auto before=snapshotCalls,closes=snapshotCloses;
  check(imports::refresh(),"Transient ERROR_BAD_LENGTH was not retried to success");
  check(snapshotCalls==before+failures+1&&snapshotCloses==closes+1,"Snapshot retry count or handle ownership changed");
  check(renderer.slot(0)==address(&hookFactory),"Recovered scan failed to intercept renderer");
 }
 renderer.slot(0,address(&proxyFactory));snapshotFailures=3;auto before=snapshotCalls,closes=snapshotCloses;
 check(!imports::refresh()&&snapshotCalls==before+3&&snapshotCloses==closes,"Snapshot retry is unbounded or closed an invalid handle");
 check(renderer.slot(0)==address(&proxyFactory),"Failed snapshot modified imports");
 check(imports::refresh()&&renderer.slot(0)==address(&hookFactory),"Retry exhaustion left discovery permanently disabled");
 snapshotFailures=3;snapshotError=5;before=snapshotCalls;
 check(!imports::refresh()&&snapshotCalls==before+1&&snapshotFailures==2,"Permanent snapshot failure was retried");
 snapshotFailures=0;snapshotReenters=true;check(imports::refresh(),"Reentry guard blocked outer scan");snapshotReenters=false;images.clear();
}
void extendedWindowsRegression(){
 for(const wchar_t* path:{LR"(\\?\C:\Windows\System32\dxgi.dll)",L"C:/Windows/System32/kernelbase.dll",L"c:\\WINDOWS/System32\\foo.dll"}){
  Image os(path);images={&os};os.slot(0,address(&proxyFactory));exerciseModule(os);
  check(os.slot(0)==address(&proxyFactory),"Extended or mixed-separator Windows path had protected imports patched");
  originAndDynamicResolution(os.caller(),module_origin::Origin::excluded);cachedGraphicsEntry(os.caller(),false,false);
 }
 for(const wchar_t* path:{LR"(\\?\C:\Program Files\WindowsApps\Fixture_x64\engine.dll)",L"D:\\XboxGames\\Fixture\\Content\\engine.dll",L"C:\\WindowsGames\\engine.dll",L"C:\\Program Files\\ModifiableWindowsApps\\Fixture\\engine.dll"}){
  Image game(path);images={&game};game.slot(0,address(&proxyFactory));exerciseModule(game);
  check(game.slot(0)==address(&hookFactory),"Package/game renderer was overexcluded");originAndDynamicResolution(game.caller(),module_origin::Origin::eligible);
 }
 check(module_origin::excludedPath(LR"(\\?\C:\Windows\System32\dxgi.dll)",LR"(\\?\C:\Windows\)"),"Extended Windows-directory spelling failed");images.clear();
}
void loaderForwardingRegression(){
 const char narrow[]="render.dll";const wchar_t wide[]=L"render-\u6e32\u67d3.dll";
 for(unsigned kind=0;kind<5;++kind)for(DWORD flags:{DWORD{0},DWORD{1},DWORD{2},DWORD{0x20},DWORD{0x40},DWORD{0x1000}}){
  if((kind<2||kind==4)&&flags)continue;
  for(bool success:{false,true}){
   Image renderer(L"D:\\XboxGames\\Fixture\\Content\\renderer.dll");images.clear();renderer.slot(0,address(&proxyFactory));nextLoaded=success?&renderer:nullptr;
   expectedLoader=kind;expectedLoadPath=(kind==0||kind==2)?static_cast<const void*>(narrow):wide;expectedLoadFile=(kind==2||kind==3)?&snapshotHandle:nullptr;expectedLoadFlags=flags;
   const auto before=loadCalls,scans=snapshotCalls;loadError=success?0x8888:126;HMODULE result{};
   switch(kind){case 0:result=onLoadLibraryA(narrow);break;case 1:result=onLoadLibraryW(wide);break;case 2:result=onLoadLibraryExA(narrow,expectedLoadFile,flags);break;case 3:result=onLoadLibraryExW(wide,expectedLoadFile,flags);break;case 4:result=onLoadPackagedLibrary(wide,flags);break;}
   check(result==(success?renderer.handle():nullptr)&&lastError==loadError&&loadCalls==before+1,"Loader did not preserve exactly one native call and outputs");
   const bool scan=success&&module_watch::executable_load(flags);
   check(snapshotCalls==scans+unsigned(scan),"Failed or resource-only load scanned executable imports");
   check(renderer.slot(0)==(scan?address(&hookFactory):address(&proxyFactory)),"Loader interception violated resource mapping policy");
  }
 }
 Image renderer(L"D:\\XboxGames\\Fixture\\Content\\renderer.dll");images.clear();nextLoaded=&renderer;expectedLoader=4;expectedLoadPath=wide;expectedLoadFile=nullptr;expectedLoadFlags=0;loadError=0x8888;
 snapshotThrows=true;check(onLoadPackagedLibrary(wide,0)==renderer.handle()&&lastError==loadError,"Scan exception escaped packaged loader");snapshotThrows=false;
 check(imports::refresh(),"Scan exception left reentry flag set");nextLoaded=nullptr;images.clear();
}

namespace {
IUnknown adapter12;IDXGIAdapter adapter11;ID3D11Device resultDevice;ID3D11DeviceContext resultContext{&resultDevice};IDXGISwapChain resultSwap;
D3D_FEATURE_LEVEL featureLevels[]{11,12,13};DXGI_SWAP_CHAIN_DESC swapDesc{&resultSwap};
HRESULT providerResult=731;unsigned exactProviderCalls=0;
void providerCall(){++exactProviderCalls;check(lastError==0x3141,"Provider did not receive original LastError");lastError=0x2718;}
HRESULT slFactory(REFIID iid,void** out){providerCall();check(iid==0x5678,"Provider factory IID changed");*out=&resultSwap;return providerResult;}
HRESULT slFactory1(REFIID iid,void** out){return slFactory(iid,out);}
HRESULT slFactory2(UINT flags,REFIID iid,void** out){check(flags==0x42,"Provider factory flags changed");return slFactory(iid,out);}
HRESULT slDevice12(IUnknown* adapter,D3D_FEATURE_LEVEL level,REFIID iid,void** out){
 check(adapter==&adapter12&&level==12&&iid==0x5678,"Provider D3D12 arguments changed");providerCall();*out=&resultDevice;return providerResult;
}
HRESULT slDevice11(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 check(adapter==&adapter11&&type==7&&software==&snapshotHandle&&flags==0x42&&levels==featureLevels&&count==3&&sdk==88,"Provider D3D11 arguments changed");
 providerCall();if(device)*device=&resultDevice;if(level)*level=13;if(context)*context=&resultContext;return providerResult;
}
HRESULT slDevice11Swap(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL* levels,UINT count,UINT sdk,const DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** swap,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context){
 check(desc==&swapDesc,"Provider changed swapchain descriptor");if(swap)*swap=&resultSwap;
 return slDevice11(adapter,type,software,flags,levels,count,sdk,device,level,context);
}
HRESULT slOtherFactory(REFIID iid,void** out){slFactory(iid,out);return providerResult+1;}
void providerRegression(){
 // Consumer comes FIRST, exactly the ordering that misses a provider with a
 // one-pass module scan. The production import scanner and all six production
 // thunks execute here, with no address equality to the built-in DXGI hooks.
 static Image game(L"E:\\EA Games\\Dead Space (2023)\\Dead Space.exe"),provider(L"E:\\EA Games\\Dead Space (2023)\\sl.interposer.dll"),overlay(L"C:\\Steam\\gameoverlayrenderer64.dll");
 provider.graphics={{address(&slFactory),address(&slFactory1),address(&slFactory2),address(&slDevice12),address(&slDevice11),address(&slDevice11Swap)}};
 for(unsigned i=0;i<provider.graphics.size();++i){game.slot(i,provider.graphics[i]);overlay.slot(i,provider.graphics[i]);}
 images={&game,&overlay,&provider};simulatedCaller=game.caller();
 check(imports::refresh(),"Streamline snapshot scan failed");
 check(imports::providers.count()==1&&provider.references==1,"Provider was not published with exactly one retained module reference");
 const auto row=imports::providers.find(reinterpret_cast<std::uintptr_t>(provider.handle()));
 for(unsigned i=0;i<provider.graphics.size();++i){
  check(game.slot(i)==imports::providerWrappers[row][i],"Provider-backed game import escaped the first scan");
  check(overlay.slot(i)==provider.graphics[i],"Protected overlay provider import was modified");
 }
 const auto priorPatches=patches;check(imports::refresh()&&patches==priorPatches&&provider.references==1,"Repeated provider scan stacked hooks or retained extra module refs");
 for(HRESULT status:{731,-31}){
  providerResult=status;
  for(unsigned api=0;api<graphics_provider::apiCount;++api){
   const auto starts=graphicsStarts,calls=exactProviderCalls,observed=deviceObservations,swaps=swapObservations;
   void* output=nullptr;ID3D11Device* device=nullptr;ID3D11DeviceContext* context=nullptr;IDXGISwapChain* swap=nullptr;D3D_FEATURE_LEVEL level{};
   HRESULT hr{};lastError=0x3141;
   switch(api){
    case 0:case 1:hr=reinterpret_cast<decltype(&CreateDXGIFactory)>(game.slot(api))(0x5678,&output);break;
    case 2:hr=reinterpret_cast<decltype(&CreateDXGIFactory2)>(game.slot(api))(0x42,0x5678,&output);break;
    case 3:hr=reinterpret_cast<decltype(&D3D12CreateDevice)>(game.slot(api))(&adapter12,12,0x5678,&output);break;
    case 4:hr=reinterpret_cast<decltype(&D3D11CreateDevice)>(game.slot(api))(&adapter11,7,&snapshotHandle,0x42,featureLevels,3,88,&device,&level,&context);break;
    case 5:hr=reinterpret_cast<decltype(&D3D11CreateDeviceAndSwapChain)>(game.slot(api))(&adapter11,7,&snapshotHandle,0x42,featureLevels,3,88,&swapDesc,&swap,&device,&level,&context);break;
   }
   check(hr==status&&lastError==0x2718&&graphicsStarts==starts+1&&exactProviderCalls==calls+1,"Provider dispatch changed HRESULT/LastError, missed initialization, or forwarded twice");
   if(api<3)check(output==&resultSwap,"Provider factory output changed");
   if(api==3)check(output==&resultDevice,"Provider D3D12 output changed");
   if(api>=4)check(device==&resultDevice&&context==&resultContext&&level==13&&deviceObservations==observed+unsigned(status>=0),"Provider D3D11 output/observation changed");
   if(api==5)check(swap==&resultSwap&&swapObservations==swaps+unsigned(status>=0),"Provider swapchain output/observation changed");
  }
 }
 // Cached provider callbacks invoked by an excluded caller must forward but
 // cannot initialize, including when the provider re-enters an eligible helper.
 unsigned nestedStarts=0,nestedObserves=0;const auto starts=graphicsStarts;
 imports::graphicsCall(overlay.caller(),false,[&]{++nestedStarts;},[&]{
  return imports::graphicsCall(game.caller(),false,[&]{++nestedStarts;},[]{return -7;},[&](int){++nestedObserves;});
 },[&](int){++nestedObserves;});
 check(!nestedStarts&&!nestedObserves&&!imports::suppressedGraphics,"Excluded origin was lost across provider reentry");
 simulatedCaller=overlay.caller();void* output{};lastError=0x3141;
 check(reinterpret_cast<decltype(&CreateDXGIFactory)>(game.slot(0))(0x5678,&output)==providerResult&&graphicsStarts==starts&&lastError==0x2718,"Cached provider callback admitted protected origin");
 simulatedCaller=game.caller();
 for(unsigned api=0;api<graphics_provider::apiCount;++api){
  lastError=0x1234;const auto result=imports::resolved(provider.handle(),graphics_provider::names[api],reinterpret_cast<FARPROC>(provider.graphics[api]),game.caller());
  check(result==reinterpret_cast<FARPROC>(game.slot(api))&&lastError==0x1234,"Dynamic Streamline export did not preserve the provider binding/error");
  check(imports::resolved(provider.handle(),graphics_provider::names[api],reinterpret_cast<FARPROC>(provider.graphics[api]),overlay.caller())==reinterpret_cast<FARPROC>(provider.graphics[api]),"Dynamic export hooked an excluded origin");
 }
 check(imports::resolved(provider.handle(),reinterpret_cast<LPCSTR>(1),nullptr,game.caller())==nullptr,"Ordinal/missing resolution changed");
 // A newly loaded second interposer is discovered synchronously by GPA,
 // before a worker scan, and has its own forward destination.
 static Image dynamicProvider(L"D:\\XboxGames\\Fixture\\Content\\sl.interposer.dll");
 dynamicProvider.graphics[0]=address(&slOtherFactory);images.push_back(&dynamicProvider);
 auto dynamic=imports::resolved(dynamicProvider.handle(),"CreateDXGIFactory",reinterpret_cast<FARPROC>(&slOtherFactory),game.caller());
 check(imports::providers.count()==2&&dynamicProvider.references==1&&dynamic!=reinterpret_cast<FARPROC>(&slOtherFactory),"Late dynamic provider was not intercepted");
 lastError=0x3141;check(reinterpret_cast<decltype(&CreateDXGIFactory)>(dynamic)(0x5678,&output)==providerResult+1&&lastError==0x2718,"Second provider forwarded to the first provider");
 for(const wchar_t* path:{L"C:\\Windows\\System32\\sl.interposer.dll",L"C:\\Games\\sl.interposer.dll.backup",L"C:\\Games\\another.dll"}){
  Image rejected(path);rejected.graphics=provider.graphics;images.push_back(&rejected);imports::discoverProvider(rejected.handle());
  check(rejected.references==0&&imports::providers.find(reinterpret_cast<std::uintptr_t>(rejected.handle()))==decltype(imports::providers)::missing,"Provider recognition accepted an excluded/lookalike module");images.pop_back();
 }
 check(game.references==0&&overlay.references==0,"Consumer/overlay module references leaked");
 images.clear();simulatedCaller=nullptr;
}
}

namespace {
unsigned aliasCalls=0;
FARPROC baseGetProc(HMODULE module,LPCSTR name){++aliasCalls;
 if(reinterpret_cast<std::uintptr_t>(name)<=0xffff){lastError=127;return nullptr;}
 return realGetProcAddress(module,name);
}
HMODULE baseLoadA(LPCSTR path){++aliasCalls;return fakeLoad(0,path,nullptr,0);}
HMODULE baseLoadW(LPCWSTR path){++aliasCalls;return fakeLoad(1,path,nullptr,0);}
HMODULE baseLoadExA(LPCSTR path,HANDLE file,DWORD flags){++aliasCalls;return fakeLoad(2,path,file,flags);}
HMODULE baseLoadExW(LPCWSTR path,HANDLE file,DWORD flags){++aliasCalls;return fakeLoad(3,path,file,flags);}
HMODULE baseLoadPackage(LPCWSTR path,DWORD reserved){++aliasCalls;return fakeLoad(4,path,nullptr,reserved);}
void loaderAliasRegression(){
 static Image base(L"C:\\Windows\\System32\\KernelBase.dll"),game(L"C:\\Steam\\Dead Space\\Dead Space.exe"),overlay(L"C:\\Steam\\gameoverlayrenderer64.dll");
 base.loaders={{address(&baseGetProc),address(&baseLoadA),address(&baseLoadW),address(&baseLoadExA),address(&baseLoadExW),address(&baseLoadPackage)}};
 // Before provider discovery, every KernelBase target is invisible to the
 // old single-address matching strategy. No alias may accidentally equal it.
 for(unsigned i=0;i<base.loaders.size();++i){
  check(imports::replacement(reinterpret_cast<FARPROC>(base.loaders[i]))==reinterpret_cast<FARPROC>(base.loaders[i]),"Alias fixture already matched canonical hooks");
  game.slot(i,base.loaders[i]);overlay.slot(i,base.loaders[i]);base.slot(i,base.loaders[i]);
 }
 // The consumer precedes the system provider in the snapshot.
 images={&game,&overlay,&base};simulatedCaller=game.caller();check(imports::refresh(),"Alias initial scan failed");
 check(imports::loader_api::providers.count()==1&&base.references==1,"Alias module must retain exactly one reference");
 const auto row=imports::loader_api::providers.find(reinterpret_cast<std::uintptr_t>(base.handle()));
 for(unsigned i=0;i<base.loaders.size();++i){
  check(game.slot(i)==imports::loader_api::wrappers[row][i],"API-set loader import was missed");
  check(overlay.slot(i)==base.loaders[i]&&base.slot(i)==base.loaders[i],"System/overlay IAT must stay excluded");
 }
 const auto before=patches;check(imports::refresh()&&patches==before&&base.references==1,"Duplicate alias scan changed bindings or leaked reference");
 const char narrow[]="Engine.Render.Core2.PlatformPcDx12.dll";const wchar_t wide[]=L"Engine.Render.Core2.PlatformPcDx12.dll";
 for(unsigned kind=0;kind<5;++kind)for(DWORD flags:{DWORD{0},DWORD{1},DWORD{2},DWORD{0x20},DWORD{0x40},DWORD{0x1000}}){
  if((kind<2||kind==4)&&flags)continue;
  for(bool success:{false,true}){
   Image engine(L"C:\\Steam\\Dead Space\\Engine.Render.Core2.PlatformPcDx12.dll");
   engine.slot(0,address(&baseGetProc));engine.slot(1,address(&proxyFactory));
   images={&game,&overlay,&base};nextLoaded=success?&engine:nullptr;
   expectedLoader=kind;expectedLoadPath=(kind==0||kind==2)?static_cast<const void*>(narrow):wide;
   expectedLoadFile=(kind==2||kind==3)?&snapshotHandle:nullptr;expectedLoadFlags=flags;
   const auto calls=aliasCalls,loads=loadCalls,scans=snapshotCalls;loadError=success?0x8888:126;HMODULE loaded{};
   switch(kind){
    case 0:loaded=reinterpret_cast<decltype(&LoadLibraryA)>(game.slot(1))(narrow);break;
    case 1:loaded=reinterpret_cast<decltype(&LoadLibraryW)>(game.slot(2))(wide);break;
    case 2:loaded=reinterpret_cast<decltype(&LoadLibraryExA)>(game.slot(3))(narrow,expectedLoadFile,flags);break;
    case 3:loaded=reinterpret_cast<decltype(&LoadLibraryExW)>(game.slot(4))(wide,expectedLoadFile,flags);break;
    case 4:loaded=reinterpret_cast<decltype(&LoadPackagedLibrary)>(game.slot(5))(wide,flags);break;
   }
   const bool scan=success&&module_watch::executable_load(flags);
   check(loaded==(success?engine.handle():nullptr)&&lastError==loadError&&aliasCalls==calls+1&&loadCalls==loads+1,"Loader alias changed exact forwarding or error");
   check(snapshotCalls==scans+unsigned(scan),"Alias scanned failed/resource-only load");
   check(engine.slot(0)==(scan?game.slot(0):address(&baseGetProc)),"New renderer GPA alias missed synchronous scan");
   check(engine.slot(1)==(scan?address(&hookFactory):address(&proxyFactory)),"New renderer factory missed synchronous scan");
   if(scan){
    // Use the engine's newly hooked lookup immediately, before any worker
    // refresh. This is the call chain GP3 cannot intercept through KernelBase.
    simulatedCaller=engine.caller();const auto gpa=reinterpret_cast<decltype(&GetProcAddress)>(engine.slot(0));
    const auto observed=hookCalls;
    auto factory=gpa(nullptr,"CreateDXGIFactory");check(lastError==0xbaa1,"Alias GPA changed error");callFactory(address(factory));
    check(hookCalls==observed+1,"Immediate engine graphics startup bypassed interception");
    check(gpa(nullptr,"Missing")==nullptr&&lastError==0xbaa2,"Alias missing export changed");
    check(gpa(nullptr,reinterpret_cast<LPCSTR>(1))==nullptr&&lastError==127,"Alias ordinal lookup changed");
    simulatedCaller=game.caller();
   }
  }
 }
 images={&game,&overlay,&base};nextLoaded=nullptr;
 auto gpa=reinterpret_cast<decltype(&GetProcAddress)>(game.slot(0));simulatedCaller=overlay.caller();
 check(gpa(nullptr,"CreateDXGIFactory")==reinterpret_cast<FARPROC>(&proxyFactory),"Cached alias lookup admitted overlay origin");
 simulatedCaller=game.caller();
 for(unsigned i=0;i<base.loaders.size();++i){
  lastError=0x2211;check(imports::resolved(base.handle(),imports::loader_api::names[i],reinterpret_cast<FARPROC>(base.loaders[i]),game.caller())==reinterpret_cast<FARPROC>(game.slot(i))&&lastError==0x2211,"Dynamic alias binding lost destination/error");
 }
 for(const wchar_t* path:{L"C:\\Games\\kernelbase.dll",L"C:\\WindowsGames\\kernel32.dll",L"C:\\Windows\\System32\\kernelbase.dll.backup"}){
  Image wrong(path);wrong.loaders=base.loaders;images.push_back(&wrong);imports::discoverLoader(wrong.handle());
  check(wrong.references==0&&imports::loader_api::providers.count()==1,"Untrusted loader lookalike was accepted");images.pop_back();
 }
 check(imports::loader_api::patches.load()>=6,"Alias interception status not counted");
 images.clear();simulatedCaller=nullptr;
}
}

namespace {
unsigned wrappedCalls=0;unsigned expectedStart=0;
void enteredWrapped(){++wrappedCalls;check(graphicsStarts==expectedStart,"Named graphics original ran before initialization or started twice");}
HRESULT wrappedFactory(REFIID id,void** out){enteredWrapped();return slFactory(id,out);}
HRESULT wrappedFactory1(REFIID id,void** out){enteredWrapped();return slFactory1(id,out);}
HRESULT wrappedFactory2(UINT flags,REFIID id,void** out){enteredWrapped();return slFactory2(flags,id,out);}
HRESULT wrappedDevice12(IUnknown* a,D3D_FEATURE_LEVEL l,REFIID id,void** out){enteredWrapped();return slDevice12(a,l,id,out);}
HRESULT wrappedDevice11(IDXGIAdapter* a,D3D_DRIVER_TYPE t,HMODULE m,UINT f,const D3D_FEATURE_LEVEL* l,UINT n,UINT sdk,ID3D11Device** d,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** c){enteredWrapped();return slDevice11(a,t,m,f,l,n,sdk,d,level,c);}
HRESULT wrappedDevice11Swap(IDXGIAdapter* a,D3D_DRIVER_TYPE t,HMODULE m,UINT f,const D3D_FEATURE_LEVEL* l,UINT n,UINT sdk,const DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** swap,ID3D11Device** d,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** c){enteredWrapped();return slDevice11Swap(a,t,m,f,l,n,sdk,desc,swap,d,level,c);}
FARPROC resolverTarget{};unsigned resolverCalls=0;
FARPROC interceptedResolver(HMODULE image,LPCSTR name){++resolverCalls;if(reinterpret_cast<std::uintptr_t>(name)>0xffff&&!std::strcmp(name,"CreateDXGIFactory")){lastError=0x5050;return resolverTarget;}return baseGetProc(image,name);}
HMODULE interceptedLoadA(LPCSTR p){return baseLoadA(p);}HMODULE interceptedLoadW(LPCWSTR p){return baseLoadW(p);}
HMODULE interceptedLoadExA(LPCSTR p,HANDLE f,DWORD flags){return baseLoadExA(p,f,flags);}HMODULE interceptedLoadExW(LPCWSTR p,HANDLE f,DWORD flags){return baseLoadExW(p,f,flags);}
HMODULE interceptedPackage(LPCWSTR p,DWORD r){return baseLoadPackage(p,r);}
Image* delayImage=nullptr;unsigned delayCalls=0;
HRESULT unresolvedDevice12(IUnknown* a,D3D_FEATURE_LEVEL level,REFIID id,void** out){
 ++delayCalls;check(graphicsStarts==expectedStart,"Delay thunk executed before graphics initialization");
 // Model the standard delay helper overwriting the active IAT. Neither the
 // bound nor unload table may have been overwritten by our import scanner.
 check(delayImage!=nullptr,"Missing delay fixture");
 delayImage->put<std::uintptr_t>(1408,reinterpret_cast<std::uintptr_t>(&wrappedDevice12));
 return wrappedDevice12(a,level,id,out);
}
void namedInterceptionRegression(){
 static Image game(L"C:\\Steam\\Dead Space\\Dead Space.exe"),code(L"C:\\RTSS\\RTSSHooks64.dll"),os(L"C:\\Windows\\System32\\dxgi.dll"),loader(L"C:\\Steam\\Dead Space\\dxgi.dll"),protectedImage(L"C:\\Steam\\gameoverlayrenderer64.dll");
 const std::array<void*,6> originals{{address(&wrappedFactory),address(&wrappedFactory1),address(&wrappedFactory2),address(&wrappedDevice12),address(&wrappedDevice11),address(&wrappedDevice11Swap)}};
 code.code.assign(originals.begin(),originals.end());code.code.push_back(address(&realSystemFactory));
 game.names("sl.interposer.dll",{graphics_provider::names.begin(),graphics_provider::names.end()});
 protectedImage.names("sl.interposer.dll",{graphics_provider::names.begin(),graphics_provider::names.end()});
 for(unsigned i=0;i<6;++i){game.slot(i,originals[i]);protectedImage.slot(i,originals[i]);check(imports::replacement(reinterpret_cast<FARPROC>(originals[i]))==reinterpret_cast<FARPROC>(originals[i]),"GP4 address-only regression target must be unknown");}
 images={&game,&code,&os,&loader,&protectedImage};simulatedCaller=game.caller();
 imports::moduleGP4(game.handle(),game.bytes.size());
 for(unsigned i=0;i<6;++i)check(game.slot(i)==originals[i],"GP4 comparison unexpectedly intercepted the named wrapper");
 check(imports::refresh(),"Named import scan failed");
 check(imports::named::graphics.count()==6&&code.references==6,"Named graphics targets not individually retained");
 for(unsigned i=0;i<6;++i)check(game.slot(i)!=originals[i]&&protectedImage.slot(i)==originals[i],"Named interception missed target or modified overlay IAT");
 const auto old=patches;check(imports::refresh()&&patches==old&&code.references==6,"Named repeated scan wrapped our callbacks or leaked refs");
 for(HRESULT status:{731,-31})for(unsigned api=0;api<6;++api){
  providerResult=status;const auto calls=wrappedCalls,observed=deviceObservations,swaps=swapObservations;expectedStart=graphicsStarts+1;
  void* output{};ID3D11Device* device{};ID3D11DeviceContext* context{};IDXGISwapChain* swap{};D3D_FEATURE_LEVEL level{};lastError=0x3141;HRESULT hr{};
  switch(api){
   case 0:case 1:hr=reinterpret_cast<decltype(&CreateDXGIFactory)>(game.slot(api))(0x5678,&output);break;
   case 2:hr=reinterpret_cast<decltype(&CreateDXGIFactory2)>(game.slot(api))(0x42,0x5678,&output);break;
   case 3:hr=reinterpret_cast<decltype(&D3D12CreateDevice)>(game.slot(api))(&adapter12,12,0x5678,&output);break;
   case 4:hr=reinterpret_cast<decltype(&D3D11CreateDevice)>(game.slot(api))(&adapter11,7,&snapshotHandle,0x42,featureLevels,3,88,&device,&level,&context);break;
   case 5:hr=reinterpret_cast<decltype(&D3D11CreateDeviceAndSwapChain)>(game.slot(api))(&adapter11,7,&snapshotHandle,0x42,featureLevels,3,88,&swapDesc,&swap,&device,&level,&context);break;
  }
  check(hr==status&&lastError==0x2718&&wrappedCalls==calls+1&&graphicsStarts==expectedStart,"Named forwarding changed HRESULT, LastError or exact target count");
  if(api<3)check(output==&resultSwap,"Named factory output changed");if(api==3)check(output==&resultDevice,"Named device12 output changed");
  if(api>=4)check(device==&resultDevice&&level==13&&context==&resultContext&&deviceObservations==observed+unsigned(status>=0),"Named D3D11 observations changed");
  if(api==5)check(swap==&resultSwap&&swapObservations==swaps+unsigned(status>=0),"Named swap observations changed");
 }
 // Cached callback admitted at game use, excluded at overlay use.
 simulatedCaller=protectedImage.caller();expectedStart=graphicsStarts;lastError=0x3141;void* output{};
 reinterpret_cast<decltype(&CreateDXGIFactory)>(game.slot(0))(0x5678,&output);check(graphicsStarts==expectedStart,"Cached named callback admitted overlay");simulatedCaller=game.caller();
 // A resolver already replaced by an overlay is found by its named IAT
 // identity. Its actual returned graphics wrapper must remain in the chain.
 static Image engine(L"C:\\Steam\\Dead Space\\Engine.Render.Core2.PlatformPcDx12.dll");
 const std::array<void*,6> loaderOriginals{{address(&interceptedResolver),address(&interceptedLoadA),address(&interceptedLoadW),address(&interceptedLoadExA),address(&interceptedLoadExW),address(&interceptedPackage)}};
 code.code.insert(code.code.end(),loaderOriginals.begin(),loaderOriginals.end());
 engine.names("api-ms-win-core-libraryloader-l1-2-0.dll",{imports::loader_api::names.begin(),imports::loader_api::names.end()});
 for(unsigned i=0;i<6;++i)engine.slot(i,loaderOriginals[i]);images.push_back(&engine);exerciseModule(engine);simulatedCaller=engine.caller();
 check(imports::named::loaders.count()==6,"Named loader interception missed existing wrapper destinations");
 const auto gpa=reinterpret_cast<decltype(&GetProcAddress)>(engine.slot(0));resolverTarget=reinterpret_cast<FARPROC>(&wrappedFactory);
 const auto rc=resolverCalls;auto dynamic=gpa(os.handle(),"CreateDXGIFactory");check(lastError==0x5050&&resolverCalls==rc+1&&dynamic!=resolverTarget,"Named resolver chain was skipped or System32 graphics target was missed");
 lastError=0x3141;expectedStart=graphicsStarts+1;reinterpret_cast<decltype(&CreateDXGIFactory)>(dynamic)(0x5678,&output);
 check(graphicsStarts==expectedStart&&lastError==0x2718,"Dynamic wrapped graphics entry bypassed initialization");
 // Same request later returns a different original: neither cached callback
 // may be rebound, and the direct system call must not traverse local proxy.
 resolverTarget=reinterpret_cast<FARPROC>(&realSystemFactory);auto system=gpa(os.handle(),"CreateDXGIFactory");
 const auto systems=systemCalls,proxies=providerCalls;check(system!=resolverTarget&&system!=dynamic,"Distinct graphics originals shared a mutable callback");
 check(reinterpret_cast<Factory>(system)(0x1234,&output)==111&&systemCalls==systems+1&&providerCalls==proxies,"System32 target traversed the local proxy instead");
 expectedStart=graphicsStarts+1;lastError=0x3141;reinterpret_cast<decltype(&CreateDXGIFactory)>(dynamic)(0x5678,&output);check(lastError==0x2718,"Older cached callback was redirected to later target");
 resolverTarget=dynamic;check(gpa(os.handle(),"CreateDXGIFactory")==dynamic,"Dynamic resolution wrapped our callback recursively");
 check(gpa(os.handle(),reinterpret_cast<LPCSTR>(1))==nullptr&&lastError==127,"Named resolver ordinal lookup changed");
 check(gpa(os.handle(),"Missing")==nullptr&&lastError==0xbaa2,"Named resolver missing export changed");
 // All named loader callback ABIs use their exact original address.
 const char narrow[]="renderer.dll";const wchar_t wide[]=L"renderer.dll";
 for(unsigned kind=0;kind<5;++kind)for(bool success:{false,true})for(DWORD flags:{DWORD{0},DWORD{2},DWORD{0x40}}){
  if((kind<2||kind==4)&&flags)continue;
  Image loaded(L"C:\\Games\\new-renderer.dll");nextLoaded=success?&loaded:nullptr;
  expectedLoader=kind;expectedLoadPath=kind==0||kind==2?static_cast<const void*>(narrow):wide;expectedLoadFile=kind==2||kind==3?&snapshotHandle:nullptr;expectedLoadFlags=flags;loadError=success?0x6767:126;
  const auto scans=snapshotCalls,loads=loadCalls;HMODULE result{};
  switch(kind){case 0:result=reinterpret_cast<decltype(&LoadLibraryA)>(engine.slot(1))(narrow);break;case 1:result=reinterpret_cast<decltype(&LoadLibraryW)>(engine.slot(2))(wide);break;case 2:result=reinterpret_cast<decltype(&LoadLibraryExA)>(engine.slot(3))(narrow,expectedLoadFile,flags);break;case 3:result=reinterpret_cast<decltype(&LoadLibraryExW)>(engine.slot(4))(wide,expectedLoadFile,flags);break;case 4:result=reinterpret_cast<decltype(&LoadPackagedLibrary)>(engine.slot(5))(wide,flags);break;}
  check(result==(success?loaded.handle():nullptr)&&lastError==loadError&&loadCalls==loads+1,"Named loader changed result, LastError or call count");
  check(snapshotCalls==scans+unsigned(success&&!flags),"Named loader scanned resource-only/failed load");
  if(success)images.pop_back();
 }
 nextLoaded=nullptr;
 // Delay IAT stores a game thunk, not the DLL's final D3D12 export. Intercept
 // that first call by identity, preserving the helper and its own IAT update.
 static Image delayed(L"C:\\Steam\\Dead Space\\delay-engine.dll");delayed.delay("d3d12.dll","D3D12CreateDevice",address(&unresolvedDevice12));delayed.code.push_back(address(&unresolvedDevice12));images.push_back(&delayed);delayImage=&delayed;
 const auto delays=imports::named::delayPatches.load();
 imports::moduleGP4(delayed.handle(),delayed.bytes.size());void* gp4Delay{};std::memcpy(&gp4Delay,delayed.bytes.data()+1408,8);
 check(gp4Delay==address(&unresolvedDevice12),"GP4 comparison unexpectedly hooked unresolved delay thunk");
 exerciseModule(delayed);
 void* active{};std::memcpy(&active,delayed.bytes.data()+1408,8);check(active!=address(&unresolvedDevice12)&&imports::named::delayPatches==delays+1,"Unresolved delay IAT was missed");
 for(auto at:{1600,1664}){void* copy{};std::memcpy(&copy,delayed.bytes.data()+at,8);check(copy==address(&unresolvedDevice12),"Bound/unload delay copy was modified");}
 simulatedCaller=delayed.caller();expectedStart=graphicsStarts+1;lastError=0x3141;const auto delayBefore=delayCalls;
 reinterpret_cast<decltype(&D3D12CreateDevice)>(active)(&adapter12,12,0x5678,&output);
 check(delayCalls==delayBefore+1&&graphicsStarts==expectedStart&&lastError==0x2718,"Delay helper chain failed");
 exerciseModule(delayed);void* after{};std::memcpy(&after,delayed.bytes.data()+1408,8);check(after!=address(&wrappedDevice12)&&after!=active,"Resolved delay slot did not acquire its own stable binding");
 expectedStart=graphicsStarts+1;lastError=0x3141;reinterpret_cast<decltype(&D3D12CreateDevice)>(after)(&adapter12,12,0x5678,&output);check(delayCalls==delayBefore+1,"Resolved delay call re-entered unresolved helper");
 const auto captured=imports::named::graphics.count();
 for(auto dll:{"other.dll","dxgi.dll.backup"}){
  Image wrong(L"C:\\Games\\lookalike.dll");wrong.names(dll,{"CreateDXGIFactory"});wrong.slot(0,address(&wrappedFactory));images.push_back(&wrong);exerciseModule(wrong);
  check(wrong.slot(0)==address(&wrappedFactory)&&imports::named::graphics.count()==captured,"Named interception accepted unrelated DLL identity");images.pop_back();
 }
 images.clear();simulatedCaller=nullptr;delayImage=nullptr;
}
}

int main(int argc,char** argv){
 if(argc==2&&!std::strcmp(argv[1],"--packaged-load-only")){packagedLoadingRegression();return 0;}
 if(argc==2&&!std::strcmp(argv[1],"--snapshot-only")){snapshotRegression();return 0;}
 if(argc==2&&!std::strcmp(argv[1],"--extended-windows-only")){extendedWindowsRegression();return 0;}
 const bool small=argc==2&&!std::strcmp(argv[1],"--small-stack");
 Image game(L"C:\\Games\\fixture.exe");game.slot(0,address(&proxyFactory));game.slot(1,address(&realGetProcAddress));game.slot(2,address(&unrelated));images.push_back(&game);simulatedCaller=game.caller();
 if(small){
  pthread_attr_t attr;check(pthread_attr_init(&attr)==0,"pthread_attr_init");check(pthread_attr_setstacksize(&attr,64*1024)==0,"Cannot select a 64 KiB test stack");pthread_t thread{};
  check(pthread_create(&thread,&attr,smallStackScan,&game)==0,"Cannot start small-stack test thread");pthread_attr_destroy(&attr);check(pthread_join(thread,nullptr)==0,"Cannot join small-stack test thread");
 }else exerciseModule(game);
 check(game.slot(0)==address(&hookFactory)&&game.slot(1)==address(&hookGetProcAddress),"Production scanner missed callable IAT entries");check(game.slot(2)==address(&unrelated),"Production scanner modified unrelated import");
 callFactory(game.slot(0));check(providerCalls==1&&systemCalls==1&&hookCalls==1,"IAT forwarding recursed, skipped or repeated the provider");
 using GPA=FARPROC(*)(HMODULE,const char*);auto gpa=reinterpret_cast<GPA>(game.slot(1));
 callFactory(address(gpa(nullptr,"CreateDXGIFactory")));check(providerCalls==2&&systemCalls==2&&hookCalls==2,"Dynamic forwarding did not preserve local carrier chain");
 check(gpa(nullptr,"Missing")==nullptr,"Missing export changed into callable hook");gpa(nullptr,"Unrelated")();check(unrelatedCalls==1,"Unrelated dynamic export changed");
 // Different-address System32 resolutions must not accidentally route through
 // a local carrier. Current code preserves this target but does not intercept
 // it; report the discovery limitation rather than assert false coverage.
 auto system=gpa(&snapshotHandle,"CreateDXGIFactory");check(system==reinterpret_cast<FARPROC>(&realSystemFactory),"System32 resolution was incorrectly redirected through the local provider");
 void* output{};check(reinterpret_cast<Factory>(system)(0x1234,&output)==111,"System32 target result changed");check(providerCalls==2&&systemCalls==3,"System32 call traversed the wrong provider");
 auto before=patches;exerciseModule(game);check(patches==before,"Repeated scan repatched or chained its own hooks");
 Image own(L"C:\\Games\\normal.asi"),os(L"c:\\WINDOWS\\System32\\dxgi.dll"),prefix(L"C:\\WindowsGames\\renderer.dll"),loader(L"C:\\Games\\dxgi.dll"),backend(L"C:\\Games\\other.asi"),bad(L"C:\\Games\\inaccessible.dll");
 Image steam64(L"C:\\Program Files (x86)\\Steam\\gameoverlayrenderer64.dll"),steam32(L"C:\\OtherSteam\\GAMEOVERLAYRENDERER.DLL"),similar(L"C:\\Games\\gameoverlayrenderer64-helper.dll"),suffix(L"C:\\Games\\gameoverlayrenderer64.dll.backup"),engine(L"C:\\Program Files (x86)\\Steam\\engine.dll");
 for(auto* image:{&own,&os,&prefix,&loader,&backend,&bad,&steam64,&steam32,&similar,&suffix,&engine}){image->slot(0,address(&proxyFactory));image->slot(1,address(&realGetProcAddress));images.push_back(image);}
 imports::owner=own.handle();loader.exported("IsUltimateASILoader");backend.exported("SmoothMotionGetStatus");bad.inaccessible=true;
 check(imports::refresh(),"Production refresh failed");
 check(own.slot(0)==address(&proxyFactory)&&own.references==0,"Own imports were patched or retained");check(os.slot(0)==address(&proxyFactory),"System-directory imports were patched");
 check(loader.slot(0)==address(&proxyFactory)&&backend.slot(0)==address(&proxyFactory),"Loader/backend exclusion failed");check(bad.slot(0)==address(&proxyFactory),"Inaccessible image was partially patched");check(prefix.slot(0)==address(&hookFactory),"Windows directory prefix overexcluded an unrelated game directory");
 for(auto* steam:{&steam64,&steam32}){check(steam->exportName.empty(),"Steam regression fixture must have ordinary exports");check(steam->slot(0)==address(&proxyFactory)&&steam->slot(1)==address(&realGetProcAddress),"Production scanner rewrote confirmed Steam overlay imports");}
 for(auto* eligible:{&similar,&suffix,&engine})check(eligible->slot(0)==address(&hookFactory)&&eligible->slot(1)==address(&hookGetProcAddress),"Origin exclusion overreached an eligible engine");
#ifndef NVS30_SKIP_ORIGIN_TESTS
 for(auto* protectedImage:{&steam64,&steam32,&own,&os,&loader,&backend}){originAndDynamicResolution(protectedImage->caller(),module_origin::Origin::excluded);cachedGraphicsEntry(protectedImage->caller(),false,false);}
 for(auto* eligible:{&game,&prefix,&similar,&suffix,&engine}){originAndDynamicResolution(eligible->caller(),module_origin::Origin::eligible);cachedGraphicsEntry(eligible->caller(),false,true);}
 for(const auto* unknown:{static_cast<const void*>(nullptr),reinterpret_cast<const void*>(std::uintptr_t{0x12345})}){originAndDynamicResolution(unknown,module_origin::Origin::unknown);cachedGraphicsEntry(unknown,false,true);}
 cachedGraphicsEntry(game.caller(),true,false);cachedGraphicsEntry(steam64.caller(),true,false);
#endif
 for(auto* image:images)check(image->references==0,"Module reference leaked after scan");
 imports::owner=nullptr;images.clear();snapshotRegression();extendedWindowsRegression();packagedLoadingRegression();loaderForwardingRegression();
 providerRegression();loaderAliasRegression();namedInterceptionRegression();
 std::printf("{\"result\":\"PASS\",\"test\":\"production_import_dispatch_host\",\"checks\":%u,\"small_stack_bytes\":%u,\"native_windows_executed\":false,\"streamline_creation_apis_tested\":6,\"steam_overlay_origin_exclusion_tested\":true,\"loader_alias_apis_tested\":6,\"named_graphics_and_loader_apis_tested\":12,\"delay_first_call_tested\":true}\n",checks,small?65536:0);
}
