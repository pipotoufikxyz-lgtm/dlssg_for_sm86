// Released GP6 startup controller. Only namespace and include location are changed.
#pragma once
#include <atomic>
#include <string_view>
#include "../include/nvs30/module_origin.hpp"

namespace gp6_startup_bootstrap {
enum class Context { outside_loader, loader_callout, unavailable };
// Scope early driver startup to the reported Frostbite title. Other games
// retain graphics-call activation, including the Steam/Game Pass fixes.
inline bool deadSpace(std::wstring_view executable, bool rendererPresent) noexcept {
 return rendererPresent && module_origin::equal(module_origin::filename(executable), L"Dead Space.exe");
}
class Controller {
 std::atomic_bool pending_{false},workerTried_{false};
public:
 std::atomic_ulong asiEntries{0},attempts{0},loaderDeferrals{0};
 std::atomic<const char*> policy{"unselected"},entry{"none"};
 // Probe context BEFORE filesystem/configuration/graphics work. The worker
 // never waits for a thread which may still own the Windows loader lock.
 template<class Probe,class Select,class Initialize>
 void asi(Probe probe,Select select,Initialize initialize) {
  ++asiEntries;
  if(defer(probe()))return;
  run("InitializeASI",select,initialize);
 }
 template<class Probe,class Select,class Initialize>
 void service(bool standalone,Probe probe,Select select,Initialize initialize) {
  const bool deferred=pending_.exchange(false);
  if(!deferred&&(!standalone||workerTried_.exchange(true)))return;
  if(defer(probe()))return;
  run(deferred?"deferred_asi_worker":"standalone_worker",select,initialize);
 }
private:
 bool defer(Context context) noexcept {
  if(context==Context::outside_loader)return false;
  policy=context==Context::loader_callout?"waiting_for_loader_exit":"loader_context_unavailable";
  ++loaderDeferrals;pending_=true;return true;
 }
 template<class Select,class Initialize> void run(const char* source,Select select,Initialize initialize) {
  if(!select()){policy="graphics_call";return;}
  policy="dead_space_early";entry=source;++attempts;
  // The existing GraphicsInitialization gate owns configuration and driver
  // initialization together; it prevents duplicate/reentrant backend setup.
  initialize(source);
 }
};
}
