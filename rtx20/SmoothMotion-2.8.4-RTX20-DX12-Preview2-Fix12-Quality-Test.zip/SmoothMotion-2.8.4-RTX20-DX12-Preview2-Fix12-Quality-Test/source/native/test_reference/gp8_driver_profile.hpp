// Frozen GP8 acceptance policy, namespace/include path adapted for regression.
#pragma once
// Exact binary-profile facts recovered from the public 0.5.0 distribution.
// Only offsets, byte values, hashes and API-layout facts are represented here;
// no archived Python code is used or executed by this implementation.
// 616.64 is an upstream reported validated profile, not a local GPU test result.
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace gp8_baseline::driver_profile {
enum class Kind { none, golden61664, suppliedReference };
inline constexpr const char source_sha256[]="f36a5f10458a9b67833df97ea2a4634d8c03b634d8edcbfbd9e49bc47ad8b54e";
inline constexpr const char output_sha256[]="e6e578af927495084021cb7dfe9e008d066e1504f602a0b678caf35a5466887c";
inline constexpr const char reference_sha256[]="bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68";
// Independently calculated from the supplied reference by applying only the
// same 41 reviewed sites; this is static validation, not a live-GPU claim.
inline constexpr const char reference_output_sha256[]="b9387d39a872e2d6f9a6be7d8af572d10e8030697349b1f0127d00c6c6f1bfb8";
inline constexpr const char reference_code_sha256[]="148ed6f41d36b9c68d136a73c3d36be02d9cdd97dee3da550ab16b17c710d9cb";
inline constexpr const char reference_sections_sha256[]="2d19d8e11aa4fe0088e4ba413af8566242b0751f714d9d6f1146b5eec7cbaa74";
inline constexpr const char reference_output_sections_sha256[]="f6330bedc847d829e2fe6a63d766d9691d8678afcec7e32f0ca100203addfbeb";
// Independently reported by the affected system's read-only 2.7 diagnostics.
inline constexpr const char reported_code_sha256[]="d4e502a88123a5fff8a2a9e4a9b10fdd7236933ef1f4c389cb85ead83b30a9c0";
inline constexpr std::size_t source_size=8417512;
inline constexpr std::uint32_t init_rva=0x59e0, config_rva=0x7d7810;
inline constexpr std::uint32_t gate_file_offset=0xb81c, gate_rva=0xc41c;
inline constexpr std::size_t expected_changed_bytes=61, expected_sites=41;
struct KernelSite {const char* name;std::uint32_t tag_offset,flags_offset;};
inline constexpr std::array<KernelSite,20> non_fp8_kernels{{
    {"depth_to_space",0x484d1c,0x484d70},
    {"downscale_kernel",0x48c3ec,0x48c440},
    {"warp_coarse_kernel",0x4940ac,0x494100},
    {"attn1",0x4c8e14,0x4c8e68},
    {"attn2",0x50af54,0x50afa8},
    {"conv1",0x52366c,0x5236c0},
    {"conv2",0x52cc0c,0x52cc60},
    {"conv3",0x533a9c,0x533af0},
    {"conv4",0x53c02c,0x53c080},
    {"conv5",0x546e7c,0x546ed0},
    {"conv6",0x55617c,0x5561d0},
    {"conv7",0x570bd4,0x570c28},
    {"conv8",0x591aa4,0x591af8},
    {"conv_fused",0x5d9d7c,0x5d9dd0},
    {"conv_proj1",0x5f15a4,0x5f15f8},
    {"conv_proj2",0x623d24,0x623d78},
    {"conv_out1",0x641104,0x641158},
    {"conv_out2",0x648794,0x6487e8},
    {"conv_out3",0x64fa74,0x64fac8},
    {"main_kernel",0x7d2d04,0x7d2d58}
}};
inline constexpr std::array<unsigned char,4> gate_before{{0x83,0x79,0x14,0x03}},gate_after{{0x83,0x79,0x14,0x02}};
inline constexpr std::array<unsigned char,4> tag_before{{0x59,0,0,0}},tag_after{{0x56,0,0,0}};
inline constexpr std::array<unsigned char,4> flags_before{{0x59,0x05,0x59,0}},flags_after{{0x56,0x05,0x56,0}};
struct Edit {std::size_t offset;std::array<unsigned char,4> before,after;};
inline std::array<Edit,expected_sites> edits(){
    std::array<Edit,expected_sites> out{};out[0]={gate_file_offset,gate_before,gate_after};
    for(std::size_t i=0;i<non_fp8_kernels.size();++i){const auto& k=non_fp8_kernels[i];
        out[1+i*2]={k.tag_offset,tag_before,tag_after};out[2+i*2]={k.flags_offset,flags_before,flags_after};}
    return out;
}
inline bool source_identity(std::string_view hash,std::size_t bytes){return hash==source_sha256&&bytes==source_size;}
inline Kind identify(std::string_view hash,std::size_t bytes){
    if(bytes!=source_size)return Kind::none;
    return hash==source_sha256?Kind::golden61664:hash==reference_sha256?Kind::suppliedReference:Kind::none;
}
inline const char* expected_output(Kind kind){return kind==Kind::golden61664?output_sha256:kind==Kind::suppliedReference?reference_output_sha256:"";}
inline const char* expected_code(Kind kind){return kind==Kind::golden61664?reported_code_sha256:kind==Kind::suppliedReference?reference_code_sha256:"";}
inline bool original_sites(const std::vector<unsigned char>& source){
    const auto plan=edits();
    for(std::size_t i=0;i<plan.size();++i){const auto& e=plan[i];
        if(e.offset>source.size()||e.before.size()>source.size()-e.offset||
           std::memcmp(source.data()+e.offset,e.before.data(),e.before.size()))return false;
        for(std::size_t j=0;j<i;++j)if(e.offset<plan[j].offset+plan[j].before.size()&&plan[j].offset<e.offset+e.before.size())return false;
    }
    return true;
}
// This helper makes only a candidate for hash validation, never an authorized
// runtime patch. Callers must check a full or complete-sections input identity
// and independently verify the matching output oracle before using it.
inline bool apply_sites_for_validation(const std::vector<unsigned char>& source,std::vector<unsigned char>& output){
    if(&source==&output)return false;
    output.clear();if(!original_sites(source))return false;
    auto candidate=source;
    for(const auto& e:edits())std::memcpy(candidate.data()+e.offset,e.after.data(),e.after.size());
    std::size_t changed=0;for(std::size_t i=0;i<source.size();++i)changed+=source[i]!=candidate[i];
    if(changed!=expected_changed_bytes)return false;
    output=std::move(candidate);return true;
}
// Compute an independently checked candidate in memory. Does not modify a
// driver file, load a DLL, patch process memory or accept user manifests.
// The full output oracle ensures that all code/data outside the 61 changed
// bytes—including all 17 FP8 objects and SM120 objects—remain untouched.
template<class Hash> inline bool prepare(const std::vector<unsigned char>& source,Hash hash,
                                         std::vector<unsigned char>& output,const char*& reason){
    if(&source==&output){reason="source/output alias is not allowed";return false;}
    output.clear();reason="unrecognized exact 616.64 source";
    if(source.size()!=source_size)return false;
    const auto kind=identify(hash(source.data(),source.size()),source.size());
    if(kind==Kind::none)return false;
    reason="616.64 original patch bytes differ";
    std::vector<unsigned char> candidate;if(!apply_sites_for_validation(source,candidate))return false;
    reason="616.64 transformation output differs from reviewed oracle";
    if(hash(candidate.data(),candidate.size())!=expected_output(kind))return false;
    output=std::move(candidate);reason="exact 616.64 source and 41-site/61-byte transform verified";return true;
}
}
