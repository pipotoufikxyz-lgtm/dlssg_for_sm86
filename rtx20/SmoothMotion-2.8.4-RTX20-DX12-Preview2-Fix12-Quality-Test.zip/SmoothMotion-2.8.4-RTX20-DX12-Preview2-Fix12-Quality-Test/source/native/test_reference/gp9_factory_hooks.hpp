namespace dx12 {
using CreateSwapFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory*,IUnknown*,DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**);
using CreateHwndFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,HWND,const DXGI_SWAP_CHAIN_DESC1*,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*,IDXGIOutput*,IDXGISwapChain1**);
using CreateCoreFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**);
using CreateCompositionFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**);
struct FactoryHooks {void** table=nullptr;CreateSwapFn swap=nullptr;CreateHwndFn hwnd=nullptr;CreateCoreFn core=nullptr;CreateCompositionFn composition=nullptr;unsigned extent=0;bool hooked=false;};
std::array<FactoryHooks,64> factories{};unsigned factoryCount=0;SRWLOCK factoryLock=SRWLOCK_INIT;
FactoryHooks factoryHooks(void* object){auto v=*reinterpret_cast<void***>(object);FactoryHooks result;AcquireSRWLockShared(&factoryLock);for(unsigned i=0;i<factoryCount;++i)if(factories[i].table==v){result=factories[i];break;}ReleaseSRWLockShared(&factoryLock);return result;}
void created(IDXGISwapChain* swap,IUnknown* input){if(swap){(void)input;registerSwapchain(swap);}}
HRESULT STDMETHODCALLTYPE onCreateSwap(IDXGIFactory* f,IUnknown* device,DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.swap)return E_FAIL;
 return imports::graphicsCall(caller,internalCreation,[&]{if(desc)beforeSwapchain(desc->OutputWindow);},
  [&]{return h.swap(f,device,desc,out);},[&](HRESULT hr){if(SUCCEEDED(hr)&&out)created(*out,device);});
}
HRESULT STDMETHODCALLTYPE onCreateHwnd(IDXGIFactory2* f,IUnknown* device,HWND window,const DXGI_SWAP_CHAIN_DESC1* desc,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* full,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.hwnd)return E_FAIL;
 return imports::graphicsCall(caller,internalCreation,[&]{beforeSwapchain(window);},
  [&]{return h.hwnd(f,device,window,desc,full,output,out);},[&](HRESULT hr){if(SUCCEEDED(hr)&&out)created(*out,device);});
}
HRESULT STDMETHODCALLTYPE onCreateCore(IDXGIFactory2* f,IUnknown* device,IUnknown* window,const DXGI_SWAP_CHAIN_DESC1* desc,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.core)return E_FAIL;
 return imports::graphicsCall(caller,internalCreation,[]{},[&]{return h.core(f,device,window,desc,output,out);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&out)created(*out,device);});
}
HRESULT STDMETHODCALLTYPE onCreateComposition(IDXGIFactory2* f,IUnknown* device,const DXGI_SWAP_CHAIN_DESC1* desc,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.composition)return E_FAIL;
 return imports::graphicsCall(caller,internalCreation,[]{},[&]{return h.composition(f,device,desc,output,out);},
  [&](HRESULT hr){if(SUCCEEDED(hr)&&out)created(*out,device);});
}
bool registerFactory(void* object,unsigned size){
 auto v=*reinterpret_cast<void***>(object);AcquireSRWLockExclusive(&factoryLock);
 struct Unlock{~Unlock(){ReleaseSRWLockExclusive(&factoryLock);}} unlock;
 unsigned index=0;for(;index<factoryCount;++index)if(factories[index].table==v)break;
 if(index==factoryCount){if(factoryCount==factories.size()){
  static bool reported=false;if(!reported){reported=true;logf("[normal] Factory table capacity reached; new untracked tables are not patched.\n");}return false;
 }++factoryCount;}
 auto& h=factories[index];
 if(size<h.extent||(h.hooked&&size==h.extent))return h.hooked;
 h.table=v;h.extent=size;h.hooked=false;
 if(!h.swap)h.swap=reinterpret_cast<CreateSwapFn>(v[10]);
 if(size>=25){
  if(!h.hwnd)h.hwnd=reinterpret_cast<CreateHwndFn>(v[15]);
  if(!h.core)h.core=reinterpret_cast<CreateCoreFn>(v[16]);
  if(!h.composition)h.composition=reinterpret_cast<CreateCompositionFn>(v[24]);
 }
 h.swap=recoverOriginal(h.swap,&onCreateSwap,factories,factoryCount,&FactoryHooks::swap);
 if(h.hwnd)h.hwnd=recoverOriginal(h.hwnd,&onCreateHwnd,factories,factoryCount,&FactoryHooks::hwnd);
 if(h.core)h.core=recoverOriginal(h.core,&onCreateCore,factories,factoryCount,&FactoryHooks::core);
 if(h.composition)h.composition=recoverOriginal(h.composition,&onCreateComposition,factories,factoryCount,&FactoryHooks::composition);
 if(!h.swap||(size>=25&&(!h.hwnd||!h.core||!h.composition)))return false;
 const std::array<hook_group::Slot,4> slots{{
  {v+10,reinterpret_cast<void*>(h.swap),reinterpret_cast<void*>(&onCreateSwap)},
  {size>=25?v+15:nullptr,reinterpret_cast<void*>(h.hwnd),reinterpret_cast<void*>(&onCreateHwnd)},
  {size>=25?v+16:nullptr,reinterpret_cast<void*>(h.core),reinterpret_cast<void*>(&onCreateCore)},
  {size>=25?v+24:nullptr,reinterpret_cast<void*>(h.composition),reinterpret_cast<void*>(&onCreateComposition)}}};
 h.hooked=hook_group::install(slots,readSlot,patch);return h.hooked;
}
bool hookFactory(IDXGIFactory* factory){
 bool hooked=false;
 // COM may return different vtables for different interface versions. Each
 // Factory2+ interface shares the inherited creation-method prefix.
 for(const auto& iid:{__uuidof(IDXGIFactory7),__uuidof(IDXGIFactory6),__uuidof(IDXGIFactory5),__uuidof(IDXGIFactory4),__uuidof(IDXGIFactory3),__uuidof(IDXGIFactory2)}){
  Com<IUnknown> version;if(SUCCEEDED(factory->QueryInterface(iid,reinterpret_cast<void**>(version.put()))))hooked=registerFactory(version.p,25)||hooked;
 }
 Com<IDXGIFactory1> v1;if(SUCCEEDED(factory->QueryInterface(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(v1.put()))))hooked=registerFactory(v1.p,12)||hooked;
 return registerFactory(factory,12)||hooked;
}

}
