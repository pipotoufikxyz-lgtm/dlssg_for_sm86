// Exact GP4 scanner body, renamed only for the regression comparison.
namespace imports {
inline void moduleGP4(HMODULE image,size_t available){
 if(!image||image==owner)return;
 HMODULE held=nullptr;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,reinterpret_cast<LPCWSTR>(image),&held))return;
 struct Release{HMODULE module;~Release(){FreeLibrary(module);}} release{held};
 // This path also runs synchronously after a game's LoadLibrary call. Large
 // automatic path arrays consumed over 128 KiB of the caller's Windows stack.
 // Heap allocation failures are caught by refresh(), preserving the API call.
 std::wstring path(32768,L'\0'),system(32768,L'\0');
 const auto length=GetModuleFileNameW(held,path.data(),static_cast<DWORD>(path.size()));
 const auto systemLength=GetWindowsDirectoryW(system.data(),static_cast<UINT>(system.size()));
 if(!length||length>=32768)return;
 // Do not patch Windows components or the confirmed crashing Steam overlay.
 // Its own startup graphics probes must not initialize the native backend.
 if(module_origin::excludedPath(std::wstring_view(path.data(),length),
    systemLength&&systemLength<system.size()?std::wstring_view(system.data(),systemLength):std::wstring_view{}))return;
 auto base=reinterpret_cast<unsigned char*>(held);
 auto copy=[&](size_t offset,void* out,size_t bytes){
  SIZE_T received{};
  return ReadProcessMemory(GetCurrentProcess(),base+offset,out,bytes,&received)&&received==bytes;
 };
 motion::ImportPageReader reader(available,copy);
 unsigned changed=0,graphics=0;
 const bool valid=motion::visitImportSlotsReader(available,reader,[&](size_t offset,std::uint64_t value){
   auto location=reinterpret_cast<void**>(base+offset);
   auto original=reinterpret_cast<void*>(static_cast<std::uintptr_t>(value));
   auto target=reinterpret_cast<void*>(replacement(reinterpret_cast<FARPROC>(original)));
   if(target!=original&&patch(location,original,target)){
    ++patched;++changed;
    const bool provider=providers.replacement(original,providerWrappers)!=original;
    if(provider)++providerPatches;
    bool directGraphics=false;for(std::size_t i=0;i<6;++i)directGraphics|=hooks[i].original==original;
    if(provider||directGraphics){++graphics;++graphicsPatches;}
    if(loader_api::providers.replacement(original,loader_api::wrappers)!=original)++loader_api::patches;
   }
 },{"IsUltimateASILoader","SmoothMotionGetStatus","NVP_Init_D3D","SM_Prepare","SM_ProviderPath"});
 if(!valid)++scanFailures;
 path.resize(length);reportScan(path,valid,changed,graphics);
}
}
