// Exercise the production native-wrapper branch helpers with callable original
// entries and mutation callbacks. This is a host regression, not Windows DXGI,
// NvPresent execution, or evidence of displayed/generated frame counts.
#include "include/nvs30/presentation_ownership.hpp"
#include "include/nvs30/presentation_policy.hpp"
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <type_traits>
#include <thread>

namespace {
unsigned checks=0;
void check(bool condition,const char* why){++checks;if(!condition){std::fprintf(stderr,"Native presentation check failed: %s\n",why);std::abort();}}
using Result=std::int32_t;
struct Chain {unsigned cookie=0x4865;};
struct Output {unsigned cookie=0x7642;};
struct PresentParameters {unsigned dirtyCount;const void* dirty;const void* scroll;const void* offset;};
struct Arguments {
 Chain chain;Output output;int rectangle=1,scroll=2,offset=3,queue0=4,queue1=5,queue2=6;
 PresentParameters params{1,&rectangle,&scroll,&offset};
 unsigned masks[3]{1,2,4};void* queues[3]{&queue0,&queue1,&queue2};
 unsigned sync=3,flags=0x204,bufferCount=3,width=1919,height=1079,format=28;
} arguments;
Result originalResult=0;unsigned originalCalls=0,originalError=0;
Result returned(){++originalCalls;originalError=0x3456;return originalResult;}
Result present(Chain* chain,unsigned sync,unsigned flags){check(chain==&arguments.chain&&sync==arguments.sync&&flags==arguments.flags,"Present original arguments changed");return returned();}
Result present1(Chain* chain,unsigned sync,unsigned flags,const PresentParameters* parameters){check(chain==&arguments.chain&&sync==arguments.sync&&flags==arguments.flags&&parameters==&arguments.params,"Present1 original arguments or parameter pointer changed");check(parameters->dirtyCount==1&&parameters->dirty==&arguments.rectangle&&parameters->scroll==&arguments.scroll&&parameters->offset==&arguments.offset,"Present1 parameters were rewritten");return returned();}
Result fullscreen(Chain* chain,int enabled,Output* output){check(chain==&arguments.chain&&enabled==1&&output==&arguments.output,"Fullscreen original arguments changed");return returned();}
Result resize(Chain* chain,unsigned count,unsigned width,unsigned height,unsigned format,unsigned flags){check(chain==&arguments.chain&&count==arguments.bufferCount&&width==arguments.width&&height==arguments.height&&format==arguments.format&&flags==arguments.flags,"Resize original arguments changed");return returned();}
Result resize1(Chain* chain,unsigned count,unsigned width,unsigned height,unsigned format,unsigned flags,const unsigned* masks,void* const* queues){check(chain==&arguments.chain&&count==arguments.bufferCount&&width==arguments.width&&height==arguments.height&&format==arguments.format&&flags==arguments.flags&&masks==arguments.masks&&queues==arguments.queues,"Resize1 original arguments or queue-array pointers changed");check(masks[0]==1&&masks[1]==2&&masks[2]==4&&queues[0]==&arguments.queue0&&queues[1]==&arguments.queue1&&queues[2]==&arguments.queue2,"Resize1 node masks or queues were rewritten");return returned();}

void sharedTableCases(){
 using namespace nvs30::presentation_ownership;
 int nativePresent=1,nativePresent1=2,ownHook=3,systemPresent=4;
 const auto contains=[&](const void* p){return p==&nativePresent||p==&nativePresent1;};
 // Original public-method detection succeeds before hooking, then loses the
 // native wrapper when an earlier chain has already patched a shared table.
 check(inspect(&nativePresent,&nativePresent1,nullptr,nullptr,contains).native(),"Unhooked native wrapper missing");
 check(!contains(&ownHook),"Fixture hook accidentally belongs to native image");
 for(unsigned source=0;source<2;++source){
  const auto hidden=inspect(&ownHook,&ownHook,source==0?&nativePresent:nullptr,source==1?&nativePresent1:nullptr,contains);
  check(!hidden.live_method&&hidden.native(),"Saved native method lost behind own hook");
  nvs30::presentation::ProgressWindow progress;progress.start(0);
  for(unsigned i=0;i<10000;++i)check(progress.assess(0,hidden.native())!=nvs30::presentation::Activity::retire_unconfirmed,"Hooked native wrapper retired for missing CUDA interception");
 }
 check(!inspect(&ownHook,&ownHook,&systemPresent,&systemPresent,contains).native(),"System originals incorrectly confirm a native wrapper");
 check(!inspect(nullptr,nullptr,nullptr,nullptr,contains).native(),"Absent entries incorrectly confirm a native wrapper");
 for(unsigned table=0;table<5;++table){
  Evidence combined;
  for(unsigned i=0;i<5;++i){
   auto e=inspect(&ownHook,&ownHook,&systemPresent,i==table?&nativePresent1:&systemPresent,contains);
   combined.observe(e.live_method,e.saved_present,e.saved_present1);
  }
  check(combined.native()&&!combined.live_method&&combined.saved_present1,"Separate Present1 table lost native evidence");
 }
}
void registrationCases(){
 using nvs30::presentation_ownership::Evidence;
 // Every evidence source must suppress private-data reads/writes, including a
 // saved Present1 original from a different QueryInterface table. Simulate an
 // inner object with a live Context that a wrapper forwards Get/SetPrivateData
 // to; native registration must preserve its reference and lifetime.
 for(unsigned bits=0;bits<8;++bits)for(bool d3d11:{false,true})for(bool enabled:{false,true}){
  const Evidence evidence{bool(bits&1),bool(bits&2),bool(bits&4)};
  unsigned privateReads=0,privateWrites=0,releases=0;std::uintptr_t privateContext=0x13579;
  auto attach=[&]{++privateReads;++privateWrites;++releases;privateContext=0x24680;};
  nvs30::presentation_ownership::attach_context(evidence,d3d11,enabled,attach);
  const bool managed=!bits&&d3d11&&enabled;
  check(privateReads==unsigned(managed)&&privateWrites==unsigned(managed),"Registration read/wrote a native, non-D3D11 or disabled Context");
  check(releases==unsigned(managed),"Registration released protected inner Context");
  check(privateContext==(managed?0x24680u:0x13579u),"Native wrapper altered an existing inner private value");
 }
 // Five public interface tables can differ. Native evidence can first appear
 // at any one of them, and later observations must never erase it.
 for(unsigned nativeInterface=0;nativeInterface<5;++nativeInterface)for(unsigned source=0;source<3;++source){
  Evidence evidence;
  for(unsigned current=0;current<5;++current){
   const bool native=current==nativeInterface;
   evidence.observe(native&&source==0,native&&source==1,native&&source==2);
   check(evidence.native()==(current>=nativeInterface),"Distinct interface evidence was lost or invented");
  }
  unsigned attachCalls=0;
  nvs30::presentation_ownership::attach_context(evidence,true,true,[&]{++attachCalls;});
  check(attachCalls==0,"Saved original in another COM interface failed native admission");
 }
 Evidence ordinary;for(unsigned i=0;i<5;++i)ordinary.observe(false,false,false);
 unsigned managed=0;nvs30::presentation_ownership::attach_context(ordinary,true,true,[&]{++managed;});
 check(managed==1,"Unwrapped game chain lost its D3D11 bridge Context");
}

thread_local bool nativeForwarding=false;
void nestedCases(){
 using nvs30::presentation_ownership::entry;
 // Model a native wrapper tail-calling an inner Present1 whose table belongs
 // to Windows: neither its caller address nor its saved original proves native
 // ownership. A resize reached during that forwarding stack must also bypass
 // Context transitions, while a later unrelated game call remains managed.
 for(unsigned mode=0;mode<3;++mode){
  nativeForwarding=false;unsigned outer=0,inner=0,resizeCalls=0,managed=0;
  auto manage=[&]()->Result{++managed;return -1;};
  auto result=entry(nativeForwarding,mode!=1,mode!=0,[&]()->Result{
   ++outer;check(nativeForwarding,"Outer native forward did not establish ownership scope");
   const auto innerResult=entry(nativeForwarding,false,false,[&]()->Result{
    ++inner;check(nativeForwarding,"Tail-forwarded Present1 lost native scope");
    const auto resized=entry(nativeForwarding,false,false,[&]()->Result{
     ++resizeCalls;check(nativeForwarding,"Nested resize lost native scope");return 37;
    },manage);
    check(resized==37&&nativeForwarding,"Nested resize changed result or prematurely cleared native scope");return 83;
   },manage);
   check(innerResult==83&&nativeForwarding,"Tail-forwarded Present1 changed result or cleared outer scope");return 91;
  },manage);
  check(result==91&&outer==1&&inner==1&&resizeCalls==1&&managed==0,"Native tail-call reentered managed bridge/transition path");
  check(!nativeForwarding,"Native stack scope survived its outer return");
  check(entry(nativeForwarding,false,false,[]{return -2;},manage)==-1&&managed==1,"Later ordinary application call did not recover managed dispatch");
 }
 // Preserve prior state both on ordinary return and during C++ unwinding.
 // The helper does not catch or transform an exception raised by the original.
 for(bool previous:{false,true}){
  nativeForwarding=previous;
  check(entry(nativeForwarding,true,false,[]{return 53;},[]{return -1;})==53,"Native scope altered return value");
  check(nativeForwarding==previous,"Native scope did not restore a pre-existing state");
  bool caught=false;unsigned managed=0;
  try{
   entry(nativeForwarding,true,false,[&]()->Result{
    return entry(nativeForwarding,false,false,[]()->Result{throw 0x13579;},[&]{++managed;return -1;});
   },[&]{++managed;return -2;});
  }catch(int value){caught=value==0x13579;}
  check(caught&&managed==0,"Native unwinding changed exception or entered managed dispatch");
  check(nativeForwarding==previous,"Nested exception leaked or prematurely cleared native scope");
 }
 nativeForwarding=false;
 bool workerStartedClean=false,workerStayedClean=false;unsigned workerManaged=0,workerForwarded=0;
 const auto result=entry(nativeForwarding,true,false,[&]()->Result{
  std::thread independent([&]{
   workerStartedClean=!nativeForwarding;
   entry(nativeForwarding,false,false,[&]{++workerForwarded;return 1;},[&]{++workerManaged;return 0;});
   workerStayedClean=!nativeForwarding;
  });
  independent.join();
  check(nativeForwarding,"Independent thread changed active native scope");return 17;
 },[]{return -1;});
 check(result==17&&!nativeForwarding,"Cross-thread scope test changed return/restoration");
 check(workerStartedClean&&workerStayedClean&&workerManaged==1&&workerForwarded==0,"Native ownership leaked across threads");
}

template<class Original> void entryCases(const char* name,Original original){
 struct Origin {bool caller,entry,native;};
 const Origin origins[]={{true,false,true},{false,true,true},{true,true,true},{false,false,false}};
 const Result results[]={0,1,static_cast<Result>(0x087a0001u),static_cast<Result>(0x887a000au),static_cast<Result>(0x887a0005u),static_cast<Result>(0x80004005u)};
 for(const auto origin:origins)for(const auto expected:results){
  originalResult=expected;originalCalls=0;originalError=0x1234;
  bool inNativeForward=false;unsigned forwarded=0,managed=0,bridgeActions=0,contextMutations=0;
  auto forward=[&]()->Result{++forwarded;return original();};
  auto manage=[&]()->Result{++managed;++bridgeActions;++contextMutations;return original();};
  static_assert(std::is_same_v<decltype(nvs30::presentation_ownership::entry(inNativeForward,origin.caller,origin.entry,forward,manage)),Result>);
  const auto result=nvs30::presentation_ownership::entry(inNativeForward,origin.caller,origin.entry,forward,manage);
  check(!inNativeForward,"Forwarding scope leaked into the next application call");
  check(result==expected,"Hook changed the original HRESULT");check(originalCalls==1,"Hook repeated or skipped the original API call");
  if(origin.native){check(forwarded==1&&managed==0,"NvPresent caller/original entered managed dispatch");check(bridgeActions==0&&contextMutations==0,"NvPresent call prepared a bridge or mutated Context");}
  else{check(forwarded==0&&managed==1,"Ordinary game call lost managed dispatch");check(bridgeActions==1&&contextMutations==1,"Ordinary game call skipped its managed callback");}
  check(originalError==0x3456,"Branch helper altered state returned by the original call");
 }
 std::printf("%s original forwarding and native bypass verified\n",name);
}
}

int main(){
 sharedTableCases();
 registrationCases();
 nestedCases();
 entryCases("Present",[]{return present(&arguments.chain,arguments.sync,arguments.flags);});
 entryCases("Present1",[]{return present1(&arguments.chain,arguments.sync,arguments.flags,&arguments.params);});
 entryCases("SetFullscreenState",[]{return fullscreen(&arguments.chain,1,&arguments.output);});
 entryCases("ResizeBuffers",[]{return resize(&arguments.chain,arguments.bufferCount,arguments.width,arguments.height,arguments.format,arguments.flags);});
 entryCases("ResizeBuffers1",[]{return resize1(&arguments.chain,arguments.bufferCount,arguments.width,arguments.height,arguments.format,arguments.flags,arguments.masks,arguments.queues);});
 std::printf("{\"result\":\"PASS\",\"test\":\"production_presentation_ownership\",\"checks\":%u,\"native_windows_executed\":false,\"generated_frames_measured\":false}\n",checks);
}
