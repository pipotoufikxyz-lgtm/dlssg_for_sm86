#include "include/nvs30/slot_patch.hpp"
#include <cassert>
#include <iostream>
#include <vector>
int main(){
 int original{},hook{},foreign{};unsigned cases=0;
 // Permission acquisition and both restore attempts may fail independently.
 for(bool acquire:{false,true})for(bool first:{false,true})for(bool retry:{false,true}){
  void* slot=&original;unsigned writes=0,restores=0;
  const auto result=nvs30::slot_patch::apply(&original,&hook,[&](void*& value){value=slot;return true;},[&]{return acquire;},
   [&](void* before,void* after){++writes;auto prior=slot;if(slot==before)slot=after;return prior;},
   [&]{return ++restores==1?first:retry;});
  assert(result.installed==(acquire&&first));
  assert(slot==(result.installed?static_cast<void*>(&hook):static_cast<void*>(&original)));
  assert(result.protection_restored==(!acquire||first||retry));
  assert(writes==(!acquire?0u:first?1u:2u));assert(restores==(!acquire?0u:first?1u:2u));++cases;
 }
 // A third-party write between read and exchange must never be overwritten.
 for(bool first:{false,true}){
  void* slot=&original;unsigned writes=0,restores=0;
  const auto result=nvs30::slot_patch::apply(&original,&hook,[&](void*& value){value=slot;return true;},[&]{slot=&foreign;return true;},
   [&](void* before,void* after){++writes;auto prior=slot;if(slot==before)slot=after;return prior;},
   [&]{return ++restores==1?first:true;});
  assert(!result.installed&&result.protection_restored&&slot==&foreign&&writes==1);++cases;
 }
 // A later owner wins even when our protection restore fails after installing.
 {
  void* slot=&original;unsigned restores=0;
  const auto result=nvs30::slot_patch::apply(&original,&hook,[&](void*& value){value=slot;return true;},[]{return true;},
   [&](void* before,void* after){auto prior=slot;if(slot==before)slot=after;return prior;},
   [&]{if(++restores==1){slot=&foreign;return false;}return true;});
  assert(!result.installed&&result.protection_restored&&slot==&foreign);++cases;
 }
 // Unreadable, unexpected, and already-installed slots need no page edit.
 for(unsigned mode=0;mode<3;++mode){
  const auto result=nvs30::slot_patch::apply(&original,&hook,[&](void*& value){value=mode==2?&hook:&foreign;return mode!=0;},
   []{assert(false);return false;},[](void*,void*)->void*{assert(false);return nullptr;},[]{assert(false);return false;});
  assert(result.installed==(mode==2)&&result.protection_restored);++cases;
 }
 std::cout<<"PASS: "<<cases<<" slot patch cases: exact compare/exchange, failed protection rollback, unreadable memory, idempotence and intervening owner. Win32 operations mocked.\n";
}
