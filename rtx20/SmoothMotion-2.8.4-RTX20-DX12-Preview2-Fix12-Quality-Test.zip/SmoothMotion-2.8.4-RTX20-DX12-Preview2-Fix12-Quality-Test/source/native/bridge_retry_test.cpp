#include "include/nvs30/bridge_retry.hpp"
#include <cassert>
#include <iostream>
using namespace nvs30::bridge_retry;
int main() {
    const Shape haydee{0x100,1920,1009,28,1,0,1,0,0,true};
    Attempts attempts;assert(!attempts.blocked(haydee));attempts.failed(haydee);
    // Resource reset and repeated same-size ResizeBuffers do not replace this
    // state. The live bridge keeps it separately from its GPU resource fields.
    for(unsigned i=0;i<1000;++i)assert(attempts.blocked(haydee));
    unsigned cases=0;
    for(unsigned member=0;member<10;++member){
        auto changed=haydee;
        switch(member){case 0:++changed.window;break;case 1:++changed.width;break;
        case 2:++changed.height;break;case 3:++changed.format;break;case 4:++changed.buffers;break;
        case 5:++changed.effect;break;case 6:++changed.samples;break;case 7:++changed.quality;break;
        case 8:++changed.flags;break;case 9:changed.windowed=false;break;}
        assert(!attempts.blocked(changed));attempts.failed(changed);assert(attempts.blocked(changed));
        assert(!attempts.blocked(haydee));attempts.failed(haydee);++cases;
    }
    attempts.succeeded();assert(!attempts.blocked(haydee));
    std::cout<<"PASS: "<<cases<<" descriptor changes can retry; unchanged failed descriptor stays blocked; successful setup clears failure. Host policy only.\n";
}
