#pragma once
#ifndef NVS30_INIT_TRACE_TEST
#error Test-only Win32 declarations
#endif
#include <cstddef>
#include <cstdint>
#define CALLBACK
using DWORD=std::uint32_t;using LONG=std::int32_t;using BOOL=int;
using HANDLE=void*;using HMODULE=void*;using LPCWSTR=const wchar_t*;
#define INVALID_HANDLE_VALUE reinterpret_cast<HANDLE>(~std::uintptr_t{})
constexpr LONG EXCEPTION_CONTINUE_SEARCH=0;
constexpr DWORD FILE_APPEND_DATA=4,FILE_SHARE_READ=1,FILE_SHARE_WRITE=2,FILE_SHARE_DELETE=4;
constexpr DWORD OPEN_ALWAYS=4,FILE_ATTRIBUTE_NORMAL=0x80,FILE_FLAG_WRITE_THROUGH=0x80000000u;
constexpr DWORD GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS=4,GET_MODULE_HANDLE_EX_FLAG_PIN=1;
struct CONTEXT {
 std::uint64_t unusedBefore[4]{};
 std::uint64_t Rip{},Rsp{},Rax{},Rcx{},Rdx{},R8{},R9{};
 std::uint64_t unusedAfter[4]{};
};
struct EXCEPTION_RECORD {
 DWORD ExceptionCode{},ExceptionFlags{};
 EXCEPTION_RECORD* ExceptionRecord{};
 void* ExceptionAddress{};
 DWORD NumberParameters{};
 std::uintptr_t ExceptionInformation[15]{};
};
struct EXCEPTION_POINTERS {EXCEPTION_RECORD* ExceptionRecord{};CONTEXT* ContextRecord{};};
using PEXCEPTION_POINTERS=EXCEPTION_POINTERS*;
using PVECTORED_EXCEPTION_HANDLER=LONG(CALLBACK*)(PEXCEPTION_POINTERS);
DWORD GetLastError();void SetLastError(DWORD);
DWORD GetCurrentThreadId();DWORD GetCurrentProcessId();
DWORD GetModuleFileNameW(HMODULE,wchar_t*,DWORD);
HANDLE CreateFileW(LPCWSTR,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
BOOL GetModuleHandleExW(DWORD,LPCWSTR,HMODULE*);
BOOL CloseHandle(HANDLE);
void* AddVectoredExceptionHandler(unsigned long,PVECTORED_EXCEPTION_HANDLER);
BOOL WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);
