#include "nvs30/pe.hpp"
#include "nvs30/import_lookup.hpp"
#include "nvs30/patch_transaction.hpp"
#include "nvs30/log.hpp"

#include <cctype>

namespace nvs30::pe {
namespace {
IMAGE_NT_HEADERS64* nt_headers(HMODULE module) {
    if (!module) return nullptr;
    auto* base = reinterpret_cast<std::byte*>(module);
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) return nullptr;
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC)
        return nullptr;
    return nt;
}


}

bool valid_image(HMODULE module) { return nt_headers(module) != nullptr; }

std::size_t image_size(HMODULE module) {
    const auto* nt = nt_headers(module);
    return nt ? nt->OptionalHeader.SizeOfImage : 0;
}

std::vector<Section> sections(HMODULE module) {
    std::vector<Section> out;
    auto* nt = nt_headers(module);
    if (!nt) return out;
    auto* base = reinterpret_cast<std::byte*>(module);
    auto* first = IMAGE_FIRST_SECTION(nt);
    const std::size_t image = nt->OptionalHeader.SizeOfImage;
    out.reserve(nt->FileHeader.NumberOfSections);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i) {
        const auto& s = first[i];
        const std::size_t requested = std::max<std::size_t>(s.Misc.VirtualSize, s.SizeOfRawData);
        const std::size_t bounded = s.VirtualAddress < image
            ? std::min<std::size_t>(requested, image - s.VirtualAddress) : 0;
        out.push_back({base + s.VirtualAddress,
                       bounded,
                       s.Characteristics});
    }
    return out;
}

bool address_in_image(HMODULE module, const void* address) {
    const auto* base = reinterpret_cast<const std::byte*>(module);
    const auto* p = reinterpret_cast<const std::byte*>(address);
    const auto size = image_size(module);
    return size && p >= base && p < base + size;
}

bool address_in_writable_section(HMODULE module, const void* address, std::size_t bytes) {
    const auto* p = reinterpret_cast<const std::byte*>(address);
    for (const auto& s : sections(module)) {
        if (!(s.characteristics & IMAGE_SCN_MEM_WRITE)) continue;
        if (p >= s.begin && bytes <= s.size && p <= s.begin + s.size - bytes) return true;
    }
    return false;
}

void** find_import_slot(HMODULE module, std::string_view dll, std::string_view symbol) {
    auto* base=reinterpret_cast<unsigned char*>(module);
    auto at=import_lookup::find(base,image_size(module),dll,symbol);
    return at?reinterpret_cast<void**>(base+at):nullptr;
}
void** find_delay_import_slot(HMODULE module, std::string_view dll, std::string_view symbol) {
    auto* base=reinterpret_cast<unsigned char*>(module);
    auto at=import_lookup::find(base,image_size(module),dll,symbol,true);
    return at?reinterpret_cast<void**>(base+at):nullptr;
}

void** find_iat_value(HMODULE module, const void* value) {
    auto* nt = nt_headers(module);
    if (!nt) return nullptr;
    auto* base = reinterpret_cast<std::byte*>(module);
    const auto& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT];
    if (!dir.VirtualAddress || dir.Size < sizeof(void*) ||
        static_cast<std::size_t>(dir.VirtualAddress) + dir.Size > nt->OptionalHeader.SizeOfImage)
        return nullptr;
    auto** first = reinterpret_cast<void**>(base + dir.VirtualAddress);
    const std::size_t count = dir.Size / sizeof(void*);
    for (std::size_t i = 0; i < count; ++i) if (first[i] == value) return first + i;
    return nullptr;
}

std::vector<void**> find_data_pointer_slots(HMODULE module, const void* value) {
    std::vector<void**> out;
    if (!module || !value) return out;
    const auto needle = reinterpret_cast<std::uintptr_t>(value);
    for (const auto& section : sections(module)) {
        // Runtime-resolved imports/dispatch pointers can live in .data or in
        // linker-produced read-only import sections. Scan all non-executable
        // readable image data for the exact ASLR-resolved function address;
        // write_memory() will temporarily change protection only on matches.
        if (!(section.characteristics & IMAGE_SCN_MEM_READ) ||
            (section.characteristics & IMAGE_SCN_MEM_EXECUTE) ||
            section.size < sizeof(void*))
            continue;

        const auto begin = reinterpret_cast<std::uintptr_t>(section.begin);
        const auto end = begin + section.size;
        auto current = (begin + alignof(void*) - 1) & ~(std::uintptr_t(alignof(void*) - 1));
        for (; current + sizeof(void*) <= end; current += sizeof(void*)) {
            std::uintptr_t candidate{};
            std::memcpy(&candidate, reinterpret_cast<const void*>(current), sizeof(candidate));
            if (candidate == needle)
                out.push_back(reinterpret_cast<void**>(current));
        }
    }
    return out;
}

bool write_memory(void* destination, const void* source, std::size_t size) {
    DWORD protection{};bool protectionRestored=true;
    const bool ok=patch_transaction::apply(destination,source,size,
        [&]{const bool writable=VirtualProtect(destination,size,PAGE_EXECUTE_READWRITE,&protection)!=FALSE;protectionRestored=!writable;return writable;},
        [&](const void* bytes,std::size_t n){
            if(n==sizeof(void*)&&reinterpret_cast<std::uintptr_t>(destination)%alignof(void*)==0){
                void* value{};std::memcpy(&value,bytes,n);InterlockedExchangePointer(reinterpret_cast<void* volatile*>(destination),value);
            }else std::memcpy(destination,bytes,n);
        },
        [&]{return FlushInstructionCache(GetCurrentProcess(),destination,size)!=FALSE;},
        [&]{DWORD ignored{};protectionRestored=VirtualProtect(destination,size,protection,&ignored)!=FALSE;return protectionRestored;});
    if(!ok)logf("[normal] patch transaction failed at %p (%zu bytes); replacement not retained; original protection restored=%d.\n",destination,size,protectionRestored?1:0);
    return ok;
}

bool write_pointer(void** slot, void* value, void** previous) {
    if (!slot || !*slot) return false;
    if (previous) *previous = *slot;
    return write_memory(slot, &value, sizeof(value));
}
}
