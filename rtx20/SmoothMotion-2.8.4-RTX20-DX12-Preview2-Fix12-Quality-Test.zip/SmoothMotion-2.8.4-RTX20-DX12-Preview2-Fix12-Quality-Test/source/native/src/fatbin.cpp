#include "nvs30/fatbin.hpp"
#include "nvs30/fatbin_capture.hpp"
namespace nvs30::fatbin {
RewrittenImage rewrite_sm89_to_sm86(const void* image){
 if(!image)return {};
 const auto base=reinterpret_cast<std::uintptr_t>(image);
 return capture_and_rewrite([&](std::size_t offset,void* out,std::size_t bytes){
  if(!address_range(base,offset,bytes))return false;
  SIZE_T received{};
  return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<const void*>(base+offset),out,bytes,&received)&&received==bytes;
 });
}
}
