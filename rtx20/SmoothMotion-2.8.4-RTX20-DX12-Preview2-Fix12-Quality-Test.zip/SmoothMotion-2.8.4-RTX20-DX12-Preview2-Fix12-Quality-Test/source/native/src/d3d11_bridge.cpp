#include "nvs30/d3d11_bridge.hpp"

#include "nvs30/config.hpp"
#include "nvs30/dxgi_hooks.hpp"
#include "nvs30/log.hpp"
#include "nvs30/nvpresent.hpp"
#include "nvs30/gpu_wait.hpp"

namespace nvs30 {
namespace {
template<class Fence> HRESULT wait_for_fence(Fence* fence, HANDLE event, std::uint64_t value) {
    if (!value) return S_OK;
    if (!fence || !event) return E_HANDLE;
    return static_cast<HRESULT>(gpu_wait::fence(value, 500,
        [&]{return fence->GetCompletedValue();},
        [&](std::uint64_t target){return fence->SetEventOnCompletion(target,event);},
        [&](unsigned remaining)->HRESULT {
            const auto result=WaitForSingleObject(event,remaining);
            if(result==WAIT_OBJECT_0)return S_OK;
            if(result==WAIT_TIMEOUT)return HRESULT_FROM_WIN32(WAIT_TIMEOUT);
            if(result==WAIT_FAILED)return HRESULT_FROM_WIN32(GetLastError());
            return E_FAIL;
        },[]{return GetTickCount64();}));
}
bridge_retry::Shape shape_of(const DXGI_SWAP_CHAIN_DESC& desc, HWND hwnd) {
    return {reinterpret_cast<std::uintptr_t>(hwnd), desc.BufferDesc.Width, desc.BufferDesc.Height,
        unsigned(desc.BufferDesc.Format), desc.BufferCount, unsigned(desc.SwapEffect),
        desc.SampleDesc.Count, desc.SampleDesc.Quality, desc.Flags, desc.Windowed!=FALSE};
}
D3D12_RESOURCE_BARRIER transition(ID3D12Resource* resource,
                                  D3D12_RESOURCE_STATES before,
                                  D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.pResource = resource;
    b.Transition.StateBefore = before;
    b.Transition.StateAfter = after;
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    return b;
}

}

D3D11Bridge::~D3D11Bridge() { reset(); }

bool D3D11Bridge::wrapper_active() const noexcept {
    return dxgi::native_wrapper(shadow_.Get());
}

DXGI_FORMAT D3D11Bridge::linear_format(DXGI_FORMAT format) {
    // Use the linear UNORM equivalents required by the flip-model chain.
    // Flip-model DXGI swapchains cannot be created with the *_SRGB variants;
    // the reference therefore maps those two source formats to their linear
    // UNORM equivalents before creating both the shared texture and the D3D12
    // shadow swapchain.  Do this unconditionally: SM86_BRIDGE_LINEARIZE is not
    // allowed to make the DXGI descriptor invalid.
    switch (format) {
    case DXGI_FORMAT_R8G8B8A8_UNORM:      // 28 -> 28
    case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: // 29 -> 28
        return DXGI_FORMAT_R8G8B8A8_UNORM;
    case DXGI_FORMAT_B8G8R8A8_UNORM:      // 87 -> 87
    case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: // 91 -> 87
        return DXGI_FORMAT_B8G8R8A8_UNORM;
    default:
        return DXGI_FORMAT_UNKNOWN;
    }
}

void D3D11Bridge::reset() {
    if (unsafe_inflight_ || (completion_value_ && FAILED(wait_for_gpu(completion_value_)))) {
        // Do not free resources still referenced by uncompleted GPU commands.
        // At most one abandoned bridge per game swapchain; never retry it.
        device11_.Detach();context11_.Detach();shared11_.Detach();copy_query_.Detach();
        fence_context11_.Detach();copy_fence11_.Detach();copy_event_=nullptr;copy_value_=0;
        device12_.Detach();queue12_.Detach();allocator12_.Detach();list12_.Detach();
        shared12_.Detach();completion_fence_.Detach();shadow_.Detach();
        completion_event_=nullptr;completion_value_=0;active_=false;permanently_failed_=true;
        logf("[normal-bridge] GPU completion unavailable; resources retained until process exit and this bridge disabled.\n");
        return;
    }
    if (completion_event_) CloseHandle(completion_event_);
    if (copy_event_) CloseHandle(copy_event_);
    copy_event_=nullptr;copy_value_=0;
    completion_event_ = nullptr;
    shadow_.Reset();
    completion_fence_.Reset();
    copy_query_.Reset();
    copy_fence11_.Reset();fence_context11_.Reset();
    shared12_.Reset();
    shared11_.Reset();
    list12_.Reset();
    allocator12_.Reset();
    queue12_.Reset();
    device12_.Reset();
    context11_.Reset();
    device11_.Reset();
    active_ = false;
    wrapper_confirmed_ = false;
    activity_warning_ = false;
    progress_.start(nvpresent::cuda_activity_count());
    hwnd_ = nullptr;
    width_ = height_ = 0;
    source_format_ = DXGI_FORMAT_UNKNOWN;
    completion_value_ = 0;
}

HRESULT D3D11Bridge::wait_for_gpu(std::uint64_t value) {
    return wait_for_fence(completion_fence_.Get(),completion_event_,value);
}

void D3D11Bridge::initialize_copy_fence() {
    // Negotiate the optional D3D11.4 interfaces. This is a CPU event wait, not
    // an unbounded cross-queue dependency. Older runtimes retain the query path.
    ComPtr<ID3D11Device5> device;
    auto hr=device11_.As(&device);
    if(SUCCEEDED(hr))hr=context11_.As(&fence_context11_);
    if(SUCCEEDED(hr))hr=device->CreateFence(0,D3D11_FENCE_FLAG_NONE,IID_PPV_ARGS(&copy_fence11_));
    if(SUCCEEDED(hr)){
        copy_event_=CreateEventW(nullptr,FALSE,FALSE,nullptr);
        if(!copy_event_)hr=HRESULT_FROM_WIN32(GetLastError());
    }
    if(FAILED(hr)){
        copy_fence11_.Reset();fence_context11_.Reset();
        logf("[normal-bridge] D3D11 copy sync=query fallback; fence setup HRESULT=0x%08X.\n",unsigned(hr));
    }else logf("[normal-bridge] D3D11 copy sync=fence event; 500 ms completion deadline.\n");
}

HRESULT D3D11Bridge::wait_for_d3d11_copy() {
    if(copy_fence11_&&fence_context11_){
        if(copy_value_==UINT64_MAX-1)return E_UNEXPECTED;
        const auto hr=fence_context11_->Signal(copy_fence11_.Get(),++copy_value_);
        if(FAILED(hr))return hr;
        context11_->Flush();
        return wait_for_fence(copy_fence11_.Get(),copy_event_,copy_value_);
    }
    if (!context11_ || !copy_query_) return E_UNEXPECTED;
    context11_->End(copy_query_.Get());
    context11_->Flush();
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(500);
    unsigned polls=0;
    for (;;) {
        const HRESULT hr = context11_->GetData(copy_query_.Get(), nullptr, 0,
                                                D3D11_ASYNC_GETDATA_DONOTFLUSH);
        if (hr == S_OK) return S_OK;
        if (FAILED(hr)) return hr;
        if (std::chrono::steady_clock::now() >= deadline) return HRESULT_FROM_WIN32(WAIT_TIMEOUT);
        if(++polls<=32)SwitchToThread();else Sleep(1);
    }
}

bool D3D11Bridge::build_shared_resources(IDXGISwapChain* source, DXGI_FORMAT source_format,
                                         UINT /*width*/, UINT /*height*/) {
    ComPtr<ID3D11Texture2D> source_buffer;
    HRESULT hr = source->GetBuffer(0, IID_PPV_ARGS(&source_buffer));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] source GetBuffer failed: 0x%08X.\n", static_cast<unsigned>(hr));
        return false;
    }

    D3D11_TEXTURE2D_DESC texture_desc{};
    source_buffer->GetDesc(&texture_desc);
    texture_desc.Format = linear_format(source_format);
    texture_desc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    texture_desc.CPUAccessFlags = 0;
    texture_desc.Usage = D3D11_USAGE_DEFAULT;
    texture_desc.ArraySize = 1;
    texture_desc.MipLevels = 1;
    texture_desc.SampleDesc = {1, 0};

    // D3D12 owns the allocation. Share an NT handle into D3D11, as specified
    // by Microsoft's D3D11/D3D12 interop contract; never use a legacy handle.
    D3D12_HEAP_PROPERTIES heap{};heap.Type=D3D12_HEAP_TYPE_DEFAULT;
    heap.CreationNodeMask=heap.VisibleNodeMask=1;
    D3D12_RESOURCE_DESC desc{};desc.Dimension=D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width=texture_desc.Width;desc.Height=texture_desc.Height;
    desc.DepthOrArraySize=desc.MipLevels=1;desc.Format=texture_desc.Format;
    desc.SampleDesc={1,0};desc.Layout=D3D12_TEXTURE_LAYOUT_UNKNOWN;
    desc.Flags=D3D12_RESOURCE_FLAG_ALLOW_SIMULTANEOUS_ACCESS;
    hr=device12_->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_SHARED,&desc,
        D3D12_RESOURCE_STATE_COMMON,nullptr,IID_PPV_ARGS(&shared12_));
    if(FAILED(hr)){logf("[normal-bridge] shared D3D12 allocation failed: %08X.\n",unsigned(hr));return false;}
    HANDLE handle{};hr=device12_->CreateSharedHandle(shared12_.Get(),nullptr,GENERIC_ALL,nullptr,&handle);
    if(FAILED(hr)||!handle)return false;
    ComPtr<ID3D11Device1> d11;hr=device11_.As(&d11);
    if(SUCCEEDED(hr))hr=d11->OpenSharedResource1(handle,IID_PPV_ARGS(&shared11_));
    CloseHandle(handle);
    if(FAILED(hr)){logf("[normal-bridge] D3D11 OpenSharedResource1 failed: %08X.\n",unsigned(hr));return false;}

    initialize_copy_fence();
    if(!copy_fence11_){
        D3D11_QUERY_DESC query_desc{};
        query_desc.Query = D3D11_QUERY_EVENT;
        hr = device11_->CreateQuery(&query_desc, &copy_query_);
        if (FAILED(hr)) {
            logf("[nvs30-bridge] CreateQuery(D3D11_QUERY_EVENT) failed: 0x%08X.\n",
                 static_cast<unsigned>(hr));
            return false;
        }
    }

    hr = device12_->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                           IID_PPV_ARGS(&allocator12_));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] CreateCommandAllocator failed: 0x%08X.\n",
             static_cast<unsigned>(hr));
        return false;
    }
    hr = device12_->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT,
                                      allocator12_.Get(), nullptr, IID_PPV_ARGS(&list12_));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] CreateCommandList failed: 0x%08X.\n", static_cast<unsigned>(hr));
        return false;
    }
    hr = list12_->Close();
    if (FAILED(hr)) {
        logf("[nvs30-bridge] initial command-list Close failed: 0x%08X.\n",
             static_cast<unsigned>(hr));
        return false;
    }
    hr = device12_->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&completion_fence_));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] CreateFence(completion) failed: 0x%08X.\n",
             static_cast<unsigned>(hr));
        return false;
    }
    completion_event_ = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!completion_event_)
        logf("[nvs30-bridge] CreateEvent(completion) failed: %lu.\n", GetLastError());
    return completion_event_ != nullptr;
}

bool D3D11Bridge::initialize(IDXGISwapChain* source, HWND hwnd) {
    reset();
    if(permanently_failed_)return false;
    DXGI_SWAP_CHAIN_DESC source_desc{};
    if (!source || !hwnd) {
        logf("[nvs30-bridge] initialization skipped: source=%p hwnd=%p.\n", source, hwnd);
        return false;
    }
    HRESULT hr = source->GetDesc(&source_desc);
    if (FAILED(hr)) {
        logf("[nvs30-bridge] source GetDesc failed: 0x%08X.\n", static_cast<unsigned>(hr));
        return false;
    }
    width_=source_desc.BufferDesc.Width;height_=source_desc.BufferDesc.Height;
    hwnd_=hwnd;source_format_=source_desc.BufferDesc.Format;
    if(!source_desc.Windowed||source_desc.SwapEffect!=DXGI_SWAP_EFFECT_DISCARD||
       source_desc.SampleDesc.Count!=1||source_desc.Flags!=0){
        logf("[normal-bridge] pass-through: bridge needs windowed legacy DISCARD, single-sample SDR, no special flags.\n");return false;
    }
    if (source_desc.BufferDesc.Width < 480 || source_desc.BufferDesc.Height < 480) {
        logf("[nvs30-bridge] resolution %ux%u is below the bridge threshold.\n",
             source_desc.BufferDesc.Width, source_desc.BufferDesc.Height);
        return false;
    }
    width_ = source_desc.BufferDesc.Width;
    height_ = source_desc.BufferDesc.Height;
    source_format_ = source_desc.BufferDesc.Format;
    hwnd_ = hwnd;

    const DXGI_FORMAT bridge_format = linear_format(source_format_);
    if (bridge_format == DXGI_FORMAT_UNKNOWN) {
        logf("[nvs30-bridge] format %u is not safe for the shared bridge; native passthrough.\n",
             unsigned(source_format_));
        return false;
    }

    logf("[nvs30-bridge] initializing source=%p hwnd=%p %ux%u format=%u bridge_format=%u.\n",
         source, hwnd, width_, height_, unsigned(source_format_), unsigned(bridge_format));
    hr = source->GetDevice(IID_PPV_ARGS(&device11_));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] source is not D3D11: GetDevice failed 0x%08X.\n",
             static_cast<unsigned>(hr));
        return false;
    }
    device11_->GetImmediateContext(&context11_);
    if (!context11_) return false;

    // Resolve the game's adapter so the D3D12 device lives on the same GPU
    // the game is rendering on. The shadow chain itself is created on a fresh
    // factory (matching the reference bridge); NvPresent observes that path
    // after NVP_Init_D3D without us touching the game's factory instance.
    ComPtr<IDXGIAdapter> game_adapter;
    ComPtr<IDXGIFactory2> game_factory;
    DXGI_ADAPTER_DESC game_adapter_desc{};
    bool have_game_adapter = false;
    if (ComPtr<IDXGIDevice> dxgi_device; SUCCEEDED(device11_.As(&dxgi_device)) && dxgi_device) {
        ComPtr<IDXGIAdapter> adapter;
        if (SUCCEEDED(dxgi_device->GetAdapter(&adapter)) && adapter) {
            game_adapter = adapter;
            if (SUCCEEDED(adapter->GetDesc(&game_adapter_desc))) have_game_adapter = true;
            ComPtr<IDXGIFactory> factory0;
            if (SUCCEEDED(adapter->GetParent(IID_PPV_ARGS(&factory0))) && factory0)
                factory0.As(&game_factory);
        }
    }
    logf("[nvs30-bridge] game adapter=%p factory=%p desc='%ls' vid=0x%X dev=0x%X luid=%08X:%08X.\n",
         game_adapter.Get(), game_factory.Get(),
         have_game_adapter ? game_adapter_desc.Description : L"<unknown>",
         have_game_adapter ? game_adapter_desc.VendorId : 0,
         have_game_adapter ? game_adapter_desc.DeviceId : 0,
         have_game_adapter ? static_cast<unsigned>(game_adapter_desc.AdapterLuid.HighPart) : 0,
         have_game_adapter ? static_cast<unsigned>(game_adapter_desc.AdapterLuid.LowPart) : 0);

    if(!have_game_adapter||game_adapter_desc.VendorId!=0x10de)return false;
    hr=D3D12CreateDevice(game_adapter.Get(),D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&device12_));
    if(FAILED(hr)){logf("[normal-bridge] D3D12 creation on game's adapter failed: %08X.\n",unsigned(hr));return false;}
    const auto luid=device12_->GetAdapterLuid();
    if(luid.HighPart!=game_adapter_desc.AdapterLuid.HighPart||luid.LowPart!=game_adapter_desc.AdapterLuid.LowPart){
        logf("[normal-bridge] adapter mismatch; bridge rejected.\n");return false;
    }

    D3D12_COMMAND_QUEUE_DESC queue_desc{};
    queue_desc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
    hr = device12_->CreateCommandQueue(&queue_desc, IID_PPV_ARGS(&queue12_));
    if (FAILED(hr)) {
        logf("[nvs30-bridge] CreateCommandQueue failed: 0x%08X.\n", static_cast<unsigned>(hr));
        return false;
    }

    ComPtr<IDXGIFactory2> factory;
    struct Internal {bool previous=dxgi::internal_creation();Internal(){dxgi::set_internal_creation(true);}~Internal(){dxgi::set_internal_creation(previous);}} internal;
    const HRESULT factory_hr = CreateDXGIFactory1(IID_PPV_ARGS(&factory));
    if (FAILED(factory_hr)) {
        logf("[nvs30-bridge] CreateDXGIFactory1 failed: 0x%08X.\n",
             static_cast<unsigned>(factory_hr));
        return false;
    }
    logf("[nvs30-bridge] shadow factory=%p (fresh; game factory left untouched).\n",
         factory.Get());
    DXGI_SWAP_CHAIN_DESC1 shadow_desc{};
    shadow_desc.Width = width_;
    shadow_desc.Height = height_;
    shadow_desc.Format = linear_format(source_format_);
    shadow_desc.SampleDesc = {1, 0};
    shadow_desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    // Keep the two-buffer HWND shape used by the reviewed reference path.
    // Wrapper presence and actual displayed interpolation remain separate checks.
    shadow_desc.BufferCount = 2;
    shadow_desc.Scaling = DXGI_SCALING_STRETCH;
    shadow_desc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    shadow_desc.AlphaMode = DXGI_ALPHA_MODE_UNSPECIFIED;
    // Plain flip-discard HWND chain, without unsupported presentation flags.
    shadow_desc.Flags = 0;
    ComPtr<IDXGISwapChain1> shadow1;
    const auto cuda_before_swapchain = nvpresent::cuda_intercept_count();
    const HRESULT swap_hr = factory->CreateSwapChainForHwnd(queue12_.Get(), hwnd_, &shadow_desc,
                                                             nullptr, nullptr, &shadow1);
    const auto cuda_after_swapchain = nvpresent::cuda_intercept_count();
    if (FAILED(swap_hr)) {
        logf("[nvs30-bridge] CreateSwapChainForHwnd(shadow) failed: 0x%08X.\n",
             static_cast<unsigned>(swap_hr));
        return false;
    }
    logf("[nvs30-bridge] shadow creation CUDA intercepts=%llu->%llu.\n",
         static_cast<unsigned long long>(cuda_before_swapchain),
         static_cast<unsigned long long>(cuda_after_swapchain));
    if(nvpresent::cuda_execution_failure_count()){stop("CUDA execution failure during shadow creation",DXGI_ERROR_UNSUPPORTED);return false;}
    hr = shadow1.As(&shadow_);
    if (FAILED(hr)) {
        logf("[nvs30-bridge] shadow IDXGISwapChain3 query failed: 0x%08X.\n",
             static_cast<unsigned>(hr));
        return false;
    }


    if (!build_shared_resources(source, source_format_, width_, height_)) {
        logf("[nvs30-bridge] shared-resource initialization failed.\n");
        return false;
    }
    // Private COM slots are not a public API. Do not call guessed enable
    // methods or interpret unrelated object fields as an NvPresent object.
    const bool wrapped=wrapper_active();
    if(!wrapped)logf("[normal-bridge] NvPresent entry not visible; requires fresh CUDA activity within each 64 accepted Presents.\n");
    if(wrapped)logf("[normal-bridge] NvPresent present entry detected. Interpolated output still requires measurement.\n");
    active_ = true;
    wrapper_confirmed_ = wrapped;
    activity_warning_ = false;
    progress_.start(nvpresent::cuda_activity_count());
    attempts_.succeeded();
    logf("[nvs30-bridge] D3D11>D3D12 shadow swapchain ready (output unverified): %ux%u format=%u wrapper=%p detected=%d.\n",
         width_, height_, unsigned(source_format_), nullptr, wrapped);
    return true;
}

bool D3D11Bridge::retire_if_idle() {
    if(completion_value_&&completion_fence_&&!unsafe_inflight_){
        const auto value=completion_fence_->GetCompletedValue();
        if(value==UINT64_MAX)unsafe_inflight_=true;
        else if(value<completion_value_)return false;
    }
    reset();return true;
}
HRESULT D3D11Bridge::stop(const char* operation,HRESULT result,bool unsafe) {
    if(!permanently_failed_){
        logf("[normal-bridge] stopped at %s: HRESULT=0x%08X D3D11_reason=0x%08X D3D12_reason=0x%08X. Original presentation restored; no retry on this chain.\n",
            operation,unsigned(result),unsigned(device11_?device11_->GetDeviceRemovedReason():S_OK),unsigned(device12_?device12_->GetDeviceRemovedReason():S_OK));
    }
    permanently_failed_=true;unsafe_inflight_|=unsafe;reset();return result;
}
void D3D11Bridge::accepted_present() {
    if(!active_||permanently_failed_)return;
    if(nvpresent::cuda_execution_failure_count())stop("CUDA execution",DXGI_ERROR_UNSUPPORTED);
    else switch(progress_.assess(nvpresent::cuda_activity_count(),wrapper_confirmed_)){
        case presentation::Activity::within_window:activity_warning_=false;break;
        case presentation::Activity::unobserved:
            if(!activity_warning_)logf("[normal-bridge] No fresh CUDA calls observed in 64 accepted Presents; native NvPresent wrapper retained. Interpolated output remains unverified.\n");
            activity_warning_=true;break;
        case presentation::Activity::retire_unconfirmed:
            stop("unconfirmed wrapper and no fresh CUDA activity in 64 accepted Presents",DXGI_ERROR_UNSUPPORTED);break;
    }
}

HRESULT D3D11Bridge::prepare(IDXGISwapChain* source, HWND hwnd, ComPtr<IDXGISwapChain3>& output) {
    output.Reset();if(permanently_failed_)return DXGI_ERROR_UNSUPPORTED;
    if(nvpresent::cuda_execution_failure_count())return stop("CUDA failure",DXGI_ERROR_UNSUPPORTED);
    DXGI_SWAP_CHAIN_DESC desc{};
    if (FAILED(source->GetDesc(&desc))) return DXGI_ERROR_INVALID_CALL;
    const auto shape=shape_of(desc,hwnd);
    if(!desc.Windowed||desc.SwapEffect!=DXGI_SWAP_EFFECT_DISCARD||desc.SampleDesc.Count!=1||desc.Flags!=0){
        if(active_)reset();return DXGI_ERROR_UNSUPPORTED;
    }
    if (!active_ || hwnd != hwnd_ || desc.BufferDesc.Width != width_ ||
        desc.BufferDesc.Height != height_ || desc.BufferDesc.Format != source_format_) {
        // Hard resource failures suppress retries only for the same shape;
        // a resize/HWND/format change always gets one fresh attempt.
        if (attempts_.blocked(shape)) return DXGI_ERROR_UNSUPPORTED;
        // Resize/HWND change: retry init instead of suppressing forever. Only
        // a hard resource failure records this full descriptor, and even then
        // a different size/HWND clears the way for one fresh attempt.
        if (!initialize(source, hwnd)) {
            reset();attempts_.failed(shape);
            logf("[nvs30-bridge] initialization failed; original presentation retained. Descriptor recorded; permanent=%d.\n",permanently_failed_?1:0);
            return DXGI_ERROR_UNSUPPORTED;
        }
    }
    const auto completion_hr=wait_for_gpu(completion_value_);
    if(FAILED(completion_hr))return stop("D3D12 copy completion",completion_hr,true);

    ComPtr<ID3D11Texture2D> source_buffer;
    const HRESULT buffer_hr = source->GetBuffer(0, IID_PPV_ARGS(&source_buffer));
    if (FAILED(buffer_hr)) return stop("source GetBuffer",buffer_hr);
    context11_->CopyResource(shared11_.Get(), source_buffer.Get());
    const auto copy_hr=wait_for_d3d11_copy();
    if(FAILED(copy_hr))return stop("D3D11 copy completion",copy_hr,true);

    auto hr=allocator12_->Reset();if(FAILED(hr))return stop("allocator Reset",hr);
    hr=list12_->Reset(allocator12_.Get(),nullptr);if(FAILED(hr))return stop("command list Reset",hr);
    ComPtr<ID3D12Resource> destination;
    hr=shadow_->GetBuffer(shadow_->GetCurrentBackBufferIndex(),IID_PPV_ARGS(&destination));
    if(FAILED(hr))return stop("shadow GetBuffer",hr);
    std::array<D3D12_RESOURCE_BARRIER, 2> before{
        transition(shared12_.Get(), D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_SOURCE),
        transition(destination.Get(), D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_DEST)};
    list12_->ResourceBarrier(static_cast<UINT>(before.size()), before.data());
    list12_->CopyResource(destination.Get(), shared12_.Get());
    std::array<D3D12_RESOURCE_BARRIER, 2> after{
        transition(destination.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PRESENT),
        transition(shared12_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COMMON)};
    list12_->ResourceBarrier(static_cast<UINT>(after.size()), after.data());
    hr=list12_->Close();if(FAILED(hr))return stop("command list Close",hr);
    ID3D12CommandList* lists[]{list12_.Get()};
    queue12_->ExecuteCommandLists(1, lists);
    ++completion_value_;
    hr=queue12_->Signal(completion_fence_.Get(),completion_value_);
    if(FAILED(hr))return stop("queue Signal",hr,true);
    output=shadow_;return S_OK;
}
}
