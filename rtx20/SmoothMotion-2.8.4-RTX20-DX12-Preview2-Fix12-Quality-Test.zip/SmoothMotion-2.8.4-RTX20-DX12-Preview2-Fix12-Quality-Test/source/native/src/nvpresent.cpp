#include "nvs30/nvpresent.hpp"

#include "nvs30/config.hpp"
#include "nvs30/fatbin.hpp"
#include "nvs30/log.hpp"
#include "nvs30/pe.hpp"
#include "nvs30/driver_file.hpp"
#include "nvs30/pointer_journal.hpp"
#include "nvs30/profile_transaction.hpp"
#include "nvs30/cuda_health.hpp"
#include "nvs30/init_trace.hpp"

#include <intrin.h>
#include <bcrypt.h>
#include <setupapi.h>
#include <tlhelp32.h>
#include <cstdio>

namespace nvs30::nvpresent {
namespace {
using CuModuleLoadData = int (WINAPI*)(void** module, const void* image);
using GetProcAddressFn = FARPROC (WINAPI*)(HMODULE, LPCSTR);
// The reviewed export returns a C++ bool in AL, not a Win32 BOOL in EAX.
// Testing all32 bits can interpret a FALSE low byte plus stale upper bits as
// success. Read the actual return ABI, then verify the profile readiness byte.
using NvpInitD3D = bool (WINAPI*)();

HMODULE g_nvp{};
HANDLE g_backend_claim{}; // Process-lifetime reservation across DLL/ASI copies.
CuModuleLoadData g_real_cu_load{};
GetProcAddressFn g_real_getproc{};
PointerJournal<24> g_pointer_patches;
bool write_cuda_pointer(void** slot,void* value){return pe::write_pointer(slot,value);}
void** g_getproc_slot{};
std::atomic_bool g_initialized{};
bool g_sm86_present=false;
std::atomic_bool g_profile_applied{false};
std::atomic<const char*> g_state{"not_started"};
bool fail(const char* state){g_state=state;logf("[normal] initialization stopped: %s.\n",state);return false;}

bool claim_backend(){
    if(g_backend_claim)return true;
    wchar_t name[96]{};std::swprintf(name,std::size(name),L"Local\\SmoothMotion-Normal-%lu",GetCurrentProcessId());
    SetLastError(ERROR_SUCCESS);
    HANDLE claim=CreateMutexW(nullptr,FALSE,name);const auto error=GetLastError();
    if(!claim)return fail("backend_reservation_unavailable");
    if(error==ERROR_ALREADY_EXISTS){CloseHandle(claim);return fail("duplicate_normal_backend");}
    g_backend_claim=claim;return true;
}

bool competing_backend(){
    HMODULE self{};
    if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
        reinterpret_cast<LPCWSTR>(&competing_backend),&self))return true;
    struct Release{HMODULE module;~Release(){FreeLibrary(module);}} releaseSelf{self};
    const auto snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());
    if(snapshot==INVALID_HANDLE_VALUE)return false; // Existing NvPresent check remains.
    struct Close{HANDLE value;~Close(){CloseHandle(value);}} close{snapshot};
    MODULEENTRY32W entry{};entry.dwSize=sizeof entry;
    if(!Module32FirstW(snapshot,&entry))return false;
    unsigned visited=0;
    do {
        if(++visited>4096)break;
        if(entry.hModule==self)continue;
        HMODULE held{};
        if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
            reinterpret_cast<LPCWSTR>(entry.hModule),&held))continue;
        Release release{held};
        // Paired exports identify the inspected combined SM/MFG providers or
        // another normal-backend build, including older versions which lack
        // the shared reservation. Generic ASI loaders are not matched.
        const bool combined=GetProcAddress(held,"SM_Prepare")&&GetProcAddress(held,"SM_ProviderPath");
        const bool normal=GetProcAddress(held,"SmoothMotionGetStatus")&&GetProcAddress(held,"InitializeASI");
        if(combined||normal){
            logf("[normal] Competing Smooth Motion provider detected: %ls. Use one Smooth Motion engine in this process.\n",entry.szExePath);
            return true;
        }
    } while(Module32NextW(snapshot,&entry));
    return false;
}
using ErrorText=int (WINAPI*)(int,const char**);
ErrorText error_name{},error_text{};
std::atomic_uint64_t g_cuda_intercepts{};
std::atomic_uint64_t g_cuda_successes{};
cuda_health::Failures g_cuda_failures;
using ContextDevice=int (WINAPI*)(int*);
using DeviceAttribute=int (WINAPI*)(int*,int,int);
ContextDevice g_context_device{};DeviceAttribute g_device_attribute{};

using KernelLaunch=int (WINAPI*)(void*,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,void*,void**,void**);
using GraphLaunch=int (WINAPI*)(void*,void*);
using StreamSync=int (WINAPI*)(void*);
KernelLaunch real_kernel{};GraphLaunch real_graph{};StreamSync real_sync{},real_event_sync{};
std::atomic_uint64_t g_execution_submissions{};
int record_cuda(const char* operation,int rc,bool submission,bool moduleLoad=false){
    g_cuda_failures.record(moduleLoad?cuda_health::Operation::ModuleLoad:cuda_health::Operation::Execution,rc);
    if(rc){auto failures=moduleLoad?g_cuda_failures.modules():g_cuda_failures.execution();if(failures<=16){
        const char* name=nullptr;const char* description=nullptr;
        if(error_name)error_name(rc,&name);if(error_text)error_text(rc,&description);
        logf("[normal] CUDA %s failed: rc=%d name=%s description=%s. Interpolation is not verified.\n",operation,rc,name?name:"unavailable",description?description:"unavailable");
    }}
    else if(submission){auto count=++g_execution_submissions;if(count==1||count%1000==0)logf("[normal] CUDA activity calls=%llu; kernel/graph API success is not completion or a displayed-frame counter.\n",static_cast<unsigned long long>(count));}
    return rc;
}
int WINAPI kernel_observer(void* f,unsigned gx,unsigned gy,unsigned gz,unsigned bx,unsigned by,unsigned bz,unsigned shared,void* stream,void** params,void** extra){return record_cuda("cuLaunchKernel",real_kernel(f,gx,gy,gz,bx,by,bz,shared,stream,params,extra),true);}
int WINAPI graph_observer(void* graph,void* stream){return record_cuda("cuGraphLaunch",real_graph(graph,stream),true);}
int WINAPI sync_observer(void* stream){return record_cuda("cuStreamSynchronize",real_sync(stream),false);}
int WINAPI event_sync_observer(void* event){return record_cuda("cuEventSynchronize",real_event_sync(event),false);}
template<class Function> void observe(const char* name,Function replacement,Function& original){
    auto slot=pe::find_import_slot(g_nvp,"nvcuda.dll",name);if(!slot||!*slot)return;
    original=reinterpret_cast<Function>(*slot);
    if(!g_pointer_patches.install(slot,reinterpret_cast<void*>(replacement),write_cuda_pointer))
        logf("[normal] CUDA observer %s unavailable.\n",name);
}
void observe_execution(){observe("cuLaunchKernel",&kernel_observer,real_kernel);observe("cuGraphLaunch",&graph_observer,real_graph);observe("cuStreamSynchronize",&sync_observer,real_sync);observe("cuEventSynchronize",&event_sync_observer,real_event_sync);}

void log_nvp_exports() {
    // List NvPresent's export names so the log shows whether a per-device /
    // per-swapchain registration entry point exists that the bridge should
    // call after NVP_Init_D3D. Bounds-checked against the image size; never
    // throws.
    const auto* base = reinterpret_cast<const std::byte*>(g_nvp);
    const std::size_t image = pe::image_size(g_nvp);
    if (!base || image < sizeof(IMAGE_DOS_HEADER)) return;
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 ||
        static_cast<std::size_t>(dos->e_lfanew) + sizeof(IMAGE_NT_HEADERS64) > image)
        return;
    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    const auto& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!dir.VirtualAddress || !dir.Size ||
        static_cast<std::size_t>(dir.VirtualAddress) + dir.Size > image)
        return;
    const auto* exp = reinterpret_cast<const IMAGE_EXPORT_DIRECTORY*>(base + dir.VirtualAddress);
    if (exp->NumberOfNames == 0 || exp->NumberOfNames > 512) {
        logf("[nvs30] NvPresent exports: %u functions.\n", exp->NumberOfFunctions);
        return;
    }
    if (static_cast<std::size_t>(exp->AddressOfNames) + exp->NumberOfNames * 4 > image) return;
    const auto* names = reinterpret_cast<const DWORD*>(base + exp->AddressOfNames);
    char line[1024]{};
    std::size_t pos = 0;
    unsigned count = 0;
    for (DWORD i = 0; i < exp->NumberOfNames && pos + 32 < sizeof(line); ++i) {
        if (names[i] >= image) continue;
        const char* s = reinterpret_cast<const char*>(base + names[i]);
        std::size_t len = 0;
        while (len < 64 && s + len < reinterpret_cast<const char*>(base + image) && s[len]) ++len;
        if (len == 0 || len >= 64) continue;
        if (pos + len + 1 >= sizeof(line)) break;
        if (count) line[pos++] = ' ';
        std::memcpy(line + pos, s, len);
        pos += len;
        ++count;
    }
    line[pos] = '\0';
    logf("[nvs30] NvPresent exports (%u): %s\n", count, line);
}

struct BytePatch {
    std::byte* address{};
    std::vector<std::byte> original;
    bool active{};

    bool apply(const void* replacement, std::size_t size) {
        if (!address || !replacement || !size) return false;
        original.resize(size);SIZE_T copied{};
        if(!ReadProcessMemory(GetCurrentProcess(),address,original.data(),size,&copied)||copied!=size)return false;
        // Retain the original even when protection/cache restoration fails.
        // A group rollback can retry a write left in an indeterminate state.
        active=true;return pe::write_memory(address, replacement, size);
    }
    bool restore() {
        if (!active || original.empty())return true;
        if(pe::write_memory(address, original.data(), original.size())){active=false;return true;}
        else logf("[normal] patch rollback incomplete at %p; hook storage remains resident.\n",address);
        return false;
    }
};

BytePatch g_arch_patch;
BytePatch g_capability_patch;
std::array<BytePatch, 3> g_config_patches;
std::array<BytePatch, driver_profile::maximum_sites> g_profile_patches;

bool install_model_profile(const driver_file::File& file){
    const auto edits=driver_profile::edits(file.verdict.profile);
    for(std::size_t i=0;i<edits.size();++i){
        const auto& edit=edits[i];std::uint32_t rva=0;
        for(const auto& section:file.image.sections){
            if(edit.offset>=section.raw&&driver_layout::range(edit.offset-section.raw,edit.before.size(),std::min(section.bytes,section.size))){
                rva=section.rva+static_cast<std::uint32_t>(edit.offset-section.raw);break;
            }
        }
        if(!rva||!driver_layout::range(rva,edit.before.size(),file.image.size))return false;
        g_profile_patches[i].address=reinterpret_cast<std::byte*>(g_nvp)+rva;
    }
    const auto result=profile_transaction::run(edits,
        [&](std::size_t i,auto& bytes){SIZE_T copied{};return ReadProcessMemory(GetCurrentProcess(),g_profile_patches[i].address,bytes.data(),bytes.size(),&copied)&&copied==bytes.size();},
        [&](std::size_t i,const auto& bytes){return g_profile_patches[i].apply(bytes.data(),bytes.size());},
        [&](std::size_t i){return g_profile_patches[i].restore();});
    if(result!=profile_transaction::Result::Applied){logf("[normal] Loaded model-profile transaction rejected: result=%u.\n",unsigned(result));return false;}
    g_profile_applied=true;
    logf("[normal] Exact model profile applied before initialization: %zu sites, %zu bytes, 20 non-FP8 modules; 17 FP8 modules and capability SETGE unchanged.\n",edits.size(),driver_profile::changed_bytes(file.verdict.profile));
    return true;
}

std::vector<std::wstring> active_driver_paths(){
    const GUID display={0x4d36e968,0xe325,0x11ce,{0xbf,0xc1,0x08,0x00,0x2b,0xe1,0x03,0x18}};
    std::vector<std::wstring> paths;
    auto devices=SetupDiGetClassDevsW(&display,nullptr,nullptr,DIGCF_PRESENT);
    if(devices==INVALID_HANDLE_VALUE)return paths;
    struct DeviceSet{HDEVINFO handle;~DeviceSet(){SetupDiDestroyDeviceInfoList(handle);}} deviceSet{devices};
    SP_DEVINFO_DATA device{};device.cbSize=sizeof device;
    for(DWORD i=0;SetupDiEnumDeviceInfo(devices,i,&device);++i){
        std::wstring hardware(4096,L'\0'),driver(512,L'\0');DWORD type=0;
        if(!SetupDiGetDeviceRegistryPropertyW(devices,&device,SPDRP_HARDWAREID,&type,reinterpret_cast<PBYTE>(hardware.data()),static_cast<DWORD>((hardware.size()-2)*sizeof(wchar_t)),nullptr))continue;
        std::wstring hw(hardware.c_str());std::transform(hw.begin(),hw.end(),hw.begin(),::towupper);
        if(hw.find(L"VEN_10DE")==hw.npos)continue;
        if(!SetupDiGetDeviceRegistryPropertyW(devices,&device,SPDRP_DRIVER,&type,reinterpret_cast<PBYTE>(driver.data()),static_cast<DWORD>((driver.size()-2)*sizeof(wchar_t)),nullptr))continue;
        std::wstring key=L"SYSTEM\\CurrentControlSet\\Control\\Class\\";key+=driver.c_str();HKEY registry{};
        if(RegOpenKeyExW(HKEY_LOCAL_MACHINE,key.c_str(),0,KEY_READ|KEY_WOW64_64KEY,&registry)!=ERROR_SUCCESS)continue;
        struct RegistryKey{HKEY handle;~RegistryKey(){RegCloseKey(handle);}} registryKey{registry};
        for(auto name:{L"D3DDriverName",L"OpenGLDriverName",L"UserModeDriverName"}){
            std::wstring value(16384,L'\0');DWORD bytes=static_cast<DWORD>((value.size()-2)*sizeof(wchar_t));
            if(RegQueryValueExW(registry,name,nullptr,&type,reinterpret_cast<BYTE*>(value.data()),&bytes)!=ERROR_SUCCESS||
               (type!=REG_SZ&&type!=REG_MULTI_SZ&&type!=REG_EXPAND_SZ))continue;
            for(const wchar_t* at=value.c_str();*at;at+=std::wcslen(at)+1){
                std::wstring expanded(32768,L'\0');auto expandedSize=ExpandEnvironmentStringsW(at,expanded.data(),32768);if(!expandedSize||expandedSize>32768)continue;
                std::wstring text(expanded.data());
                if(text.rfind(L"\\SystemRoot\\",0)==0){wchar_t win[MAX_PATH]{};GetWindowsDirectoryW(win,MAX_PATH);text=std::wstring(win)+text.substr(11);}
                std::filesystem::path file=text;if(!file.is_absolute())continue;
                auto candidate=file.parent_path()/L"NvPresent64.dll";
                if(std::filesystem::exists(candidate)&&std::find(paths.begin(),paths.end(),candidate.wstring())==paths.end())paths.push_back(candidate.wstring());
            }
        }
    }
    return paths;
}
std::wstring locate_nvpresent() {
    if(!config().nvpresent_path.empty()){
        std::filesystem::path p(config().nvpresent_path);
        if(!p.is_absolute()){fail("override_path_not_absolute");return {};}
        return p.wstring();
    }
    const auto active=active_driver_paths();
    if(active.size()==1)return active[0];
    if(active.size()>1){fail("multiple_active_driver_components");return {};}
    wchar_t system[MAX_PATH]{};if(!GetSystemDirectoryW(system,MAX_PATH)){fail("system_directory_unavailable");return {};}
    auto direct=std::filesystem::path(system)/L"NvPresent64.dll";
    if(std::filesystem::exists(direct))return direct.wstring();
    auto root=std::filesystem::path(system)/L"DriverStore"/L"FileRepository";
    WIN32_FIND_DATAW data{};HANDLE search=FindFirstFileW((root/L"nv*.inf_amd64_*").c_str(),&data);
    if(search==INVALID_HANDLE_VALUE){fail("driver_file_not_found");return {};}
    std::vector<std::wstring> candidates;
    do{if(!(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY))continue;auto p=root/data.cFileName/L"NvPresent64.dll";
        if(std::filesystem::exists(p))candidates.push_back(p.wstring());}while(FindNextFileW(search,&data));FindClose(search);
    if(candidates.size()!=1){
        logf("[normal] DriverStore candidates=%zu. SM86_NVPRESENT_PATH can select the active component by full path.\n",candidates.size());
        fail(candidates.empty()?"driver_file_not_found":"active_driver_ambiguous");return {};
    }
    return candidates.front();
}

bool decode_reference_gate_tail(const std::byte* instruction, std::size_t available,
                                std::array<std::byte, 4>& output,
                                std::size_t& length) {
    output.fill(std::byte{0x90});

    // Reference NvPresent builds use SIL for the capability result. Accept
    // either the original SETGE encoding or the already-patched MOV SIL,1
    // form so initialization is idempotent across repeated loads.
    if (available >= 4 &&
        instruction[0] == std::byte{0x40} &&
        instruction[1] == std::byte{0x0f} &&
        instruction[2] == std::byte{0x9d} &&
        instruction[3] == std::byte{0xc6}) {
        output = {std::byte{0x40}, std::byte{0xb6}, std::byte{0x01}, std::byte{0x90}};
        length = 4;
        return true;
    }
    if (available >= 4 &&
        instruction[0] == std::byte{0x40} &&
        instruction[1] == std::byte{0xb6} &&
        instruction[2] == std::byte{0x01} &&
        instruction[3] == std::byte{0x90}) {
        output = {std::byte{0x40}, std::byte{0xb6}, std::byte{0x01}, std::byte{0x90}};
        length = 4;
        return true;
    }
    if (available >= 3 &&
        instruction[0] == std::byte{0x0f} &&
        instruction[1] == std::byte{0x9d} &&
        instruction[2] == std::byte{0xc6}) {
        output[0] = std::byte{0xb6};
        output[1] = std::byte{0x01};
        output[2] = std::byte{0x90};
        length = 3;
        return true;
    }
    if (available >= 3 &&
        instruction[0] == std::byte{0xb6} &&
        instruction[1] == std::byte{0x01} &&
        instruction[2] == std::byte{0x90}) {
        output[0] = std::byte{0xb6};
        output[1] = std::byte{0x01};
        output[2] = std::byte{0x90};
        length = 3;
        return true;
    }
    return false;
}

struct GateMatch {
    std::byte* immediate{};
    std::byte* setge{};
    std::array<std::byte, 4> force_true{};
    std::size_t setge_size{};
};

std::uintptr_t module_offset(const void* address) {
    return reinterpret_cast<std::uintptr_t>(address) - reinterpret_cast<std::uintptr_t>(g_nvp);
}

std::optional<GateMatch> find_gate(NvpInitD3D /*init*/) {
    // Match the working rehost's structural signature exactly:
    //   cmp dword ptr [rcx+14h], 2/3
    // followed within 40 bytes by SETGE SIL (or its already-patched form).
    // Avoid the broader "any [reg+disp8]" scan used by the second DLL; that
    // can select unrelated comparisons in newer NvPresent text sections.
    std::optional<GateMatch> found;
    for (const auto& section : pe::sections(g_nvp)) {
        if (!(section.characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        if (section.size < 8) continue;

        for (std::size_t i = 0; i + 8 <= section.size; ++i) {
            auto* p = section.begin + i;
            if (p[0] != std::byte{0x83} ||
                p[1] != std::byte{0x79} ||
                p[2] != std::byte{0x14} ||
                (p[3] != std::byte{0x03} && p[3] != std::byte{0x02}))
                continue;

            const std::size_t limit = std::min<std::size_t>(40, section.size - i);
            for (std::size_t j = 4; j < limit; ++j) {
                GateMatch match{};
                match.immediate = p + 3;
                match.setge = p + j;
                if (!decode_reference_gate_tail(p + j, section.size - i - j,
                                                match.force_true,
                                                match.setge_size))
                    continue;

                logf("[nvs30] Gate located dynamically: cmp=+0x%zx setge=+0x%zx len=%zu.\n",
                     module_offset(match.immediate), module_offset(match.setge),
                     match.setge_size);
                if(found)return std::nullopt;found=match;break;
            }
        }
    }
    return found;
}

std::byte* find_config(NvpInitD3D init) {
    auto* code = reinterpret_cast<std::byte*>(init);
    for (std::size_t i = 0; i + 7 <= 96; ++i) {
        if (code[i] != std::byte{0x48} || code[i + 1] != std::byte{0x8d} ||
            code[i + 2] != std::byte{0x0d}) continue;
        std::int32_t displacement{};
        std::memcpy(&displacement, code + i + 3, sizeof(displacement));
        auto* target = code + i + 7 + displacement;
        if (pe::address_in_writable_section(g_nvp, target, 0x12a6)) return target;
    }
    return nullptr;
}

int WINAPI hooked_cu_module_load_data(void** module_out, const void* image) {
    if (!g_real_cu_load) return 3;
    static std::atomic_long serial{0};const long id=++serial;++g_cuda_intercepts;
    if(g_profile_applied.load()){
        // The verified model was adapted in its owning loaded image before
        // NVP_Init_D3D. Preserve its original pointer and all FP8/SM120 bytes.
        const int rc=record_cuda("cuModuleLoadData (exact model profile)",g_real_cu_load(module_out,image),false,true);
        if(!rc)++g_cuda_successes;
        if(id<=48||rc)logf("[normal] CUDA module #%ld exact-profile original pointer: rc=%d.\n",id,rc);
        return rc;
    }
    int device=-1,major=0,minor=0;
    if(!g_context_device||!g_device_attribute||g_context_device(&device)!=0||
        g_device_attribute(&major,75,device)!=0||g_device_attribute(&minor,76,device)!=0){
        logf("[normal] CUDA module #%ld: current-device query unavailable; original image retained.\n",id);
        int rc=record_cuda("cuModuleLoadData (device unavailable)",g_real_cu_load(module_out,image),false,true);if(!rc)++g_cuda_successes;return rc;
    }
    if(major!=8||minor!=6){int rc=g_real_cu_load(module_out,image);record_cuda("cuModuleLoadData",rc,false,true);if(!rc)++g_cuda_successes;return rc;}
    fatbin::RewrittenImage rewritten;
    try { rewritten = fatbin::rewrite_sm89_to_sm86(image); }
    catch (...) {
        // Container allocation/inspection is our work. Do not propagate a C++
        // exception through the driver's C ABI or invoke the CUDA loader twice.
        logf("[normal] CUDA fatbin #%ld inspection exception; forwarding original image once.\n",id);
        const int rc=record_cuda("cuModuleLoadData (inspection unavailable)",g_real_cu_load(module_out,image),false,true);
        if(!rc)++g_cuda_successes;return rc;
    }
    if (!rewritten.valid || rewritten.stats.sm89_to_sm86 == 0) {
        if (config().diagnostics)
            logf("[nvs30] CUDA fatbin #%ld left unmodified: valid=%d entries=%u sm89=%u sm120=%u.\n",
                 id, rewritten.valid ? 1 : 0, rewritten.stats.entries,
                 rewritten.stats.sm89_to_sm86, rewritten.stats.sm120_left);
        int rc=g_real_cu_load(module_out,image);record_cuda("cuModuleLoadData",rc,false,true);if(!rc)++g_cuda_successes;return rc;
    }
    const int rc = g_real_cu_load(module_out, rewritten.bytes.data());
    record_cuda("cuModuleLoadData",rc,false,true);if(!rc)++g_cuda_successes;
    logf("[nvs30] CUDA fatbin #%ld: bytes=%zu entries=%u cubins=%u sm89->86=%u sm120-left=%u elf=%u rc=%d\n",
         id, rewritten.bytes.size(), rewritten.stats.entries, rewritten.stats.cubins,
         rewritten.stats.sm89_to_sm86, rewritten.stats.sm120_left,
         rewritten.stats.elf_headers, rc);
    return rc;
}

FARPROC WINAPI hooked_get_proc_address(HMODULE module, LPCSTR name) {
    auto result=g_real_getproc(module,name);
    if (result==reinterpret_cast<FARPROC>(g_real_cu_load)&&reinterpret_cast<std::uintptr_t>(name) > 0xffff && name &&
        std::strcmp(name, "cuModuleLoadData") == 0)
        return reinterpret_cast<FARPROC>(&hooked_cu_module_load_data);
    return result;
}

bool install_cuda_hook(const GateMatch&, const std::byte*) {
    auto cuda=GetModuleHandleW(L"nvcuda.dll");if(!cuda)cuda=LoadLibraryExW(L"nvcuda.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(!cuda)return false;
    error_name=reinterpret_cast<ErrorText>(GetProcAddress(cuda,"cuGetErrorName"));
    error_text=reinterpret_cast<ErrorText>(GetProcAddress(cuda,"cuGetErrorString"));
    g_context_device=reinterpret_cast<ContextDevice>(GetProcAddress(cuda,"cuCtxGetDevice"));
    g_device_attribute=reinterpret_cast<DeviceAttribute>(GetProcAddress(cuda,"cuDeviceGetAttribute"));
    if(!g_context_device||!g_device_attribute)return false;
    using Init=int (WINAPI*)(unsigned);using Count=int (WINAPI*)(int*);
    auto init=reinterpret_cast<Init>(GetProcAddress(cuda,"cuInit"));auto count=reinterpret_cast<Count>(GetProcAddress(cuda,"cuDeviceGetCount"));
    int devices=0;bool eligible=false;
    if(!init||!count||init(0)!=0||count(&devices)!=0)return false;
    for(int device=0;device<devices;++device){int major=0,minor=0;
        if(g_device_attribute(&major,75,device)||g_device_attribute(&minor,76,device))continue;
        logf("[normal] CUDA device %d compute capability %d.%d.\n",device,major,minor);
        eligible|=(major==8&&(minor==6||minor==9))||(major==12&&minor==0);
        g_sm86_present|=major==8&&minor==6;
    }
    if(!eligible){logf("[normal] No compatible CUDA target for the recognized payload.\n");return false;}
    // First try the exact path used by the reviewed upstream build: locate the
    // named cuModuleLoadData thunk in NvPresent's normal import table and patch
    // that slot directly.
    if (auto** direct = pe::find_import_slot(g_nvp, "nvcuda.dll", "cuModuleLoadData")) {
        g_real_cu_load = reinterpret_cast<CuModuleLoadData>(*direct);
        if (!g_real_cu_load ||
            !g_pointer_patches.install(direct, reinterpret_cast<void*>(&hooked_cu_module_load_data),write_cuda_pointer))
            return false;
        logf("[nvs30] cuModuleLoadData IAT found dynamically: +0x%zx; direct hook installed.\n",
             module_offset(direct));
        return true;
    }

    // Newer/previously-initialized NvPresent builds can have the CUDA entry
    // point resolved before we arrive, leaving no name-addressable thunk for a
    // normal PE import lookup. Resolve the real driver entry point ourselves
    // and search NvPresent's non-executable image data for slots that already contain
    // that exact function pointer. This catches both a bound IAT and driver
    // dispatch globals while staying away from executable code.

    if (cuda)
        g_real_cu_load = reinterpret_cast<CuModuleLoadData>(
            GetProcAddress(cuda, "cuModuleLoadData"));

    if (g_real_cu_load) {
        if (auto** delay = pe::find_delay_import_slot(g_nvp, "nvcuda.dll", "cuModuleLoadData")) {
            if (!g_pointer_patches.install(delay, reinterpret_cast<void*>(&hooked_cu_module_load_data),write_cuda_pointer))
                return false;
            logf("[nvs30] cuModuleLoadData delay-IAT found dynamically: +0x%zx; direct hook installed.\n",
                 module_offset(delay));
            return true;
        }

        if (auto** slot = pe::find_iat_value(g_nvp, reinterpret_cast<void*>(g_real_cu_load))) {
            if (!g_pointer_patches.install(slot, reinterpret_cast<void*>(&hooked_cu_module_load_data),write_cuda_pointer))
                return false;
            logf("[nvs30] cuModuleLoadData IAT found by resolved value: +0x%zx; direct hook installed.\n",
                 module_offset(slot));
            return true;
        }

        auto slots = pe::find_data_pointer_slots(
            g_nvp, reinterpret_cast<void*>(g_real_cu_load));
        if (!slots.empty()) {
            std::size_t patched = 0;
            for (auto** slot : slots) {
                // Limit the fallback to a small number of exact resolved-value
                // slots. Multiple driver dispatch aliases are safe to redirect
                // because they all originally call the same CUDA entry point.
                if (patched >= 16) break;
                if (!g_pointer_patches.install(slot, reinterpret_cast<void*>(&hooked_cu_module_load_data),write_cuda_pointer))
                    continue;
                logf("[nvs30] cuModuleLoadData resolved pointer slot hooked: +0x%zx.\n",
                     module_offset(slot));
                ++patched;
            }
            if (patched) {
                logf("[nvs30] direct CUDA interception installed through %zu resolved NvPresent slot(s).\n",
                     patched);
                return true;
            }
        }
    }

    // Last resort only. This works when NvPresent resolves CUDA after our hook
    // is installed, but cannot repair a function pointer that was cached before
    // NVSmooth30 loaded; the resolved-pointer scan above exists for that case.
    if (!g_real_cu_load) return false;
    g_real_getproc = &GetProcAddress;
    g_getproc_slot = pe::find_import_slot(g_nvp, "KERNEL32.dll", "GetProcAddress");
    if (!g_getproc_slot)
        g_getproc_slot = pe::find_iat_value(g_nvp, reinterpret_cast<void*>(GetProcAddress));
    if (!g_getproc_slot ||
        !g_pointer_patches.install(g_getproc_slot, reinterpret_cast<void*>(&hooked_get_proc_address),write_cuda_pointer))
        return false;
    logf("[nvs30] adaptive CUDA hook installed through NvPresent64 GetProcAddress IAT (last resort).\n");
    return true;
}

void restore_all() {
    g_profile_applied=false;
    for (auto& patch : g_config_patches) patch.restore();
    for(auto it=g_profile_patches.rbegin();it!=g_profile_patches.rend();++it)it->restore();
    g_capability_patch.restore();
    g_arch_patch.restore();
    if(!g_pointer_patches.restore(write_cuda_pointer))
        logf("[normal] CUDA pointer rollback incomplete; original-pointer records and callbacks retained.\n");
}


}

static bool initialize_impl(bool& driver_entered) {
    if (g_initialized.load()) return true;
    if(!claim_backend())return false;
    if(competing_backend())return fail("competing_smooth_motion_provider");
    g_state="locating_driver";
    if(GetModuleHandleW(L"NvPresent64.dll")){
        logf("[normal] NvPresent was loaded before this backend. Existing driver hooks left untouched; restart with a single loader.\n");return fail("driver_already_loaded");
    }
    const std::wstring path = locate_nvpresent();
    if(path.empty())return false; // Selection already recorded the precise reason.
    g_state="validating_driver";
    driver_file::File file;
    const bool accepted=file.inspect(path);
    logf("[normal] NvPresent candidate: %ls\n",path.c_str());
    logf("[normal] NvPresent SHA256=%s code_SHA256=%s validation=%s Win32=%lu.\n",
        file.digest.c_str(),file.codeDigest.c_str(),file.error,file.win32Error);
    if(!accepted){
        logf("[normal] Installed driver bytes are outside the reviewed profiles, or inspection failed. Keep this SHA256 and validation reason in the diagnostic report; do not mix driver-package DLLs.\n");
        return fail("driver_validation_rejected");
    }
    g_state="loading_driver";
    g_nvp = LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(!g_nvp){logf("[normal] LoadLibraryExW(NvPresent) failed Win32=%lu.\n",GetLastError());return fail("driver_load_failed");}
    if(!pe::valid_image(g_nvp))return fail("loaded_driver_invalid");
    logf("[nvs30] Loaded NvPresent64: %ls\n", path.c_str());
    log_nvp_exports();

    auto* init = reinterpret_cast<NvpInitD3D>(GetProcAddress(g_nvp, "NVP_Init_D3D"));
    if (!init) {
        logf("[nvs30] NVP_Init_D3D export not found; no NvPresent patches retained.\n");
        return fail("initialization_export_missing");
    }
    g_state="validating_patch_sites";
    const auto gate = find_gate(init);
    auto* cfg = init ? find_config(init) : nullptr;
    const bool referenceSites=gate && cfg && driver_profile::runtime_sites_match(file.verdict.profile,
        module_offset(reinterpret_cast<const void*>(init)),module_offset(cfg),
        module_offset(gate->immediate),module_offset(gate->setge),gate->setge_size);
    if (!gate || !cfg || (module_offset(cfg)!=0x7d7810&&module_offset(cfg)!=0x7f0cd0) ||
        (file.verdict.reference && !referenceSites)) {
        logf("[nvs30] gate/config validation failed; no NvPresent patches retained.\n");
        return fail("patch_site_mismatch");
    }
    logf("[nvs30] Config structure resolved dynamically: +0x%zx.\n", module_offset(cfg));
    g_state="installing_cuda_hooks";
    if (!install_cuda_hook(*gate, cfg)) {
        logf("[nvs30] no CUDA interception path available; rolling back NvPresent patches.\n");
        restore_all();
        return fail("cuda_interception_unavailable");
    }

    observe_execution();

    // The exact profile adapts its model in place before any initialization.
    // It intentionally does not force the capability result or rewrite FP8.
    g_state="patching_driver";
    const bool exactProfile=file.verdict.profile!=driver_profile::Kind::none;
    if(exactProfile){
        if(g_sm86_present&&!install_model_profile(file)){restore_all();return fail("model_profile_patch_failed");}
    }else{
        const std::byte arch{2};
        g_arch_patch.address = gate->immediate;
        if (!g_arch_patch.apply(&arch, 1)) { restore_all(); return fail("arch_patch_failed"); }
        g_capability_patch.address = gate->setge;
        if (!g_capability_patch.apply(gate->force_true.data(), gate->setge_size)) {
            restore_all(); return fail("capability_or_config_patch_failed");
        }
    }

    const std::byte one{1};
    logf("[nvs30] Config before init: 4c=%u e8=%u e9=%u 12a5=%u\n",
         std::to_integer<unsigned>(cfg[0x4c]), std::to_integer<unsigned>(cfg[0xe8]),
         std::to_integer<unsigned>(cfg[0xe9]), std::to_integer<unsigned>(cfg[0x12a5]));
    if(exactProfile){
        // Independently implemented from the profile's observed runtime ABI:
        // DWORD +6c=1, DWORD +48=0, BYTE +e9=1, then NVP_Init_D3D.
        const std::uint32_t enabled=1,zero=0;
        g_config_patches[0].address=cfg+0x6c;
        g_config_patches[1].address=cfg+0x48;
        g_config_patches[2].address=cfg+0xe9;
        if(!g_config_patches[0].apply(&enabled,sizeof enabled)||
           !g_config_patches[1].apply(&zero,sizeof zero)||
           !g_config_patches[2].apply(&one,1)){restore_all();return fail("profile_configuration_failed");}
        logf("[normal] Profile configuration: DWORD+6c=1 DWORD+48=0 BYTE+e9=1; +4c and +e8 retained.\n");
    }else{
        g_config_patches[0].address = cfg + 0x4c;
        g_config_patches[1].address = cfg + 0xe9;
        if (!g_config_patches[0].apply(&one, 1) || !g_config_patches[1].apply(&one, 1)) {
            restore_all(); return fail("capability_or_config_patch_failed");
        }
    }
    logf("[normal] NvPresent preparation complete: profile=%s CUDA interception=active.\n",exactProfile?"exact non-FP8":"legacy upstream");
    g_state="initializing_driver";
    driver_entered=true;
    bool initResult=false;
    const auto initStarted=GetTickCount64();
    logf("[normal] Entering NVP_Init_D3D: thread=%lu entry=%p config-ready=%u DX11-allowed=%u DX12-allowed=%u optional-setup=%u.\n",
        GetCurrentThreadId(),reinterpret_cast<void*>(init),std::to_integer<unsigned>(cfg[0]),
        std::to_integer<unsigned>(cfg[0x4f]),std::to_integer<unsigned>(cfg[0x50]),std::to_integer<unsigned>(cfg[0x7a]));
    {
        init_trace::Scope trace(g_nvp,pe::image_size(g_nvp));
        logf("[normal] Passive init exception tracing armed=%u; file=nvsmooth30-init-exception.log.\n",trace.active()?1u:0u);
        initResult=init();
    }
    logf("[normal] NVP_Init_D3D returned AL=%u; profile config-ready=%u; elapsed_ms=%llu.\n",initResult?1u:0u,std::to_integer<unsigned>(cfg[0]),GetTickCount64()-initStarted);
    if (!exactProfile&&!initResult) {
        logf("[nvs30] NVP_Init_D3D returned FALSE; rolling back.\n");
        restore_all();
        return fail("driver_initialization_failed");
    }
    if(exactProfile){
        if(cfg[0]==std::byte{0})return fail("profile_initialization_not_ready");
        logf("[normal] Exact profile initialization completed; config-ready=1. No post-init configuration overwrite.\n");
    }else if(!pe::write_memory(cfg + 0x4c, &one, 1)||!pe::write_memory(cfg + 0xe9, &one, 1)){
        logf("[normal] Post-init configuration failed.\n");return fail("post_init_configuration_failed");
    }
    logf("[nvs30] Config after init: 4c=%u e8=%u e9=%u 12a5=%u\n",
         std::to_integer<unsigned>(cfg[0x4c]), std::to_integer<unsigned>(cfg[0xe8]),
         std::to_integer<unsigned>(cfg[0xe9]), std::to_integer<unsigned>(cfg[0x12a5]));
    logf("[normal] NvPresent initialization readiness accepted.\n");
    g_state="driver_initialized_output_unverified";
    g_initialized = true;
    return true;
}

bool initialize() {
    bool driver_entered=false;
    try { return initialize_impl(driver_entered); }
    catch (...) {
        // Before NVP_Init_D3D there can only be our recorded edits. Afterwards
        // the driver may own hooks/work; keep its module and callbacks resident.
        if(!driver_entered)restore_all();
        return fail(driver_entered?"driver_initialization_exception":"backend_setup_exception");
    }
}

void shutdown() { restore_all(); g_initialized = false; }
HMODULE module() { return g_nvp; }
bool contains_address(const void* address) { return pe::address_in_image(g_nvp, address); }
bool wrapper_active(IDXGISwapChain* swapchain, void** wrapper, std::size_t* offset) {
    if(wrapper)*wrapper=nullptr;if(offset)*offset=0;if(!swapchain||!g_nvp)return false;
    // Inspect only documented COM vtable slots. Never scan private object
    // fields or invoke guessed private toggles (old slots 19/20).
    auto** table=*reinterpret_cast<void***>(swapchain);
    bool found=contains_address(table[8]);
    ComPtr<IDXGISwapChain1> s1;if(SUCCEEDED(swapchain->QueryInterface(IID_PPV_ARGS(&s1)))){
        auto** t=*reinterpret_cast<void***>(s1.Get());found=found||contains_address(t[22]);}
    if(found&&wrapper)*wrapper=swapchain;return found;
}
bool wrapper_active(IDXGISwapChain* swapchain,void** wrapper){return wrapper_active(swapchain,wrapper,nullptr);}
std::uint64_t cuda_activity_count(){return g_execution_submissions.load();}
std::uint64_t cuda_success_count(){return g_cuda_successes.load();}
std::uint64_t cuda_failure_count(){return g_cuda_failures.total();}
std::uint64_t cuda_module_failure_count(){return g_cuda_failures.modules();}
std::uint64_t cuda_execution_failure_count(){return g_cuda_failures.execution();}
std::uint64_t cuda_intercept_count() { return g_cuda_intercepts.load(); }
const char* initialization_status(){return g_state.load();}
bool initialized() { return g_initialized.load(); }
}
