#include "nvs30/dxgi_hooks.hpp"
#include "nvs30/module_watch.hpp"
namespace nvs30::dxgi {void startup();}
extern "C" unsigned WINAPI SmoothMotionGetStatus(char*,unsigned);
#include "nvs30/log.hpp"
namespace {
std::atomic_bool started{false};
void CALLBACK moduleNotification(ULONG reason,const void*,void* context) noexcept {
    if(reason==1||reason==2)
        static_cast<std::atomic<std::uint64_t>*>(context)->fetch_add(1,std::memory_order_relaxed);
}
struct Notifications {
    using Callback=void(CALLBACK*)(ULONG,const void*,void*);
    using Register=LONG(NTAPI*)(ULONG,Callback,void*,void**);
    using Unregister=LONG(NTAPI*)(void*);
    Unregister remove=nullptr;void* cookie=nullptr;
    Notifications(){
        const auto ntdll=GetModuleHandleW(L"ntdll.dll");if(!ntdll)return;
        const auto add=reinterpret_cast<Register>(GetProcAddress(ntdll,"LdrRegisterDllNotification"));
        remove=reinterpret_cast<Unregister>(GetProcAddress(ntdll,"LdrUnregisterDllNotification"));
        void* candidate=nullptr;
        if(add&&remove&&add(0,&moduleNotification,&nvs30::module_watch::generation,&candidate)==0&&candidate){
            cookie=candidate;nvs30::module_watch::registered=true;
        }
    }
    ~Notifications(){if(cookie&&remove)remove(cookie);nvs30::module_watch::registered=false;}
};
DWORD WINAPI worker(void*){
 try{
    Notifications notifications;
    nvs30::dxgi::startup();
#ifdef NVS30_STANDALONE
    nvs30::dxgi::service_startup(true);
#endif
    nvs30::logf("[normal] Late renderer discovery: DLL notifications=%s; worker remains active for this process.\n",
        nvs30::module_watch::registered?"available":"unavailable (periodic fallback)");
    nvs30::module_watch::Schedule schedule;
    const auto startedAt=GetTickCount64();auto lastStatus=startedAt;unsigned nextStatus=0;
    constexpr ULONGLONG statusTimes[]={5000,15000,30000};
    for(;;){
        nvs30::dxgi::service_startup(false);
        const auto now=GetTickCount64();
        const auto before=nvs30::module_watch::generation.load(std::memory_order_relaxed);
        if(schedule.due(now,before,nvs30::module_watch::registered.load())){
            if(nvs30::dxgi::install_hooks())schedule.scanned(now,before);
        }
        if((nextStatus<3&&now-startedAt>=statusTimes[nextStatus])||
           (nextStatus>=3&&now-lastStatus>=60000)){
            if(nextStatus<3)++nextStatus;lastStatus=now;
            char status[8192]{};SmoothMotionGetStatus(status,sizeof status);
            nvs30::logf("[normal] runtime status: %s\n",status);
        }
        Sleep(500);
    }
 }catch(...){nvs30::logf("[normal] startup worker exception.\n");}
 return 0;
}
void start(){
 bool expected=false;if(!started.compare_exchange_strong(expected,true))return;
 // Background entry points must already be resident when CreateThread returns.
 // No scan or logging is done here; this path can run under DllMain.
 HMODULE pinned{};
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
      reinterpret_cast<LPCWSTR>(&worker),&pinned)){started=false;return;}
 HANDLE t=CreateThread(nullptr,0,worker,nullptr,0,nullptr);
 if(t)CloseHandle(t);else started=false;
}
#include "nvs30/asi_entry.hpp"
}
extern "C" __declspec(dllexport) void InitializeASI(){initializeAsiEntry();}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(instance);start();}return TRUE;}
