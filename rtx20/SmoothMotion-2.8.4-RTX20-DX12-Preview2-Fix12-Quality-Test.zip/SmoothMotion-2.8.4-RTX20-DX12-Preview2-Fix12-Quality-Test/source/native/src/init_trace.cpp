#include "nvs30/init_trace.hpp"

#if defined(NVS30_INIT_TRACE_TEST)
#include "../trace_windows_test.hpp"
#else
#include <windows.h>
#endif
#include <atomic>
#include <memory>
#include <new>

namespace nvs30::init_trace {
namespace {
static_assert(std::atomic<bool>::is_always_lock_free);

// All objects touched by the VEH have trivial process lifetime. The module and
// file handle are deliberately retained, so scope-end cannot race with a
// callback that already observed armed=true. Only one scope may ever arm.
std::atomic<bool> g_attempted{false};
std::atomic<bool> g_armed{false};
std::atomic_flag g_writing = ATOMIC_FLAG_INIT;
HANDLE g_file = INVALID_HANDLE_VALUE;
std::uint64_t g_base{}, g_size{};
DWORD g_process{}, g_init_thread{};
unsigned g_records{}; // Only read/written while g_writing is held.
char g_line[1024];
detail::Fault g_fault;

LONG CALLBACK observe(PEXCEPTION_POINTERS pointers) noexcept {
    if (!g_armed.load(std::memory_order_acquire) || !pointers ||
        !pointers->ExceptionRecord || !pointers->ContextRecord ||
        !detail::accepted(pointers->ExceptionRecord->ExceptionCode))
        return EXCEPTION_CONTINUE_SEARCH;
    if (g_writing.test_and_set(std::memory_order_acquire))
        return EXCEPTION_CONTINUE_SEARCH;

    // No waits on another reporting thread, and no recursively entered writer.
    // Limit repeated handled exceptions to keep this narrowly diagnostic.
    if (g_armed.load(std::memory_order_acquire) && g_records < 16) {
        ++g_records;
        const DWORD savedError = GetLastError();
        const auto* record = pointers->ExceptionRecord;
        const auto* context = pointers->ContextRecord;
        g_fault.code = record->ExceptionCode;
        g_fault.process = g_process;
        g_fault.thread = GetCurrentThreadId();
        g_fault.initThread = g_init_thread;
        g_fault.parameterCount = record->NumberParameters;
        g_fault.address = reinterpret_cast<std::uintptr_t>(record->ExceptionAddress);
        g_fault.moduleBase = g_base;
        g_fault.moduleBytes = g_size;
#if defined(_WIN64)
        g_fault.rip = context->Rip;
        g_fault.rsp = context->Rsp;
        g_fault.rax = context->Rax;
        g_fault.rcx = context->Rcx;
        g_fault.rdx = context->Rdx;
        g_fault.r8 = context->R8;
        g_fault.r9 = context->R9;
#else
        g_fault.rip = context->Eip;
        g_fault.rsp = context->Esp;
        g_fault.rax = context->Eax;
        g_fault.rcx = context->Ecx;
        g_fault.rdx = context->Edx;
        g_fault.r8 = 0;
        g_fault.r9 = 0;
#endif
        g_fault.access = record->NumberParameters >= 1 ? record->ExceptionInformation[0] : 0;
        g_fault.target = record->NumberParameters >= 2 ? record->ExceptionInformation[1] : 0;
        g_fault.inPageStatus = record->NumberParameters >= 3 ? record->ExceptionInformation[2] : 0;
        const auto bytes = detail::format(g_line, sizeof(g_line), g_fault);
        DWORD written{};
        // File path, handle, handler registration and module bounds were all
        // prepared before arming. Never symbolize, unwind, allocate, logf, call
        // the loader or acquire a CRT mutex here, especially on stack overflow.
        WriteFile(g_file, g_line, static_cast<DWORD>(bytes), &written, nullptr);
        SetLastError(savedError);
    }
    g_writing.clear(std::memory_order_release);
    return EXCEPTION_CONTINUE_SEARCH;
}

bool prepare(const void* module, std::size_t imageBytes) noexcept {
    if (!module || !imageBytes) return false;
    std::unique_ptr<wchar_t[]> path(new (std::nothrow) wchar_t[32768]);
    if (!path) return false;
    const DWORD count = GetModuleFileNameW(nullptr, path.get(), 32768);
    if (!count || count >= 32768) return false;
    std::size_t prefix = count;
    while (prefix && path[prefix - 1] != L'\\' && path[prefix - 1] != L'/') --prefix;
    if (!prefix) return false;
    constexpr wchar_t name[] = L"nvsmooth30-init-exception.log";
    if (prefix + sizeof(name) / sizeof(name[0]) > 32768) return false;
    for (std::size_t i = 0; i < sizeof(name) / sizeof(name[0]); ++i) path[prefix + i] = name[i];
    const HANDLE file = CreateFileW(path.get(), FILE_APPEND_DATA,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
        OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;

    HMODULE self{};
    // Registration survives DLL unloading. Pin before publishing our callback;
    // retaining a pin is safer than removing a handler racing another thread.
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
            reinterpret_cast<LPCWSTR>(&observe), &self)) {
        CloseHandle(file);
        return false;
    }
    g_file = file;
    g_base = reinterpret_cast<std::uintptr_t>(module);
    g_size = imageBytes;
    g_process = GetCurrentProcessId();
    g_init_thread = GetCurrentThreadId();
    // Register first so other VEH consumers cannot hide a useful INT3/AV.
    // Returning SEARCH preserves the exception dispatch and original context.
    if (!AddVectoredExceptionHandler(1, &observe)) {
        g_file = INVALID_HANDLE_VALUE;
        CloseHandle(file);
        return false;
    }
    return true;
}

void boundary(detail::Boundary event) noexcept {
    // Scope-end may race a handler that already entered: never wait or reuse its
    // output storage. An end record is consequently best-effort as well.
    if (g_writing.test_and_set(std::memory_order_acquire)) return;
    const auto bytes = detail::format_boundary(g_line, sizeof(g_line), event,
        g_process, g_init_thread, g_base, g_size);
    DWORD written{};
    WriteFile(g_file, g_line, static_cast<DWORD>(bytes), &written, nullptr);
    g_writing.clear(std::memory_order_release);
}
}

Scope::Scope(const void* nvPresent, std::size_t imageBytes) noexcept {
    const DWORD savedError = GetLastError();
    bool expected = false;
    if (g_attempted.compare_exchange_strong(expected, true, std::memory_order_acq_rel) &&
        prepare(nvPresent, imageBytes)) {
        active_ = true;
        boundary(detail::Boundary::Begin);
        g_armed.store(true, std::memory_order_release);
    }
    SetLastError(savedError);
}

Scope::~Scope() noexcept {
    if (active_) {
        const DWORD savedError = GetLastError();
        g_armed.store(false, std::memory_order_release);
        boundary(detail::Boundary::End);
        SetLastError(savedError);
    }
}
}
