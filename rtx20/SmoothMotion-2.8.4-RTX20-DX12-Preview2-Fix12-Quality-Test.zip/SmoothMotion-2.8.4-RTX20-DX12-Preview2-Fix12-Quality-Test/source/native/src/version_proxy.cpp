// Standalone entry carrier for the same backend compiled into normal.asi.
// Only Windows version APIs are forwarded here; no graphics or ASI loader work.
#ifdef NVS_VERSION_PROXY_TEST
#include "../proxy_windows_test.hpp"
#else
#include <windows.h>
#include <winver.h>
#endif
#include <atomic>
#include <cstring>
#include <type_traits>

extern "C" IMAGE_DOS_HEADER __ImageBase;
namespace {
std::atomic<HMODULE> real_version{nullptr};
thread_local bool resolving_version=false;
static_assert(std::atomic<HMODULE>::is_always_lock_free);

HMODULE system_version() noexcept {
    if(const auto module=real_version.load(std::memory_order_acquire))return module;
    wchar_t path[MAX_PATH]{};
    constexpr wchar_t suffix[]=L"\\version.dll";
    const UINT length=GetSystemDirectoryW(path,MAX_PATH);
    if(!length)return nullptr;
    if(length>MAX_PATH-sizeof(suffix)/sizeof(*suffix)){
        SetLastError(ERROR_INSUFFICIENT_BUFFER);return nullptr;
    }
    std::memcpy(path+length,suffix,sizeof(suffix));
    const auto candidate=LoadLibraryExW(path,nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(!candidate)return nullptr;
    if(candidate==reinterpret_cast<HMODULE>(&__ImageBase)){
        FreeLibrary(candidate);SetLastError(ERROR_BAD_EXE_FORMAT);return nullptr;
    }
    // Do not hold a private initialization lock across the OS loader. Concurrent
    // successful loads own separate references; keep exactly one permanently.
    HMODULE previous=nullptr;
    if(real_version.compare_exchange_strong(previous,candidate,std::memory_order_release,std::memory_order_acquire))return candidate;
    FreeLibrary(candidate);return previous;
}

template<class Fn>
Fn resolve(std::atomic<Fn>& cache,const char* name) noexcept {
    if(const auto fn=cache.load(std::memory_order_acquire))return fn;
    if(resolving_version){SetLastError(ERROR_POSSIBLE_DEADLOCK);return nullptr;}
    struct Guard {Guard(){resolving_version=true;}~Guard(){resolving_version=false;}} guard;
    const auto module=system_version();if(!module)return nullptr;
    const auto fn=reinterpret_cast<Fn>(GetProcAddress(module,name));
    if(!fn){SetLastError(ERROR_PROC_NOT_FOUND);return nullptr;}
    cache.store(fn,std::memory_order_release);return fn;
}
}

#define NVS_PROXY(ret, exported, target, params, args, fallback) \
extern "C" ret WINAPI exported params { \
    using Fn=ret(WINAPI*)params; \
    static_assert(std::is_same_v<Fn,decltype(&::target)>,"version API signature mismatch"); \
    static std::atomic<Fn> cache{nullptr}; \
    const auto incoming=GetLastError(); \
    const auto fn=resolve(cache,#target); \
    if(!fn)return fallback; \
    SetLastError(incoming); \
    return fn args; \
}

// GetFileVersionInfoByHandle is documented but missing from some MinGW SDKs.
// Microsoft: https://learn.microsoft.com/windows/win32/menurc/getfileversioninfobyhandle
extern "C" BOOL WINAPI GetFileVersionInfoByHandle(DWORD,HANDLE,LPVOID*,PDWORD);
NVS_PROXY(BOOL,nvs_GetFileVersionInfoA,GetFileVersionInfoA,
          (LPCSTR a,DWORD b,DWORD c,LPVOID d),(a,b,c,d),FALSE)
NVS_PROXY(BOOL,nvs_GetFileVersionInfoW,GetFileVersionInfoW,
          (LPCWSTR a,DWORD b,DWORD c,LPVOID d),(a,b,c,d),FALSE)
NVS_PROXY(BOOL,nvs_GetFileVersionInfoExA,GetFileVersionInfoExA,
          (DWORD a,LPCSTR b,DWORD c,DWORD d,LPVOID e),(a,b,c,d,e),FALSE)
NVS_PROXY(BOOL,nvs_GetFileVersionInfoExW,GetFileVersionInfoExW,
          (DWORD a,LPCWSTR b,DWORD c,DWORD d,LPVOID e),(a,b,c,d,e),FALSE)
NVS_PROXY(DWORD,nvs_GetFileVersionInfoSizeA,GetFileVersionInfoSizeA,
          (LPCSTR a,LPDWORD b),(a,b),0)
NVS_PROXY(DWORD,nvs_GetFileVersionInfoSizeW,GetFileVersionInfoSizeW,
          (LPCWSTR a,LPDWORD b),(a,b),0)
NVS_PROXY(DWORD,nvs_GetFileVersionInfoSizeExA,GetFileVersionInfoSizeExA,
          (DWORD a,LPCSTR b,LPDWORD c),(a,b,c),0)
NVS_PROXY(DWORD,nvs_GetFileVersionInfoSizeExW,GetFileVersionInfoSizeExW,
          (DWORD a,LPCWSTR b,LPDWORD c),(a,b,c),0)
NVS_PROXY(BOOL,nvs_GetFileVersionInfoByHandle,GetFileVersionInfoByHandle,
          (DWORD a,HANDLE b,LPVOID* c,PDWORD d),(a,b,c,d),FALSE)
// The bundled MinGW SDK uses mutable pointers for these historical APIs;
// matching them here preserves the exact SDK function type and Windows ABI.
NVS_PROXY(DWORD,nvs_VerFindFileA,VerFindFileA,
          (DWORD a,LPSTR b,LPSTR c,LPSTR d,LPSTR e,PUINT f,LPSTR g,PUINT h),
          (a,b,c,d,e,f,g,h),VFF_BUFFTOOSMALL)
NVS_PROXY(DWORD,nvs_VerFindFileW,VerFindFileW,
          (DWORD a,LPWSTR b,LPWSTR c,LPWSTR d,LPWSTR e,PUINT f,LPWSTR g,PUINT h),
          (a,b,c,d,e,f,g,h),VFF_BUFFTOOSMALL)
NVS_PROXY(DWORD,nvs_VerInstallFileA,VerInstallFileA,
          (DWORD a,LPSTR b,LPSTR c,LPSTR d,LPSTR e,LPSTR f,LPSTR g,PUINT h),
          (a,b,c,d,e,f,g,h),VIF_CANNOTREADSRC)
NVS_PROXY(DWORD,nvs_VerInstallFileW,VerInstallFileW,
          (DWORD a,LPWSTR b,LPWSTR c,LPWSTR d,LPWSTR e,LPWSTR f,LPWSTR g,PUINT h),
          (a,b,c,d,e,f,g,h),VIF_CANNOTREADSRC)
NVS_PROXY(DWORD,nvs_VerLanguageNameA,VerLanguageNameA,
          (DWORD a,LPSTR b,DWORD c),(a,b,c),0)
NVS_PROXY(DWORD,nvs_VerLanguageNameW,VerLanguageNameW,
          (DWORD a,LPWSTR b,DWORD c),(a,b,c),0)
NVS_PROXY(BOOL,nvs_VerQueryValueA,VerQueryValueA,
          (LPCVOID a,LPCSTR b,LPVOID* c,PUINT d),(a,b,c,d),FALSE)
NVS_PROXY(BOOL,nvs_VerQueryValueW,VerQueryValueW,
          (LPCVOID a,LPCWSTR b,LPVOID* c,PUINT d),(a,b,c,d),FALSE)
#undef NVS_PROXY
