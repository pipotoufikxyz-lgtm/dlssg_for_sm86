#include "include/nvs30/graphics_initialization.hpp"
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <thread>

namespace {
std::atomic_uint checks{0};
void check(bool ok){++checks;if(!ok)std::abort();}
void wait(const std::atomic_bool& flag){while(!flag.load(std::memory_order_acquire))std::this_thread::yield();}
}

int main(){
 using nvs30::GraphicsInitialization;
 using nvs30::InitializationGate;
 // Deterministic reproduction of 2.8.2's two-gate startup ordering: UAL has
 // installed hooks; the worker owns configuration; the game creates its only
 // device while configuration is Running. Its real API still runs, but native
 // initialization is never attempted even after the worker finishes.
 {
  InitializationGate configuration,runtime;
  std::atomic_bool configuring=false,release=false;
  unsigned creates=0,initializations=0;
  std::thread worker([&]{configuration.run([&]{configuring=true;wait(release);return true;});});
  wait(configuring);
  const bool configured=configuration.run([]{return true;});
  if(configured)runtime.run([&]{++initializations;return true;});
  ++creates;
  check(!configured&&creates==1&&initializations==0);
  release=true;worker.join();
  check(creates==1&&initializations==0);
 }
 // New wiring: background discovery can be inside logging while the sole
 // graphics caller configures AND initializes. Both callbacks run on that
 // caller before the one real API call. A second graphics call is not needed.
 for(unsigned iteration=0;iteration<100;++iteration){
  GraphicsInitialization runtime;InitializationGate logging;
  std::atomic_bool loggingStarted=false,release=false;
  unsigned configurations=0,initializations=0,creates=0,configurationValue=0;
  const auto graphicsThread=std::this_thread::get_id();
  std::thread worker([&]{logging.run([&]{loggingStarted=true;wait(release);return true;});});
  wait(loggingStarted);
  const bool ready=runtime.run([&]{
   check(std::this_thread::get_id()==graphicsThread);
   ++configurations;configurationValue=0x3086;
   check(!logging.run([]{return false;}));
   return true;
  },[&]{
   check(std::this_thread::get_id()==graphicsThread&&configurationValue==0x3086);
   ++initializations;return true;
  });
  check(ready&&configurations==1&&initializations==1&&creates==0);
  ++creates;check(creates==1);
  release=true;worker.join();
  check(runtime.run([&]{++configurations;return false;},[&]{++initializations;return false;}));
  check(configurations==1&&initializations==1&&creates==1);
 }
 // Reentry from configuration or native initialization must never wait or
 // duplicate work, and a ready result must publish configuration to readers.
 {
  GraphicsInitialization runtime;unsigned configurations=0,initializations=0;
  auto unexpected=[&]{check(false);return true;};
  check(runtime.run([&]{++configurations;check(!runtime.run(unexpected,unexpected));return true;},
                    [&]{++initializations;check(!runtime.run(unexpected,unexpected));return true;}));
  check(configurations==1&&initializations==1);
 }
 {
  GraphicsInitialization runtime;std::atomic_bool preparing=false,release=false;
  unsigned value=0;std::atomic_uint configurations=0,initializations=0;
  std::thread graphics([&]{
   check(runtime.run([&]{++configurations;preparing=true;wait(release);value=0x3086;return true;},
                     [&]{++initializations;check(value==0x3086);return true;}));
  });
  wait(preparing);
  check(!runtime.run([&]{++configurations;return true;},[&]{++initializations;return true;}));
  release=true;graphics.join();
  check(runtime.run([]{return false;},[]{return false;}));
  check(value==0x3086&&configurations==1&&initializations==1);
 }
 // Configuration failure prevents driver entry; driver rejection remains
 // terminal. Exceptions before publication remain retryable through the
 // original gate contract, rather than caching partial configuration as ready.
 {
  GraphicsInitialization runtime;unsigned calls=0;
  check(!runtime.run([]{return false;},[&]{++calls;return true;}));
  check(!runtime.run([]{return true;},[&]{++calls;return true;}));check(calls==0);
 }
 {
  GraphicsInitialization runtime;unsigned calls=0;
  check(!runtime.run([]{return true;},[&]{++calls;return false;}));
  check(!runtime.run([]{return true;},[&]{++calls;return true;}));check(calls==1);
 }
 {
  GraphicsInitialization runtime;unsigned calls=0;bool caught=false;
  try{runtime.run([]()->bool{throw std::runtime_error("configuration allocation");},[&]{++calls;return true;});}
  catch(const std::runtime_error&){caught=true;}
  check(caught&&calls==0);
  check(runtime.run([]{return true;},[&]{++calls;return true;}));check(calls==1);
 }
 std::printf("%u graphics initialization checks passed: old worker-config race reproduced; sole creation, busy diagnostics, same-thread ordering, publication, reentry, rejection and retry. Host orchestration only.\n",checks.load());
}
