// Execute the production scope and exception callback with Win32 API seams.
// Each scenario is a fresh host process because production intentionally permits
// only one initialization trace attempt per process. No Windows VEH is installed.
#define NVS30_INIT_TRACE_TEST
#define _WIN64 1
#include "src/init_trace.cpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <string>
#include <thread>
#include <vector>
#include <sys/wait.h>
#include <unistd.h>

namespace {
using nvs30::init_trace::Scope;
std::atomic<unsigned> checks=0;
void check(bool ok,const char* why){++checks;if(!ok){std::fprintf(stderr,"Trace lifecycle check failed: %s\n",why);std::abort();}}
thread_local DWORD lastError=0,threadId=0x2222;
std::atomic<unsigned> pathCalls=0,fileCalls=0,pinCalls=0,registrationCalls=0,closeCalls=0,writes=0;
std::atomic<bool> closed=false,writerEntered=false,releaseWriter=false;
bool denyPath=false,denyFile=false,denyPin=false,denyRegistration=false,denyWrite=false;
bool reenterWrite=false,blockFaultWrite=false;
unsigned nestedCallbacks=0;
int fileToken=0,moduleToken=0,handlerToken=0;
std::uintptr_t pinnedAddress=0;
PVECTORED_EXCEPTION_HANDLER callback=nullptr;
std::vector<std::string> lines;
constexpr auto moduleBase=std::uintptr_t{0x7ff900000000};
const void* module(){return reinterpret_cast<const void*>(moduleBase);}
struct Fault {
 EXCEPTION_RECORD record{};CONTEXT context{};EXCEPTION_POINTERS pointers{&record,&context};
 explicit Fault(DWORD code=0xc0000005){
  record.ExceptionCode=code;record.ExceptionFlags=0x55;record.ExceptionAddress=reinterpret_cast<void*>(moduleBase+0x37ab9);record.NumberParameters=3;
  record.ExceptionInformation[0]=1;record.ExceptionInformation[1]=0xabcdef;record.ExceptionInformation[2]=0xc0000185;
  context.Rip=moduleBase+0x37ab9;context.Rsp=0x1000;context.Rax=87;context.Rcx=2;context.Rdx=3;context.R8=4;context.R9=5;
  for(auto& value:context.unusedBefore)value=0x1122334455667788;for(auto& value:context.unusedAfter)value=0x8877665544332211;
 }
 LONG invoke(){
  std::array<unsigned char,sizeof record> beforeRecord{};std::array<unsigned char,sizeof context> beforeContext{};std::array<unsigned char,sizeof pointers> beforePointers{};
  std::memcpy(beforeRecord.data(),&record,sizeof record);std::memcpy(beforeContext.data(),&context,sizeof context);std::memcpy(beforePointers.data(),&pointers,sizeof pointers);const auto beforeError=lastError;
  check(callback!=nullptr,"No registered production callback");auto result=callback(&pointers);
  check(result==EXCEPTION_CONTINUE_SEARCH,"Production callback changed exception dispatch");
  check(!std::memcmp(&record,beforeRecord.data(),sizeof record)&&!std::memcmp(&context,beforeContext.data(),sizeof context)&&!std::memcmp(&pointers,beforePointers.data(),sizeof pointers),"Production callback changed the exception record or context");
  check(lastError==beforeError,"Production callback changed caller LastError");return result;
 }
};
void unchangedNullInput(PEXCEPTION_POINTERS p){const auto before=writes.load();lastError=0x77;check(callback(p)==EXCEPTION_CONTINUE_SEARCH,"Null exception input did not continue search");check(writes==before&&lastError==0x77,"Null exception input changed state");}
void failedPreparation(const char* kind){
 denyPath=!std::strcmp(kind,"path");denyFile=!std::strcmp(kind,"append");denyPin=!std::strcmp(kind,"pin");denyRegistration=!std::strcmp(kind,"registration");
 lastError=0xabc;{Scope scope(module(),0x810000);check(!scope.active(),"Failed preparation activated the trace");check(lastError==0xabc,"Failed constructor changed LastError");}
 check(lastError==0xabc&&writes==0&&!callback,"Failed scope retained an active callback or wrote records");
 if(denyPath)check(fileCalls==0&&pinCalls==0&&closeCalls==0,"Invalid process path reached file/pin APIs");
 if(denyFile)check(fileCalls==1&&pinCalls==0&&closeCalls==0,"Append-open failure leaked a handle or pinned the module");
 if(denyPin)check(fileCalls==1&&pinCalls==1&&registrationCalls==0&&closeCalls==1,"Module pin failure did not close only its own handle");
 if(denyRegistration)check(pinCalls==1&&registrationCalls==1&&closeCalls==1,"Handler registration failure leaked its append handle");
 const auto calls=pathCalls.load();denyPath=denyFile=denyPin=denyRegistration=false;
 {Scope retry(module(),0x810000);check(!retry.active(),"One-shot preparation unexpectedly retried");}check(pathCalls==calls,"Failed one-shot scope entered preparation again");
}
void invalidScope(){lastError=0xabc;{Scope scope(nullptr,0x810000);check(!scope.active(),"Null module activated trace");}check(pathCalls==0&&writes==0&&lastError==0xabc,"Invalid scope had external effects");}
void activeLifecycle(){
 lastError=0xabc;
 {
  Scope scope(module(),0x810000);check(scope.active(),"Valid scope was not active");check(lastError==0xabc,"Constructor changed LastError");check(writes==1&&lines.front().find("event=init-trace-begin")==0,"Begin marker missing");
  {Scope duplicate(module(),0x810000);check(!duplicate.active(),"Second scope replaced live trace");}check(fileCalls==1&&registrationCalls==1,"Duplicate scope reopened or reregistered trace");
  unchangedNullInput(nullptr);EXCEPTION_POINTERS empty{};unchangedNullInput(&empty);Fault fault;empty.ExceptionRecord=&fault.record;unchangedNullInput(&empty);empty.ExceptionRecord=nullptr;empty.ContextRecord=&fault.context;unchangedNullInput(&empty);
  for(DWORD code:{0u,0xe06d7363u,0x80000001u,0x80000004u,0xc0000409u}){Fault ignored(code);lastError=0x456;auto before=writes.load();ignored.invoke();check(writes==before,"Excluded exception was logged");}
  for(DWORD code:{0xc0000005u,0xc0000006u,0xc000001du,0xc00000fdu,0x80000003u}){Fault accepted(code);lastError=0x567;auto before=writes.load();accepted.invoke();check(writes==before+1,"Accepted exception was not logged");check(lines.back().find("terminal=unknown phase=NVP_Init_D3D")!=std::string::npos,"Fault incorrectly described terminal status");}
  for(unsigned i=0;i<24;++i){Fault repeated;lastError=0x678;repeated.invoke();}
  check(writes==17,"Fault record cap was not exactly sixteen plus begin");lastError=0xdef;
 }
 check(lastError==0xdef&&writes==18&&lines.back().find("event=init-trace-end")==0,"Scope-end marker or LastError preservation failed");
 check(closeCalls==0&&!closed,"Scope end closed a handle that an in-flight callback might retain");
 Fault late;lastError=0x789;late.invoke();check(writes==18,"Disarmed retained callback wrote a fault");
 {Scope later(module(),0x810000);check(!later.active(),"Later scope rearmed the one-shot trace");}check(fileCalls==1&&registrationCalls==1,"Later scope changed retained resources");
}
void reentrantWriting(){
 reenterWrite=true;lastError=0xabc;
 {Scope scope(module(),0x810000);check(scope.active()&&writes==1&&nestedCallbacks==1,"Begin callback reentry was not passive");Fault fault;fault.invoke();check(writes==2&&nestedCallbacks==2,"Fault writer recursively wrote another fault");denyWrite=true;fault.invoke();check(writes==3&&lastError==0xabc,"Failed WriteFile changed dispatch or LastError");}
 check(writes==4&&nestedCallbacks==4&&closeCalls==0&&lastError==0xabc,"Reentrant end writer changed lifecycle semantics");
}
void inFlightEnd(){
 auto scope=std::make_unique<Scope>(module(),0x810000);check(scope->active(),"Concurrent scenario could not arm");
 blockFaultWrite=true;
 std::atomic<bool> finished=false;std::thread writer([&]{threadId=0x3333;lastError=0xdef;Fault fault;fault.invoke();finished.store(true,std::memory_order_release);});
 while(!writerEntered.load(std::memory_order_acquire))std::this_thread::yield();
 lastError=0xabc;scope.reset();check(lastError==0xabc&&closeCalls==0&&!closed,"Concurrent scope-end closed the handle or changed LastError");
 check(!finished.load(std::memory_order_acquire),"In-flight writer was not controlled by fixture");const auto before=writes.load();Fault late;late.invoke();check(writes==before,"Disarmed callback entered an in-flight writer");
 releaseWriter.store(true,std::memory_order_release);writer.join();check(finished.load()&&writes==2&&closeCalls==0,"In-flight fault lost its retained handle or wrote an unsafe end marker");
 check(lines.back().find("tid=0x0000000000003333")!=std::string::npos,"Handler did not capture actual faulting thread");
 late.invoke();check(writes==2,"Post-flight disarmed callback wrote another record");
}
}

DWORD GetLastError(){return lastError;}void SetLastError(DWORD value){lastError=value;}
DWORD GetCurrentThreadId(){lastError=0x901;return threadId;}DWORD GetCurrentProcessId(){lastError=0x902;return 0x1111;}
DWORD GetModuleFileNameW(HMODULE image,wchar_t* out,DWORD capacity){++pathCalls;check(image==nullptr&&capacity==32768,"Trace did not resolve host executable path");lastError=0x903;if(denyPath)return 0;constexpr wchar_t value[]=L"C:\\Games\\fixture\\game.exe";std::wmemcpy(out,value,std::size(value));return DWORD(std::size(value)-1);}
HANDLE CreateFileW(LPCWSTR path,DWORD access,DWORD share,void* security,DWORD disposition,DWORD flags,HANDLE model){
 ++fileCalls;check(std::wstring(path)==L"C:\\Games\\fixture\\nvsmooth30-init-exception.log","Trace path was not placed beside host executable");
 check(access==FILE_APPEND_DATA&&share==(FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE)&&!security&&disposition==OPEN_ALWAYS&&flags==(FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH)&&!model,"Trace file flags changed append/share semantics");lastError=0x904;return denyFile?INVALID_HANDLE_VALUE:&fileToken;
}
BOOL GetModuleHandleExW(DWORD flags,LPCWSTR address,HMODULE* out){++pinCalls;check(flags==(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN)&&address!=nullptr&&out,"Trace callback was not pinned by its code address");lastError=0x905;if(denyPin)return 0;pinnedAddress=reinterpret_cast<std::uintptr_t>(address);*out=&moduleToken;return 1;}
BOOL CloseHandle(HANDLE file){check(file==&fileToken&&!closed.exchange(true),"Unexpected or repeated handle close");++closeCalls;lastError=0x906;return 1;}
void* AddVectoredExceptionHandler(unsigned long first,PVECTORED_EXCEPTION_HANDLER fn){
 ++registrationCalls;check(first==1&&fn&&pinCalls==1&&!closed&&pinnedAddress==reinterpret_cast<std::uintptr_t>(fn),"Handler registered before pin, after handle close, or using a different pinned code address");lastError=0x907;if(denyRegistration)return nullptr;callback=fn;
 // Registration occurs before arming: even synchronous first-chance delivery
 // during registration must remain a passive no-op.
 Fault early;early.invoke();check(writes==0,"Registration exposed armed trace before preparation finished");return &handlerToken;
}
BOOL WriteFile(HANDLE file,const void* data,DWORD bytes,DWORD* written,void* overlapped){
 check(file==&fileToken&&!closed&&data&&bytes<=1024&&written&&!overlapped,"Trace used invalid append handle/buffer");++writes;
 const std::string before(static_cast<const char*>(data),bytes);lines.push_back(before);
 if(reenterWrite){++nestedCallbacks;Fault fault;fault.invoke();check(std::string(static_cast<const char*>(data),bytes)==before,"Reentrant callback overwrote outer output buffer");}
 if(blockFaultWrite&&before.find("event=first-chance-exception")==0){writerEntered.store(true,std::memory_order_release);while(!releaseWriter.load(std::memory_order_acquire))std::this_thread::yield();check(!closed,"Scope end closed a handle still in use by a callback");check(std::string(static_cast<const char*>(data),bytes)==before,"Scope end reused in-flight output storage");}
 *written=denyWrite?0:bytes;lastError=0x908;return denyWrite?0:1;
}

int main(){
 struct Scenario{const char* name;void(*run)();};
 const Scenario cases[]={{"invalid module",invalidScope},{"path failure",[]{failedPreparation("path");}},{"append-open failure",[]{failedPreparation("append");}},{"module pin failure",[]{failedPreparation("pin");}},{"VEH registration failure",[]{failedPreparation("registration");}},{"active and disarmed lifecycle",activeLifecycle},{"reentrant and failed WriteFile",reentrantWriting},{"scope end with in-flight writer",inFlightEnd}};
 for(const auto& scenario:cases){std::fflush(nullptr);const pid_t child=fork();check(child>=0,"Could not isolate one-shot trace scenario");if(child==0){checks=0;scenario.run();std::printf("%s: %u checks passed\n",scenario.name,checks.load());std::fflush(stdout);_exit(0);}int status{};check(waitpid(child,&status,0)==child,"Could not join trace scenario");check(WIFEXITED(status)&&WEXITSTATUS(status)==0,"Production trace lifecycle scenario failed");}
 std::printf("{\"result\":\"PASS\",\"test\":\"production_init_trace_lifecycle\",\"scenarios\":%zu,\"native_windows_executed\":false,\"Windows_VEH_dispatch_executed\":false}\n",std::size(cases));
}
