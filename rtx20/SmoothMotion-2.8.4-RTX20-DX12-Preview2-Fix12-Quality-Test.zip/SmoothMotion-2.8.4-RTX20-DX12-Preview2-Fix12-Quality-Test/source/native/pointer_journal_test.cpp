#include "include/nvs30/pointer_journal.hpp"
#include <cassert>
#include <iostream>
int main() {
    int first=1,delay=2,hook=3,foreign=4;void* a=&first;void* b=&delay;void* c=&first;
    nvs30::PointerJournal<2> patches;
    unsigned writes=0;auto write=[&](void** slot,void* value){++writes;*slot=value;return true;};
    auto fail=[](void**,void*){return false;};
    assert(!patches.install(nullptr,&hook,write));assert(!patches.install(&a,nullptr,write));
    assert(!patches.install(&a,&hook,fail)&&a==&first&&patches.size()==0);
    assert(patches.install(&a,&hook,write)&&a==&hook&&patches.size()==1);
    assert(patches.install(&a,&hook,write)&&writes==1); // idempotent, exact saved original
    assert(!patches.install(&a,&foreign,write)&&writes==1);
    assert(patches.install(&b,&hook,write)&&b==&hook&&patches.size()==2);
    assert(!patches.install(&c,&hook,write)&&c==&first); // capacity cannot leave untracked hook
    assert(!patches.restore(fail)&&patches.size()==2&&a==&hook&&b==&hook);
    assert(patches.restore(write)&&patches.size()==0&&a==&first&&b==&delay);
    assert(patches.install(&b,&hook,write));b=&foreign;
    assert(patches.restore(write)&&b==&foreign&&patches.size()==0); // preserve a later owner
    assert(patches.install(&a,&hook,write));assert(patches.install(&b,&hook,write));
    assert(!patches.restore([&](void** slot,void* value){return slot==&a?false:write(slot,value);}));
    assert(patches.size()==1&&a==&hook&&b==&foreign);
    assert(patches.restore(write)&&a==&first&&patches.size()==0);
    a=&hook;assert(!patches.install(&a,&hook,write)); // cannot infer an unrecorded original
    std::cout<<"PASS: exact normal/delay originals, capacity/failure rollback, retained failed restores, idempotence, later-owner preservation. Host pointer operations only.\n";
}
