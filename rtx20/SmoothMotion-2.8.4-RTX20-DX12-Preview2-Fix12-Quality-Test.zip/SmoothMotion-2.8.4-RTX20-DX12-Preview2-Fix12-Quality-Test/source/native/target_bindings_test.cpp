#include "include/nvs30/target_bindings.hpp"
#include "include/nvs30/import_identity.hpp"
#include <thread>
#include <vector>
#include <cassert>
#include <cstdio>
int main(){
 target_binding::Table<4,6> table;int a,b,c,d;
 assert(table.publish(nullptr,0).slot==4&&table.publish(&a,6).slot==4);
 std::atomic<unsigned> added{0};std::atomic_bool finished{false};
 std::thread reader([&]{while(!finished){auto slot=table.find(&a,3);if(slot!=4)assert(table.target(slot,3)==&a&&table.target(slot,2)==nullptr);}});
 std::vector<std::thread> writers;
 for(unsigned i=0;i<12;++i)writers.emplace_back([&]{for(;;){auto result=table.publish(&a,3);if(result.slot!=4){added+=result.added;break;}std::this_thread::yield();}});
 for(auto& t:writers)t.join();finished=true;reader.join();assert(added==1&&table.count()==1);
 const auto first=table.find(&a,3);const auto other=table.publish(&a,4);assert(other.added&&other.slot!=first);
 assert(table.target(other.slot,4)==&a&&table.target(first,3)==&a);
 assert(table.publish(&b,0).added&&table.publish(&c,1).added);
 assert(table.publish(&d,2).slot==4&&!table.publish(&a,3).added&&table.count()==4);
 assert(!table.target(4,0)&&!table.target(first,7));
 for(auto name:{"dxgi.dll","DXGI.DLL","api-ms-win-dx-dxgi-l1-1-0.dll"}){
  for(unsigned api=0;api<6;++api)assert(import_identity::graphics(name,api)==(api<3));
 }
 for(auto name:{"d3d12.dll","api-ms-win-dx-d3d12-l1-1-0.dll"})for(unsigned api=0;api<6;++api)assert(import_identity::graphics(name,api)==(api==3));
 for(auto name:{"d3d11.dll","api-ms-win-dx-d3d11-l1-1-0.dll"})for(unsigned api=0;api<6;++api)assert(import_identity::graphics(name,api)==(api==4||api==5));
 for(unsigned api=0;api<6;++api)assert(import_identity::graphics("sl.interposer.dll",api));
 for(auto name:{"dxgi.dll.bak","other.dll","dir/dxgi.dll","api-ms-win-dx-dxgi-bad.exe"})for(unsigned api=0;api<6;++api)assert(!import_identity::graphics(name,api));
 for(auto name:{"KERNEL32.dll","kernelbase.dll","kernel32legacy.dll","api-ms-win-core-libraryloader-l1-2-0.dll"})assert(import_identity::loader(name));
 for(auto name:{"other.dll","dir/kernel32.dll","kernelbase.dll.bak","api-ms-win-core-libraryloader-test.exe"})assert(!import_identity::loader(name));
 std::puts("PASS: immutable (API,address) bindings, 12 concurrent writers, stable readers, capacity, ABI separation and exact import identity admission; host only.");
}
