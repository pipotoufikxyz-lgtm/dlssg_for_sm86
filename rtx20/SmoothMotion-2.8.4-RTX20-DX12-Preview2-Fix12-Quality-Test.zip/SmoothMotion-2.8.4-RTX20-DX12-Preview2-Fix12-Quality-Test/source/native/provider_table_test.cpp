#include "include/nvs30/provider_table.hpp"
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <vector>

using namespace graphics_provider;
void check(bool ok){if(!ok)std::abort();}
int main(){
 Table<> table;
 std::array<int,apiCount> real{},wrapped{},second{};
 std::array<void*,apiCount> targets{};
 std::array<std::array<void*,apiCount>,capacity> wrappers{};
 for(std::size_t i=0;i<apiCount;++i){targets[i]=&real[i];for(auto& row:wrappers)row[i]=&wrapped[i];}
 check(table.publish(0,targets)==Publish::invalid);
 check(table.publish(1,{})==Publish::invalid);
 check(table.replacement(nullptr,wrappers)==nullptr&&table.target(0,factory)==nullptr);
 std::atomic_bool stop=false;std::atomic<unsigned> added=0;
 std::thread reader([&]{while(!stop.load())for(std::size_t slot=0;slot<capacity;++slot)for(std::size_t i=0;i<apiCount;++i){
  const auto value=table.target(slot,static_cast<Api>(i));check(!value||value==targets[i]);
 }});
 std::vector<std::thread> writers;
 for(unsigned i=0;i<12;++i)writers.emplace_back([&]{for(unsigned attempt=0;attempt<10000;++attempt){
  const auto result=table.publish(17,targets);
  if(result==Publish::busy){std::this_thread::yield();continue;}
  check(result==Publish::added||result==Publish::existing);if(result==Publish::added)++added;return;
 }std::abort();});
 for(auto& thread:writers)thread.join();stop=true;reader.join();
 check(added==1&&table.count()==1&&table.find(17)==0);
 for(std::size_t i=0;i<apiCount;++i)check(table.replacement(targets[i],wrappers)==&wrapped[i]);
 auto changed=targets;changed[0]=&second[0];
 check(table.publish(17,changed)==Publish::existing&&table.target(0,factory)==targets[0]);
 check(table.replacement(&second[0],wrappers)==&second[0]);
 for(unsigned i=1;i<capacity;++i)check(table.publish(17+i,changed)==Publish::added);
 check(table.publish(99,changed)==Publish::full&&table.count()==capacity);
 check(table.target(capacity,factory)==nullptr&&table.target(0,apiCount)==nullptr);
 std::puts("{\"result\":\"PASS\",\"test\":\"immutable_provider_publication\",\"concurrent_writers\":12,\"native_windows_executed\":false}");
}
