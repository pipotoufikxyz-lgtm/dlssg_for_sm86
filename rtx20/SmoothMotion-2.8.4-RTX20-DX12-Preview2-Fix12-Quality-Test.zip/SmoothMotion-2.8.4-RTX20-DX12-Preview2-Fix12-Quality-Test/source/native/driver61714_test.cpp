#include "include/nvs30/driver_layout.hpp"
#include "test_reference/gp8_driver_layout.hpp"
#include "include/nvs30/profile_transaction.hpp"
#include <openssl/sha.h>
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
namespace profile=nvs30::driver_profile;
namespace layout=nvs30::driver_layout;
std::string sha(const unsigned char* bytes,std::size_t size){
    unsigned char digest[32]{};SHA256(bytes,size,digest);constexpr char hex[]="0123456789abcdef";std::string out;
    for(auto b:digest){out+=hex[b>>4];out+=hex[b&15];}return out;
}
int main(int argc,char** argv){
    constexpr auto kind=profile::Kind::nvidia61714;
    assert(profile::identify(profile::source61714_sha256,profile::source61714_size)==kind);
    assert(profile::identify(profile::source61714_sha256,profile::source_size)==profile::Kind::none);
    assert(profile::identify(profile::source_sha256,profile::source61714_size)==profile::Kind::none);
    assert(profile::identify(profile::output61714_sha256,profile::source61714_size)==profile::Kind::none);
    assert(profile::runtime_sites_match(kind,0x59e0,0x7f0cd0,0xc41f,0xc437,4));
    assert(!profile::runtime_sites_match(kind,0x59e0,0x7d7810,0xc41f,0xc437,4));
    assert(!profile::runtime_sites_match(profile::Kind::golden61664,0x59e0,0x7f0cd0,0xc41f,0xc437,4));
    assert(profile::runtime_sites_match(profile::Kind::golden61664,0x59e0,0x7d7810,0xc41f,0xc437,4));
    for(unsigned field=0;field<5;++field){
        std::array<std::uintptr_t,5> sites{0x59e0,0x7f0cd0,0xc41f,0xc437,4};++sites[field];
        assert(!profile::runtime_sites_match(kind,sites[0],sites[1],sites[2],sites[3],sites[4]));
    }
    const auto plan=profile::edits(kind);std::set<std::size_t> touched,changed;
    for(const auto& e:plan)for(std::size_t i=0;i<e.before.size();++i){
        assert(touched.insert(e.offset+i).second);if(e.before[i]!=e.after[i])changed.insert(e.offset+i);
    }
    assert(plan.size()==61&&changed.size()==61&&profile::changed_bytes(kind)==61);
    // New ELF ABI stores SM in the second byte; all format bits stay intact.
    for(std::size_t i=2;i<plan.size();i+=3){
        assert((plan[i].before==std::array<unsigned char,4>{4,89,0,6}));
        assert((plan[i].after==std::array<unsigned char,4>{4,86,0,6}));
        assert((plan[i+1].before==std::array<unsigned char,4>{2,0,89,0}));
        assert((plan[i+1].after==std::array<unsigned char,4>{2,0,86,0}));
    }
    std::vector<unsigned char> synthetic(profile::source61714_size);
    for(const auto& e:plan)std::memcpy(synthetic.data()+e.offset,e.before.data(),e.before.size());
    assert(profile::original_sites(synthetic,kind));
    std::vector<unsigned char> output{1,2,3};const char* reason{};
    assert(!profile::prepare(synthetic,sha,output,reason)&&output.empty());
    const auto unchanged=synthetic;
    assert(!profile::apply_sites_for_validation(synthetic,synthetic,kind)&&synthetic==unchanged);
    for(const auto& e:plan){synthetic[e.offset]^=1;assert(!profile::original_sites(synthetic,kind));synthetic[e.offset]^=1;}
    unsigned real=0;
    if(argc==2){
        std::ifstream f(argv[1],std::ios::binary);std::vector<unsigned char> input{std::istreambuf_iterator<char>(f),{}};
        assert(sha(input.data(),input.size())==profile::source61714_sha256);
        gp8_baseline::driver_layout::Image before;
        assert(gp8_baseline::driver_layout::parse(input,before));
        assert(!gp8_baseline::driver_layout::validate(before,input,sha(input.data(),input.size()),sha).accepted);
        layout::Image image;assert(layout::parse(input,image)&&layout::layout61714(image,input));
        const auto verdict=layout::validate(image,input,sha(input.data(),input.size()),sha);
        assert(verdict.accepted&&verdict.profile==kind&&verdict.reference);
        assert(profile::prepare(input,sha,output,reason));
        assert(sha(output.data(),output.size())==profile::output61714_sha256);
        std::set<std::size_t> actual;
        for(std::size_t i=0;i<input.size();++i)if(input[i]!=output[i])actual.insert(i);
        // Use the same production transaction as install_model_profile, on the actual specimen.
        auto mapped=input;
        auto transaction=[&](const auto& selected){return nvs30::profile_transaction::run(selected,
            [&](auto i,auto& bytes){std::memcpy(bytes.data(),mapped.data()+plan[i].offset,bytes.size());return true;},
            [&](auto i,const auto& bytes){std::memcpy(mapped.data()+plan[i].offset,bytes.data(),bytes.size());return true;},
            [&](auto i){std::memcpy(mapped.data()+plan[i].offset,input.data()+plan[i].offset,4);return true;});};
        assert(transaction(profile::edits())==nvs30::profile_transaction::Result::PreflightRejected);
        assert(mapped==input); // A 617.14 mapping cannot accidentally run the legacy byte plan.
        assert(transaction(plan)==nvs30::profile_transaction::Result::Applied&&mapped==output);
        assert(actual==changed); // Every instruction, FP8/SM120 payload and non-target byte stays untouched.
        assert(!profile::original_sites(input)); // Old 616.64 patch plan must never apply to 617.14.
        assert(!profile::prepare(output,sha,synthetic,reason)); // No repeated transformation.
        auto check=[](const std::vector<unsigned char>& bytes){
            layout::Image pe;return layout::parse(bytes,pe)&&layout::validate(pe,bytes,sha(bytes.data(),bytes.size()),sha).accepted;
        };
        for(const auto& e:plan){auto bad=input;bad[e.offset]^=1;assert(!check(bad));++real;}
        // A matching four-byte gate is insufficient to authorize another build.
        for(const auto& s:image.sections){auto bad=input;bad[s.raw+8]^=1;assert(!check(bad));++real;}
        for(const auto& k:profile::non_fp8_kernels61714){
            auto bad=input;bad[k.flags_offset+96]^=1;assert(!check(bad));++real;
            assert(input[k.flags_offset-40]==8); // Actual ELF ABI marker.
            assert((std::array<unsigned char,4>{output[k.note_offset],output[k.note_offset+1],output[k.note_offset+2],output[k.note_offset+3]}==profile::note61714_after));
        }
        auto truncated=input;truncated.pop_back();assert(!check(truncated));++real;
        auto extended=input;extended.push_back(0);assert(!check(extended));++real;
        // Header-only changes are not admitted on this new exact-identity route.
        auto header=input;header[layout::read<std::uint32_t>(input,60)+8]^=1;assert(!check(header));++real;
    }
    std::cout<<"PASS: 617.14 exact identity, GP8 rejection/new acceptance, ABI 8 real/virtual SM fields, 61-byte transform, per-profile startup addresses, wrong/mutated input rejection; real mutation cases="<<real<<". GPU execution NOT tested.\n";
}
