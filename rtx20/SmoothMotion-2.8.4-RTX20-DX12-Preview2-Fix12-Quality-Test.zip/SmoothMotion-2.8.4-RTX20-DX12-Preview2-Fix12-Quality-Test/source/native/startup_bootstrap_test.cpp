// Production startup entry/controller with a deterministic driver seam.
// This covers activation ordering, not NVIDIA/Windows/game execution.
#include "include/nvs30/startup_bootstrap.hpp"
#include "test_reference/gp6_startup_bootstrap.hpp"
#include "include/nvs30/graphics_initialization.hpp"
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <memory>
#include <thread>
#include <vector>
#include <cstdint>
// The production context probe is exercised with Win32 seams, including the
// native BOOLEAN return type (8 bits), not a Win32 BOOL (32 bits).
using DWORD=std::uint32_t;using BOOLEAN=unsigned char;using HMODULE=void*;using FARPROC=void(*)();
#define NTAPI
static DWORD lastError=0;static bool ntdllPresent=true,probePresent=true;static BOOLEAN insideLoader=0;
DWORD GetLastError(){return lastError;}void SetLastError(DWORD value){lastError=value;}
HMODULE GetModuleHandleW(const wchar_t*){lastError=3;return ntdllPresent?&insideLoader:nullptr;}
BOOLEAN probeLoader(){lastError=5;return insideLoader;}
FARPROC GetProcAddress(HMODULE,const char* name){lastError=4;return probePresent&&!std::strcmp(name,"RtlIsThreadWithinLoaderCallout")?reinterpret_cast<FARPROC>(&probeLoader):nullptr;}
#include "include/nvs30/loader_context.hpp"
using namespace nvs30::startup_bootstrap;
namespace {
unsigned checks=0;
void check(bool value,const char* message){++checks;if(!value){std::fprintf(stderr,"Startup regression: %s\n",message);std::abort();}}
constexpr auto deadSpaceExe=L"C:\\Steam\\steamapps\\common\\Dead Space (2023)\\Dead Space.exe";
constexpr auto genshinExe=L"D:\\HoYoPlay\\games\\Genshin Impact game\\GenshinImpact.exe";
constexpr auto kcd2Exe=L"D:\\Games\\KingdomComeDeliverance2\\Bin\\Win64MasterMasterSteamPGO\\KingdomCome.exe";
struct Fixture {
 Controller startup;nvs30::GraphicsInitialization gate;
 Context context=Context::outside_loader;
 std::wstring_view exe=deadSpaceExe;
 MarkerKind marker=MarkerKind::file;
 Profile initializedProfile=Profile::graphics_call;
 bool initSuccess=true,reenter=false;
 unsigned scans=0,workers=0,selects=0,markerProbes=0,configs=0,drivers=0;
 std::wstring markerPath;
 std::vector<int> order;
 void host(Profile profile){
  exe=profile==Profile::genshin?genshinExe:profile==Profile::kingdom_come_2?kcd2Exe:deadSpaceExe;
  marker=profile==Profile::genshin?MarkerKind::directory:MarkerKind::file;
 }
 void initialize(const char*,Profile profile){
  gate.run([&]{++configs;order.push_back(1);return true;},[&]{
   ++drivers;order.push_back(2);initializedProfile=profile;
   if(reenter)asi();
   return initSuccess;
  });
 }
 Profile select(){
  ++selects;check(context==Context::outside_loader,"Host probe ran in loader callout");
  return selectProfile(exe,[&](const wchar_t* path){++markerProbes;markerPath=path;return marker;});
 }
 void asi(){startup.asi([&]{return context;},[&]{return select();},[&](const char* source,Profile profile){initialize(source,profile);});}
 void service(bool standalone){startup.service(standalone,[&]{return context;},[&]{return select();},[&](const char* source,Profile profile){initialize(source,profile);});}
};
Fixture* active{};
void start(){++active->workers;active->order.push_back(3);}
}
namespace nvs30::dxgi {
bool install_hooks(){++active->scans;return true;}
void asi_startup(){if(active->context==Context::outside_loader)install_hooks();active->asi();}
}
namespace {
#include "include/nvs30/asi_entry.hpp"
// Exact GP5 InitializeASI body, renamed for the A/B control. No graphics calls
// occur after the entry in this fixture, just as the reported counters show.
void initializeAsiGP5(){nvs30::dxgi::install_hooks();start();}
void stalledImportControl(){
 Fixture old;active=&old;initializeAsiGP5();
 check(old.scans==1&&old.workers==1&&old.drivers==0,"GP5 control no longer reproduces the unstarted driver");
 for(unsigned i=0;i<500;++i)nvs30::dxgi::install_hooks();
 check(old.drivers==0,"Repeated import scans must not manufacture initialization");
 Fixture updated;active=&updated;initializeAsiEntry();
 check(updated.scans==1&&updated.drivers==1&&updated.configs==1,"ASI entry did not initialize without a graphics callback");
 check(updated.order==std::vector<int>({1,2,3}),"Driver startup must complete before the loader entry returns");
 check(updated.startup.asiEntries==1&&updated.startup.attempts==1,"Entry diagnostics did not record real activation");
 check(std::strcmp(updated.startup.entry,"InitializeASI")==0,"Wrong initialization trigger");
 check(updated.initializedProfile==Profile::dead_space&&std::strcmp(updated.startup.policy,"dead_space_early")==0,"Working Dead Space startup profile changed");
 initializeAsiEntry();updated.service(false);
 check(updated.drivers==1&&updated.configs==1,"Repeated ASI entry duplicated backend initialization");
}
void genshinBaselineControl(){
 // Run the released GP6 controller/selection as the baseline. This is a host
 // control, not a claim that the supplied GP1 log came from GP6.
 gp6_startup_bootstrap::Controller old;unsigned starts=0;
 auto probe=[]{return gp6_startup_bootstrap::Context::outside_loader;};
 auto select=[]{return gp6_startup_bootstrap::deadSpace(genshinExe,true);};
 auto initialize=[&](const char*){++starts;};
 old.asi(probe,select,initialize);old.service(true,probe,select,initialize);
 check(starts==0&&old.attempts==0,"GP6 control unexpectedly selected Genshin early startup");
 check(std::strcmp(old.policy,"graphics_call")==0,"GP6 Genshin baseline policy changed");
 Fixture updated;updated.host(Profile::genshin);active=&updated;initializeAsiEntry();
 check(updated.drivers==1&&updated.configs==1,"Genshin still needs a graphics callback to initialize");
 check(updated.order==std::vector<int>({1,2,3}),"Genshin driver did not initialize before ASI entry returned");
 check(updated.initializedProfile==Profile::genshin&&std::strcmp(updated.startup.policy,"genshin_early")==0,"Genshin activation was not identified in diagnostics");
 check(updated.markerPath==L"D:\\HoYoPlay\\games\\Genshin Impact game\\GenshinImpact_Data","Genshin marker was not probed beside the reported executable");
 initializeAsiEntry();updated.service(false);
 check(updated.drivers==1&&updated.configs==1,"Genshin repeated ASI activation duplicated the driver");
}
void contextAndHostPolicy(){
 for(const auto profile:{Profile::dead_space,Profile::genshin,Profile::kingdom_come_2})for(const auto state:{Context::loader_callout,Context::unavailable}){
  Fixture f;f.host(profile);active=&f;f.context=state;initializeAsiEntry();
  check(f.scans==0&&f.selects==0&&f.configs==0&&f.drivers==0,"Loader callout performed scan/configuration/driver work");
  check(f.workers==1&&f.startup.loaderDeferrals==1,"Unsafe entry was not deferred");
  f.service(false);check(f.selects==0&&f.drivers==0,"Unsafe worker state did not remain deferred");
  f.context=Context::outside_loader;f.service(false);
  check(f.drivers==1&&f.configs==1,"Deferred ASI failed to activate after loader callout ended");
  check(f.initializedProfile==profile,"Deferred activation changed the selected title");
  check(std::strcmp(f.startup.entry,"deferred_asi_worker")==0,"Deferred source was not recorded");
  f.service(false);check(f.drivers==1,"Deferred request was not consumed");
 }
 for(auto exe:{L"C:\\Steam\\Decline's Drop.exe",L"C:\\XboxGames\\Marvel Cosmic Invasion\\Content\\Game.exe",L"C:\\Games\\Haydee2.exe",L"C:\\Games\\PCSX2.exe",L"C:\\Games\\Not Dead Space.exe",L"C:\\Games\\Dead Space.exe.old",L"D:\\HoYoPlay\\launcher.exe",L"D:\\Games\\NotGenshinImpact.exe",L"D:\\Games\\GenshinImpact.exe.old",L"D:\\Games\\GenshinImpact.exe\\other.exe"}){
  Fixture f;f.exe=exe;active=&f;initializeAsiEntry();f.service(true);
  check(f.drivers==0&&f.configs==0,"Early startup changed another game's graphics activation policy");
  check(std::strcmp(f.startup.policy,"graphics_call")==0,"Unselected policy was misreported");
  check(f.markerProbes==0,"Unrelated game performed a profile filesystem probe");
 }
 for(const auto profile:{Profile::dead_space,Profile::genshin,Profile::kingdom_come_2}){
  Fixture absent;absent.host(profile);absent.marker=MarkerKind::unavailable;active=&absent;initializeAsiEntry();
  check(absent.drivers==0&&absent.markerProbes==1,"Filename alone selected an early startup profile");
 }
}
void adjacentMarkerSelection(){
 struct Case{const wchar_t* exe;const wchar_t* marker;Profile profile;MarkerKind kind;};
 for(const auto& test:{
  Case{kcd2Exe,L"D:\\Games\\KingdomComeDeliverance2\\Bin\\Win64Shared\\WHGame.dll",Profile::kingdom_come_2,MarkerKind::file},
  Case{deadSpaceExe,L"C:\\Steam\\steamapps\\common\\Dead Space (2023)\\Engine.Render.Core2.PlatformPcDx12.dll",Profile::dead_space,MarkerKind::file},
  Case{genshinExe,L"D:\\HoYoPlay\\games\\Genshin Impact game\\GenshinImpact_Data",Profile::genshin,MarkerKind::directory},
  Case{L"\\\\?\\D:/Games/DEAD SPACE.EXE",L"\\\\?\\D:/Games/Engine.Render.Core2.PlatformPcDx12.dll",Profile::dead_space,MarkerKind::file},
  Case{L"\\\\?\\D:\\Games\\GENSHINIMPACT.EXE",L"\\\\?\\D:\\Games\\GenshinImpact_Data",Profile::genshin,MarkerKind::directory},
  Case{L"D:/\u6e38\u620f/GenshinImpact.exe",L"D:/\u6e38\u620f/GenshinImpact_Data",Profile::genshin,MarkerKind::directory}}){
  for(const auto kind:{MarkerKind::unavailable,MarkerKind::file,MarkerKind::directory}){
   unsigned probes=0;
   const auto profile=selectProfile(test.exe,[&](const wchar_t* path){++probes;check(std::wstring_view(path)==test.marker,"Wrong adjacent marker path");return kind;});
   check(probes==1,"Profile should inspect exactly one game marker");
   check(profile==(kind==test.kind?test.profile:Profile::graphics_call),"Missing or wrong marker type selected early activation");
  }
 }
 for(const auto* exe:{L"Dead Space.exe",L"GenshinImpact.exe",L"",L"D:\\Games\\GenshinImpact.exe\\"}){
  unsigned probes=0;
  check(selectProfile(exe,[&](const wchar_t*){++probes;return MarkerKind::directory;})==Profile::graphics_call,"Invalid executable path selected early initialization");
  check(probes==0,"Invalid path fell back to the current working directory");
 }
}
void standaloneFailureAndReentry(){
 for(const auto profile:{Profile::dead_space,Profile::genshin,Profile::kingdom_come_2}){
 Fixture worker;worker.host(profile);worker.service(false);check(worker.drivers==0,"ASI worker raced the explicit loader entry");
 worker.service(true);check(worker.drivers==1,"Standalone backend still waited indefinitely for graphics interception");
 worker.service(true);check(worker.drivers==1&&worker.selects==1,"Standalone worker repeatedly probed or initialized");
 check(std::strcmp(worker.startup.entry,"standalone_worker")==0,"Standalone trigger not recorded");
 check(worker.initializedProfile==profile,"Standalone worker initialized the wrong profile");
 Fixture failed;failed.host(profile);failed.initSuccess=false;active=&failed;initializeAsiEntry();initializeAsiEntry();failed.service(true);
 check(failed.drivers==1&&failed.configs==1,"Rejected native initializer was entered repeatedly");
 Fixture recursive;recursive.host(profile);recursive.reenter=true;active=&recursive;initializeAsiEntry();
 check(recursive.drivers==1&&recursive.configs==1,"Same-thread initializer reentry repeated setup");
 }
}
void concurrentActivation(){
 for(const auto profile:{Profile::dead_space,Profile::genshin,Profile::kingdom_come_2}){
 Controller c;nvs30::GraphicsInitialization gate;
 std::atomic_uint drivers{0},configs{0},returned{0};std::atomic_bool entered{false},release{false};
 auto initialize=[&](const char*,Profile){gate.run([&]{++configs;return true;},[&]{++drivers;entered=true;while(!release.load())std::this_thread::yield();return true;});};
 auto asi=[&]{c.asi([]{return Context::outside_loader;},[&]{return profile;},initialize);++returned;};
 std::thread owner(asi);while(!entered.load())std::this_thread::yield();
 std::vector<std::thread> others;for(unsigned i=0;i<12;++i)others.emplace_back(asi);
 for(auto& t:others)t.join();
 check(returned==12&&drivers==1&&configs==1,"Concurrent entry waited for the initialization owner or duplicated it");
 release=true;owner.join();check(returned==13,"Initialization owner did not return");
 }
}
void actualContextProbe(){
 for(const bool module:{false,true})for(const bool exported:{false,true})for(const BOOLEAN inside:{BOOLEAN(0),BOOLEAN(1),BOOLEAN(128)}){
  ntdllPresent=module;probePresent=exported;insideLoader=inside;lastError=0x12345678;
  const auto expected=!module||!exported?Context::unavailable:inside?Context::loader_callout:Context::outside_loader;
  check(loaderContext()==expected,"Native loader-callout probe misclassified context");
  check(lastError==0x12345678,"Native loader-callout probe leaked LastError");
 }
}
}
int main(){actualContextProbe();stalledImportControl();genshinBaselineControl();contextAndHostPolicy();adjacentMarkerSelection();standaloneFailureAndReentry();concurrentActivation();std::printf("%u startup checks passed; GP6 control skips Genshin; Fixes1 starts KCD II, Genshin and Dead Space through the production ASI entry without a graphics callback.\n",checks);}
