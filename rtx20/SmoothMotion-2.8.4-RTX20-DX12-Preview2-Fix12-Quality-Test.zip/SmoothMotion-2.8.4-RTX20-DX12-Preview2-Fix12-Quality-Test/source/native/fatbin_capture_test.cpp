#include "include/nvs30/fatbin_capture.hpp"
#include <algorithm>
#include <iostream>
#include <stdexcept>
using namespace nvs30::fatbin;
int main(){
 unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("Capture check "+std::to_string(checks));};
 std::vector<std::byte> image(112);auto* p=image.data();
 write<std::uint32_t>(p,0xba55ed50);write<std::uint16_t>(p+4,1);write<std::uint16_t>(p+6,16);write<std::uint64_t>(p+8,96);
 p+=16;write<std::uint16_t>(p,2);write<std::uint16_t>(p+2,0x101);write<std::uint32_t>(p+4,32);write<std::uint64_t>(p+8,64);write<std::uint32_t>(p+28,89);
 p+=32;std::memcpy(p,"\177ELF",4);p[4]=std::byte{2};p[5]=std::byte{1};write<std::uint16_t>(p+18,190);write<std::uint16_t>(p+52,64);write<std::uint32_t>(p+48,0x00590559);
 auto original=image;unsigned reads=0;std::size_t maximum=0;
 auto copy=[&](std::size_t at,void* out,std::size_t bytes){
  ++reads;maximum=std::max(maximum,bytes);
  if(at>image.size()||bytes>image.size()-at)return false;
  std::memcpy(out,image.data()+at,bytes);return true;
 };
 auto result=capture_and_rewrite(copy);
 check(result.valid&&result.stats.sm89_to_sm86==1&&reads==2&&maximum==112&&image==original);
 check(read<std::uint32_t>(result.bytes.data()+96)==0x00560556);
 for(unsigned fail=1;fail<=2;++fail){reads=0;auto out=capture_and_rewrite([&](auto at,auto target,auto bytes){
   if(reads+1==fail){++reads;return false;}return copy(at,target,bytes);
  });check(!out.valid&&reads==fail);}
 // A short body read with partial bytes copied must not produce any rewrite.
 reads=0;check(!capture_and_rewrite([&](auto at,auto target,auto bytes){
  if(reads==1){++reads;std::memcpy(target,image.data(),bytes-1);return false;}return copy(at,target,bytes);
 }).valid);
 // Adjacent readable regions are copied as one bounded image, independent of
 // the first region's size (the regression for the old VirtualQuery adapter).
 for(std::size_t split:{1u,15u,16u,17u,47u,64u,111u}){
  reads=0;auto out=capture_and_rewrite([&](std::size_t at,void* target,std::size_t bytes){
   ++reads;if(at!=0||bytes>image.size())return false;
   const auto first=std::min(split,bytes);std::memcpy(target,image.data(),first);
   std::memcpy(static_cast<std::byte*>(target)+first,image.data()+first,bytes-first);return true;
  });check(out.valid&&out.bytes==result.bytes&&reads==2);
 }
 // Headers changing between the small read and full copy are rejected.
 reads=0;check(!capture_and_rewrite([&](auto at,auto target,auto bytes){
  const auto ok=copy(at,target,bytes);if(reads==2)static_cast<std::byte*>(target)[8]^=std::byte{8};return ok;
 }).valid);
 for(auto payload:{std::uint64_t(0),std::uint64_t(64u*1024*1024)+1,UINT64_MAX}){
  image=original;write<std::uint64_t>(image.data()+8,payload);reads=0;
  check(!capture_and_rewrite(copy).valid&&reads==1);
 }
 for(unsigned prefix:{0u,15u,257u,65535u}){
  image=original;write<std::uint16_t>(image.data()+6,static_cast<std::uint16_t>(prefix));reads=0;
  check(!capture_and_rewrite(copy).valid&&reads==1);
 }
 for(std::size_t size=0;size<original.size();++size){image.assign(original.begin(),original.begin()+size);check(!capture_and_rewrite(copy).valid);}
 image=original;image[0]=std::byte{};reads=0;check(!capture_and_rewrite(copy).valid&&reads==1);
 image=original;image[4]=std::byte{2};reads=0;check(!capture_and_rewrite(copy).valid&&reads==1);
 const auto last=std::numeric_limits<std::uintptr_t>::max();
 check(!address_range(0,0,16));check(address_range(1,0,16));check(address_range(last,0,1));
 check(!address_range(last,0,2));check(!address_range(last,1,1));
 check(address_range(last-16,1,16));check(!address_range(last-16,1,17));
 std::cout<<checks<<" CUDA image capture checks: exact/partial read failures, adjacent readable regions, changing headers, size bounds, all truncations and address overflow. Host readers only.\n";
}
