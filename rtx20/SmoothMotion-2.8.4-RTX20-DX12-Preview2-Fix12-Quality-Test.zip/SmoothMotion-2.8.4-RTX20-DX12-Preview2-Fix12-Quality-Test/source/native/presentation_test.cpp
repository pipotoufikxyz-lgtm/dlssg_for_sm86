#include "include/nvs30/presentation_policy.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace nvs30::presentation;
constexpr auto hr(std::uint32_t value){return static_cast<std::int32_t>(value);}
int main(){
    for(unsigned sync=0;sync<=4;++sync){assert(request(sync,0,false)==Request::frame);assert(request(sync,1,false)==Request::probe);}
    for(unsigned flags:{2u,3u,4u,8u,9u,16u,32u,64u,256u,512u,~0u})assert(request(0,flags,false)==Request::original);
    assert(request(5,0,false)==Request::original);assert(request(0,0,true)==Request::original);assert(request(0,1,true)==Request::original);
    unsigned cases=0;
    // Inject successful, occluded, transient-busy, mode-change, invalid-call,
    // device-lost and arbitrary error results into the production dispatcher.
    for(bool probe:{false,true})for(auto code:{0u,occluded,still_drawing,0x087a0007u,0x80070057u,0x887a0001u,0x887a0005u,0x887a0006u,0x80004005u}){
        std::vector<int> trace;
        auto result=submit(probe,[&]{trace.push_back(1);return hr(code);},[&]{trace.push_back(2);},[&](auto error){assert(error==hr(code));trace.push_back(3);},[&]{trace.push_back(4);return hr(0x887a0007u);});
        if(fatal(hr(code))){assert((trace==std::vector<int>{1,3,4}));assert(result==hr(0x887a0007u));}
        else if(code==0&&!probe){assert((trace==std::vector<int>{1,2}));assert(result==0);}
        else{assert((trace==std::vector<int>{1}));assert(result==hr(code));}
        ++cases;
    }
    // Activity from initialization cannot keep an inactive bridge alive.
    ProgressWindow progress;progress.start(9000);
    for(unsigned i=1;i<64;++i)assert(progress.accepted(9000));
    assert(!progress.accepted(9000));
    for(unsigned i=0;i<1000;++i)assert(!progress.accepted(9000));
    // A fresh call restarts a bounded observation window, never a lifetime
    // "some CUDA once succeeded" flag.
    assert(progress.accepted(9001));
    for(unsigned i=1;i<64;++i)assert(progress.accepted(9001));
    assert(!progress.accepted(9001));
    progress.start(100);
    for(unsigned i=1;i<64;++i){assert(progress.accepted(99));}
    assert(!progress.accepted(99));
    // Repeated occlusion/TEST/busy outcomes do not consume warm-up frames.
    progress.start(0);unsigned accepted=0;
    for(unsigned i=0;i<1000;++i){
        for(auto code:{occluded,still_drawing})submit(false,[&]{return hr(code);},[&]{++accepted;progress.accepted(0);},[](auto){assert(false);},[]{assert(false);return 0;});
        submit(true,[]{return 0;},[&]{++accepted;progress.accepted(0);},[](auto){assert(false);},[]{assert(false);return 0;});
    }
    assert(!accepted);for(unsigned i=1;i<64;++i)assert(progress.accepted(0));assert(!progress.accepted(0));
    // Reproduce the old 64-frame shutdown, then distinguish an independently
    // confirmed native wrapper from an unconfirmed bridge using the same
    // production policy called by accepted_present(). Missing interception is
    // not a verified loss of generated frames.
    for(bool wrapped:{false,true}){
        progress.start(9000);
        for(unsigned i=1;i<64;++i)assert(progress.assess(9000,wrapped)==Activity::within_window);
        const auto expected=wrapped?Activity::unobserved:Activity::retire_unconfirmed;
        for(unsigned i=0;i<10000;++i)assert(progress.assess(9000,wrapped)==expected);
        assert(progress.assess(9001,wrapped)==Activity::within_window);
        for(unsigned i=1;i<64;++i)assert(progress.assess(9001,wrapped)==Activity::within_window);
        assert(progress.assess(9001,wrapped)==expected);
        progress.start(17);
        for(unsigned i=1;i<64;++i)assert(progress.assess(17,wrapped)==Activity::within_window);
        assert(progress.assess(17,wrapped)==expected);
    }
    std::cout<<"PASS: "<<cases<<" Present result/probe cases; exact fallback order and HRESULT propagation; confirmed wrapper survives 10,000 silent observations; unconfirmed deadline retained; reset/recovery; no health credit for probes/occlusion/backpressure. GPU execution NOT tested.\n";
}
