// Execute the production factory registration path with ABI-shaped COM seams.
// No NVIDIA/Windows execution is implied by these host checks.
#include "include/nvs30/presentation_profile.hpp"
#include "include/nvs30/graphics_initialization.hpp"
#include "include/nvs30/hook_group.hpp"
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>

using namespace nvs30;
using HRESULT=std::int32_t;using UINT=unsigned;using HWND=void*;
constexpr HRESULT E_FAIL=-1;
#define STDMETHODCALLTYPE
#define SUCCEEDED(hr) ((hr)>=0)
#define NVS30_CALLER_ADDRESS() nullptr
#define __uuidof(T) 1
using SRWLOCK=int;
#define SRWLOCK_INIT 0
void AcquireSRWLockShared(SRWLOCK*){} void ReleaseSRWLockShared(SRWLOCK*){}
void AcquireSRWLockExclusive(SRWLOCK*){} void ReleaseSRWLockExclusive(SRWLOCK*){}
unsigned queries=0,reads=0,writes=0;
struct IUnknown {void** table{};HRESULT QueryInterface(int,void** out){++queries;*out=this;return 0;}};
struct IDXGIFactory:IUnknown{};struct IDXGIFactory1:IDXGIFactory{};
struct IDXGIFactory2:IDXGIFactory{};
struct IDXGISwapChain:IUnknown{};struct IDXGISwapChain1:IDXGISwapChain{};
struct IDXGIOutput{};struct DXGI_SWAP_CHAIN_DESC{HWND OutputWindow{};};
struct DXGI_SWAP_CHAIN_DESC1{};struct DXGI_SWAP_CHAIN_FULLSCREEN_DESC{};
template<class T>struct Com{T* p{};T** put(){return &p;}};
template<class F,class E,std::size_t N>F recoverOriginal(F observed,F own,const std::array<E,N>& entries,unsigned count,F E::*member){
 if(observed!=own)return observed;F result=nullptr;
 for(unsigned i=0;i<count;++i){auto candidate=entries[i].*member;if(!candidate||candidate==own)continue;if(result&&result!=candidate)return nullptr;result=candidate;}return result;
}
auto profile=presentation_profile::Profile::standard;
bool observeGraphicsObjects(){return presentation_profile::object_hooks(profile);}
bool internalCreation=false;
void registerSwapchain(IUnknown*){} void beforeSwapchain(HWND){}
void logf(const char*,...){}
bool readSlot(void** p,void*& value){++reads;value=*p;return true;}
bool patch(void** p,void* expected,void* after){assert(*p==expected);++writes;*p=after;return true;}
namespace imports {
template<class Before,class Forward,class After>HRESULT graphicsCall(const void*,bool,Before before,Forward forward,After after){before();auto r=forward();after(r);return r;}
}
#ifndef NVS30_FACTORY_HOOKS_HEADER
#define NVS30_FACTORY_HOOKS_HEADER "include/nvs30/factory_hooks.hpp"
#endif
#include NVS30_FACTORY_HOOKS_HEADER
HRESULT originalSwap(IDXGIFactory*,IUnknown*,DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**){return 7;}
HRESULT originalHwnd(IDXGIFactory2*,IUnknown*,HWND,const DXGI_SWAP_CHAIN_DESC1*,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*,IDXGIOutput*,IDXGISwapChain1**){return 9;}
HRESULT originalCore(IDXGIFactory2*,IUnknown*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**){return 11;}
HRESULT originalComposition(IDXGIFactory2*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**){return 13;}
int main(){
 using namespace presentation_profile;
 for(const auto* p:{L"sora_2nd.exe",L"D:\\Games\\Trails in the Sky 2nd Chapter\\sora_2nd.exe",L"D:/Games/SORA_2ND.EXE",L"\\\\?\\D:\\Games\\SoRa_2nD.ExE"})assert(select(p)==Profile::trails_native);
 for(const auto* p:{L"",L"sora_2nd.exe.bak",L"sora_2nd.exe\\launcher.exe",L"sora_2nd.exe.old",L"sora_2nd.exe --steam",L"sora_2nd.exe/",L"other_sora_2nd.exe",L"Dead Space.exe",L"KingdomCome.exe",L"GenshinImpact.exe"})assert(select(p)==Profile::standard);
 std::array<void*,25> table{};
 table[10]=reinterpret_cast<void*>(&originalSwap);table[15]=reinterpret_cast<void*>(&originalHwnd);table[16]=reinterpret_cast<void*>(&originalCore);table[24]=reinterpret_cast<void*>(&originalComposition);
 const auto before=table;IDXGIFactory factory;factory.table=table.data();
 // An alias represents an overlay or a second factory sharing the same table.
 IDXGIFactory overlay;overlay.table=table.data();
 unsigned starts=0,creations=0;
 GraphicsInitialization gate;
 for(unsigned i=0;i<3;++i){
  assert(gate.run([&]{profile=select(L"D:\\Game\\sora_2nd.exe");return true;},[&]{++starts;return true;}));
  ++creations;
  assert(!dx12::hookFactory(&factory));
  assert(!dx12::registerFactory(&factory,25));
  assert(!dx12::hookFactory(&overlay));
 }
 assert(starts==1&&creations==3&&queries==0&&reads==0&&writes==0&&table==before&&dx12::factoryCount==0);
 // Even an unusable object must not be touched in the native-only profile.
 assert(!dx12::hookFactory(reinterpret_cast<IDXGIFactory*>(std::uintptr_t{1})));
 assert(!dx12::registerFactory(nullptr,25));
 assert(std::string_view(counter_kind(profile))=="disabled_native_presentation");
 // KCD II uses its native D3D12 path; first-game/launcher false positives stay standard.
 for(const auto* path:{L"D:/Games/KCD2/Bin/Win64MasterMasterSteamPGO/KingdomCome.exe",L"D:/BIN/WIN64MASTERMASTERSTEAMPGO/KINGDOMCOME.EXE"}){
  profile=select(path);assert(profile==Profile::kcd2_native);
  assert(!dx12::hookFactory(&factory)&&!dx12::registerFactory(&factory,25));
  assert(queries==0&&reads==0&&writes==0&&table==before);
 }
 for(const auto* path:{L"D:/Games/KCD1/Bin/Win64/KingdomCome.exe",L"D:/Games/Bin/Win64MasterMasterSteamPGO/launcher.exe",L"D:/Games/Bin/Win64MasterMasterSteamPGO-Backup/KingdomCome.exe"})assert(select(path)==Profile::standard);
 // Other games keep the existing factory hooks and original method forwarding.
 profile=Profile::standard;
 assert(dx12::hookFactory(&factory)&&queries>0&&writes==4);
 const auto patched=table;assert(dx12::hookFactory(&overlay)&&table==patched&&writes==4);
 assert(dx12::onCreateSwap(&factory,nullptr,nullptr,nullptr)==7);
 assert(dx12::onCreateHwnd(reinterpret_cast<IDXGIFactory2*>(&factory),nullptr,nullptr,nullptr,nullptr,nullptr,nullptr)==9);
 assert(dx12::onCreateCore(reinterpret_cast<IDXGIFactory2*>(&factory),nullptr,nullptr,nullptr,nullptr,nullptr)==11);
 assert(dx12::onCreateComposition(reinterpret_cast<IDXGIFactory2*>(&factory),nullptr,nullptr,nullptr,nullptr)==13);
 std::puts("PASS: exact Trails/KCD II profiles, initialization once, repeated/shared factory tables untouched, no native-profile COM reads, standard-game hooks and HRESULT forwarding preserved. Windows/GPU/game execution not tested.");
}
