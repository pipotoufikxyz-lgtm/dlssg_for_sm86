#include "include/nvs30/driver_profile.hpp"
#include "include/nvs30/driver_layout.hpp"
#include <openssl/sha.h>
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
using namespace nvs30;
std::string sha(const unsigned char* bytes,std::size_t size){
    unsigned char digest[32]{};SHA256(bytes,size,digest);constexpr char hex[]="0123456789abcdef";std::string out;
    for(auto b:digest){out+=hex[b>>4];out+=hex[b&15];}return out;
}
int main(int argc,char** argv){
    using namespace driver_profile;
    assert(identify(source_sha256,source_size)==Kind::golden61664);
    assert(identify(reference_sha256,source_size)==Kind::suppliedReference);
    assert(identify(source_sha256,source_size-1)==Kind::none);
    assert(identify(output_sha256,source_size)==Kind::none); // Already-transformed input is not original.
    assert(identify(std::string(64,'0'),source_size)==Kind::none);
    const auto plan=edits();assert(plan.size()==41&&non_fp8_kernels.size()==20);
    std::set<std::size_t> changed,covered;
    for(const auto& e:plan)for(std::size_t i=0;i<e.before.size();++i){assert(covered.insert(e.offset+i).second);if(e.before[i]!=e.after[i])changed.insert(e.offset+i);}
    assert(changed.size()==61);
    std::vector<unsigned char> synthetic(source_size);
    for(const auto& e:plan)std::memcpy(synthetic.data()+e.offset,e.before.data(),e.before.size());
    assert(original_sites(synthetic)); // Pattern agreement alone must NOT authorize transformation.
    const auto unchanged=synthetic;assert(!apply_sites_for_validation(synthetic,synthetic)&&synthetic==unchanged);
    std::vector<unsigned char> out{1,2,3};const char* reason{};
    assert(!prepare(synthetic,sha,out,reason)&&out.empty());
    for(const auto& e:plan){synthetic[e.offset]^=1;assert(!original_sites(synthetic));synthetic[e.offset]^=1;}
    synthetic.resize(gate_file_offset+2);assert(!original_sites(synthetic));
    unsigned real=0;
    if(argc==2){
        std::ifstream file(argv[1],std::ios::binary);std::vector<unsigned char> input{std::istreambuf_iterator<char>(file),{}};
        assert(sha(input.data(),input.size())==reference_sha256);
        assert(original_sites(input));
        assert(prepare(input,sha,out,reason));assert(out.size()==input.size());
        assert(sha(out.data(),out.size())==reference_output_sha256);
        std::size_t actual=0;for(std::size_t i=0;i<input.size();++i)if(input[i]!=out[i]){assert(changed.count(i));++actual;}
        assert(actual==61);
        // The SETGE instruction is deliberately untouched. No forced-SIL patch
        // appears in the reviewed 616.64 transform.
        assert(std::memcmp(input.data()+0xb837,out.data()+0xb837,4)==0);
        assert(std::memcmp(out.data()+gate_file_offset,gate_after.data(),4)==0);
        // All 17 FP8 fatbins occupy this reference interval and remain identical.
        assert(std::memcmp(input.data()+0x652300,out.data()+0x652300,0x7d0d70-0x652300)==0);
        driver_layout::Image image;assert(driver_layout::parse(input,image));
        auto verdict=driver_layout::validate(image,input,reference_sha256,sha);
        assert(verdict.accepted&&verdict.profile==Kind::suppliedReference);
        // Supplying the golden identity for different CPU bytes is insufficient.
        assert(!driver_layout::validate(image,input,source_sha256,sha).accepted);
        input[0x1000]^=1;assert(!prepare(input,sha,out,reason)&&out.empty());
        real=1;
    }
    std::cout<<"PASS: exact profile identities, 41 nonoverlapping sites / 61 changed bytes, original-byte rejection, transformed output oracle; supplied reference checked="<<real<<"; actual f36 specimen and GPU execution NOT tested.\n";
}
