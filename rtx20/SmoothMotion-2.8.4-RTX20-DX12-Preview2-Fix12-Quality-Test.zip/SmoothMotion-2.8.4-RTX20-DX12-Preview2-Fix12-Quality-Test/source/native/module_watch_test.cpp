#include "include/nvs30/module_watch.hpp"
#include <iostream>
#include <stdexcept>
int main(){
 using namespace nvs30::module_watch;
 unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("module watcher check "+std::to_string(checks));};
 Schedule s;check(s.due(100,0,true));s.scanned(100,0);
 check(!s.due(599,0,true));check(s.due(600,0,true));
 s.scanned(600,0);check(s.due(601,1,true));s.scanned(601,1);
 check(!s.due(601,1,true));check(s.due(602,2,true)); // load races previous scan
 s.scanned(29900,2);check(!s.due(30400,2,false)); // fallback interval begins after bootstrap
 s.scanned(30100,2);check(!s.due(35099,2,false));check(s.due(35100,2,false));
 check(!s.due(60099,2,true));check(s.due(60100,2,true));
 check(s.due(40000,3,true));check(s.due(30000,2,true)); // clock regression
 s.scanned(40000,UINT64_MAX);check(s.due(40001,0,true)); // generation wrap
 s.scanned(40001,0);check(!s.due(40002,0,true));
 // An emulator can sit at its launcher for hours and switch renderer later.
 s.scanned(3600000,20);check(s.due(3600001,21,true));
 check(!s.due(3601000,20,true));check(s.due(3630000,20,true));
 check(executable_load(0));check(executable_load(0x1000));
 for(unsigned bit:{1u,2u,0x20u,0x40u}){check(!executable_load(bit));check(!executable_load(bit|0x1000));}
 generation.store(0);generation.fetch_add(1,std::memory_order_relaxed);check(generation.load()==1);
 std::cout<<checks<<" watcher checks: delayed renderer loads, coalescing, scan races, fallback, periodic repair, resource loads; host schedule only.\n";
}
