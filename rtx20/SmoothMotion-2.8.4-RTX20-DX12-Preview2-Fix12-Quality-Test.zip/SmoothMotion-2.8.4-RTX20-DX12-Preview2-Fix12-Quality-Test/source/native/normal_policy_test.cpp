#include "../normal_policy.hpp"
#include <cassert>
#include "../motion/dx12_policy.hpp"
int main(){using namespace normal_motion;
 for(unsigned bits=0;bits<16;++bits){assert(supportedAPIs(bits)==((bits&3)!=0));assert(motion::supportedAPIs(bits)==(!bits||(bits&3)!=0));}
assert(choice("native"));for(auto s:{"x2","x3","x4","","Native","unknown"})assert(!choice(s));assert(supportedAPIs(1)&&supportedAPIs(2)&&supportedAPIs(3));assert(!supportedAPIs(0)&&!supportedAPIs(4)&&!supportedAPIs(8)&&!supportedAPIs(12));}
