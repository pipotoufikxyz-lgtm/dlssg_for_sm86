// Exercise the actual production forwarding wrappers with deterministic Win32
// seams. This is not Windows execution or a replacement for an in-game test.
#define NVS_VERSION_PROXY_TEST
#include "src/version_proxy.cpp"
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <vector>
#include <barrier>

extern "C" {IMAGE_DOS_HEADER __ImageBase{};}
namespace {
std::atomic<unsigned> checks=0,loads=0,releases=0,lookups=0;
thread_local DWORD error=0;
int backing=0;
bool badDirectory=false,failLoad=false,selfLoad=false,missing=false,reenter=false;
std::barrier<>* loadBarrier=nullptr;
char textA[8][4]{};wchar_t textW[8][4]{};
DWORD handleSize=0;UINT lengths[2]{};LPVOID output=nullptr;
void check(bool condition){++checks;if(!condition){std::fputs("proxy check failed\n",stderr);std::abort();}}
void forwarded(){check(error==0xABCDEF01u);SetLastError(0x12345678u);}
}
DWORD GetLastError(){return error;}void SetLastError(DWORD value){error=value;}
UINT GetSystemDirectoryW(LPWSTR buffer,UINT capacity){
 check(capacity==MAX_PATH);SetLastError(900);
 if(badDirectory)return MAX_PATH;
 const wchar_t value[]=L"C:\\Windows\\System32";std::memcpy(buffer,value,sizeof(value));return 19;
}
HMODULE LoadLibraryExW(LPCWSTR path,HANDLE file,DWORD flags){
 ++loads;check(std::wstring(path)==L"C:\\Windows\\System32\\version.dll");check(!file&&flags==LOAD_LIBRARY_SEARCH_SYSTEM32);
 if(reenter){reenter=false;check(!nvs_GetFileVersionInfoA(nullptr,0,0,nullptr));check(GetLastError()==ERROR_POSSIBLE_DEADLOCK);}
 if(failLoad){SetLastError(5);return nullptr;}
 if(loadBarrier)loadBarrier->arrive_and_wait();
 SetLastError(901);return selfLoad?static_cast<void*>(&__ImageBase):&backing;
}
BOOL FreeLibrary(HMODULE value){++releases;check(value==&backing||value==&__ImageBase);SetLastError(902);return 1;}
FARPROC GetProcAddress(HMODULE module,LPCSTR name){
 ++lookups;check(module==&backing);SetLastError(903);if(missing)return nullptr;
#define RESOLVE(n) if(!std::strcmp(name,#n))return reinterpret_cast<FARPROC>(&n)
 RESOLVE(GetFileVersionInfoA);RESOLVE(GetFileVersionInfoW);RESOLVE(GetFileVersionInfoExA);RESOLVE(GetFileVersionInfoExW);
 RESOLVE(GetFileVersionInfoSizeA);RESOLVE(GetFileVersionInfoSizeW);RESOLVE(GetFileVersionInfoSizeExA);RESOLVE(GetFileVersionInfoSizeExW);
 RESOLVE(GetFileVersionInfoByHandle);RESOLVE(VerFindFileA);RESOLVE(VerFindFileW);RESOLVE(VerInstallFileA);RESOLVE(VerInstallFileW);
 RESOLVE(VerLanguageNameA);RESOLVE(VerLanguageNameW);RESOLVE(VerQueryValueA);RESOLVE(VerQueryValueW);
#undef RESOLVE
 return nullptr;
}
extern "C" {
BOOL GetFileVersionInfoA(LPCSTR a,DWORD b,DWORD c,LPVOID d){forwarded();check(a==textA[0]&&b==17&&c==23&&d==&backing);return 1;}
BOOL GetFileVersionInfoW(LPCWSTR a,DWORD b,DWORD c,LPVOID d){forwarded();check(a==textW[0]&&b==17&&c==23&&d==&backing);return 1;}
BOOL GetFileVersionInfoExA(DWORD a,LPCSTR b,DWORD c,DWORD d,LPVOID e){forwarded();check(a==11&&b==textA[0]&&c==17&&d==23&&e==&backing);return 1;}
BOOL GetFileVersionInfoExW(DWORD a,LPCWSTR b,DWORD c,DWORD d,LPVOID e){forwarded();check(a==11&&b==textW[0]&&c==17&&d==23&&e==&backing);return 1;}
DWORD GetFileVersionInfoSizeA(LPCSTR a,LPDWORD b){forwarded();check(a==textA[0]&&b==&handleSize);*b=33;return 41;}
DWORD GetFileVersionInfoSizeW(LPCWSTR a,LPDWORD b){forwarded();check(a==textW[0]&&b==&handleSize);*b=34;return 42;}
DWORD GetFileVersionInfoSizeExA(DWORD a,LPCSTR b,LPDWORD c){forwarded();check(a==11&&b==textA[0]&&c==&handleSize);*c=35;return 43;}
DWORD GetFileVersionInfoSizeExW(DWORD a,LPCWSTR b,LPDWORD c){forwarded();check(a==11&&b==textW[0]&&c==&handleSize);*c=36;return 44;}
BOOL GetFileVersionInfoByHandle(DWORD a,HANDLE b,LPVOID* c,PDWORD d){forwarded();check(a==11&&b==&backing&&c==&output&&d==&handleSize);*c=&backing;*d=0xDEADBEEF;return 1;}
DWORD VerFindFileA(DWORD a,LPSTR b,LPSTR c,LPSTR d,LPSTR e,PUINT f,LPSTR g,PUINT h){forwarded();check(a==11&&b==textA[1]&&c==textA[2]&&d==textA[3]&&e==textA[4]&&f==&lengths[0]&&g==textA[5]&&h==&lengths[1]);return 51;}
DWORD VerFindFileW(DWORD a,LPWSTR b,LPWSTR c,LPWSTR d,LPWSTR e,PUINT f,LPWSTR g,PUINT h){forwarded();check(a==11&&b==textW[1]&&c==textW[2]&&d==textW[3]&&e==textW[4]&&f==&lengths[0]&&g==textW[5]&&h==&lengths[1]);return 52;}
DWORD VerInstallFileA(DWORD a,LPSTR b,LPSTR c,LPSTR d,LPSTR e,LPSTR f,LPSTR g,PUINT h){forwarded();check(a==11&&b==textA[1]&&c==textA[2]&&d==textA[3]&&e==textA[4]&&f==textA[5]&&g==textA[6]&&h==&lengths[1]);return 53;}
DWORD VerInstallFileW(DWORD a,LPWSTR b,LPWSTR c,LPWSTR d,LPWSTR e,LPWSTR f,LPWSTR g,PUINT h){forwarded();check(a==11&&b==textW[1]&&c==textW[2]&&d==textW[3]&&e==textW[4]&&f==textW[5]&&g==textW[6]&&h==&lengths[1]);return 54;}
DWORD VerLanguageNameA(DWORD a,LPSTR b,DWORD c){forwarded();check(a==11&&b==textA[0]&&c==23);return 61;}
DWORD VerLanguageNameW(DWORD a,LPWSTR b,DWORD c){forwarded();check(a==11&&b==textW[0]&&c==23);return 62;}
BOOL VerQueryValueA(LPCVOID a,LPCSTR b,LPVOID* c,PUINT d){forwarded();check(a==&backing&&b==textA[0]&&c==&output&&d==&lengths[0]);return 1;}
BOOL VerQueryValueW(LPCVOID a,LPCWSTR b,LPVOID* c,PUINT d){forwarded();check(a==&backing&&b==textW[0]&&c==&output&&d==&lengths[0]);return 1;}
}
int main(){
 badDirectory=true;check(!nvs_GetFileVersionInfoA(nullptr,0,0,nullptr));check(GetLastError()==ERROR_INSUFFICIENT_BUFFER&&loads==0);badDirectory=false;
 failLoad=true;check(!nvs_GetFileVersionInfoA(nullptr,0,0,nullptr));check(GetLastError()==5);failLoad=false;
 selfLoad=true;check(!nvs_GetFileVersionInfoA(nullptr,0,0,nullptr));check(GetLastError()==ERROR_BAD_EXE_FORMAT&&releases==1);selfLoad=false;
 reenter=true;missing=true;check(!nvs_GetFileVersionInfoA(nullptr,0,0,nullptr));check(GetLastError()==ERROR_PROC_NOT_FOUND);
 check(nvs_VerInstallFileA(0,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr)==VIF_CANNOTREADSRC);check(GetLastError()==ERROR_PROC_NOT_FOUND);
 check(nvs_VerFindFileW(0,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr)==VFF_BUFFTOOSMALL);check(GetLastError()==ERROR_PROC_NOT_FOUND);missing=false;
#define RUN(call,expected) SetLastError(0xABCDEF01u);check((call)==(expected));check(GetLastError()==0x12345678u)
 RUN(nvs_GetFileVersionInfoA(textA[0],17,23,&backing),1);RUN(nvs_GetFileVersionInfoW(textW[0],17,23,&backing),1);
 RUN(nvs_GetFileVersionInfoExA(11,textA[0],17,23,&backing),1);RUN(nvs_GetFileVersionInfoExW(11,textW[0],17,23,&backing),1);
 RUN(nvs_GetFileVersionInfoSizeA(textA[0],&handleSize),41);check(handleSize==33);
 RUN(nvs_GetFileVersionInfoSizeW(textW[0],&handleSize),42);check(handleSize==34);
 RUN(nvs_GetFileVersionInfoSizeExA(11,textA[0],&handleSize),43);check(handleSize==35);
 RUN(nvs_GetFileVersionInfoSizeExW(11,textW[0],&handleSize),44);check(handleSize==36);
 RUN(nvs_GetFileVersionInfoByHandle(11,&backing,&output,&handleSize),1);check(output==&backing&&handleSize==0xDEADBEEF);
 RUN(nvs_VerFindFileA(11,textA[1],textA[2],textA[3],textA[4],&lengths[0],textA[5],&lengths[1]),51);
 RUN(nvs_VerFindFileW(11,textW[1],textW[2],textW[3],textW[4],&lengths[0],textW[5],&lengths[1]),52);
 RUN(nvs_VerInstallFileA(11,textA[1],textA[2],textA[3],textA[4],textA[5],textA[6],&lengths[1]),53);
 RUN(nvs_VerInstallFileW(11,textW[1],textW[2],textW[3],textW[4],textW[5],textW[6],&lengths[1]),54);
 RUN(nvs_VerLanguageNameA(11,textA[0],23),61);RUN(nvs_VerLanguageNameW(11,textW[0],23),62);
 RUN(nvs_VerQueryValueA(&backing,textA[0],&output,&lengths[0]),1);RUN(nvs_VerQueryValueW(&backing,textW[0],&output,&lengths[0]),1);
 const auto previousLoads=loads.load(),previousLookups=lookups.load();
 std::vector<std::thread> threads;
 for(unsigned i=0;i<8;++i)threads.emplace_back([]{for(unsigned j=0;j<200;++j){RUN(nvs_GetFileVersionInfoA(textA[0],17,23,&backing),1);}});
 for(auto& thread:threads)thread.join();
 check(loads==previousLoads&&lookups==previousLookups);
 // Concurrent uncached module loads retain one owned reference, with no private
 // init lock held around a fake (or real) OS loader call.
 real_version=nullptr;const auto previousReleases=releases.load();threads.clear();std::barrier ready(8),insideLoader(8);loadBarrier=&insideLoader;
 for(unsigned i=0;i<8;++i)threads.emplace_back([&]{ready.arrive_and_wait();check(system_version()==&backing);});
 for(auto& thread:threads)thread.join();
 loadBarrier=nullptr;check(loads-previousLoads==8&&releases-previousReleases==7);
 std::printf("%u standalone proxy checks passed (17 exports, ABI arguments, LastError, failures, recursion, concurrent caches)\n",checks.load());
}
