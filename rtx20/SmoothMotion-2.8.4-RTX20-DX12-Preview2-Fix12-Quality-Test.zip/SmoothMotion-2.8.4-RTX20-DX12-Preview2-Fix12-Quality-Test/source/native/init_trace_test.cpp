#include "include/nvs30/init_trace.hpp"
#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
#include <string_view>

using namespace nvs30::init_trace::detail;
int main() {
    unsigned checks{};
    const auto require = [&](bool condition) { ++checks; assert(condition); };
    for (const auto code : {0xc0000005u, 0xc0000006u, 0xc000001du, 0xc00000fdu, 0x80000003u})
        require(accepted(code));
    for (const auto code : {0u, 0xe06d7363u, 0x80000001u, 0x80000004u, 0xc0000409u})
        require(!accepted(code));
    Fault f{};
    f.code = 0xc0000005u;
    f.moduleBase = 0x7ff900000000;
    f.moduleBytes = 0x810000;
    f.address = f.moduleBase + 0x37ab9;
    f.rip = f.address;
    f.rsp = 0x1000;
    f.rax = 87; f.rcx = 1; f.rdx = 2; f.r8 = 3; f.r9 = 4;
    f.process = 77; f.thread = 42; f.initThread = 41;
    f.parameterCount = 2; f.access = 1; f.target = 0x1234;
    std::array<char, 1024> out{};
    auto run = [&] { return std::string_view(out.data(), format(out.data(), out.size(), f)); };
    auto s = run();
    require(s.find("terminal=unknown phase=NVP_Init_D3D") != s.npos);
    require(s.find("nvp_rva=0x0000000000037ab9") != s.npos);
    require(s.find("access=write") != s.npos);
    require(s.find("target=0x0000000000001234") != s.npos);
    require(s.find("rax=0x0000000000000057") != s.npos);
    require(s.find("rcx=0x0000000000000001") != s.npos);
    require(s.find("rdx=0x0000000000000002") != s.npos);
    require(s.find("r8=0x0000000000000003") != s.npos);
    require(s.find("r9=0x0000000000000004") != s.npos);
    require(s.ends_with("\r\n"));
    f.access = 0; require(run().find("access=read") != s.npos);
    f.access = 8; require(run().find("access=execute") != s.npos);
    f.access = 9; require(run().find("access=unknown") != s.npos);
    f.parameterCount = 1; require(run().find(" access=") == s.npos);
    f.code = 0xc0000006u; f.parameterCount = 3; f.inPageStatus = 0xc0000185u;
    require(run().find("inpage_status=0x00000000c0000185") != s.npos);
    f.parameterCount = 2;
    require(run().find("inpage_status=") == s.npos);
    f.code = 0x80000003u;
    require(run().find(" access=") == s.npos);
    f.address = f.moduleBase - 1;
    require(run().find("nvp_rva=outside") != s.npos);
    f.address = f.moduleBase + f.moduleBytes;
    require(run().find("nvp_rva=outside") != s.npos);
    f.address = f.moduleBase;
    require(run().find("nvp_rva=0x0000000000000000") != s.npos);
    // Subtraction-based range check must also reject overflowed ranges.
    f.moduleBase = ~std::uint64_t{0} - 10; f.moduleBytes = 100; f.address = 20;
    require(run().find("nvp_rva=outside") != s.npos);
    // Exercise every possible truncation boundary with surrounding canaries.
    for (std::size_t cap = 0; cap <= out.size() - 2; ++cap) {
        out.fill('#');
        const auto count = format(out.data() + 1, cap, f);
        require(count <= cap && out.front() == '#' && out[cap + 1] == '#');
    }
    require(format(nullptr, 0, f) == 0);
    for (auto event : {Boundary::Begin, Boundary::End}) {
        const auto bytes = format_boundary(out.data(), out.size(), event, 77, 41, 0x10000, 0x80000);
        const std::string_view line(out.data(), bytes);
        require(line.find(event == Boundary::Begin ? "event=init-trace-begin" : "event=init-trace-end") == 0);
        require(line.find("first-chance-is-not-terminal-proof") != line.npos);
        require(line.find("nvp_base=0x0000000000010000") != line.npos);
        require(line.ends_with("\r\n"));
        for (std::size_t cap = 0; cap <= bytes + 1; ++cap) {
            out.fill('#');
            const auto count = format_boundary(out.data() + 1, cap, event, 77, 41, 0x10000, 0x80000);
            require(count <= cap && out.front() == '#' && out[cap + 1] == '#');
        }
    }
    std::cout << "init trace policy/format: " << checks << " checks passed; Windows VEH dispatch not executed\n";
}
