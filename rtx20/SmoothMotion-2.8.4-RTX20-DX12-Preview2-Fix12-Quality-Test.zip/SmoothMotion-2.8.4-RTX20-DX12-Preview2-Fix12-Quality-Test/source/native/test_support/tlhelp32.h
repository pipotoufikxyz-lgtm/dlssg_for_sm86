#pragma once
// Host-test-only Win32 seams for import_hooks.hpp. Never ship as a Windows SDK
// replacement; this directory is an include path only for import_dispatch_test.
#ifdef _WIN32
#error This test seam is for the non-Windows host fixture only.
#endif
#include <cstddef>
#include <cstdint>
#include <cwchar>
using DWORD=std::uint32_t;using UINT=unsigned;using SIZE_T=std::size_t;using BOOL=int;
using HMODULE=void*;using HANDLE=void*;using LPCWSTR=const wchar_t*;
using FARPROC=void(*)();
using LPCSTR=const char*;
#define WINAPI
constexpr DWORD ERROR_BAD_LENGTH=24,LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE=0x40;
HMODULE LoadLibraryA(LPCSTR);HMODULE LoadLibraryW(LPCWSTR);
HMODULE LoadLibraryExA(LPCSTR,HANDLE,DWORD);HMODULE LoadLibraryExW(LPCWSTR,HANDLE,DWORD);
HMODULE LoadPackagedLibrary(LPCWSTR,DWORD);
constexpr DWORD GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS=4,GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT=2,TH32CS_SNAPMODULE=8,ERROR_NO_MORE_FILES=18;
#define INVALID_HANDLE_VALUE reinterpret_cast<HANDLE>(~std::uintptr_t{})
struct MODULEENTRY32W {DWORD dwSize{};HMODULE hModule{};DWORD modBaseSize{};};
BOOL GetModuleHandleExW(DWORD,LPCWSTR,HMODULE*);
BOOL FreeLibrary(HMODULE);
DWORD GetModuleFileNameW(HMODULE,wchar_t*,DWORD);
DWORD GetWindowsDirectoryW(wchar_t*,DWORD);
HANDLE GetCurrentProcess();
DWORD GetCurrentProcessId();
BOOL ReadProcessMemory(HANDLE,const void*,void*,SIZE_T,SIZE_T*);
HANDLE CreateToolhelp32Snapshot(DWORD,DWORD);
BOOL CloseHandle(HANDLE);
BOOL Module32FirstW(HANDLE,MODULEENTRY32W*);
BOOL Module32NextW(HANDLE,MODULEENTRY32W*);
DWORD GetLastError();
void SetLastError(DWORD);
FARPROC GetProcAddress(HMODULE,const char*);
inline int _wcsnicmp(const wchar_t* a,const wchar_t* b,std::size_t n){return ::wcsncasecmp(a,b,n);}
