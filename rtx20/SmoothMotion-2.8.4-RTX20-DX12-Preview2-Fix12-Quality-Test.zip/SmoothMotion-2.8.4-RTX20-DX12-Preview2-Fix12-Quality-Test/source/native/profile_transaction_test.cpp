#include "include/nvs30/profile_transaction.hpp"
#include <iostream>
#include <stdexcept>
using namespace nvs30;
unsigned checks=0;
void check(bool v){if(!v)throw std::runtime_error("profile transaction check failed");++checks;}
int main(){
 for(auto kind:{driver_profile::Kind::suppliedReference,driver_profile::Kind::nvidia61714}){
 const auto edits=driver_profile::edits(kind);
 using Memory=std::vector<std::array<unsigned char,4>>;
 Memory original(edits.size());for(std::size_t i=0;i<edits.size();++i)original[i]=edits[i].before;
 for(int failure=-1;failure<int(edits.size());++failure){
  auto memory=original;unsigned writes=0;std::vector<bool> owned(edits.size());
  auto result=profile_transaction::run(edits,[&](auto i,auto& out){out=memory[i];return true;},
   [&](auto i,const auto& bytes){++writes;owned[i]=true;memory[i]=bytes;return int(i)!=failure;},
   [&](auto i){if(owned[i]){memory[i]=original[i];owned[i]=false;}return true;});
  if(failure<0){check(result==profile_transaction::Result::Applied);check(writes==edits.size());for(std::size_t i=0;i<edits.size();++i)check(memory[i]==edits[i].after);}
  else{check(result==profile_transaction::Result::RolledBack);check(memory==original);check(writes==unsigned(failure+1));}
 }
 for(std::size_t failure=0;failure<edits.size();++failure){
  auto memory=original;memory[failure][0]^=1;unsigned writes=0;
  check(profile_transaction::run(edits,[&](auto i,auto& out){out=memory[i];return true;},[&](auto,const auto&){++writes;return true;},[](auto){return true;})==profile_transaction::Result::PreflightRejected);
  check(writes==0);
 }
 auto memory=original;unsigned reads=0,writes=0;
 check(profile_transaction::run(edits,[&](auto i,auto& out){++reads;out=memory[i];return reads!=edits.size()+5;},[&](auto i,const auto& bytes){++writes;memory[i]=bytes;return true;},[&](auto i){memory[i]=original[i];return true;})==profile_transaction::Result::RolledBack);
 check(memory==original&&writes==4);
 check(profile_transaction::run(edits,[&](auto i,auto& out){out=memory[i];return true;},[](auto,const auto&){return false;},[](auto){return false;})==profile_transaction::Result::RollbackIncomplete);
 }
 // A missing profile may never report successful application.
 check(profile_transaction::run({},[](auto,auto&){return true;},[](auto,const auto&){return true;},[](auto){return true;})==profile_transaction::Result::PreflightRejected);
 std::cout<<checks<<" 616.64/617.14 loaded-profile transaction checks: all-site preflight, each failed write, read races, rollback failure; host memory only\n";
}
