#include "include/nvs30/initialization_gate.hpp"
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <thread>

namespace {unsigned checks=0;void check(bool value){++checks;if(!value)std::abort();}}
int main(){
 using nvs30::InitializationGate;
 InitializationGate success;unsigned called=0;
 check(success.run([&]{++called;check(!success.run([&]{++called;return false;}));return true;}));
 check(success.run([&]{++called;return false;}));check(called==1);
 InitializationGate rejected;called=0;
 check(!rejected.run([&]{++called;return false;}));check(!rejected.run([&]{++called;return true;}));check(called==1);
 InitializationGate retry;called=0;bool caught=false;
 try{retry.run([&]()->bool{++called;throw std::runtime_error("unpublished configuration");});}catch(const std::runtime_error&){caught=true;}
 check(caught);check(retry.run([&]{++called;return true;}));check(called==2);
 // Model the exact loader-lock inversion: an owner cannot finish until this
 // caller releases a resource. The second call MUST return without waiting.
 // No clocks or sleeps are needed; an implementation that waits will deadlock
 // and fail the test runner's timeout.
 InitializationGate concurrent;std::atomic_bool entered=false,release=false;
 std::atomic_uint executions=0;unsigned published=0;
 std::thread owner([&]{concurrent.run([&]{++executions;entered.store(true,std::memory_order_release);while(!release.load(std::memory_order_acquire))std::this_thread::yield();published=0xCAFE;return true;});});
 while(!entered.load(std::memory_order_acquire))std::this_thread::yield();
 check(!concurrent.run([&]{++executions;return true;}));
 release.store(true,std::memory_order_release);
 while(!concurrent.run([&]{++executions;return false;}))std::this_thread::yield();
 check(published==0xCAFE&&executions==1);owner.join();
 check(concurrent.run([&]{++executions;return false;}));
 // Configuration and logging are separate: a blocked log owner cannot block
 // another configured graphics caller from acquiring runtime initialization.
 InitializationGate configured,logging,runtime;check(configured.run([]{return true;}));
 entered=false;release=false;
 std::thread logger([&]{logging.run([&]{entered.store(true,std::memory_order_release);while(!release.load(std::memory_order_acquire))std::this_thread::yield();return true;});});
 while(!entered.load(std::memory_order_acquire))std::this_thread::yield();
 check(configured.run([]{return false;}));check(!logging.run([]{return false;}));check(runtime.run([]{return true;}));
 release.store(true,std::memory_order_release);logger.join();
 std::printf("%u nonblocking initialization checks passed (reentry, rejection, exception retry, concurrent ownership, publication, independent logging)\n",checks);
}
