"""Build ASI and standalone version carriers from one normal-mode backend."""
import argparse,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--zig',required=True);a=p.parse_args()
src=pathlib.Path(__file__).resolve().parent;root=src.parents[1];destination=root/'payload/native';destination.mkdir(parents=True,exist_ok=True)
files=[p for p in sorted((src/'src').glob('*.cpp')) if p.name not in ['version_proxy.cpp','osd.cpp','pacer.cpp']]
common=[a.zig,'c++','-target','x86_64-windows-gnu','-std=c++20','-O2','-static','-shared','-DUNICODE','-D_UNICODE','-DWIN32_LEAN_AND_MEAN','-DNOMINMAX','-DNVS30_VERSION="2.8.2-r3-gp9-fixes1-normal"','-I'+str(src/'include')]
libraries=['-ld3d11','-ld3d12','-ldxgi','-ldxguid','-luser32','-lgdi32','-lshlwapi','-lbcrypt','-lsetupapi','-ladvapi32']
artifacts={}
for name,extra in [('normal.asi',[]),('version.dll',[src/'src/version_proxy.cpp',src/'src/version_proxy.def'])]:
 out=destination/name
 subprocess.run([*common,*( ['-DNVS30_STANDALONE=1'] if name=='version.dll' else []),*map(str,files),*map(str,extra),*libraries,'-o',str(out)],check=True)
 artifacts[name]={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size}
report={'backend':'NVIDIA Smooth Motion compatibility','version':'2.8.2-r3-gp9-fixes1-normal',**artifacts['normal.asi'],'artifacts':artifacts,'native_windows_executed':False,'GPU_tested':False,'game_compatibility_verified':False,'source_sha256':{str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src.rglob('*')) if p.is_file() and p.suffix in ['.hpp','.h','.cpp','.py','.def']}}
(src/'build-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}))
