#include "include/nvs30/hook_group.hpp"
#include <array>
#include <iostream>
#include <stdexcept>
#include <vector>
int main(){
 using namespace nvs30::hook_group;
 unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("hook group check "+std::to_string(checks));};
 int old[5]{},ours[5]{},external{};
 std::array<void*,5> table{};std::array<Slot,5> slots{};
 auto reset=[&]{for(size_t i=0;i<5;++i){table[i]=old+i;slots[i]={table.data()+i,old+i,ours+i};}};
 unsigned writes=0,reads=0,failWrite=0,failRead=0;
 bool mutate=false,failRollback=false;
 auto read=[&](void** at,void*& value){if(++reads==failRead)return false;value=*at;return true;};
 auto patch=[&](void** at,void* before,void* after){
  ++writes;bool restoring=false;for(auto& value:old)restoring|=after==&value;
  if(failRollback&&restoring)return false;
  if(writes==failWrite){if(mutate)table[0]=&external;return false;}
  if(*at!=before)return false;*at=after;return true;
 };
 reset();check(install(slots,read,patch));check(writes==5);
 check(install(slots,read,patch));check(writes==5); // all already installed
 for(unsigned fail=1;fail<=5;++fail){
  reset();writes=reads=0;failWrite=fail;
  check(!install(slots,read,patch));for(size_t i=0;i<5;++i)check(table[i]==old+i);
 }
 failWrite=0;
 for(unsigned fail=1;fail<=5;++fail){
  reset();writes=reads=0;failRead=fail;
  check(!install(slots,read,patch));check(writes==0); // complete preflight
 }
 failRead=0;reset();writes=reads=0;table[4]=&external;
 check(!install(slots,read,patch));check(writes==0);
 reset();writes=reads=0;failWrite=4;mutate=true;
 check(!install(slots,read,patch));check(table[0]==&external);check(table[1]==old+1);check(table[2]==old+2);
 mutate=false;failWrite=0;
 // Base-interface methods already active; newer methods fail part-way. Roll
 // back only the extension, retaining the three previously installed slots.
 reset();for(size_t i=0;i<3;++i)table[i]=ours+i;
 writes=reads=0;failWrite=2;
 check(!install(slots,read,patch));for(size_t i=0;i<3;++i)check(table[i]==ours+i);
 check(table[3]==old+3&&table[4]==old+4);
 failWrite=0;writes=reads=0;check(install(slots,read,patch));check(writes==2);
 for(size_t i=0;i<5;++i)check(table[i]==ours+i);
 // Simulate an unwriteable rollback: caller must keep originals and regard
 // the group as incomplete, even if one callback could not be removed.
 reset();writes=reads=0;failWrite=3;failRollback=true;
 check(!install(slots,read,patch));check(table[0]==ours&&table[1]==ours+1&&table[2]==old+2);
 failRollback=false;failWrite=0;
 // A base-only view never accesses optional Present1/ResizeBuffers1 slots.
 reset();slots[3]={};slots[4]={};writes=reads=0;
 check(install(slots,read,patch));check(writes==3&&reads==3);
 check(table[3]==old+3&&table[4]==old+4);
 reset();slots[4].original=nullptr;writes=reads=0;check(!install(slots,read,patch));check(writes==0);
 reset();slots[4].original=slots[4].replacement;writes=reads=0;check(!install(slots,read,patch));check(writes==0);
 std::array<Slot,0> empty{};check(!install(empty,read,patch));
 std::cout<<checks<<" hook-group checks: preflight, partial rollback, prior hook preservation, interface extension, optional slots and competing pointer ownership. Host operations only.\n";
}
