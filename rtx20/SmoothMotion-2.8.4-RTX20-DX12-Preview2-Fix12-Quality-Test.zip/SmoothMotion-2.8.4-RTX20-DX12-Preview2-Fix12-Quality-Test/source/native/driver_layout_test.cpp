#include "include/nvs30/driver_layout.hpp"
#include "include/nvs30/import_lookup.hpp"
#include <openssl/sha.h> // Independent host hashing, not the Windows BCrypt implementation.
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
#include <random>
using namespace nvs30::driver_layout;
template<class T> void put(std::vector<unsigned char>& b,std::size_t at,T value){assert(range(at,sizeof value,b.size()));std::memcpy(b.data()+at,&value,sizeof value);}
std::string sha(const unsigned char* b,std::size_t n){
    unsigned char digest[32]{};SHA256(b,n,digest);const char* hex="0123456789abcdef";std::string text;
    for(auto v:digest){text+=hex[v>>4];text+=hex[v&15];}return text;
}
std::vector<unsigned char> fixture(){
    std::vector<unsigned char> b(1024);put<std::uint16_t>(b,0,0x5a4d);put<std::uint32_t>(b,60,0x80);
    put<std::uint32_t>(b,0x80,0x4550);put<std::uint16_t>(b,0x84,0x8664);put<std::uint16_t>(b,0x86,1);
    put<std::uint16_t>(b,0x94,240);put<std::uint16_t>(b,0x96,0x2000);put<std::uint16_t>(b,0x98,0x20b);
    put<std::uint32_t>(b,0xa8,0x1000);put<std::uint32_t>(b,0xd0,0x2000);put<std::uint32_t>(b,0xd4,0x200);
    put<std::uint32_t>(b,0x104,16);std::memcpy(b.data()+0x188,".text",5);
    put<std::uint32_t>(b,0x190,512);put<std::uint32_t>(b,0x194,0x1000);put<std::uint32_t>(b,0x198,512);
    put<std::uint32_t>(b,0x19c,512);put<std::uint32_t>(b,0x1ac,0x60000020);return b;
}
int main(int argc,char** argv){
    Image pe;auto b=fixture();assert(parse(b,pe));assert(!reference_layout(pe,b));
    assert(!validate(pe,b,sha(b.data(),b.size()),sha).accepted);
    for(std::size_t n=0;n<b.size();++n){auto truncated=b;truncated.resize(n);assert(!parse(truncated,pe));}
    for(auto at:{60u,0xd0u,0xd4u,0x190u,0x194u,0x198u,0x19cu}){auto bad=b;put<std::uint32_t>(bad,at,UINT32_MAX);assert(!parse(bad,pe));}
    // A certificate entry is a file offset; it must never overlap mapped code.
    auto certificate=b;certificate.resize(1040);put<std::uint32_t>(certificate,0x128,1024);put<std::uint32_t>(certificate,0x12c,16);assert(parse(certificate,pe));
    put<std::uint32_t>(certificate,0x128,0x200);assert(!parse(certificate,pe));
    auto overlap=b;put<std::uint16_t>(overlap,0x86,2);std::memcpy(overlap.data()+0x1b0,overlap.data()+0x188,40);assert(!parse(overlap,pe));
    std::mt19937 rng(3070);for(unsigned i=0;i<10000;++i){auto bad=b;for(unsigned j=0;j<6;++j)bad[rng()%bad.size()]=static_cast<unsigned char>(rng());
        if(parse(bad,pe)){assert(pe.size<=limit);assert(!reference_layout(pe,bad));export_rva(pe,bad,"NVP_Init_D3D");}
        nvs30::import_lookup::find(bad.data(),bad.size(),"nvcuda.dll","cuModuleLoadData");
        nvs30::import_lookup::find(bad.data(),bad.size(),"nvcuda.dll","cuModuleLoadData",true);}
    unsigned real=0;
    if(argc==2){
        std::ifstream f(argv[1],std::ios::binary);b.assign(std::istreambuf_iterator<char>(f),{});assert(!b.empty());
        assert(sha(b.data(),b.size())=="bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68");
        assert(parse(b,pe)&&reference_layout(pe,b));
        std::vector<unsigned char> mapped(pe.size);
        std::memcpy(mapped.data(),b.data(),0x400);
        for(const auto& s:pe.sections)std::memcpy(mapped.data()+s.rva,b.data()+s.raw,s.bytes);
        auto slot=[&]{return nvs30::import_lookup::find(mapped.data(),mapped.size(),"nvcuda.dll","cuModuleLoadData");};
        assert(slot()==0x1d2820);
        // An unterminated/thunk RVA past the image must not turn into a read
        // from adjacent memory. Mutate the matching descriptor's name table.
        for(unsigned i=0;i<pe.directories[1].second/20;++i){const auto at=pe.directories[1].first+i*20;
            const auto name=read<std::uint32_t>(mapped,at+12);if(range(name,11,mapped.size()) && std::memcmp(mapped.data()+name,"nvcuda.dll",11)==0)put<std::uint32_t>(mapped,at,pe.size-4);}
        assert(slot()==0);
        auto check=[&](const std::vector<unsigned char>& bytes){Image image;return parse(bytes,image)&&validate(image,bytes,sha(bytes.data(),bytes.size()),sha).accepted;};
        assert(check(b));++real;
        // Re-signing, COFF timestamps, checksum and raw section padding do
        // not alter the reviewed CPU instructions or the patch ABI.
        auto changed=b;changed.back()^=1;assert(check(changed));++real;
        const auto nt=read<std::uint32_t>(b,60);
        changed=b;changed[nt+8]^=1;assert(check(changed));++real;
        changed=b;changed[nt+24+64]^=1;assert(check(changed));++real;
        changed=b;changed[pe.sections[0].raw+pe.sections[0].size]^=1;assert(check(changed));++real;
        // These mutations leave every hashed section unchanged but alter how
        // Windows loads/relocates the image. They are not signing metadata.
        changed=b;put<std::uint64_t>(changed,nt+24+24,0x190000000ull);assert(!check(changed));++real;
        changed=b;put<std::uint32_t>(changed,nt+24+32,0x2000);assert(!check(changed));++real;
        changed=b;put<std::uint32_t>(changed,nt+24+36,0x400);assert(!check(changed));++real;
        changed=b;changed[nt+24+70]^=0x40;assert(!check(changed));++real;
        // Every initialized byte in CPU/data/CUDA/unwind/Detours sections
        // must match, not just code or the nearby gate bytes.
        for(auto index:{0u,1u,2u,3u,4u}){changed=b;changed[pe.sections[index].raw+0x100]^=1;assert(!check(changed));++real;}
        // A CUDA instruction mutation must never inherit profile acceptance
        // solely because CPU code and patch-site metadata still match.
        changed=b;changed[0x525000]^=1;assert(!check(changed));++real;
        // Certificate-only growth changes full-file identity, but no mapped
        // initialized section. Retain the exact reference transform profile.
        changed=b;changed.resize(changed.size()+8,0);put<std::uint32_t>(changed,nt+24+112+8*4+4,pe.directories[4].second+8);assert(check(changed));++real;
        changed=b;const auto table=nt+24+read<std::uint16_t>(b,nt+20);changed[table+36]^=1;assert(!check(changed));++real;
        // Export table changes cannot redirect initialization to other code.
        changed=b;const auto exp=offset(pe,pe.directories[0].first,40);const auto functions=offset(pe,read<std::uint32_t>(b,exp+28),4);
        const auto count=read<std::uint32_t>(b,exp+20);
        for(unsigned i=0;i<count;++i)if(read<std::uint32_t>(changed,functions+4*i)==0x59e0)put<std::uint32_t>(changed,functions+4*i,0x59e1);
        assert(!check(changed));++real;
        changed=b;put<std::uint32_t>(changed,nt+24+112+8*9,pe.directories[9].first+8);assert(!check(changed));++real;
    }
    std::cout<<"PASS: PE bounds, overlapping sections/certificates, 10000 malformed headers; real reference cases="<<real<<". GPU execution NOT tested.\n";
}
