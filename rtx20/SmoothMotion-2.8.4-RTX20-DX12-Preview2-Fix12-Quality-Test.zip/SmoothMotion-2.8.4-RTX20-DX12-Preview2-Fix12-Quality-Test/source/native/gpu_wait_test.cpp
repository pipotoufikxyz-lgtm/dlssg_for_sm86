#include "include/nvs30/gpu_wait.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace nvs30::gpu_wait;
constexpr auto error=static_cast<std::int32_t>(0x8007000eu);
int main() {
    unsigned cases=0;
    auto test=[&](std::uint64_t target,std::vector<std::uint64_t> values,
                  std::vector<std::int32_t> waits,std::vector<std::uint64_t> times,
                  std::int32_t arm_result,std::int32_t expected,unsigned arms_expected,
                  std::vector<unsigned> budgets) {
        unsigned reads=0,arms=0,waited=0,ticks=0;
        auto result=fence(target,500,
            [&]{assert(reads<values.size());return values[reads++];},
            [&](auto value){assert(value==target);++arms;return arm_result;},
            [&](unsigned budget){assert(waited<waits.size());assert(budget==budgets[waited]);return waits[waited++];},
            [&]{assert(ticks<times.size());return times[ticks++];});
        assert(result==expected&&arms==arms_expected&&waited==waits.size());
        assert(reads==values.size()&&ticks==times.size());++cases;
    };
    test(0,{}, {}, {},0,0,0,{});
    test(9,{9},{},{100},0,0,0,{});
    test(9,{12},{},{100},0,0,0,{});
    test(9,{removed},{},{100},0,device_removed,0,{});
    test(9,{8},{},{100},error,error,1,{});
    test(9,{8,9},{},{100},0,0,1,{}); // completion races event registration
    test(9,{8,8,9},{0},{100,100},0,0,1,{500});
    test(9,{8,8,8,9},{0,0},{100,100,120},0,0,1,{500,480}); // stale wake
    test(9,{8,8,8},{timeout},{100,100},0,timeout,1,{500});
    test(9,{8,8,9},{timeout},{100,100},0,0,1,{500}); // timeout race
    test(9,{8,8,removed},{timeout},{100,100},0,device_removed,1,{500});
    test(9,{8,8,removed},{0},{100,100},0,device_removed,1,{500});
    test(9,{8,8},{error},{100,100},0,error,1,{500});
    test(9,{8,8,8},{0},{100,100,600},0,timeout,1,{500}); // wakes cannot extend deadline
    test(9,{8,8},{},{100,601},0,timeout,1,{});
    test(removed-1,{removed-1},{},{100},0,0,0,{});
    std::cout<<"PASS: "<<cases<<" production fence-wait cases: exact completion, stale wake, timeout race, deadline, removal and original error. Host callbacks only.\n";
}
