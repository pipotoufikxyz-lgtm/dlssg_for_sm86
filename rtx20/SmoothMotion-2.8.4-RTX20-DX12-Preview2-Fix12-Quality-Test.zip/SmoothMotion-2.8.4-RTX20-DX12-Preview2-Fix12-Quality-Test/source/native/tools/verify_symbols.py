#!/usr/bin/env python3
"""Match each source-built PE to its exact PDB; no Windows execution."""
import argparse,hashlib,json,pathlib,struct,sys,uuid
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[3]);a=p.parse_args();root=a.root.resolve()
sys.path.insert(0,str(root/'source/native/tools'))
from inspect_nvp import PE
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pdb_stream(path,index):
 b=path.read_bytes();assert b.startswith(b'Microsoft C/C++ MSF 7.00')
 block,free,count,dbytes,reserved,mapblock=struct.unpack_from('<6I',b,32)
 blocks=(dbytes+block-1)//block
 directory_ids=struct.unpack_from('<'+'I'*blocks,b,mapblock*block)
 d=b''.join(b[n*block:(n+1)*block] for n in directory_ids)[:dbytes]
 streams=struct.unpack_from('<I',d)[0];sizes=struct.unpack_from('<'+'I'*streams,d,4);at=4+4*streams
 for i,size in enumerate(sizes):
  n=0 if size==0xffffffff else (size+block-1)//block
  ids=struct.unpack_from('<'+'I'*n,d,at);at+=4*n
  if i==index:return b''.join(b[j*block:(j+1)*block] for j in ids)[:size]
 raise ValueError(index)
items=[]
for binary,symbol in [('payload/native/normal.asi','payload/native/normal.pdb'),('payload/native/version.dll','payload/native/version.pdb'),('Install.exe','Install.pdb'),('SmoothMotion_Manager.exe','SmoothMotion_Manager.pdb'),('Collect_Diagnostics.exe','source/diagnostic/Collect_Diagnostics.pdb')]:
 pe=PE(root/binary);rva,size=struct.unpack_from('<II',pe.data,pe.optional+112+6*8);offset=pe.rva_to_offset(rva);found=[]
 for i in range(0,size,28):
  chars,stamp,major,minor,kind,n,addr,ptr=struct.unpack_from('<IIHHIIII',pe.data,offset+i)
  if kind==2 and pe.data[ptr:ptr+4]==b'RSDS':found.append((pe.data[ptr+4:ptr+20],struct.unpack_from('<I',pe.data,ptr+20)[0]))
 assert len(found)==1,(binary,found)
 guid,age=found[0];stream=pdb_stream(root/symbol,1)
 assert stream[12:28]==guid and struct.unpack_from('<I',stream,8)[0]==age,(binary,'PDB mismatch')
 items.append({'binary':binary,'sha256':sha(root/binary),'pdb':symbol,'pdb_sha256':sha(root/symbol),'guid':str(uuid.UUID(bytes_le=guid)),'age':age,'matches':True})
portable=json.loads((root/'validation/portable-normal.json').read_text())
assert portable['result']=='PASS' and all(r['result']=='PASS' for r in portable['results'])
report={'release':'2.8.2-r3-gp9-fixes1-normal','status':'PASS','symbol_pairs':items,'host_suites':portable['suite_count'],'host_test_runs':len(portable['results']),'native_windows_executed':False,'GPU_tested':False,'game_compatibility_verified':False}
(root/'validation/runtime-review-2.8.2-r3-gp9-fixes1-normal.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: five exact binary/PDB CodeView GUID and age matches.')
