#!/usr/bin/env python3
"""Check built package evidence; optionally inspect a reference NvPresent file.

This is not Windows, CUDA, interpolation-quality or in-game validation.
"""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[3]
subprocess.run([sys.executable,str(root/'source/verify_package.py'),'--root',str(root)],check=True)
if len(sys.argv)>1:subprocess.run([sys.executable,str(Path(__file__).with_name('inspect_nvp.py')),sys.argv[1]],check=True)
