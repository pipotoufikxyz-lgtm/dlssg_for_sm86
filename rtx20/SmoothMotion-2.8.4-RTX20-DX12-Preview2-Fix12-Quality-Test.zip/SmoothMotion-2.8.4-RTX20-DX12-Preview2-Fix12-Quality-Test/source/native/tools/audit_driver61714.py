#!/usr/bin/env python3
"""Read-only, reproducible 617.14 CPU/CUDA comparison. Never loads a driver.

Requires NVIDIA nvdisasm for static decoding. Temporary ELF copies are inspected
only; no NVIDIA DLL or model is redistributed. Static decoding is not a GPU test.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile
from inspect_nvp import PE, find_config, find_gate

REFERENCE = 'bec8ba29073614b0f195ee3f0c628a0beb22faeb08613bb1fbf895459d373e68'
DRIVER = '1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f'
OUTPUT = 'bcdc615f9492070c7a9ba31addd910373766ad293e777abdcbface28ad493c49'
sha = lambda b: hashlib.sha256(b).hexdigest()

def span(b, at, n):
    if at < 0 or n < 0 or at > len(b) or n > len(b)-at:
        raise ValueError('out of bounds binary span')
    return b[at:at+n]

def read(fmt, b, at):
    return struct.unpack(fmt, span(b, at, struct.calcsize(fmt)))

def sections(b, offsets=False):
    assert span(b, 0, 6) == b'\x7fELF\x02\x01' and read('<H', b, 18)[0] == 190
    table = read('<Q', b, 40)[0]
    width, count, index = read('<HHH', b, 58)
    assert width == 64 and 0 < count <= 4096 and index < count
    span(b, table, width*count)
    names = span(b, *read('<QQ', b, table+index*width+24))
    out = {}
    for i in range(count):
        row = table+i*width
        at, kind = read('<II', b, row)
        assert at < len(names)
        name = names[at:names.index(0, at)].decode()
        data = b'' if kind == 8 else span(b, *read('<QQ', b, row+24))
        assert name not in out
        out[name] = read("<Q", b, row+24)[0] if offsets else data
    return out

def modules(b):
    result = {}; cursor = 0; containers = 0
    while True:
        at = b.find(b'\x50\xed\x55\xba', cursor)
        if at < 0: break
        version, header, length = read('<HHQ', b, at+4)
        assert version == 1 and 16 <= header <= 256 and length <= 64*1024*1024
        span(b, at, header+length); pos = at+header; end = pos+length; containers += 1
        while pos < end:
            kind, ev, eh, ds = read('<HHIQ', b, pos)
            assert kind == 2 and ev == 0x101 and 32 <= eh <= 1024 and eh+ds <= end-pos
            sm = read('<I', b, pos+28)[0]; elf = span(b, pos+eh, ds); s = sections(elf)
            names = [k[6:] for k in s if k.startswith('.text.')]
            assert len(names) == 1 and (sm, names[0]) not in result
            result[sm, names[0]] = dict(elf=elf, sections=s, tag=pos+28,
                                        flags=pos+eh+48, elf_start=pos+eh, container=at)
            raw = pos+eh+ds; pos = raw if raw == end else (raw+7)&~7
            assert pos <= end
        cursor = end
    assert containers == 37 and len(result) == 74
    return result

def decode(tool, blob, path):
    path.write_bytes(blob)
    run = subprocess.run([str(tool), '-c', str(path)], capture_output=True, text=True, timeout=30)
    assert run.returncode == 0, run.stderr
    instructions = re.findall(r'/\*[0-9a-fA-F]+\*/\s+((?:@!?U?P(?:T|\d+)\s+)?[A-Z][^;]*);', run.stdout)
    assert instructions
    return instructions, run.stderr.strip()

def canonical(lines):
    # nvdisasm spells this same FP32-to-FP16 encoding differently on SM86/89.
    # Both affected kernel text sections also match the earlier reference byte-for-byte.
    return [line.replace('F2FP.F16.F32.PACK_AB', 'F2FP.PACK_AB') for line in lines]

def opcode(line):
    return re.sub(r'^@!?U?P(?:T|\d+)\s+', '', line).split()[0]

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--reference', type=Path, required=True)
    p.add_argument('--driver', type=Path, required=True)
    p.add_argument('--nvdisasm', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    old, new = PE(args.reference), PE(args.driver)
    assert sha(old.data) == REFERENCE and sha(new.data) == DRIVER
    before, after = modules(old.data), modules(new.data)
    assert before.keys() == after.keys()
    init = new.exports()['NVP_Init_D3D']
    assert init == 0x59e0 and find_config(new, init) == 0x7f0cd0
    assert find_gate(new) == [(0xc41f, 0xc437)]
    cpu = []
    for rva, size, label in [(0x9ed0, 37, 'configuration readiness'),
                             (0x9fd0, 306, 'configuration fields and initialization'),
                             (0xa110, 5, 'D3D11 configuration accessor'),
                             (0xa120, 5, 'D3D12 configuration accessor'),
                             (0xc400, 59, 'capability comparison and SETGE')]:
        a = span(old.data, old.rva_to_offset(rva), size)
        b = span(new.data, new.rva_to_offset(rva), size)
        assert a == b
        cpu.append(dict(label=label, rva=hex(rva), bytes=size, identical=True, sha256=sha(b)))
    entries = []
    for image, config in [(old, 0x7d7810), (new, 0x7f0cd0)]:
        entry = bytearray(span(image.data, image.rva_to_offset(init), 99))
        for at in [9, 21, 37, 53, 76]:
            assert entry[at:at+3] == b'\x48\x8d\x0d'
            assert init+at+7+read('<i', entry, at+3)[0] == config
            entry[at+3:at+7] = b'\0'*4
        entries.append(entry)
    assert entries[0] == entries[1]
    output = bytearray(new.data); edits = [(0xb81c, b'\x83\x79\x14\x03', b'\x83\x79\x14\x02')]
    kernels = []; old_ops = Counter(); new_ops = Counter(); tool = args.nvdisasm.resolve()
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/'input.cubin'
        for (sm, name), item in sorted(after.items()):
            if sm != 89 or '_fp8' in name: continue
            elf = item['elf']; prior = before[sm, name]
            assert elf[8] == 8 and read('<I', elf, 48)[0] == 0x06005904
            target = bytearray(elf); target[48:52] = struct.pack('<I', 0x06005604)
            note = item['sections']['.note.nv.cuinfo']
            assert note == bytes.fromhex('0c00000008000000e80300004e564944494120436f7270000200590086000000')
            note_at = sections(elf, offsets=True)['.note.nv.cuinfo']+24
            target[note_at:note_at+4] = bytes.fromhex('02005600')
            a, _ = decode(tool, prior['elf'], path)
            b, warnings = decode(tool, elf, path)
            c, _ = decode(tool, target, path)
            assert canonical(b) == canonical(c)
            old_ops.update(map(opcode, a)); new_ops.update(map(opcode, b))
            text_same = prior['sections']['.text.'+name] == item['sections']['.text.'+name]
            if b != c: assert name in ('downscale_kernel', 'warp_coarse_kernel') and text_same
            edits += [(item['tag'], struct.pack('<I', 89), struct.pack('<I', 86)),
                      (item['flags'], struct.pack('<I', 0x06005904), struct.pack('<I', 0x06005604)),
                      (item['elf_start']+note_at, bytes.fromhex('02005900'), bytes.fromhex('02005600'))]
            kernels.append(dict(name=name, instructions=len(b), elf_abi=8,
                tag_offset=hex(item['tag']), flags_offset=hex(item['flags']),
                virtual_sm_note_offset=hex(item['elf_start']+note_at), virtual_sm=86,
                code_same_as_reference=text_same, instruction_bytes_preserved=True,
                sm86_decode_matches=True, spelling_aliases=sum(x!=y for x,y in zip(b,c)),
                nvdisasm_warnings=warnings, source_elf_sha256=sha(elf), target_elf_sha256=sha(target)))
    assert len(kernels) == 20 and not (new_ops.keys()-old_ops.keys())
    for at, original, replacement in edits:
        assert output[at:at+len(original)] == original
        output[at:at+len(original)] = replacement
    assert sha(output) == OUTPUT
    changes = sum(a!=b for a,b in zip(new.data, output)); assert changes == 61
    # Model paths excluded from the normal SM86 conversion must stay byte-identical.
    excluded = 0
    for (sm, name), item in after.items():
        if sm == 120 or '_fp8' in name:
            assert output[item['elf_start']:item['elf_start']+len(item['elf'])] == item['elf']
            assert output[item['tag']:item['tag']+4] == new.data[item['tag']:item['tag']+4]
            excluded += 1
    report = dict(input_sha256=DRIVER, input_bytes=len(new.data), reference_sha256=REFERENCE,
        transformed_sha256=OUTPUT, changed_bytes=changes, patch_sites=len(edits),
        retargeted_kernels=20, excluded_elf_objects_unchanged=excluded, cpu=cpu,
        init_identical_except_configuration_addresses=True, configuration_rva='0x7f0cd0',
        cuda=kernels, instruction_count=sum(k['instructions'] for k in kernels),
        new_opcode_names_vs_reference=sorted(new_ops.keys()-old_ops.keys()),
        profile_tested=False, GPU_tested=False, native_windows_executed=False,
        note='Static decoding and code comparisons do not establish GPU execution or displayed interpolation.',
        sources=['https://uk.download.nvidia.com/Windows/617.14/617.14-desktop-win10-win11-64bit-international-dch-whql.exe',
                 'https://github.com/llvm/llvm-project/blob/main/llvm/include/llvm/BinaryFormat/ELF.h',
                 'https://docs.nvidia.com/cuda/cuda-binary-utilities/'],
        installer_sha256='63d3da5ed52547bf3fd86204bb9ea1455947b24e2aa2519f359126f9a6efe13f')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(f'PASS: {changes} changed bytes, 20 inspected SM86 objects, {excluded} excluded objects unchanged; GPU untested.')

if __name__ == '__main__': main()
