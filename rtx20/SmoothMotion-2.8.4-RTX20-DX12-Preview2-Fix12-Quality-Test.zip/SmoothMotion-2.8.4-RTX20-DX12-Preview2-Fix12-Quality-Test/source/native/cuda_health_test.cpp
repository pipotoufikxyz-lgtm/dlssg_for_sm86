#include "include/nvs30/cuda_health.hpp"
#include "include/nvs30/presentation_policy.hpp"
#include <cassert>
#include <iostream>
int main(){
 using namespace nvs30;using cuda_health::Operation;
 cuda_health::Failures failures;
 // Failed model discovery does not prove that a later selected model cannot
 // run. The fresh-activity deadline still rejects a path with no usable model.
 failures.record(Operation::ModuleLoad,200);failures.record(Operation::ModuleLoad,209);
 assert(failures.modules()==2&&failures.execution()==0&&failures.total()==2);
 failures.record(Operation::ModuleLoad,0);failures.record(Operation::Execution,0);
 assert(failures.modules()==2&&failures.execution()==0);
 presentation::ProgressWindow active;active.start(0);
 for(unsigned i=1;i<200;++i)assert(active.accepted(i));
 assert(failures.execution()==0);
 presentation::ProgressWindow idle;idle.start(0);
 for(unsigned i=1;i<64;++i)assert(idle.accepted(0));
 assert(!idle.accepted(0));
 // Kernel, graph or sync failures remain fatal even after later success.
 failures.record(Operation::Execution,700);failures.record(Operation::Execution,0);
 assert(failures.execution()==1&&failures.total()==3&&failures.modules()==2);
 std::cout<<"CUDA module-load/execute classification and failed-model activity deadline passed; host policy only\n";
}
