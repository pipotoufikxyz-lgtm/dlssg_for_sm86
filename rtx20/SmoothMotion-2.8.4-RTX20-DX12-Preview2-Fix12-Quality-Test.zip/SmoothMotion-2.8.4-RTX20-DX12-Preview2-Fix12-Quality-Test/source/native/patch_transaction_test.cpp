#include "include/nvs30/patch_transaction.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using nvs30::patch_transaction::apply;
int main(){
    unsigned cases=0;
    for(bool writable:{false,true})for(bool flush_ok:{false,true})for(bool protect_ok:{false,true}){
        std::uint64_t destination=0x1122334455667788, before=destination, replacement=0x8877665544332211;
        std::vector<int> trace;unsigned writes=0,restores=0;
        bool ok=apply(&destination,&replacement,sizeof destination,
            [&]{trace.push_back(1);return writable;},
            [&](const void* bytes,std::size_t n){trace.push_back(2);++writes;std::memcpy(&destination,bytes,n);},
            [&]{trace.push_back(3);return flush_ok;},
            [&]{trace.push_back(4);++restores;return protect_ok;});
        assert(ok==(writable&&flush_ok&&protect_ok));
        assert(destination==(ok?replacement:before));
        if(!writable){assert(writes==0&&restores==0);assert((trace==std::vector<int>{1}));}
        else if(ok){assert(writes==1&&restores==1);assert((trace==std::vector<int>{1,2,3,4}));}
        else{assert(writes==2&&restores>=1);assert(trace.back()==4);}
        ++cases;
    }
    // The second protection attempt can recover after the first fails.
    unsigned char memory=3,replacement=2;unsigned restoreCalls=0;
    assert(!apply(&memory,&replacement,1,[]{return true;},[&](const void* b,std::size_t){memory=*static_cast<const unsigned char*>(b);},[]{return true;},[&]{return ++restoreCalls==2;}));
    assert(memory==3&&restoreCalls==2);
    auto never=[]{assert(false);return false;};
    assert(!apply(nullptr,&replacement,1,never,[](const void*,std::size_t){assert(false);},never,never));
    assert(!apply(&memory,&replacement,65,never,[](const void*,std::size_t){assert(false);},never,never));
    std::cout<<"PASS: "<<cases<<" permission/cache failure combinations; failed protection restore rolls original bytes back; invalid spans never write. Win32 execution NOT tested.\n";
}
