#pragma once
#include <cstddef>
#include <cstring>
#include <limits>

namespace sm20 {
// Copy only texels, never padding. Check the full span before touching either
// mapping; the last row of a D3D12 footprint need not include trailing padding.
inline bool texture_span(std::size_t pitch,std::size_t row,std::size_t rows,std::size_t& bytes){
 if(!row||!rows||pitch<row||(rows-1)>(std::numeric_limits<std::size_t>::max()-row)/pitch)return false;
 bytes=(rows-1)*pitch+row;return true;
}
inline bool copy_texture_rows(void* dst,std::size_t dstBytes,std::size_t dstPitch,
 const void* src,std::size_t srcBytes,std::size_t srcPitch,std::size_t row,std::size_t rows){
 std::size_t ds{},ss{};
 if(!dst||!src||!texture_span(dstPitch,row,rows,ds)||!texture_span(srcPitch,row,rows,ss)||ds>dstBytes||ss>srcBytes)return false;
 auto* d=static_cast<unsigned char*>(dst);auto* s=static_cast<const unsigned char*>(src);
 for(std::size_t y=0;y<rows;++y)std::memcpy(d+y*dstPitch,s+y*srcPitch,row);
 return true;
}
}
