#pragma once
#include "nvs30/common.hpp"
#include "transfer_sequence.hpp"

namespace sm20 {
// Accept only the DIRECT queue given to this swapchain's creation/resize call.
bool presentation_queue(IDXGISwapChain*,IUnknown*,nvs30::ComPtr<ID3D12CommandQueue>&);
bool same_object(IUnknown*,IUnknown*);
extern std::atomic_ullong dx12_sessions,dx12_captures,dx12_writes,dx12_transfer_failures;

class DX12Transfer {
 using Device11=nvs30::ComPtr<ID3D11Device>;
 nvs30::ComPtr<ID3D12Device> device12_;
 nvs30::ComPtr<ID3D12CommandQueue> queue_;
 nvs30::ComPtr<ID3D12CommandAllocator> allocator_;
 nvs30::ComPtr<ID3D12GraphicsCommandList> commands_;
 nvs30::ComPtr<ID3D12Fence> fence_;
 nvs30::ComPtr<ID3D12Resource> snapshot12_,output12_,inflightBack_;
 nvs30::ComPtr<ID3D12Resource> originalUpload12_;
 Device11 device11_;
 nvs30::ComPtr<ID3D11DeviceContext> context11_;
 nvs30::ComPtr<ID3D11DeviceContext4> handoffContext11_;
 nvs30::ComPtr<ID3D11Fence> handoffFence11_;
 nvs30::ComPtr<ID3D12Fence> handoffFence12_;
 nvs30::ComPtr<ID3D11Texture2D> snapshot11_,output11_;
 nvs30::ComPtr<ID3D11Query> done11_;
 HANDLE event_{};
 std::uint64_t value_{};
 std::uint64_t handoffValue_{};
 TransferSubmission submission_;
 bool pending11_{},unsafe11_{};
 unsigned width_{},height_{};
 DXGI_FORMAT format_{};
 bool staged_{};
 D3D12_PLACED_SUBRESOURCE_FOOTPRINT footprint_{};
 std::uint64_t stagingBytes_{};
 HRESULT shared(const char*,nvs30::ComPtr<ID3D12Resource>&,nvs30::ComPtr<ID3D11Texture2D>&);
 HRESULT staging();
 HRESULT readback_snapshot();
 HRESULT upload_generated(ID3D11Texture2D*);
 HRESULT initialize_handoff();
 HRESULT handoff11();
 HRESULT wait12();
 HRESULT wait11();
 HRESULT copy(IDXGISwapChain*,ID3D12Resource*,bool capture);
public:
 ~DX12Transfer();
 HRESULT initialize(IDXGISwapChain*,ID3D12CommandQueue*);
 ID3D11Device* device()const{return device11_.Get();}
 ID3D11Texture2D* snapshot()const{return snapshot11_.Get();}
 void mark_d3d11_work(){pending11_=true;}
 HRESULT capture(IDXGISwapChain*);
 HRESULT write_generated(IDXGISwapChain*,ID3D11Texture2D*);
 HRESULT write_original(IDXGISwapChain*);
 bool quiesce();
 bool uncertain()const{return submission_.in_flight||unsafe11_;}
};
}
