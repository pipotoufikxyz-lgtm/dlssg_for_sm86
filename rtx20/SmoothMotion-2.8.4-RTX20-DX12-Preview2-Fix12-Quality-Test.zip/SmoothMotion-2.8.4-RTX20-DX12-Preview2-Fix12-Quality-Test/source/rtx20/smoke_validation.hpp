#pragma once
#include <array>
#include <cstdint>
#include <limits>
#include <string>
#include <string_view>

namespace sm20::smoke {
enum Counter : unsigned { sessions,captures,writes,flow,generated,real,tearing,transfer_errors,backend_errors,present_errors,count };
inline constexpr std::array<std::string_view,count> names={"dx12_sessions","dx12_captures","dx12_writes","flow_pairs","generated_present_accepted","real_present_accepted","present_tearing_eligible","dx12_transfer_failures","rtx20_failures","bridge_present_failures"};
struct Snapshot {std::array<std::uint64_t,count> values{};bool valid{};};
namespace detail {
// Validate the entire status object and collect only top-level counters. Text,
// nested objects, duplicate counters and truncated/overflowed values cannot
// impersonate successful backend activity.
struct Parser {
 std::string_view text;std::size_t at{};Snapshot out;std::array<bool,count> seen{};
 explicit Parser(std::string_view input):text(input){}
 void ws(){while(at<text.size()&&(text[at]==' '||text[at]=='\n'||text[at]=='\r'||text[at]=='\t'))++at;}
 bool take(char c){ws();if(at==text.size()||text[at]!=c)return false;++at;return true;}
 bool str(std::string& value){
  if(!take('"'))return false;
  value.clear();
  while(at<text.size()){
   unsigned char c=text[at++];if(c=='"')return true;if(c<32)return false;
   if(c!='\\'){value.push_back(static_cast<char>(c));continue;}
   if(at==text.size())return false;
   char e=text[at++];
   switch(e){
    case '"':case '\\':case '/':value.push_back(e);break;
    case 'b':value.push_back('\b');break;case 'f':value.push_back('\f');break;
    case 'n':value.push_back('\n');break;case 'r':value.push_back('\r');break;case 't':value.push_back('\t');break;
    case 'u':{
     unsigned code=0;for(unsigned i=0;i<4;++i){if(at==text.size())return false;char h=text[at++];unsigned n=h>='0'&&h<='9'?h-'0':h>='a'&&h<='f'?h-'a'+10:h>='A'&&h<='F'?h-'A'+10:16;if(n==16)return false;code=code*16+n;}
     // Counter names are ASCII; preserve all ASCII escapes and ensure other
     // code units cannot compare equal to an ASCII counter name.
     value.push_back(code<128?static_cast<char>(code):char(0xff));break;
    }
    default:return false;
   }
  }return false;
 }
 bool number(){
  ws();if(at<text.size()&&text[at]=='-')++at;if(at==text.size())return false;
  if(text[at]=='0')++at;else{if(text[at]<'1'||text[at]>'9')return false;while(at<text.size()&&text[at]>='0'&&text[at]<='9')++at;}
  if(at<text.size()&&text[at]=='.'){++at;auto start=at;while(at<text.size()&&text[at]>='0'&&text[at]<='9')++at;if(at==start)return false;}
  if(at<text.size()&&(text[at]=='e'||text[at]=='E')){++at;if(at<text.size()&&(text[at]=='+'||text[at]=='-'))++at;auto start=at;while(at<text.size()&&text[at]>='0'&&text[at]<='9')++at;if(at==start)return false;}
  return true;
 }
 bool integer(std::uint64_t& value){
  ws();auto begin=at;value=0;
  while(at<text.size()&&text[at]>='0'&&text[at]<='9'){
   unsigned digit=text[at++]-'0';if(value>(std::numeric_limits<std::uint64_t>::max()-digit)/10)return false;value=value*10+digit;
  }
  return at>begin&&!(text[begin]=='0'&&at-begin>1);
 }
 bool object(unsigned depth,bool root=false){
  if(!take('{'))return false;
  if(take('}'))return true;
  do{
   std::string key;if(!str(key)||!take(':'))return false;
   unsigned index=count;if(root)for(unsigned i=0;i<count;++i)if(key==names[i]){index=i;break;}
   if(index!=count){if(seen[index]||!integer(out.values[index]))return false;seen[index]=true;}
   else if(!value(depth+1))return false;
   if(take('}'))return true;
  }while(take(','));return false;
 }
 bool value(unsigned depth){
  if(depth>32)return false;
  ws();if(at==text.size())return false;
  if(text[at]=='{')return object(depth);
  if(text[at]=='['){++at;if(take(']'))return true;do{if(!value(depth+1))return false;if(take(']'))return true;}while(take(','));return false;}
  if(text[at]=='"'){std::string ignored;return str(ignored);}
  for(auto literal:{std::string_view("true"),std::string_view("false"),std::string_view("null")})if(text.substr(at,literal.size())==literal){at+=literal.size();return true;}
  return number();
 }
 Snapshot parse(){if(!object(0,true))return {};ws();if(at!=text.size())return {};for(bool found:seen)if(!found)return {};out.valid=true;return out;}
};
}
inline Snapshot parse(std::string_view text){return detail::Parser{text}.parse();}
enum class Result { pass,fail,inconclusive };
struct Validation {Result result;const char* reason;unsigned phase;};
inline Validation validate(const std::array<Snapshot,4>& snapshots,bool completed,bool tearing_supported,std::uint64_t debug_errors){
 if(debug_errors)return {Result::fail,"D3D12 debug layer reported ERROR or CORRUPTION messages",0};
 for(unsigned i=0;i<4;++i){
  if(!snapshots[i].valid)return {completed?Result::fail:Result::inconclusive,"Missing or malformed backend status snapshot",i};
  const auto& now=snapshots[i].values;
  if(now[transfer_errors]||now[backend_errors]||now[present_errors])return {Result::fail,"Backend, transfer or generated Present errors were recorded",i};
  if(i)for(unsigned j=0;j<count;++j)if(now[j]<snapshots[i-1].values[j])return {Result::fail,"Backend counters decreased during the run",i};
 }
 if(!completed)return {Result::inconclusive,"All three timed phases must complete",0};
 for(unsigned phase=1;phase<4;++phase){
  const auto& before=snapshots[phase-1].values;const auto& after=snapshots[phase].values;
  if(after[sessions]<=before[sessions]||after[captures]<=before[captures]||after[writes]<=before[writes]||after[flow]<=before[flow]||after[generated]<=before[generated]||after[real]<=before[real])
   return {Result::inconclusive,"Interpolation did not execute in every phase; leave F11 enabled and inspect the log",phase};
  if(tearing_supported&&phase!=2&&after[tearing]<=before[tearing])return {Result::fail,"Tearing presentation was supported but not admitted in its test phase",phase};
 }
 return {Result::pass,"Sessions, capture, optical flow and generated Present advanced in every phase with zero recorded errors",0};
}
inline const char* label(Result value){return value==Result::pass?"PASS":value==Result::fail?"FAIL":"INCONCLUSIVE";}
}
