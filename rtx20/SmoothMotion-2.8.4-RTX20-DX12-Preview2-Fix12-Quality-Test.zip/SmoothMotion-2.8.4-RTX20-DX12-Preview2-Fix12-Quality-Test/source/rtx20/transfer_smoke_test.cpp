// Standalone pixel regression for the production transfer layer. No ASI, CUDA
// or NVOF is loaded. Forced staging makes the fallback independently testable.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "dx12_transfer.hpp"
#include "nvs30/gpu_wait.hpp"
#include <d3d12sdklayers.h>
#include <cstdarg>
#include <cstdio>

namespace {
FILE* report{};
void print(const char* format,va_list args){
 va_list copy;va_copy(copy,args);std::vprintf(format,args);
 if(report){std::vfprintf(report,format,copy);std::fflush(report);}va_end(copy);
}
void say(const char* format,...){va_list args;va_start(args,format);print(format,args);va_end(args);}
}
// DX12Transfer's only dependencies on the hook layer are logging and the
// internal-device guard. A standalone executable needs no hook installation.
namespace nvs30 {
void logf(const char* format,...)noexcept{va_list args;va_start(args,format);print(format,args);va_end(args);}
namespace dxgi {
thread_local bool creating{};
bool internal_creation(){return creating;}
void set_internal_creation(bool value){creating=value;}
}
}
namespace {
using nvs30::ComPtr;
struct Error{HRESULT hr;const char* operation;};
void check(HRESULT hr,const char* operation){if(FAILED(hr))throw Error{hr,operation};}
void require(bool value,const char* operation){if(!value)throw Error{E_FAIL,operation};}
D3D12_RESOURCE_BARRIER transition(ID3D12Resource* r,D3D12_RESOURCE_STATES from,D3D12_RESOURCE_STATES to){
 D3D12_RESOURCE_BARRIER b{};b.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
 b.Transition={r,D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES,from,to};return b;
}
LRESULT CALLBACK procedure(HWND w,UINT m,WPARAM a,LPARAM b){return DefWindowProcW(w,m,a,b);}
struct Harness {
 ComPtr<ID3D12Device> device;
 ComPtr<ID3D12CommandQueue> queue;
 ComPtr<IDXGISwapChain3> swap;
 ComPtr<ID3D12CommandAllocator> allocator;
 ComPtr<ID3D12GraphicsCommandList> commands;
 ComPtr<ID3D12Fence> fence;
 ComPtr<ID3D12InfoQueue> debug;
 ComPtr<ID3D12Resource> upload,readback,back;
 ComPtr<ID3D11DeviceContext> context11;
 ComPtr<ID3D11Texture2D> staging11,generated11;
 ComPtr<ID3D11Query> completion11;
 sm20::DX12Transfer* transfer{};
 D3D12_PLACED_SUBRESOURCE_FOOTPRINT footprint{};
 UINT64 bytes{},fenceValue{},debugErrors{};
 UINT width=130,height=129;
 DXGI_FORMAT format=DXGI_FORMAT_R8G8B8A8_UNORM;
 HANDLE event{};
 bool inFlight{};
 unsigned cases{},checks{};
 ~Harness(){delete transfer;if(event)CloseHandle(event);}
 void initialize(HWND window){
  ComPtr<ID3D12Debug> layer;
  if(SUCCEEDED(D3D12GetDebugInterface(IID_PPV_ARGS(&layer))))layer->EnableDebugLayer();
  ComPtr<IDXGIFactory4> factory;check(CreateDXGIFactory1(IID_PPV_ARGS(&factory)),"CreateDXGIFactory1");
  ComPtr<IDXGIAdapter1> adapter;
  for(UINT i=0;;++i){
   ComPtr<IDXGIAdapter1> candidate;const auto hr=factory->EnumAdapters1(i,&candidate);
   if(hr==DXGI_ERROR_NOT_FOUND)break;check(hr,"EnumAdapters1");
   DXGI_ADAPTER_DESC1 d{};check(candidate->GetDesc1(&d),"GetDesc1");
   if(d.VendorId==0x10de){adapter=candidate;break;}
  }
  require(bool(adapter),"NVIDIA adapter not found");
  check(D3D12CreateDevice(adapter.Get(),D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&device)),"D3D12CreateDevice");
  if(layer)check(device.As(&debug),"D3D12 debug InfoQueue");
  say("D3D12 debug layer: %s\n",debug?"enabled":"unavailable; install Windows Graphics Tools to validate barriers");
  D3D12_COMMAND_QUEUE_DESC q{};q.Type=D3D12_COMMAND_LIST_TYPE_DIRECT;
  check(device->CreateCommandQueue(&q,IID_PPV_ARGS(&queue)),"CreateCommandQueue");
  DXGI_SWAP_CHAIN_DESC1 d{};d.Width=width;d.Height=height;d.Format=format;d.SampleDesc.Count=1;
  d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.BufferCount=3;d.SwapEffect=DXGI_SWAP_EFFECT_FLIP_DISCARD;
  ComPtr<IDXGISwapChain1> first;
  check(factory->CreateSwapChainForHwnd(queue.Get(),window,&d,nullptr,nullptr,&first),"CreateSwapChainForHwnd");
  check(first.As(&swap),"IDXGISwapChain3");check(factory->MakeWindowAssociation(window,DXGI_MWA_NO_ALT_ENTER),"MakeWindowAssociation");
  check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)),"CreateCommandAllocator");
  check(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,IID_PPV_ARGS(&commands)),"CreateCommandList");
  check(commands->Close(),"Close initial commands");
  check(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)),"CreateFence");
  event=CreateEventW(nullptr,FALSE,FALSE,nullptr);require(event!=nullptr,"CreateEventW");
 }
 void wait(){
  check(queue->Signal(fence.Get(),++fenceValue),"Signal test fence");
  check(static_cast<HRESULT>(nvs30::gpu_wait::fence(fenceValue,2000,
   [&]{return fence->GetCompletedValue();},[&](UINT64 v){return fence->SetEventOnCompletion(v,event);},
   [&](unsigned ms)->HRESULT{const auto r=WaitForSingleObject(event,ms);return r==WAIT_OBJECT_0?S_OK:r==WAIT_TIMEOUT?HRESULT_FROM_WIN32(WAIT_TIMEOUT):HRESULT_FROM_WIN32(GetLastError());},
   []{return GetTickCount64();})),"Wait test fence (2 seconds)");
  inFlight=false;
 }
 void collect_debug(){
  if(!debug)return;
  require(!debug->GetNumMessagesDiscardedByMessageCountLimit(),"D3D12 debug messages discarded");
  const auto count=debug->GetNumStoredMessagesAllowedByRetrievalFilter();
  for(UINT64 i=0;i<count;++i){
   SIZE_T length{};check(debug->GetMessage(i,nullptr,&length),"Get debug message size");
   std::vector<unsigned char> storage(length);auto* m=reinterpret_cast<D3D12_MESSAGE*>(storage.data());
   check(debug->GetMessage(i,m,&length),"Get debug message");
   if(m->Severity==D3D12_MESSAGE_SEVERITY_ERROR||m->Severity==D3D12_MESSAGE_SEVERITY_CORRUPTION){
    ++debugErrors;say("D3D12 error %u: %s\n",unsigned(m->ID),m->pDescription);
   }
  }
  debug->ClearStoredMessages();require(!debugErrors,"D3D12 debug layer reported errors");
 }
 void release_case(){
  if(transfer){require(transfer->quiesce(),"Transfer quiesce");delete transfer;transfer=nullptr;}
  wait();back.Reset();upload.Reset();readback.Reset();context11.Reset();staging11.Reset();generated11.Reset();completion11.Reset();
 }
 void setup_case(UINT w,UINT h,DXGI_FORMAT f){
  release_case();
  if(cases)check(swap->ResizeBuffers(3,w,h,f,0),"ResizeBuffers");
  width=w;height=h;format=f;
  check(swap->GetBuffer(swap->GetCurrentBackBufferIndex(),IID_PPV_ARGS(&back)),"GetBuffer for footprint");
  const auto d=back->GetDesc();UINT rows{};UINT64 rowBytes{};
  device->GetCopyableFootprints(&d,0,1,0,&footprint,&rows,&rowBytes,&bytes);back.Reset();
  require(rows==height&&rowBytes==UINT64(width)*4&&footprint.Footprint.RowPitch>rowBytes,"Test requires padded rows");
  auto buffer=[&](D3D12_HEAP_TYPE kind,ComPtr<ID3D12Resource>& target){
   D3D12_HEAP_PROPERTIES heap{};heap.Type=kind;heap.CreationNodeMask=heap.VisibleNodeMask=1;
   D3D12_RESOURCE_DESC b{};b.Dimension=D3D12_RESOURCE_DIMENSION_BUFFER;b.Width=bytes;b.Height=1;
   b.DepthOrArraySize=b.MipLevels=1;b.SampleDesc.Count=1;b.Layout=D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
   check(device->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_NONE,&b,kind==D3D12_HEAP_TYPE_UPLOAD?D3D12_RESOURCE_STATE_GENERIC_READ:D3D12_RESOURCE_STATE_COPY_DEST,nullptr,IID_PPV_ARGS(&target)),"Create test buffer");
  };
  buffer(D3D12_HEAP_TYPE_UPLOAD,upload);buffer(D3D12_HEAP_TYPE_READBACK,readback);
  transfer=new sm20::DX12Transfer;check(transfer->initialize(swap.Get(),queue.Get()),"Initialize production transfer");
  transfer->device()->GetImmediateContext(&context11);
  D3D11_TEXTURE2D_DESC t{};transfer->snapshot()->GetDesc(&t);
  t.Usage=D3D11_USAGE_STAGING;t.BindFlags=0;t.CPUAccessFlags=D3D11_CPU_ACCESS_READ;t.MiscFlags=0;
  check(transfer->device()->CreateTexture2D(&t,nullptr,&staging11),"Create test D3D11 readback");
  D3D11_QUERY_DESC query{D3D11_QUERY_EVENT,0};check(transfer->device()->CreateQuery(&query,&completion11),"Create test D3D11 query");
  say("Case %u: %ux%u %s, DX12 row pitch=%u (active bytes=%u)\n",cases+1,width,height,format==DXGI_FORMAT_R8G8B8A8_UNORM?"RGBA":"BGRA",footprint.Footprint.RowPitch,width*4);
 }
 // An independent upload/readback pair gives the test an oracle without using
 // DX12Transfer to construct its own expected result.
 void copy_back(bool write){
  wait();check(allocator->Reset(),"Reset test allocator");check(commands->Reset(allocator.Get(),nullptr),"Reset test commands");
  back.Reset();check(swap->GetBuffer(swap->GetCurrentBackBufferIndex(),IID_PPV_ARGS(&back)),"Get current buffer");
  const auto state=write?D3D12_RESOURCE_STATE_COPY_DEST:D3D12_RESOURCE_STATE_COPY_SOURCE;
  auto begin=transition(back.Get(),D3D12_RESOURCE_STATE_PRESENT,state);commands->ResourceBarrier(1,&begin);
  D3D12_TEXTURE_COPY_LOCATION image{};image.pResource=back.Get();image.Type=D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
  D3D12_TEXTURE_COPY_LOCATION buffer{};buffer.pResource=write?upload.Get():readback.Get();buffer.Type=D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;buffer.PlacedFootprint=footprint;
  commands->CopyTextureRegion(write?&image:&buffer,0,0,0,write?&buffer:&image,nullptr);
  auto end=transition(back.Get(),state,D3D12_RESOURCE_STATE_PRESENT);commands->ResourceBarrier(1,&end);
  check(commands->Close(),"Close test copy");ID3D12CommandList* list=commands.Get();inFlight=true;queue->ExecuteCommandLists(1,&list);wait();back.Reset();
 }
 std::vector<unsigned char> pattern(bool solid){
  std::vector<unsigned char> pixels(std::size_t(width)*height*4);
  for(UINT y=0;y<height;++y)for(UINT x=0;x<width;++x){
   const auto p=(std::size_t(y)*width+x)*4;
   // Distinct channels plus per-row/per-column values reveal row padding,
   // channel swaps, stale buffers and using generated pixels as the original.
   pixels[p]=solid?17:static_cast<unsigned char>((x*7+y*3+cases*31)%256);
   pixels[p+1]=solid?113:static_cast<unsigned char>((x+y*11+37)%256);
   pixels[p+2]=solid?229:static_cast<unsigned char>((x*13+y*5+83)%256);
   pixels[p+3]=255;
  }return pixels;
 }
 void compare(const void* memory,UINT pitch,const std::vector<unsigned char>& expected,const char* operation){
  const auto* actual=static_cast<const unsigned char*>(memory);
  for(UINT y=0;y<height;++y)for(UINT x=0;x<width*4;++x){
   const auto wanted=expected[std::size_t(y)*width*4+x],found=actual[std::size_t(y)*pitch+x];
   if(wanted!=found){say("Pixel mismatch in %s: row=%u byte=%u expected=%u actual=%u\n",operation,y,x,unsigned(wanted),unsigned(found));throw Error{E_FAIL,operation};}
  }
  ++checks;say("  PASS %s: all %u pixels match\n",operation,width*height);
 }
 void verify_back(const std::vector<unsigned char>& expected,const char* operation){
  copy_back(false);D3D12_RANGE read{0,static_cast<SIZE_T>(bytes)},none{0,0};void* memory{};
  check(readback->Map(0,&read,&memory),"Map test readback");
  try{compare(static_cast<const unsigned char*>(memory)+footprint.Offset,footprint.Footprint.RowPitch,expected,operation);}
  catch(...){readback->Unmap(0,&none);throw;}readback->Unmap(0,&none);
 }
 void verify_snapshot(const std::vector<unsigned char>& expected){
  context11->CopyResource(staging11.Get(),transfer->snapshot());context11->End(completion11.Get());context11->Flush();
  const auto start=GetTickCount64();
  for(;;){BOOL complete=FALSE;const auto hr=context11->GetData(completion11.Get(),&complete,sizeof complete,D3D11_ASYNC_GETDATA_DONOTFLUSH);
   check(hr,"D3D11 test completion");if(hr==S_OK&&complete)break;
   check(transfer->device()->GetDeviceRemovedReason(),"D3D11 device health");
   require(GetTickCount64()-start<2000,"D3D11 test completion timeout (2 seconds)");Sleep(0);
  }
  D3D11_MAPPED_SUBRESOURCE mapped{};check(context11->Map(staging11.Get(),0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&mapped),"Map test D3D11 snapshot");
  try{compare(mapped.pData,mapped.RowPitch,expected,"DX12 capture -> D3D11 snapshot");}
  catch(...){context11->Unmap(staging11.Get(),0);throw;}context11->Unmap(staging11.Get(),0);
 }
 void run_case(UINT w,UINT h,DXGI_FORMAT f){
  setup_case(w,h,f);const auto original=pattern(false),generated=pattern(true);
  D3D12_RANGE none{0,0},written{0,static_cast<SIZE_T>(bytes)};void* memory{};
  check(upload->Map(0,&none,&memory),"Map test upload");std::memset(memory,0xcd,static_cast<std::size_t>(bytes));
  for(UINT y=0;y<height;++y)std::memcpy(static_cast<unsigned char*>(memory)+footprint.Offset+std::size_t(y)*footprint.Footprint.RowPitch,original.data()+std::size_t(y)*width*4,width*4);
  upload->Unmap(0,&written);copy_back(true);
  check(transfer->capture(swap.Get()),"Production capture");verify_snapshot(original);
  D3D11_TEXTURE2D_DESC t{};transfer->snapshot()->GetDesc(&t);t.Usage=D3D11_USAGE_DEFAULT;t.CPUAccessFlags=0;t.MiscFlags=0;
  D3D11_SUBRESOURCE_DATA data{};data.pSysMem=generated.data();data.SysMemPitch=width*4;
  check(transfer->device()->CreateTexture2D(&t,&data,&generated11),"Create generated test texture");
  check(transfer->write_generated(swap.Get(),generated11.Get()),"Production write_generated");verify_back(generated,"D3D11 generated -> DX12 current buffer");
  const auto before=swap->GetCurrentBackBufferIndex();const auto present=swap->Present(1,0);
  check(present,"Present generated frame");require(present==S_OK,"Present must be visible and accepted");wait();
  require(swap->GetCurrentBackBufferIndex()!=before,"Present must advance current backbuffer");
  check(transfer->write_original(swap.Get()),"Production write_original after Present");verify_back(original,"Saved original -> next DX12 buffer");
  verify_snapshot(original);collect_debug();++cases;
 }
};
}
int main(){
 wchar_t filename[32768]{};GetModuleFileNameW(nullptr,filename,32768);std::wstring directory(filename);directory.resize(directory.find_last_of(L"\\/")+1);
 _wfopen_s(&report,(directory+L"rtx20-transfer-test-report.txt").c_str(),L"wb");
 say("RTX20 production DX12 transfer pixel test\nNo CUDA/NVOF or ASI required. CPU staging forced in this process only.\n");
 HRESULT result=S_OK;const char* operation="completed";HWND window{};auto* test=new Harness;
 try{
  require(SetEnvironmentVariableW(L"SM20_DX12_FORCE_STAGING",L"1")!=FALSE,"Set staging test override");
  WNDCLASSW wc{};wc.hInstance=GetModuleHandleW(nullptr);wc.lpfnWndProc=procedure;wc.lpszClassName=L"SM20_Transfer_Pixel_Test";
  require(RegisterClassW(&wc)!=0,"RegisterClassW");
  window=CreateWindowW(wc.lpszClassName,L"RTX20 transfer pixel regression",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,480,360,nullptr,nullptr,wc.hInstance,nullptr);
  require(window!=nullptr,"CreateWindowW");UpdateWindow(window);test->initialize(window);
  for(const auto format:{DXGI_FORMAT_R8G8B8A8_UNORM,DXGI_FORMAT_B8G8R8A8_UNORM}){
   test->run_case(130,129,format);test->run_case(257,131,format);
  }
  test->release_case();test->collect_debug();
 }catch(const Error& e){result=e.hr;operation=e.operation;say("FAIL: %s hr=0x%08lx\n",operation,(unsigned long)result);}
 catch(...){result=E_FAIL;operation="unexpected exception";say("FAIL: unexpected exception\n");}
 const bool passed=SUCCEEDED(result)&&test->cases==4&&test->checks==16;
 say("\nPixel roundtrip: %s\nCompleted format/size cases: %u/4\nFull-image comparisons: %u/16\nD3D12 debug errors: %llu\nD3D12 debug validation: %s\nResult: 0x%08lx (%s)\nThis test validates staging transfer pixels and original restoration. It does not validate shared-texture interop, optical flow, displayed interpolation or frame pacing.\n",passed?"PASS":"FAIL",test->cases,test->checks,(unsigned long long)test->debugErrors,test->debug?"enabled":"unavailable; barrier validation was not performed",(unsigned long)result,operation);
 if(report){std::fclose(report);report=nullptr;}
 // On any failure keep all potentially submitted resources until process exit.
 if(passed){delete test;DestroyWindow(window);}
 return passed?0:1;
}
