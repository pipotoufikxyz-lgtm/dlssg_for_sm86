#include "texture_rows.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdio>
#include <limits>
#include <vector>

namespace {
using Bytes=std::vector<unsigned char>;
constexpr unsigned char padding=0xcd;
constexpr std::size_t offset=512;

Bytes pixels(std::size_t width,std::size_t height,unsigned seed){
 Bytes data(width*height*4);
 for(std::size_t y=0;y<height;++y)for(std::size_t x=0;x<width;++x)
  for(std::size_t c=0;c<4;++c)data[(y*width+x)*4+c]=static_cast<unsigned char>(seed+x*17+y*31+c*53);
 return data;
}

// Build the expected image independently of the production copying helper.
Bytes padded(const Bytes& packed,std::size_t row,std::size_t rows,std::size_t pitch,
             std::size_t prefix,bool fullTail){
 Bytes out(prefix+(rows-1)*pitch+row+(fullTail?pitch-row:0),padding);
 for(std::size_t y=0;y<rows;++y)
  std::copy_n(packed.begin()+y*row,row,out.begin()+prefix+y*pitch);
 return out;
}

void round_trip(std::size_t width,std::size_t height){
 const auto row=width*4,pitch12=(row+255)/256*256,pitch11=(row+127)/128*128+128;
 const auto real=pixels(width,height,7),generated=pixels(width,height,113);
 assert(real!=generated);
 const auto readback=padded(real,row,height,pitch12,offset,false);
 const auto generated11=padded(generated,row,height,pitch11,0,false);
 const auto readbackBefore=readback,generatedBefore=generated11;
 const auto span12=readback.size()-offset;
 std::size_t span11{};
 assert(sm20::texture_span(pitch11,row,height,span11)&&span11==generated11.size());

 // A D3D12 placed footprint has an offset and may omit final-row padding.
 Bytes originalUpload(readback.size(),padding),generatedUpload(readback.size(),padding);
 assert(sm20::copy_texture_rows(originalUpload.data()+offset,span12,pitch12,
  readback.data()+offset,span12,pitch12,row,height));
 assert(originalUpload==readback);
 const auto savedOriginal=originalUpload;

 // D3D12 readback -> packed CPU image (the UpdateSubresource input layout).
 Bytes snapshot11(real.size(),padding);
 assert(sm20::copy_texture_rows(snapshot11.data(),snapshot11.size(),row,
  readback.data()+offset,span12,pitch12,row,height));
 assert(snapshot11==real);

 // D3D11 generated readback -> a DIFFERENT D3D12 upload buffer.
 assert(sm20::copy_texture_rows(generatedUpload.data()+offset,span12,pitch12,
  generated11.data(),span11,pitch11,row,height));
 assert(generatedUpload==padded(generated,row,height,pitch12,offset,false));
 assert(originalUpload==savedOriginal);
 const auto savedGenerated=generatedUpload;

 Bytes presented(real.size(),padding);
 assert(sm20::copy_texture_rows(presented.data(),presented.size(),row,
  generatedUpload.data()+offset,span12,pitch12,row,height));
 assert(presented==generated);
 assert(sm20::copy_texture_rows(presented.data(),presented.size(),row,
  originalUpload.data()+offset,span12,pitch12,row,height));
 assert(presented==real); // The extra Present must not destroy the real frame.
 assert(originalUpload==savedOriginal&&generatedUpload==savedGenerated);
 assert(readback==readbackBefore&&generated11==generatedBefore);

 // Also protect padding after EVERY row, including the last destination row.
 Bytes withTail(offset+height*pitch11,padding);
 assert(sm20::copy_texture_rows(withTail.data()+offset,withTail.size()-offset,pitch11,
  readback.data()+offset,span12,pitch12,row,height));
 assert(withTail==padded(real,row,height,pitch11,offset,true));
}

void rejected_inputs(){
 std::array<unsigned char,64> dst,src;dst.fill(0xac);src.fill(0x57);
 const auto original=dst,input=src;
 const auto maximum=std::numeric_limits<std::size_t>::max();
 auto reject=[&](void* d,std::size_t db,std::size_t dp,const void* s,
                 std::size_t sb,std::size_t sp,std::size_t row,std::size_t rows){
  assert(!sm20::copy_texture_rows(d,db,dp,s,sb,sp,row,rows));
  assert(dst==original&&src==input); // Preflight must precede the first write.
 };
 reject(nullptr,64,16,src.data(),64,16,16,4);
 reject(dst.data(),64,16,nullptr,64,16,16,4);
 reject(dst.data(),64,16,src.data(),64,16,0,4);
 reject(dst.data(),64,16,src.data(),64,16,16,0);
 reject(dst.data(),64,0,src.data(),64,16,16,4);
 reject(dst.data(),64,16,src.data(),64,0,16,4);
 reject(dst.data(),64,15,src.data(),64,16,16,4);
 reject(dst.data(),64,16,src.data(),64,15,16,4);
 reject(dst.data(),63,16,src.data(),64,16,16,4);
 reject(dst.data(),64,16,src.data(),63,16,16,4);
 reject(dst.data(),0,16,src.data(),64,16,16,4);
 reject(dst.data(),64,16,src.data(),0,16,16,4);
 // Multiplication/addition overflow on either mapping; never touch pointers.
 reject(dst.data(),maximum,maximum,src.data(),64,16,16,2);
 reject(dst.data(),64,16,src.data(),maximum,maximum,16,2);
 reject(dst.data(),maximum,16,src.data(),maximum,16,16,maximum);
 reject(dst.data(),maximum,maximum,src.data(),maximum,maximum,maximum,2);
 // One byte short of a minimal final row, with valid early rows.
 reject(dst.data(),47,32,src.data(),48,32,16,2);
 reject(dst.data(),48,32,src.data(),47,32,16,2);

 std::size_t span=123;
 assert(!sm20::texture_span(maximum,16,2,span)&&span==123);
 assert(!sm20::texture_span(16,16,maximum,span)&&span==123);
 assert(!sm20::texture_span(0,0,0,span)&&span==123);
 assert(sm20::texture_span(maximum,16,1,span)&&span==16);
 assert(sm20::texture_span(maximum-15,15,2,span)&&span==maximum);
 assert(!sm20::texture_span(maximum-15,16,2,span)&&span==maximum);
 // One-row copying needs no fictitious allocation of a whole giant pitch.
 assert(sm20::copy_texture_rows(dst.data(),16,maximum,src.data(),16,maximum,16,1));
 assert(std::equal(dst.begin(),dst.begin()+16,src.begin()));
 assert(std::equal(dst.begin()+16,dst.end(),original.begin()+16)&&src==input);
}
}

int main(){
 round_trip(130,7); // 520 texel bytes, 768-byte D3D12 row pitch.
 round_trip(1920,1200); // Uploaded log's full-resolution SDR frame.
 round_trip(1,1);
 rejected_inputs();
 std::puts("texture rows: pitched bidirectional copies, minimal tails, padding, overflow rejection and original-frame restoration passed");
}
