#include <cmath>
#include "policy.hpp"
#include "present_sequence.hpp"
#include <cassert>
#include <iostream>
#include <utility>
#include <vector>
int main(){
 using namespace sm20;
 assert(supported_gpu(0x10de,7,5));assert(!supported_gpu(0x1002,7,5));assert(!supported_gpu(0x10de,8,6));assert(!supported_gpu(0x10de,7,0));
 for(unsigned f=0;f<200;++f)assert(supported_format(f)==(f==28||f==29||f==87||f==91));
 for(unsigned sync=0;sync<6;++sync)for(unsigned flags=0;flags<2048;++flags)for(bool partial:{false,true})
 for(bool windowed:{false,true})for(unsigned swapFlags:{0u,0x42u,0x800u,0x842u}){
  const bool tearing=sync==0&&flags==0x200&&windowed&&(swapFlags&0x800);
  assert(interpolate_request(sync,flags,partial,windowed,swapFlags)==(!partial&&((sync<2&&flags==0)||tearing)));
  if(flags&1)assert(request_admission(sync,flags,partial,windowed,swapFlags)==Admission::test);
 }
 assert(!interpolate_request(0,0x200,false)); // Unknown swapchain is not assumed eligible.
 assert(request_admission(0,0x200,false,true,0x842)==Admission::eligible);
 assert(request_admission(1,0x200,false,true,0x842)==Admission::tearing_contract);
 assert(request_admission(0,0x208,false,true,0x842)==Admission::flags); // DO_NOT_WAIT
 assert(request_admission(0,0,false)==Admission::eligible);
 assert(request_admission(2,0,false)==Admission::interval);
 assert(request_admission(0,0,true)==Admission::partial);
 // Distinct captures can share one coarse GetTickCount64 tick. The caller's
 // history bit establishes that a prior capture exists; equality is fresh.
 assert(!fresh_history(0,0));assert(!fresh_history(0,30));assert(!fresh_history(50,49));
 assert(fresh_history(50,50));assert(fresh_history(50,51));assert(fresh_history(50,300));assert(!fresh_history(50,301));
 for(unsigned n=1;n<=4096;++n)assert(grid_extent(n)*4>=n&&(grid_extent(n)-1)*4<n);
 assert(dimensions(1920,1080));assert(!dimensions(0,1080));assert(!dimensions(3841,2160));
 for(const auto& request:{std::pair{0u,0u},std::pair{0u,present_allow_tearing},std::pair{1u,0u}})
 for(bool gen:{false,true})for(std::int32_t first:{0,std::int32_t(0x087a0001),std::int32_t(0x887a0005u),std::int32_t(0x887a000au)})
 for(std::int32_t second:{0,std::int32_t(0x887a0005u)})for(auto restored:{RestoreResult::restored,RestoreResult::interrupted,RestoreResult::failed}){
  const auto [sync,flags]=request;
  int presents=0,restores=0,finishes=0,generated=0,busy=0;bool accepted=false;std::vector<unsigned> syncs;
  auto hr=present_pair(gen,sync,flags,[&](unsigned s,unsigned f){
   const bool synthetic=gen&&presents==0;
   assert(s==(synthetic?0:sync)&&f==(synthetic?(flags|generated_do_not_wait):flags));
   assert(!(f&present_allow_tearing)||s==0); // Never create an invalid tearing call.
   if(gen&&!synthetic)assert(restores==1&&generated+busy==1);
   syncs.push_back(s);return ++presents==1?first:second;
  },
   [&]{++restores;return restored;},[&](bool ok){++finishes;accepted=ok;},[&]{++generated;},[&]{++busy;});
  assert(finishes==1);
  if(!gen){assert(presents==1&&restores==0&&generated==0&&busy==0&&syncs[0]==sync&&hr==first&&accepted==(first==0));}
  else if(first!=0&&first!=present_still_drawing){assert(presents==1&&restores==1&&generated==0&&busy==0&&hr==first&&!accepted);}
  else {
   assert(generated==(first==0)&&busy==(first==present_still_drawing));
   if(restored!=RestoreResult::restored){assert(presents==1&&restores==1&&hr==(restored==RestoreResult::interrupted?first:std::int32_t(0x887a0007u))&&!accepted);}
   else{assert(presents==2&&restores==1&&syncs[0]==0&&syncs[1]==sync&&hr==second&&accepted==(second==0));}
  }
 }
 for(unsigned sync=0;sync<6;++sync)for(unsigned flags=0;flags<2048;++flags){
  unsigned submits=0;
  present_pair(false,sync,flags,[&](unsigned s,unsigned f){++submits;assert(s==sync&&f==flags);return 0;},
   []{assert(false);return RestoreResult::failed;},[](bool ok){assert(ok);},[]{assert(false);},[]{assert(false);});
  assert(submits==1);
 }
 // A window-thread transition can remain active or finish entirely inside the
 // first Present. Neither is a copy failure; old-size/same-size captures are
 // invalidated by revision, with no stale write and no second submission.
 for(bool active:{false,true})for(std::int32_t first:{0,std::int32_t(0x087a0001),std::int32_t(0x887a0005u),std::int32_t(0x887a000au)}){
  PresentationRevision epoch;const auto captured=epoch.checkpoint();
  int presents=0,copies=0,finishes=0,generated=0;bool history=true;
  const auto result=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){
   assert(sync==0&&flags==(present_allow_tearing|generated_do_not_wait));++presents;epoch.begin_transition();if(!active)epoch.end_transition();return first;
  },[&]{if(!epoch.current(captured))return RestoreResult::interrupted;++copies;return RestoreResult::restored;},
  [&](bool accepted){++finishes;history=accepted&&epoch.current(captured);},[&]{++generated;},[]{});
  assert(result==first&&presents==1&&copies==0&&finishes==1&&!history&&generated==(first==0));
  if(active)epoch.end_transition();
  assert(!epoch.current(captured)&&!epoch.transitioning());
  // The next eligible call consumes the reset and gets a fresh revision, so a
  // resize interruption does not permanently disable frame generation.
  assert(epoch.consume_reset());const auto recovered=epoch.checkpoint();
  assert(epoch.current(recovered)&&recovered!=captured&&!epoch.consume_reset());
  presents=copies=finishes=generated=0;
  const auto next=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){assert(sync==0&&flags==(presents?present_allow_tearing:(present_allow_tearing|generated_do_not_wait)));++presents;return 0;},
   [&]{assert(epoch.current(recovered));++copies;return RestoreResult::restored;},
   [&](bool accepted){++finishes;history=accepted&&epoch.current(recovered);},[&]{++generated;},[]{assert(false);});
  assert(next==0&&presents==2&&copies==1&&finishes==1&&history&&generated==1);
 }
 // Transitions during the final original submission keep that actual HRESULT,
 // while rejecting old history even when the transition already completed.
 for(bool generated:{false,true})for(std::int32_t final:{0,std::int32_t(0x887a0005u)}){
  PresentationRevision epoch;const auto captured=epoch.checkpoint();int presents=0;bool history=true;
  const auto hr=present_pair(generated,0,0,[&](unsigned,unsigned){
   if(++presents==(generated?2:1)){epoch.begin_transition();epoch.end_transition();return final;}return std::int32_t(0);
  },[]{return RestoreResult::restored;},[&](bool accepted){history=accepted&&epoch.current(captured);},[]{},[]{assert(false);});
  assert(hr==final&&!history&&presents==(generated?2:1));
 }
 // A transition after prepare also prevents the first generated write, and
 // nested wrapper transitions remain active until the last matching exit.
 PresentationRevision epoch;const auto beforeWrite=epoch.checkpoint();assert(epoch.current(beforeWrite));
 epoch.begin_transition();epoch.begin_transition();assert(!epoch.current(beforeWrite));
 epoch.end_transition();assert(epoch.transitioning()&&!epoch.current(beforeWrite));
 epoch.end_transition();assert(!epoch.transitioning()&&!epoch.current(beforeWrite));
 assert(epoch.consume_reset());assert(!epoch.current(beforeWrite));assert(epoch.current(epoch.checkpoint()));
 // Repeated queue saturation must neither retry synthetic submissions nor
 // starve/replace the real image or count a dropped frame as accepted.
 for(unsigned frame=0;frame<1000;++frame){
  int submits=0,restores=0,busy=0;bool accepted=false;
  auto hr=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){
   assert(sync==0);
   if(++submits==1){assert(flags==(present_allow_tearing|generated_do_not_wait));return present_still_drawing;}
   assert(submits==2&&restores==1&&flags==present_allow_tearing);return std::int32_t(0);
  },[&]{++restores;return RestoreResult::restored;},[&](bool ok){accepted=ok;},[]{assert(false);},[&]{++busy;});
  assert(hr==0&&accepted&&submits==2&&busy==1&&restores==1);
 }
 {
  // Flow resolution: explicit settings win, automatic mode uses hysteresis
  // and never selects an unavailable half-resolution session.
  assert(parse_flow_resolution(nullptr)==FlowResolution::automatic);
  assert(parse_flow_resolution(L"Full")==FlowResolution::full&&parse_flow_resolution(L"HALF")==FlowResolution::half);
  assert(parse_flow_resolution(L"auto")==FlowResolution::automatic&&parse_flow_resolution(L"halfx")==FlowResolution::automatic);
  assert(!use_half_flow(FlowResolution::half,false,false,200));
  assert(use_half_flow(FlowResolution::half,true,false,20)&&!use_half_flow(FlowResolution::full,true,true,200));
  assert(!use_half_flow(FlowResolution::automatic,true,false,30));   // 30 FPS base: keep detail
  assert(!use_half_flow(FlowResolution::automatic,true,false,57));
  assert(use_half_flow(FlowResolution::automatic,true,false,70));    // e.g. Blackwood with full flow
  assert(use_half_flow(FlowResolution::automatic,true,true,50));     // hysteresis keeps half
  assert(!use_half_flow(FlowResolution::automatic,true,true,40));
  double average=0;
  for(int i=0;i<200;++i)average=update_frame_interval(average,1/90.0);
  assert(std::abs(1/average-90)<0.5);
  assert(update_frame_interval(average,0.4)==0&&update_frame_interval(average,0)==0);
  assert(update_frame_interval(0,1/60.0)==1/60.0);
 }
 std::cout<<"PASS: flow resolution selection and frame-interval averaging\n";
 std::cout<<"PASS: admission/pass-through policies, immediate nonblocking generated submissions, queue saturation recovery, original frame priority, errors and transition interruption/recovery\n";
}
