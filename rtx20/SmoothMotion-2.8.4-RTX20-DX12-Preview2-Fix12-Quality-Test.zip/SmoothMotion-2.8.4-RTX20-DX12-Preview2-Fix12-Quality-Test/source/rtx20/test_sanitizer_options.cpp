// This sandbox does not expose /proc/<pid>/task, which LeakSanitizer needs.
// Keep AddressSanitizer and UndefinedBehaviorSanitizer enabled; leak checking
// is outside these host tests and is disabled through the runtime's test hook.
extern "C" int __lsan_is_turned_off(){return 1;}
