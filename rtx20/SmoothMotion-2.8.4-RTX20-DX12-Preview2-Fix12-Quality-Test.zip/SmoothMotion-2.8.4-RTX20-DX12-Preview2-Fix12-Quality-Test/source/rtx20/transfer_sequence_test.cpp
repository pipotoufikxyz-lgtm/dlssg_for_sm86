#include "transfer_sequence.hpp"
#include "present_sequence.hpp"
#include <cassert>
#include <cstdio>
#include <vector>
using namespace sm20;
constexpr std::int32_t failed=static_cast<std::int32_t>(0x80004005u);
int main(){
 // Exercise the production transfer transaction at every failure boundary.
 for(int fault=0;fault<4;++fault){
  TransferSubmission state;std::vector<int> calls;
  auto run=[&]{return transfer_copy(state,[&]{calls.push_back(1);return 2u;},
   [&](unsigned index){assert(index==2);calls.push_back(2);return fault==1?failed:0;},
   [&]{assert(state.in_flight);calls.push_back(3);},
   [&]{assert(state.in_flight);calls.push_back(4);return fault>=2?failed:0;});};
  const auto hr=run();assert(hr==(fault?failed:0));
  assert(state.in_flight==(fault>=2));assert((state.failure<0)==(fault>=2));
  if(fault>=2){const auto size=calls.size();assert(run()==failed);assert(calls.size()==size);}
  if(fault==1)assert((calls==std::vector<int>{1,2}));
  if(!fault)assert((calls==std::vector<int>{1,2,3,4}));
 }
 // Simulate actual DXGI buffer changes during the production two-Present
 // sequence. The restore MUST use the index after generated Present.
 for(unsigned count:{2u,3u,16u})for(unsigned initial=0;initial<count;++initial)for(bool busy:{false,true}){
  TransferSubmission state;unsigned current=initial,presents=0,accepted=0;
  std::vector<unsigned> writes;
  auto write=[&]{return transfer_copy(state,[&]{return current;},[&](unsigned i){assert(dx12_buffer_index(i,count));writes.push_back(i);return 0;},[]{},[]{return 0;})==0;};
  assert(write());
  const auto hr=present_pair(true,0,0,[&](unsigned interval,unsigned flags){
   assert(interval==0&&flags==(presents?0:generated_do_not_wait));
   if(++presents==1&&busy)return present_still_drawing;
   current=(current+1)%count;return std::int32_t(0);
  },[&]{return write()?RestoreResult::restored:RestoreResult::failed;},[&](bool ok){assert(ok);++accepted;},[&]{assert(!busy);},[&]{assert(busy);});
  assert(hr==0&&presents==2&&accepted==1&&writes.size()==2);
  assert(writes[0]==initial&&writes[1]==(initial+(busy?0:1))%count);
 }
 // A failed generated Present can leave the index unchanged. Restore it once
 // and preserve the caller's result without retrying Present.
 {unsigned current=2,restored=99,calls=0;TransferSubmission state;
  auto result=present_pair(true,1,0,[&](unsigned,unsigned){++calls;return failed;},[&]{return transfer_copy(state,[&]{return current;},[&](unsigned i){restored=i;return 0;},[]{},[]{return 0;})==0?RestoreResult::restored:RestoreResult::failed;},[](bool ok){assert(!ok);},[]{assert(false);},[]{assert(false);});
  assert(result==failed&&calls==1&&restored==2);
 }
 for(unsigned type=0;type<4;++type)for(unsigned nodes=0;nodes<4;++nodes)for(unsigned mask=0;mask<5;++mask)
  assert(direct_single_node(type,nodes,mask)==(type==0&&nodes==1&&mask<=1));
 for(unsigned count=0;count<20;++count)for(unsigned index=0;index<20;++index)
  assert(dx12_buffer_index(index,count)==(count>=2&&count<=16&&index<count));
 auto equal=[](unsigned a,unsigned b){return a%10==b%10;};unsigned selected=99;
 assert(resize_queue(3,[](unsigned){return 1u;},[](unsigned i){return i?11u:1u;},equal,selected)&&selected==1);
 assert(!resize_queue(3,[](unsigned){return 0u;},[](unsigned i){return i==2?2u:1u;},equal,selected)&&!selected);
 assert(!resize_queue(3,[](unsigned i){return i==1?2u:1u;},[](unsigned){return 1u;},equal,selected)&&!selected);
 assert(!resize_queue(2,[](unsigned){return 1u;},[](unsigned i){return i?0u:1u;},equal,selected)&&!selected);
 assert(!resize_queue(17,[](unsigned){assert(false);return 1u;},[](unsigned){assert(false);return 1u;},equal,selected));
 std::puts("DX12 transfer faults, poisoned-session retention, current-buffer rotation, queue admission and resize queue selection passed");
}
