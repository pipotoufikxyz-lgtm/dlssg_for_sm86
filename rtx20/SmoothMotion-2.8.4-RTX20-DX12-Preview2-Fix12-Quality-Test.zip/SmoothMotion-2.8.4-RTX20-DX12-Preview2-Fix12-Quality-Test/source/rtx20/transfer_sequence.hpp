#pragma once
#include <cstdint>

namespace sm20 {
// This state is shared by the Windows bridge and host fault-injection tests.
// Once submitted work has uncertain completion, never reuse its allocator or
// release the resources it references. Errors before Execute are recoverable.
struct TransferSubmission {
 bool in_flight{};
 std::int32_t failure{};
};
template<class Current, class Record, class Execute, class Finish>
std::int32_t transfer_copy(TransferSubmission& state, Current current,
 Record record, Execute execute, Finish finish) {
 if(state.failure<0)return state.failure;
 const auto hr=static_cast<std::int32_t>(record(current()));
 if(hr<0)return hr;
 state.in_flight=true;
 execute();
 const auto completed=static_cast<std::int32_t>(finish());
 if(completed<0){state.failure=completed;return completed;}
 state.in_flight=false;
 return 0;
}
constexpr bool direct_single_node(unsigned type,unsigned nodes,unsigned mask) {
 return type==0&&nodes==1&&(mask==0||mask==1);
}
constexpr bool dx12_buffer_index(unsigned index,unsigned count) {
 return count>=2&&count<=16&&index<count;
}
template<class Queue,class Mask,class Fetch,class Equal>
bool resize_queue(unsigned count,Mask mask,Fetch fetch,Equal equal,Queue& result) {
 result=Queue{};
 if(!dx12_buffer_index(0,count))return false;
 for(unsigned i=0;i<count;++i){
  if(mask(i)>1){result=Queue{};return false;}
  auto candidate=fetch(i);
  if(!candidate||(result&&!equal(result,candidate))){result=Queue{};return false;}
  if(!result)result=candidate;
 }
 return true;
}
}
