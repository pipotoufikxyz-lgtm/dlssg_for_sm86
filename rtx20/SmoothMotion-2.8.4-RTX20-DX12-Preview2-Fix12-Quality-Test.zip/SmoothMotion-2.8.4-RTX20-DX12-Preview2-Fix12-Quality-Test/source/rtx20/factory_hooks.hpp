namespace dx12 {
using CreateSwapFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory*,IUnknown*,DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**);
using CreateHwndFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,HWND,const DXGI_SWAP_CHAIN_DESC1*,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*,IDXGIOutput*,IDXGISwapChain1**);
using CreateCoreFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**);
using CreateCompositionFn=HRESULT (STDMETHODCALLTYPE*)(IDXGIFactory2*,IUnknown*,const DXGI_SWAP_CHAIN_DESC1*,IDXGIOutput*,IDXGISwapChain1**);
struct FactoryHooks {void** table=nullptr;CreateSwapFn swap=nullptr;CreateHwndFn hwnd=nullptr;CreateCoreFn core=nullptr;CreateCompositionFn composition=nullptr;unsigned extent=0;bool hooked=false;};
std::array<FactoryHooks,64> factories{};unsigned factoryCount=0;SRWLOCK factoryLock=SRWLOCK_INIT;
FactoryHooks factoryHooks(void* object){auto v=*reinterpret_cast<void***>(object);FactoryHooks result;AcquireSRWLockShared(&factoryLock);for(unsigned i=0;i<factoryCount;++i)if(factories[i].table==v){result=factories[i];break;}ReleaseSRWLockShared(&factoryLock);return result;}
void created(IDXGISwapChain* swap,IUnknown* input){if(swap)registerSwapchain(swap,input);}
bool ownModule(const void* address){
 HMODULE image{};
 return address&&GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
  reinterpret_cast<LPCWSTR>(address),&image)&&image==imports::owner.load();
}
void logCaller(const char* prefix,const char* api,const void* caller) noexcept {
 imports::LastErrorScope error;
 try{
  static std::atomic_uint count{0};if(count.fetch_add(1)>=24)return;
  HMODULE image{};std::wstring path(32768,L'\0');DWORD n=0;
  if(caller&&GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(caller),&image))
   n=GetModuleFileNameW(image,path.data(),static_cast<DWORD>(path.size()));
  if(n&&n<path.size())logf("[normal] %s: api=%s caller=%ls RVA=0x%llx.\n",prefix,api,path.c_str(),
   static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(caller)-reinterpret_cast<std::uintptr_t>(image)));
  else logf("[normal] %s: api=%s caller=unknown address=%p.\n",prefix,api,caller);
 }catch(...){}
}
// Every CreateSwapChain* table hook goes through here. Initialization remains
// admission-gated by graphicsCall; see creation_policy.hpp for registration.
template<class Out,class Create>
HRESULT swapchainCall(const char* api,const void* caller,IUnknown* device,Out** out,Create forward){
 bool admitted=false;
 const bool internal=internalCreation;
 const HRESULT hr=imports::graphicsCall(caller,internal,[]{},forward,[&](HRESULT){admitted=true;});
 if(!admitted&&outerSwapchainCreation)return hr; // outer D3D11CreateDeviceAndSwapChain registers it
 const auto action=sm20::creation::swapchain(admitted,internal,!admitted&&ownModule(caller),nativeReady.load(),SUCCEEDED(hr),out&&*out);
 if(action==sm20::creation::Action::register_forwarded)
  logCaller("Swapchain creation forwarded by an excluded caller (overlay or system hook); runtime already ready, registering for presentation only",api,caller);
 else if(!admitted&&!internal)logCaller("Swapchain creation not registered",api,caller);
 if(action!=sm20::creation::Action::none)created(*out,device);
 return hr;
}
HRESULT STDMETHODCALLTYPE onCreateSwap(IDXGIFactory* f,IUnknown* device,DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.swap)return E_FAIL;
 return swapchainCall("CreateSwapChain",caller,device,out,[&]{return h.swap(f,device,desc,out);});
}
HRESULT STDMETHODCALLTYPE onCreateHwnd(IDXGIFactory2* f,IUnknown* device,HWND window,const DXGI_SWAP_CHAIN_DESC1* desc,const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* full,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.hwnd)return E_FAIL;
 return swapchainCall("CreateSwapChainForHwnd",caller,device,out,[&]{return h.hwnd(f,device,window,desc,full,output,out);});
}
HRESULT STDMETHODCALLTYPE onCreateCore(IDXGIFactory2* f,IUnknown* device,IUnknown* window,const DXGI_SWAP_CHAIN_DESC1* desc,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.core)return E_FAIL;
 return swapchainCall("CreateSwapChainForCoreWindow",caller,device,out,[&]{return h.core(f,device,window,desc,output,out);});
}
HRESULT STDMETHODCALLTYPE onCreateComposition(IDXGIFactory2* f,IUnknown* device,const DXGI_SWAP_CHAIN_DESC1* desc,IDXGIOutput* output,IDXGISwapChain1** out){
 const void* caller=NVS30_CALLER_ADDRESS();auto h=factoryHooks(f);if(!h.composition)return E_FAIL;
 return swapchainCall("CreateSwapChainForComposition",caller,device,out,[&]{return h.composition(f,device,desc,output,out);});
}
bool registerFactory(void* object,unsigned size){
 if(!observeGraphicsObjects())return false;
 auto v=*reinterpret_cast<void***>(object);AcquireSRWLockExclusive(&factoryLock);
 struct Unlock{~Unlock(){ReleaseSRWLockExclusive(&factoryLock);}} unlock;
 unsigned index=0;for(;index<factoryCount;++index)if(factories[index].table==v)break;
 if(index==factoryCount){if(factoryCount==factories.size()){
  static bool reported=false;if(!reported){reported=true;logf("[normal] Factory table capacity reached; new untracked tables are not patched.\n");}return false;
 }++factoryCount;}
 auto& h=factories[index];
 if(size<h.extent||(h.hooked&&size==h.extent))return h.hooked;
 h.table=v;h.extent=size;h.hooked=false;
 if(!h.swap)h.swap=reinterpret_cast<CreateSwapFn>(v[10]);
 if(size>=25){
  if(!h.hwnd)h.hwnd=reinterpret_cast<CreateHwndFn>(v[15]);
  if(!h.core)h.core=reinterpret_cast<CreateCoreFn>(v[16]);
  if(!h.composition)h.composition=reinterpret_cast<CreateCompositionFn>(v[24]);
 }
 h.swap=recoverOriginal(h.swap,&onCreateSwap,factories,factoryCount,&FactoryHooks::swap);
 if(h.hwnd)h.hwnd=recoverOriginal(h.hwnd,&onCreateHwnd,factories,factoryCount,&FactoryHooks::hwnd);
 if(h.core)h.core=recoverOriginal(h.core,&onCreateCore,factories,factoryCount,&FactoryHooks::core);
 if(h.composition)h.composition=recoverOriginal(h.composition,&onCreateComposition,factories,factoryCount,&FactoryHooks::composition);
 if(!h.swap||(size>=25&&(!h.hwnd||!h.core||!h.composition)))return false;
 const std::array<hook_group::Slot,4> slots{{
  {v+10,reinterpret_cast<void*>(h.swap),reinterpret_cast<void*>(&onCreateSwap)},
  {size>=25?v+15:nullptr,reinterpret_cast<void*>(h.hwnd),reinterpret_cast<void*>(&onCreateHwnd)},
  {size>=25?v+16:nullptr,reinterpret_cast<void*>(h.core),reinterpret_cast<void*>(&onCreateCore)},
  {size>=25?v+24:nullptr,reinterpret_cast<void*>(h.composition),reinterpret_cast<void*>(&onCreateComposition)}}};
 h.hooked=hook_group::install(slots,readSlot,patch);return h.hooked;
}
bool hookFactory(IDXGIFactory* factory){
 // Check before QueryInterface or dereferencing any shared method table.
 // Trails already receives native NvPresent objects; an observation-only
 // hook here can participate in an overlay/driver forwarding cycle.
 if(!observeGraphicsObjects())return false;
 bool hooked=false;
 // COM may return different vtables for different interface versions. Each
 // Factory2+ interface shares the inherited creation-method prefix.
 for(const auto& iid:{__uuidof(IDXGIFactory7),__uuidof(IDXGIFactory6),__uuidof(IDXGIFactory5),__uuidof(IDXGIFactory4),__uuidof(IDXGIFactory3),__uuidof(IDXGIFactory2)}){
  Com<IUnknown> version;if(SUCCEEDED(factory->QueryInterface(iid,reinterpret_cast<void**>(version.put()))))hooked=registerFactory(version.p,25)||hooked;
 }
 Com<IDXGIFactory1> v1;if(SUCCEEDED(factory->QueryInterface(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(v1.put()))))hooked=registerFactory(v1.p,12)||hooked;
 hooked=registerFactory(factory,12)||hooked;
 static std::atomic_int reported{-1};
 if(reported.exchange(hooked?1:0)!=(hooked?1:0))logf("[normal] DXGI factory swapchain-creation hooks %s.\n",hooked?"installed":"unavailable; swapchains can only be adopted at Present");
 return hooked;
}

}
