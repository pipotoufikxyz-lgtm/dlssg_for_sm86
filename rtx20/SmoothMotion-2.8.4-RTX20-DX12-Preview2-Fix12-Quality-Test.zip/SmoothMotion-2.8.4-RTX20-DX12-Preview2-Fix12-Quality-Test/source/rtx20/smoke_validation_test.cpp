#include "smoke_validation.hpp"
#include <cassert>
#include <cstdio>
using namespace sm20::smoke;
std::string json(const Snapshot& s){std::string text="{";for(unsigned i=0;i<count;++i){if(i)text+=',';text+='"';text+=names[i];text+="\":";text+=std::to_string(s.values[i]);}return text+'}';}
int main(){
 std::array<Snapshot,4> snapshots;
 for(unsigned phase=0;phase<4;++phase){auto& s=snapshots[phase];for(unsigned j=0;j<=tearing;++j)s.values[j]=phase*10;s.valid=true;assert(parse(json(s)).values==s.values);assert(parse(json(s)).valid);}
 assert(validate(snapshots,true,true,0).result==Result::pass);
 assert(validate(snapshots,true,false,0).result==Result::pass);
 assert(validate(snapshots,false,true,0).result!=Result::pass);
 assert(validate(snapshots,true,true,1).result==Result::fail);
 for(unsigned phase=1;phase<4;++phase){
  for(unsigned counter:{sessions,captures,writes,flow,generated,real}){auto modified=snapshots;modified[phase].values[counter]=modified[phase-1].values[counter];assert(validate(modified,true,true,0).result!=Result::pass);}
  for(unsigned counter:{transfer_errors,backend_errors,present_errors}){auto modified=snapshots;modified[phase].values[counter]=1;assert(validate(modified,true,true,0).result==Result::fail);}
  auto missing=snapshots;missing[phase].valid=false;assert(validate(missing,true,true,0).result==Result::fail);
 }
 auto disabled=snapshots;for(auto& s:disabled)s.values={};assert(validate(disabled,true,true,0).result!=Result::pass);
 auto tearingMissing=snapshots;tearingMissing[3].values[tearing]=tearingMissing[2].values[tearing];assert(validate(tearingMissing,true,true,0).result==Result::fail);assert(validate(tearingMissing,true,false,0).result==Result::pass);
 auto before=snapshots;before[0].values[backend_errors]=1;assert(validate(before,true,true,0).result==Result::fail);
 auto text=json(snapshots[3]);
 for(std::size_t length=0;length<text.size();++length)assert(!parse(std::string_view(text).substr(0,length)).valid);
 assert(!parse(text+"garbage").valid);
 assert(!parse("{\"nested\":"+text+"}").valid);
 assert(!parse(text.substr(0,text.size()-1)+",\"dx12_captures\":99}").valid);
 auto base=snapshots[3];base.values[captures]=std::numeric_limits<std::uint64_t>::max();assert(parse(json(base)).valid);
 for(auto bad:{"-1","1.0","1e3","01","18446744073709551616","true","\"99\"","null"}){
  auto malformed=text;auto start=malformed.find("\"dx12_captures\":")+16;auto end=malformed.find(',',start);malformed.replace(start,end-start,bad);assert(!parse(malformed).valid);
 }
 auto nested=text.substr(0,text.size()-1)+",\"unused\":{\"dx12_captures\":900,\"text\":\"\\\"generated_present_accepted\\\":10000\",\"array\":[null,true,false,-2.3e+4,{}]}}";assert(parse(nested).valid);
 auto escaped=text;escaped.replace(escaped.find("dx12_captures"),13,"dx12_\\u0063aptures");assert(parse(escaped).valid);assert(parse(escaped).values[captures]==30);
 for(auto bad:{"{\"bad\":tru,","{\"bad\":1.,","{\"bad\":01,","{\"bad\":\"\\x\",","{\"bad\":[1,],"})assert(!parse(std::string(bad)+text.substr(1)).valid);
 std::puts("Smoke validation: malformed/duplicate/nested/overflow status, no-op backend, per-phase regressions, tearing, failures and complete success passed");
}
