#pragma once

namespace sm20 {
// Borrow the game's existing D3D11 protection for the whole state transaction.
// Do not turn protection on: that is an application-owned device policy.
template<class Multithread>
class ContextTransaction {
 Multithread* locked_{};
public:
 explicit ContextTransaction(Multithread* context) {
  if(context&&context->GetMultithreadProtected()){
   context->Enter();locked_=context;
  }
 }
 ~ContextTransaction(){if(locked_)locked_->Leave();}
 ContextTransaction(const ContextTransaction&)=delete;
 ContextTransaction& operator=(const ContextTransaction&)=delete;
};
}
