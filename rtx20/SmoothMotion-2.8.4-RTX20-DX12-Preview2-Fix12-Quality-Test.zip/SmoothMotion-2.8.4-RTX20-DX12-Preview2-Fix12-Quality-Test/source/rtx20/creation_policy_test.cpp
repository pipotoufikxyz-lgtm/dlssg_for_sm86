#include "creation_policy.hpp"
#include <cassert>
#include <cstdio>
using namespace sm20::creation;
int main(){
 // Blackwood case: runtime ready, overlay forwards the game's call -> register.
 assert(swapchain(false,false,false,true,true,true)==Action::register_forwarded);
 assert(swapchain(true,false,false,true,true,true)==Action::register_admitted);
 // Never before initialization, never for our own internal or own-module work.
 assert(swapchain(false,false,false,false,true,true)==Action::none);
 assert(swapchain(true,false,false,false,true,true)==Action::none);
 assert(swapchain(false,true,false,true,true,true)==Action::none);
 assert(swapchain(true,true,false,true,true,true)==Action::none);
 assert(swapchain(false,false,true,true,true,true)==Action::none);
 // Failed creation or missing output.
 assert(swapchain(true,false,false,true,false,true)==Action::none);
 assert(swapchain(false,false,false,true,true,false)==Action::none);
 // Present-time adoption is attempted once, only when ready and unregistered.
 assert(adopt_at_present(true,false,false,false,false));
 assert(!adopt_at_present(true,false,false,false,true));
 assert(!adopt_at_present(true,false,false,true,false));
 assert(!adopt_at_present(false,false,false,false,false));
 assert(!adopt_at_present(true,true,false,false,false));
 assert(!adopt_at_present(true,false,true,false,false));
 std::puts("creation policy: forwarded registration and one-time Present adoption");
}
