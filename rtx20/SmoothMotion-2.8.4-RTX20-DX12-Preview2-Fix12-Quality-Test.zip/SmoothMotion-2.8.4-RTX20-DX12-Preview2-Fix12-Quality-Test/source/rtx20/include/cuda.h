#pragma once
// Minimal, independently declared Windows x64 CUDA Driver ABI. No CUDA kernels
// or CUDA runtime are redistributed. All entry points are resolved at runtime.
#include <cstddef>
#include <cstdint>
using CUdevice = int;
using CUdeviceptr = unsigned long long;
using CUcontext = struct CUctx_st*;
using CUstream = struct CUstream_st*;
using CUarray = struct CUarray_st*;
using CUgraphicsResource = struct CUgraphicsResource_st*;
using CUresult = int;
enum CUmemorytype { CU_MEMORYTYPE_HOST=1, CU_MEMORYTYPE_DEVICE=2, CU_MEMORYTYPE_ARRAY=3 };
struct CUDA_MEMCPY2D {
 std::size_t srcXInBytes{},srcY{}; CUmemorytype srcMemoryType{};
 const void* srcHost{}; CUdeviceptr srcDevice{}; CUarray srcArray{}; std::size_t srcPitch{};
 std::size_t dstXInBytes{},dstY{}; CUmemorytype dstMemoryType{};
 void* dstHost{}; CUdeviceptr dstDevice{}; CUarray dstArray{}; std::size_t dstPitch{};
 std::size_t WidthInBytes{},Height{};
};
static_assert(sizeof(void*)==8 && sizeof(CUDA_MEMCPY2D)==128);
static_assert(offsetof(CUDA_MEMCPY2D,srcArray)==40 && offsetof(CUDA_MEMCPY2D,dstArray)==96);
