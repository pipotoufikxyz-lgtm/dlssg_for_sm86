#pragma once
#include "nvs30/common.hpp"
#include <memory>

namespace sm20 {
// Native D3D11 NVOF; the API5 ABI stays private to this module. CUDA API2 can
// coexist as the initialization fallback. All calls use the provided immediate
// context and must obey the caller's context/session serialization.
class NvofD3D11 {
 struct Impl;
 std::unique_ptr<Impl> impl_;
public:
 // NVIDIA's D3D mapping for NV_OF_BUFFER_FORMAT_ABGR8 is BGRA8. The CUDA
 // buffer name alone must not be used to infer this API's DXGI byte layout.
 static constexpr DXGI_FORMAT input_format() noexcept{return DXGI_FORMAT_B8G8R8A8_UNORM;}
 NvofD3D11();
 ~NvofD3D11();
 NvofD3D11(const NvofD3D11&)=delete;
 NvofD3D11& operator=(const NvofD3D11&)=delete;
 static bool available() noexcept;
 bool initialize(ID3D11Device*,ID3D11DeviceContext*,unsigned width,unsigned height,
                 ID3D11Texture2D* const frames[2],ID3D11Texture2D* const flows[2]) noexcept;
 // Output[0] is previous->current; output[1] is current->previous. Resource
 // identity is resolved at execution, so swapping frame structs is supported.
 HRESULT execute(ID3D11Texture2D* previous,ID3D11Texture2D* current,ID3D11Texture2D* const flows[2]) noexcept;
 bool ready() const noexcept;
 // Reset/resize only: no per-frame CPU query. False requires retaining the
 // caller's entire session (including synthesis and swapchain resources).
 bool quiesce() noexcept;
};
}
