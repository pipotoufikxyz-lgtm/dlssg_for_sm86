#pragma once
// Preview2-Fix1. Blackwood (Unity DX12) log: runtime ready, graphics_excluded=1,
// no "game swapchain created" line and present_calls=0. An overlay that patches
// the shared DXGI factory table after us (NVIDIA capture in System32, Steam
// overlay) becomes the immediate caller of our CreateSwapChain* hook. Its
// exclusion then discarded the game's real swapchain, so no Present hook was
// ever installed.
//
// Exclusion still prevents such a caller from *initializing* the runtime. Once
// the runtime is ready, a swapchain returned through that forwarding hook is
// registered for presentation only. Registration is inert for a private probe
// swapchain that is never presented.
namespace sm20::creation {
enum class Action {none,register_admitted,register_forwarded};
constexpr Action swapchain(bool admitted,bool internal,bool own_caller,bool ready,bool succeeded,bool has_swapchain) noexcept {
 if(!succeeded||!has_swapchain||internal||!ready)return Action::none;
 if(admitted)return Action::register_admitted;
 return own_caller?Action::none:Action::register_forwarded;
}
// A swapchain created before our factory hooks (or through any unobserved
// route) reaches our Present hook without a Context. Try registration once.
constexpr bool adopt_at_present(bool ready,bool nested,bool internal,bool has_context,bool attempted) noexcept {
 return ready&&!nested&&!internal&&!has_context&&!attempted;
}
}
