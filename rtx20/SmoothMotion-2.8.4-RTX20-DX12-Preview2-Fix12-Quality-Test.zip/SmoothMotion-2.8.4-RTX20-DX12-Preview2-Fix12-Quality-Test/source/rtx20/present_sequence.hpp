#pragma once
#include <atomic>
#include <cstdint>
namespace sm20 {
// A resize/fullscreen call can run on the window thread while Present waits.
// Count every transition, including same-size and failed requests: old captures
// must not be restored after one, even when it finished before Present returns.
class PresentationRevision {
 std::atomic_uint active_{};
 std::atomic_ullong revision_{};
 std::atomic_bool reset_{};
public:
 void begin_transition() noexcept {++active_;++revision_;reset_=true;}
 void end_transition() noexcept {reset_=true;--active_;}
 bool transitioning() const noexcept {return active_.load()!=0;}
 bool consume_reset() noexcept {return reset_.exchange(false);}
 std::uint64_t checkpoint() const noexcept {return revision_.load();}
 bool current(std::uint64_t checkpoint) const noexcept {
  return !transitioning()&&!reset_.load()&&revision_.load()==checkpoint;
 }
};
enum class RestoreResult { restored, interrupted, failed };
inline constexpr unsigned generated_do_not_wait=0x8;
inline constexpr std::int32_t present_still_drawing=static_cast<std::int32_t>(0x887a000au);
// Admission has already validated flags (0 or a legal ALLOW_TEARING).
// Synthetic work never requests a VBlank or waits for a full presentation queue.
// Queue pressure drops only that optional submission. Restore the real image
// before forwarding the caller's Present exactly once, with its original flags.
// Other DXGI statuses/errors retain their original result and reject history.
template<class Present,class Restore,class Finish,class Generated,class Busy>
std::int32_t present_pair(bool generated,unsigned sync,unsigned flags,Present present,Restore restore,Finish finish,Generated generated_accepted,Busy generated_busy){
 if(generated){
  const auto hr=static_cast<std::int32_t>(present(0,flags|generated_do_not_wait));
  if(hr!=0&&hr!=present_still_drawing){restore();finish(false);return hr;}
  if(hr==0)generated_accepted();else generated_busy();
  const auto restored=restore();
  if(restored!=RestoreResult::restored){
   finish(false);
   // A transition invalidates the captured image, including after a rejected
   // nonblocking submission. Never write or submit the stale original frame.
   return restored==RestoreResult::interrupted?hr:static_cast<std::int32_t>(0x887a0007u);
  }
 }
 // No sleeps or fixed-rate limiter. Game/driver VSync and engine limits still
 // apply to this original submission. Back-to-back acceptance is not proof of
 // distinct displayed frames: compositor drops and uneven cadence are possible.
 auto hr=static_cast<std::int32_t>(present(sync,flags));finish(hr==0);return hr;
}
}
