#!/usr/bin/env python3
"""Execute production shader bodies on a CPU sampling model (not GPU validation)."""
import hashlib,json,os,pathlib,re,subprocess,tempfile
src=pathlib.Path(__file__).resolve().parent
root=src.parents[1]
shader=(src/'shaders.hlsl').read_text()
# Strip only HLSL syntax decorations and expose swizzle getters. Do not copy or
# reimplement flow, confidence, synthesis or resolve equations in the test.
body=re.sub(r':\s*register\([^)]+\)', '', shader)
body=re.sub(r':\s*(?:SV_\w+|TEXCOORD\d+)', '', body)
body=re.sub(r'cbuffer\s+Settings\s*\{([^}]+)\};',r'\1',body)
body=body.replace('[unroll]','').replace('[loop]','').replace('[branch]','').replace('.rgb','.rgb()').replace('.xy','.xy()')
results=[]
with tempfile.TemporaryDirectory() as tmp:
 tmp=pathlib.Path(tmp)
 (tmp/'shader_under_test.hpp').write_text(body)
 for name,flags in [('optimized',['-O2']),('asan-ubsan',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(src/'test_sanitizer_options.cpp')])]:
  exe=tmp/'shader-test'
  subprocess.run(['g++','-std=c++20',*flags,'-I'+str(src),'-I'+str(tmp),str(src/'shader_regression_test.cpp'),'-o',str(exe)],check=True)
  proc=subprocess.run([str(exe)],text=True,capture_output=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
  print(proc.stdout,flush=True)
  if proc.returncode: print(proc.stderr,flush=True);proc.check_returncode()
  results.append({'configuration':name,'result':'PASS','output':proc.stdout})
files=['shaders.hlsl','shader_regression_test.cpp','shader_test_support.hpp','test_shader.py','test_sanitizer_options.cpp']
report={'result':'PASS','method':'Production HLSL bodies executed via syntax-only C++ translation and CPU bilinear/half-float texture model','shader_sha256':hashlib.sha256(shader.encode()).hexdigest(),'results':results,'Windows_executed':False,'GPU_tested':False,'source_sha256':{'source/rtx20/'+n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in files}}
(root/'validation/shader-regression.json').write_text(json.dumps(report,indent=2)+'\n')
