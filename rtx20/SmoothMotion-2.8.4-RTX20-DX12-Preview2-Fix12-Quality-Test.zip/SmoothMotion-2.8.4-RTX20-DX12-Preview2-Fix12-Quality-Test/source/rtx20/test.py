#!/usr/bin/env python3
"""Host verification of shared production policies and inherited setup/hooks."""
import argparse,hashlib,json,os,pathlib,subprocess,tempfile
root=pathlib.Path(__file__).resolve().parents[2]
cases=['rtx20/policy_test.cpp','rtx20/context_transaction_test.cpp','rtx20/smoke_validation_test.cpp','rtx20/creation_policy_test.cpp','rtx20/transfer_sequence_test.cpp','rtx20/texture_rows_test.cpp','native/gpu_wait_test.cpp','native/normal_policy_test.cpp','setup/file_plan_test.cpp','setup/uninstall_test.cpp','setup/game_config_test.cpp','setup/policy_test.cpp','setup/inspection_test.cpp','native/hook_group_test.cpp','native/slot_patch_test.cpp','native/presentation_ownership_test.cpp','native/graphics_initialization_test.cpp','native/initialization_gate_test.cpp','native/proxy_test.cpp','native/import_dispatch_test.cpp','native/startup_bootstrap_test.cpp']
parser=argparse.ArgumentParser();parser.add_argument('--ubsan-only',action='store_true');args=parser.parse_args()
san_kind='ubsan' if args.ubsan_only else 'asan-ubsan'
san_flags=['-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all'] if args.ubsan_only else ['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(root/'source/rtx20/test_sanitizer_options.cpp')]
results=[]
with tempfile.TemporaryDirectory() as directory:
 for i,name in enumerate(cases):
  for kind,flags in [('optimized',['-O2']),(san_kind,san_flags)]:
   exe=pathlib.Path(directory)/'test';extra=[]
   if name=='native/import_dispatch_test.cpp':extra=['-I'+str(root/'source/native/test_support')]
   subprocess.run(['g++','-std=c++20','-pthread',*flags,*extra,str(root/'source'/name),'-o',str(exe)],check=True)
   r=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
   if r.returncode:
    print(name,kind,'FAIL',r.stdout,r.stderr,flush=True)
    r.check_returncode()
   result={'test':name,'configuration':kind,'result':'PASS','output':r.stdout.strip()};results.append(result);print(name,kind,'PASS',flush=True)
report={'result':'PASS','suite_count':len(cases),'test_runs':len(results),'results':results,'address_sanitizer_complete':not args.ubsan_only,'GPU_tested':False,'Windows_executed':False,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'source').rglob('*')) if p.is_file() and p.suffix in ['.cpp','.h','.hpp','.hlsl','.py','.def']}}
(root/'validation/host-tests.json').write_text(json.dumps(report,indent=2)+'\n')
