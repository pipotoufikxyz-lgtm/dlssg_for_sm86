// Satisfy inherited diagnostics/ownership interfaces without loading or patching
// NvPresent. No NVIDIA Smooth Motion binary retargeting is performed by RTX20.
#include "nvs30/nvpresent.hpp"
namespace nvs30::nvpresent {
bool initialize(){return false;} void shutdown(){} HMODULE module(){return nullptr;}
bool contains_address(const void*){return false;}
bool wrapper_active(IDXGISwapChain*,void**){return false;}
bool wrapper_active(IDXGISwapChain*,void**,std::size_t*){return false;}
bool initialized(){return false;}const char* initialization_status(){return "not_used_rtx20";}
std::uint64_t cuda_success_count(){return 0;}std::uint64_t cuda_activity_count(){return 0;}
std::uint64_t cuda_failure_count(){return 0;}std::uint64_t cuda_module_failure_count(){return 0;}
std::uint64_t cuda_execution_failure_count(){return 0;}std::uint64_t cuda_intercept_count(){return 0;}
}
