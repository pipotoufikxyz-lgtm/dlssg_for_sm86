#include "dx12_transfer.hpp"
#include "policy.hpp"
#include "texture_rows.hpp"
#include "nvs30/dxgi_hooks.hpp"
#include "nvs30/gpu_wait.hpp"
#include "nvs30/log.hpp"

namespace sm20 {
using nvs30::ComPtr;
std::atomic_ullong dx12_sessions{},dx12_captures{},dx12_writes{},dx12_transfer_failures{};
namespace {
constexpr unsigned wait_ms=500;
DXGI_FORMAT plain(DXGI_FORMAT f){
 return f==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB?DXGI_FORMAT_R8G8B8A8_UNORM:
        f==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB?DXGI_FORMAT_B8G8R8A8_UNORM:f;
}
D3D12_RESOURCE_BARRIER barrier(ID3D12Resource* r,D3D12_RESOURCE_STATES before,D3D12_RESOURCE_STATES after){
 D3D12_RESOURCE_BARRIER b{};b.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
 b.Transition={r,D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES,before,after};return b;
}
}
bool same_object(IUnknown* a,IUnknown* b){
 if(!a||!b)return false;ComPtr<IUnknown> x,y;
 return SUCCEEDED(a->QueryInterface(IID_PPV_ARGS(&x)))&&SUCCEEDED(b->QueryInterface(IID_PPV_ARGS(&y)))&&x.Get()==y.Get();
}
bool presentation_queue(IDXGISwapChain* swap,IUnknown* input,ComPtr<ID3D12CommandQueue>& out){
 out.Reset();if(!swap||!input)return false;
 ComPtr<ID3D12CommandQueue> queue;ComPtr<ID3D12Device> game,owner;
 if(FAILED(input->QueryInterface(IID_PPV_ARGS(&queue)))||FAILED(swap->GetDevice(IID_PPV_ARGS(&game)))||
    FAILED(queue->GetDevice(IID_PPV_ARGS(&owner)))||!same_object(game.Get(),owner.Get()))return false;
 const auto d=queue->GetDesc();
 if(!direct_single_node(d.Type,game->GetNodeCount(),d.NodeMask))return false;
 out=queue;return true;
}
namespace {
HRESULT step(const char* operation,HRESULT hr){
 if(FAILED(hr))nvs30::logf("[rtx20-dx12] API failed: %s hr=0x%08lx\n",operation,(unsigned long)hr);
 return hr;
}
struct SharedHandle {HANDLE value{};~SharedHandle(){if(value)CloseHandle(value);}};
}
HRESULT DX12Transfer::shared(const char* label,ComPtr<ID3D12Resource>& twelve,ComPtr<ID3D11Texture2D>& eleven){
 // D3D11 opening a D3D12 allocation needs interoperable bind capabilities.
 // Keep simultaneous access and RT support; do not silently remove the interop
 // contract to make only CreateCommittedResource succeed.
 D3D12_HEAP_PROPERTIES heap{};heap.Type=D3D12_HEAP_TYPE_DEFAULT;heap.CreationNodeMask=heap.VisibleNodeMask=1;
 D3D12_RESOURCE_DESC d{};d.Dimension=D3D12_RESOURCE_DIMENSION_TEXTURE2D;d.Width=width_;d.Height=height_;
 d.DepthOrArraySize=d.MipLevels=1;d.Format=format_;d.SampleDesc.Count=1;d.Layout=D3D12_TEXTURE_LAYOUT_UNKNOWN;
 d.Flags=D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET|D3D12_RESOURCE_FLAG_ALLOW_SIMULTANEOUS_ACCESS;
 ComPtr<ID3D12Resource> resource;ComPtr<ID3D11Texture2D> opened;ComPtr<ID3D11Device1> device1;SharedHandle handle;
 nvs30::logf("[rtx20-dx12] Shared texture %s: %ux%u format=%u flags=0x%x heap=SHARED state=COMMON.\n",label,width_,height_,unsigned(format_),unsigned(d.Flags));
 auto hr=step("CreateCommittedResource(shared RT+simultaneous)",device12_->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_SHARED,&d,D3D12_RESOURCE_STATE_COMMON,nullptr,IID_PPV_ARGS(&resource)));
 if(FAILED(hr))return hr;
 // D3D12 accepts GENERIC_ALL, not GENERIC_READ|GENERIC_WRITE.
 hr=step("CreateSharedHandle(GENERIC_ALL)",device12_->CreateSharedHandle(resource.Get(),nullptr,GENERIC_ALL,nullptr,&handle.value));if(FAILED(hr))return hr;
 hr=step("QueryInterface(ID3D11Device1)",device11_.As(&device1));if(FAILED(hr))return hr;
 hr=step("OpenSharedResource1(ID3D11Texture2D)",device1->OpenSharedResource1(handle.value,IID_PPV_ARGS(&opened)));if(FAILED(hr))return hr;
 D3D11_TEXTURE2D_DESC actual{};opened->GetDesc(&actual);
 if(actual.Width!=width_||actual.Height!=height_||actual.Format!=format_||actual.MipLevels!=1||actual.ArraySize!=1||actual.SampleDesc.Count!=1)
  return step("shared texture descriptor",E_INVALIDARG);
 twelve=resource;eleven=opened;return S_OK;
}
HRESULT DX12Transfer::staging(){
 // Separate original/upload buffers preserve the real frame across the extra
 // Present. These are buffers with fixed heap states, never shared textures.
 D3D12_RESOURCE_DESC image{};image.Dimension=D3D12_RESOURCE_DIMENSION_TEXTURE2D;image.Width=width_;image.Height=height_;
 image.DepthOrArraySize=image.MipLevels=1;image.Format=format_;image.SampleDesc.Count=1;
 UINT rows{};UINT64 rowBytes{};
 device12_->GetCopyableFootprints(&image,0,1,0,&footprint_,&rows,&rowBytes,&stagingBytes_);
 if(rows!=height_||rowBytes!=std::uint64_t(width_)*4||stagingBytes_==UINT64_MAX||stagingBytes_<=footprint_.Offset||footprint_.Footprint.RowPitch<rowBytes)
  return step("GetCopyableFootprints(staging layout)",E_INVALIDARG);
 auto buffer=[&](D3D12_HEAP_TYPE type,ComPtr<ID3D12Resource>& out,const char* label){
  D3D12_HEAP_PROPERTIES heap{};heap.Type=type;heap.CreationNodeMask=heap.VisibleNodeMask=1;
  D3D12_RESOURCE_DESC d{};d.Dimension=D3D12_RESOURCE_DIMENSION_BUFFER;d.Width=stagingBytes_;d.Height=1;
  d.DepthOrArraySize=d.MipLevels=1;d.SampleDesc.Count=1;d.Layout=D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
  return step(label,device12_->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_NONE,&d,
   type==D3D12_HEAP_TYPE_READBACK?D3D12_RESOURCE_STATE_COPY_DEST:D3D12_RESOURCE_STATE_GENERIC_READ,nullptr,IID_PPV_ARGS(&out)));
 };
 auto hr=buffer(D3D12_HEAP_TYPE_READBACK,snapshot12_,"CreateCommittedResource(readback buffer)");if(FAILED(hr))return hr;
 hr=buffer(D3D12_HEAP_TYPE_UPLOAD,originalUpload12_,"CreateCommittedResource(original upload buffer)");if(FAILED(hr))return hr;
 hr=buffer(D3D12_HEAP_TYPE_UPLOAD,output12_,"CreateCommittedResource(generated upload buffer)");if(FAILED(hr))return hr;
 D3D11_TEXTURE2D_DESC d{};d.Width=width_;d.Height=height_;d.MipLevels=d.ArraySize=1;d.Format=format_;d.SampleDesc.Count=1;
 d.Usage=D3D11_USAGE_DEFAULT;d.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
 hr=step("CreateTexture2D(private snapshot)",device11_->CreateTexture2D(&d,nullptr,&snapshot11_));if(FAILED(hr))return hr;
 d.Usage=D3D11_USAGE_STAGING;d.BindFlags=0;d.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
 hr=step("CreateTexture2D(generated readback)",device11_->CreateTexture2D(&d,nullptr,&output11_));if(FAILED(hr))return hr;
 staged_=true;return S_OK;
}
HRESULT DX12Transfer::initialize_handoff(){
 // This is optional: keep the existing event-query path on older interfaces
 // or drivers that cannot export this fence. No GPU work is submitted here.
 ComPtr<ID3D11Device5> device5;ComPtr<ID3D11DeviceContext4> context4;
 ComPtr<ID3D11Fence> eleven;ComPtr<ID3D12Fence> twelve;SharedHandle handle;
 auto hr=device11_.As(&device5);if(FAILED(hr))return hr;
 hr=context11_.As(&context4);if(FAILED(hr))return hr;
 hr=device5->CreateFence(0,D3D11_FENCE_FLAG_SHARED,IID_PPV_ARGS(&eleven));if(FAILED(hr))return hr;
 hr=eleven->CreateSharedHandle(nullptr,GENERIC_ALL,nullptr,&handle.value);if(FAILED(hr))return hr;
 hr=device12_->OpenSharedHandle(handle.value,IID_PPV_ARGS(&twelve));if(FAILED(hr))return hr;
 handoffContext11_=context4;handoffFence11_=eleven;handoffFence12_=twelve;
 return S_OK;
}
HRESULT DX12Transfer::handoff11(){
 if(unsafe11_)return DXGI_ERROR_DEVICE_RESET;
 if(!pending11_)return S_OK;
 auto failed=[&](const char* operation,HRESULT hr){
  // Signal/Wait failure leaves ownership uncertain. Retain the entire session
  // rather than attempt passthrough or release a fence referenced by a queue.
  unsafe11_=true; // copy() counts this failure once.
  nvs30::logf("[rtx20-dx12] GPU handoff failed: %s hr=0x%08lx; session retained.\n",operation,(unsigned long)hr);
  return hr;
 };
 const auto target=++handoffValue_;
 auto hr=handoffContext11_->Signal(handoffFence11_.Get(),target);
 if(FAILED(hr))return failed("D3D11 Signal",hr);
 context11_->Flush();
 hr=queue_->Wait(handoffFence12_.Get(),target);
 if(FAILED(hr))return failed("D3D12 queue Wait",hr);
 // pending11_ stays true until the subsequent DX12 copy fence completes.
 // That completion transitively proves the D3D11 signal, queue wait and copy.
 return S_OK;
}
HRESULT DX12Transfer::initialize(IDXGISwapChain* swap,ID3D12CommandQueue* queue){
 if(device12_)return step("initialize called twice",DXGI_ERROR_INVALID_CALL);
 if(!presentation_queue(swap,queue,queue_))return step("presentation queue contract",DXGI_ERROR_UNSUPPORTED);
 auto hr=step("GetDevice(D3D12)",queue_->GetDevice(IID_PPV_ARGS(&device12_)));if(FAILED(hr))return hr;
 DXGI_SWAP_CHAIN_DESC chain{};hr=step("GetDesc(swapchain)",swap->GetDesc(&chain));if(FAILED(hr))return hr;
 nvs30::logf("[rtx20-dx12] Swapchain contract: %ux%u format=%u buffers=%u effect=%u windowed=%d samples=%u quality=%u flags=0x%x refresh=%u/%u usage=0x%x.\n",
  chain.BufferDesc.Width,chain.BufferDesc.Height,unsigned(chain.BufferDesc.Format),chain.BufferCount,unsigned(chain.SwapEffect),int(chain.Windowed),
  chain.SampleDesc.Count,chain.SampleDesc.Quality,chain.Flags,chain.BufferDesc.RefreshRate.Numerator,chain.BufferDesc.RefreshRate.Denominator,chain.BufferUsage);
 if(!chain.Windowed||!dx12_buffer_index(0,chain.BufferCount)||chain.SampleDesc.Count!=1||
    (chain.SwapEffect!=DXGI_SWAP_EFFECT_FLIP_DISCARD&&chain.SwapEffect!=DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL)||
    (chain.Flags&(DXGI_SWAP_CHAIN_FLAG_HW_PROTECTED|DXGI_SWAP_CHAIN_FLAG_RESTRICTED_CONTENT|DXGI_SWAP_CHAIN_FLAG_DISPLAY_ONLY)))return step("swapchain contract",DXGI_ERROR_UNSUPPORTED);
 ComPtr<IDXGISwapChain3> swap3;hr=step("QueryInterface(IDXGISwapChain3)",swap->QueryInterface(IID_PPV_ARGS(&swap3)));if(FAILED(hr))return hr;
 const auto index=swap3->GetCurrentBackBufferIndex();if(!dx12_buffer_index(index,chain.BufferCount))return step("initial backbuffer index",DXGI_ERROR_INVALID_CALL);
 ComPtr<ID3D12Resource> back;hr=step("GetBuffer(initial)",swap->GetBuffer(index,IID_PPV_ARGS(&back)));if(FAILED(hr))return hr;
 const auto d=back->GetDesc();
 if(d.Dimension!=D3D12_RESOURCE_DIMENSION_TEXTURE2D||d.DepthOrArraySize!=1||d.MipLevels!=1||d.SampleDesc.Count!=1||
    !supported_format(d.Format)||d.Width>3840||!dimensions(static_cast<unsigned>(d.Width),d.Height))return step("backbuffer contract",DXGI_ERROR_UNSUPPORTED);
 width_=static_cast<unsigned>(d.Width);height_=d.Height;format_=plain(d.Format);
 ComPtr<IDXGIFactory4> factory;ComPtr<IDXGIAdapter1> adapter;
 hr=step("CreateDXGIFactory1",CreateDXGIFactory1(IID_PPV_ARGS(&factory)));if(FAILED(hr))return hr;
 hr=step("EnumAdapterByLuid",factory->EnumAdapterByLuid(device12_->GetAdapterLuid(),IID_PPV_ARGS(&adapter)));if(FAILED(hr))return hr;
 // Native D3D11 on this exact adapter; CUDA does not see D3D11On12 resources.
 struct Creation {bool before=nvs30::dxgi::internal_creation();Creation(){nvs30::dxgi::set_internal_creation(true);}~Creation(){nvs30::dxgi::set_internal_creation(before);}} creation;
 const D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_1,D3D_FEATURE_LEVEL_11_0};D3D_FEATURE_LEVEL selected{};
 hr=step("D3D11CreateDevice(same adapter)",D3D11CreateDevice(adapter.Get(),D3D_DRIVER_TYPE_UNKNOWN,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,2,D3D11_SDK_VERSION,&device11_,&selected,&context11_));if(FAILED(hr))return hr;
 // Test-only process override permits independent exercising of the fallback.
 wchar_t forced[2]{};const bool forceStaging=GetEnvironmentVariableW(L"SM20_DX12_FORCE_STAGING",forced,2)==1&&forced[0]==L'1';
 if(!forceStaging){hr=shared("snapshot",snapshot12_,snapshot11_);if(SUCCEEDED(hr))hr=shared("output",output12_,output11_);}
 if(forceStaging||FAILED(hr)){
  // Do not mask device removal or attempt further allocation on a dead device.
  auto removed=step("D3D12 device health before fallback",device12_->GetDeviceRemovedReason());if(FAILED(removed))return removed;
  removed=step("D3D11 device health before fallback",device11_->GetDeviceRemovedReason());if(FAILED(removed))return removed;
  nvs30::logf("[rtx20-dx12] Selecting CPU staging transfer: forced=%d shared_hr=0x%08lx; performance may be lower.\n",forceStaging?1:0,(unsigned long)hr);
  snapshot11_.Reset();output11_.Reset();snapshot12_.Reset();output12_.Reset();
  hr=staging();if(FAILED(hr))return hr;
 }
 D3D11_QUERY_DESC query{D3D11_QUERY_EVENT,0};hr=step("CreateQuery(D3D11 completion)",device11_->CreateQuery(&query,&done11_));if(FAILED(hr))return hr;
 hr=step("CreateCommandAllocator",device12_->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator_)));if(FAILED(hr))return hr;
 hr=step("CreateCommandList",device12_->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator_.Get(),nullptr,IID_PPV_ARGS(&commands_)));if(FAILED(hr))return hr;
 hr=step("Close(initial command list)",commands_->Close());if(FAILED(hr))return hr;
 hr=step("CreateFence",device12_->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence_)));if(FAILED(hr))return hr;
 event_=CreateEventW(nullptr,FALSE,FALSE,nullptr);if(!event_)return step("CreateEventW",HRESULT_FROM_WIN32(GetLastError()));
 if(!staged_){
  const auto handoff=initialize_handoff();
  if(FAILED(handoff)){
   const auto removed12=device12_->GetDeviceRemovedReason(),removed11=device11_->GetDeviceRemovedReason();
   if(FAILED(removed12))return step("D3D12 health after handoff setup",removed12);
   if(FAILED(removed11))return step("D3D11 health after handoff setup",removed11);
   nvs30::logf("[rtx20-dx12] Shared GPU fence unavailable hr=0x%08lx; using CPU-query handoff.\n",(unsigned long)handoff);
  }
 }
 ++dx12_sessions;
 nvs30::logf("[rtx20-dx12] Same-adapter D3D11/CUDA transfer ready: %ux%u format=%u queue=%p mode=%s handoff=%s; bounded DX12 completion.\n",width_,height_,unsigned(format_),queue_.Get(),staged_?"cpu-staging":"shared-texture",handoffContext11_?"gpu-fence":"cpu-query");
 return S_OK;
}
HRESULT DX12Transfer::wait12(){
 return static_cast<HRESULT>(nvs30::gpu_wait::fence(value_,wait_ms,
  [&]{return fence_->GetCompletedValue();},[&](std::uint64_t v){return fence_->SetEventOnCompletion(v,event_);},
  [&](unsigned ms)->HRESULT{auto r=WaitForSingleObject(event_,ms);return r==WAIT_OBJECT_0?S_OK:r==WAIT_TIMEOUT?HRESULT_FROM_WIN32(WAIT_TIMEOUT):HRESULT_FROM_WIN32(GetLastError());},
  []{return GetTickCount64();}));
}
HRESULT DX12Transfer::wait11(){
 if(unsafe11_)return DXGI_ERROR_DEVICE_RESET;
 if(!pending11_)return S_OK;
 auto failed=[&](HRESULT hr){unsafe11_=true;++dx12_transfer_failures;nvs30::logf("[rtx20-dx12] D3D11 completion failed hr=0x%08lx; session retained.\n",(unsigned long)hr);return hr;};
 context11_->End(done11_.Get());context11_->Flush();const auto start=GetTickCount64();
 for(;;){
  BOOL complete=FALSE;auto hr=context11_->GetData(done11_.Get(),&complete,sizeof complete,D3D11_ASYNC_GETDATA_DONOTFLUSH);
  if(FAILED(hr))return failed(hr);
  if(hr==S_OK&&complete){pending11_=false;return S_OK;}
  hr=device11_->GetDeviceRemovedReason();if(FAILED(hr))return failed(hr);
  if(GetTickCount64()-start>=wait_ms)return failed(HRESULT_FROM_WIN32(WAIT_TIMEOUT));
  Sleep(0);
 }
}
HRESULT DX12Transfer::copy(IDXGISwapChain* swap,ID3D12Resource* sharedResource,bool capture){
 if(submission_.failure<0)return static_cast<HRESULT>(submission_.failure);
 if(unsafe11_)return DXGI_ERROR_DEVICE_RESET;
 if(!swap||!sharedResource)return E_INVALIDARG;
 // Shared mode queues its D3D11->D3D12 dependency once the copy list is valid.
 // Staging and older drivers retain the bounded CPU-query synchronization.
 auto hr=handoffContext11_?S_OK:wait11();if(FAILED(hr))return hr;
 bool handedOff=false;
 ComPtr<IDXGISwapChain3> current;hr=step("QueryInterface(current swapchain)",swap->QueryInterface(IID_PPV_ARGS(&current)));if(FAILED(hr))return hr;
 DXGI_SWAP_CHAIN_DESC chain{};hr=swap->GetDesc(&chain);if(FAILED(hr))return hr;
 hr=static_cast<HRESULT>(transfer_copy(submission_,[&]{return current->GetCurrentBackBufferIndex();},
  [&](unsigned index)->HRESULT{
   if(!dx12_buffer_index(index,chain.BufferCount))return DXGI_ERROR_INVALID_CALL;
   // Reacquire on every copy: our first Present advances the real DXGI index.
   inflightBack_.Reset();auto result=swap->GetBuffer(index,IID_PPV_ARGS(&inflightBack_));if(FAILED(result))return result;
   const auto d=inflightBack_->GetDesc();
   if(d.Dimension!=D3D12_RESOURCE_DIMENSION_TEXTURE2D||d.Width!=width_||d.Height!=height_||plain(d.Format)!=format_||d.SampleDesc.Count!=1||d.DepthOrArraySize!=1||d.MipLevels!=1)return DXGI_ERROR_INVALID_CALL;
   result=allocator_->Reset();if(FAILED(result))return result;
   result=commands_->Reset(allocator_.Get(),nullptr);if(FAILED(result))return result;
   const auto backState=capture?D3D12_RESOURCE_STATE_COPY_SOURCE:D3D12_RESOURCE_STATE_COPY_DEST;
   const auto sharedState=capture?D3D12_RESOURCE_STATE_COPY_DEST:D3D12_RESOURCE_STATE_COPY_SOURCE;
   // At entry/exit every game buffer is PRESENT. Only shared textures
   // transition COMMON<->COPY. Staging buffers keep their mandated heap states.
   D3D12_RESOURCE_BARRIER begin[]={barrier(inflightBack_.Get(),D3D12_RESOURCE_STATE_PRESENT,backState),barrier(sharedResource,D3D12_RESOURCE_STATE_COMMON,sharedState)};
   commands_->ResourceBarrier(staged_?1:2,begin);
   if(staged_){
    D3D12_TEXTURE_COPY_LOCATION image{};image.pResource=inflightBack_.Get();image.Type=D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    D3D12_TEXTURE_COPY_LOCATION buffer{};buffer.pResource=sharedResource;buffer.Type=D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;buffer.PlacedFootprint=footprint_;
    commands_->CopyTextureRegion(capture?&buffer:&image,0,0,0,capture?&image:&buffer,nullptr);
   }else commands_->CopyResource(capture?sharedResource:inflightBack_.Get(),capture?inflightBack_.Get():sharedResource);
   D3D12_RESOURCE_BARRIER end[]={barrier(inflightBack_.Get(),backState,D3D12_RESOURCE_STATE_PRESENT),barrier(sharedResource,sharedState,D3D12_RESOURCE_STATE_COMMON)};
   commands_->ResourceBarrier(staged_?1:2,end);
   result=step("Close(copy command list)",commands_->Close());if(FAILED(result))return result;
   // Do not enqueue a GPU wait until recording has succeeded. Successful Wait
   // is followed directly by Execute and the existing bounded completion wait.
   if(handoffContext11_&&pending11_){result=handoff11();if(FAILED(result))return result;handedOff=true;}
   return S_OK;
  },[&]{ID3D12CommandList* list=commands_.Get();queue_->ExecuteCommandLists(1,&list);},
  [&]()->HRESULT{auto result=step("Signal(copy fence)",queue_->Signal(fence_.Get(),++value_));return FAILED(result)?result:step("Wait(copy fence)",wait12());}));
 if(SUCCEEDED(hr)&&handedOff)pending11_=false;
 if(!submission_.in_flight)inflightBack_.Reset();
 if(FAILED(hr)){++dx12_transfer_failures;nvs30::logf("[rtx20-dx12] Copy failed hr=0x%08lx in_flight=%d; interpolation session disabled.\n",(unsigned long)hr,submission_.in_flight?1:0);}
 else if(capture)++dx12_captures;else ++dx12_writes;
 return hr;
}
HRESULT DX12Transfer::readback_snapshot(){
 // copy() has completed its fence; neither mapping races outstanding DX12.
 D3D12_RANGE read{0,static_cast<SIZE_T>(stagingBytes_)},none{0,0};
 void* input{};auto hr=step("Map(D3D12 snapshot readback)",snapshot12_->Map(0,&read,&input));if(FAILED(hr))return hr;
 void* original{};hr=step("Map(original upload)",originalUpload12_->Map(0,&none,&original));
 if(SUCCEEDED(hr)){
  const auto offset=static_cast<std::size_t>(footprint_.Offset),bytes=static_cast<std::size_t>(stagingBytes_)-offset;
  const auto* pixels=static_cast<const unsigned char*>(input)+offset;
  if(!copy_texture_rows(static_cast<unsigned char*>(original)+offset,bytes,footprint_.Footprint.RowPitch,
      pixels,bytes,footprint_.Footprint.RowPitch,std::size_t(width_)*4,height_))hr=E_INVALIDARG;
  if(SUCCEEDED(hr)){
   // UpdateSubresource snapshots source memory before returning; it can then be
   // unmapped. Record pending work before any later failure/cleanup path.
   pending11_=true;
   context11_->UpdateSubresource(snapshot11_.Get(),0,nullptr,pixels,footprint_.Footprint.RowPitch,0);
   hr=step("D3D11 snapshot update health",device11_->GetDeviceRemovedReason());
  }
  D3D12_RANGE written{offset,static_cast<SIZE_T>(stagingBytes_)};originalUpload12_->Unmap(0,&written);
 }
 snapshot12_->Unmap(0,&none);return step("readback snapshot rows",hr);
}
HRESULT DX12Transfer::upload_generated(ID3D11Texture2D* generated){
 // output11_ is a CPU-readable D3D11 staging texture in this mode.
 pending11_=true;context11_->CopyResource(output11_.Get(),generated);
 auto hr=wait11();if(FAILED(hr))return hr;
 D3D11_MAPPED_SUBRESOURCE mapped{};
 hr=step("Map(D3D11 generated staging)",context11_->Map(output11_.Get(),0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&mapped));if(FAILED(hr))return hr;
 void* output{};D3D12_RANGE none{0,0};hr=step("Map(generated upload)",output12_->Map(0,&none,&output));
 if(SUCCEEDED(hr)){
  std::size_t sourceBytes{};const auto offset=static_cast<std::size_t>(footprint_.Offset);
  if(!texture_span(mapped.RowPitch,std::size_t(width_)*4,height_,sourceBytes)||
     !copy_texture_rows(static_cast<unsigned char*>(output)+offset,static_cast<std::size_t>(stagingBytes_)-offset,footprint_.Footprint.RowPitch,
       mapped.pData,sourceBytes,mapped.RowPitch,std::size_t(width_)*4,height_))hr=E_INVALIDARG;
  D3D12_RANGE written{offset,static_cast<SIZE_T>(stagingBytes_)};output12_->Unmap(0,&written);
 }
 context11_->Unmap(output11_.Get(),0);return step("upload generated rows",hr);
}
HRESULT DX12Transfer::capture(IDXGISwapChain* swap){
 auto hr=copy(swap,snapshot12_.Get(),true);
 if(SUCCEEDED(hr)&&staged_){hr=readback_snapshot();if(FAILED(hr))++dx12_transfer_failures;}
 return hr;
}
HRESULT DX12Transfer::write_generated(IDXGISwapChain* swap,ID3D11Texture2D* generated){
 if(submission_.failure<0||unsafe11_)return DXGI_ERROR_DEVICE_RESET;
 if(!generated)return E_INVALIDARG;
 D3D11_TEXTURE2D_DESC d{};generated->GetDesc(&d);ComPtr<ID3D11Device> owner;generated->GetDevice(&owner);
 if(!same_object(owner.Get(),device11_.Get())||d.Width!=width_||d.Height!=height_||d.Format!=format_||d.MipLevels!=1||d.ArraySize!=1||d.SampleDesc.Count!=1)
  return step("generated texture contract",E_INVALIDARG);
 if(staged_){auto hr=upload_generated(generated);if(FAILED(hr)){++dx12_transfer_failures;return hr;}}
 else{pending11_=true;context11_->CopyResource(output11_.Get(),generated);}
 return copy(swap,output12_.Get(),false);
}
HRESULT DX12Transfer::write_original(IDXGISwapChain* swap){
 return copy(swap,staged_?originalUpload12_.Get():snapshot12_.Get(),false);
}
bool DX12Transfer::quiesce(){return !uncertain()&&SUCCEEDED(wait11());}
DX12Transfer::~DX12Transfer(){if(event_)CloseHandle(event_);}
}
