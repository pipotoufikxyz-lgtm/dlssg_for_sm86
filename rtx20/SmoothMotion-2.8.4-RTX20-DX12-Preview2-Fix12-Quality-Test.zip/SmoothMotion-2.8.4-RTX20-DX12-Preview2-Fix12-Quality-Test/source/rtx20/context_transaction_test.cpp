#include "context_transaction.hpp"
#include <atomic>
#include <cassert>
#include <future>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <thread>

struct FakeContext {
 const bool protectedContext;
 std::recursive_mutex mutex;
 std::atomic_uint checks{},enters{},leaves{};
 int state=10;
 explicit FakeContext(bool enabled):protectedContext(enabled){}
 bool GetMultithreadProtected(){++checks;return protectedContext;}
 void Enter(){mutex.lock();++enters;}
 void Leave(){++leaves;mutex.unlock();}
 void setState(int value){std::scoped_lock hold(mutex);state=value;}
};

void interleaving(bool enabled){
 FakeContext context(enabled);
 std::promise<bool> attempted;
 auto result=attempted.get_future();
 std::thread engine;
 int observed=-1;
 {
  sm20::ContextTransaction scope(&context);
  context.setState(20); // The mod's temporary pipeline.
  engine=std::thread([&]{
   const bool acquired=context.mutex.try_lock();
   if(acquired){observed=context.state;context.mutex.unlock();}
   attempted.set_value(acquired);
   if(!acquired){std::scoped_lock hold(context.mutex);observed=context.state;}
  });
  // The worker has actually attempted to enter; no timing-based assertion.
  assert(result.get()==!enabled);
  context.setState(30); // A second graphics call in the transaction.
  context.setState(10); // Restore the game's pipeline before releasing.
 }
 engine.join();
 assert(observed==(enabled?10:20));
 assert(context.checks==1);
 assert(context.enters==unsigned(enabled)&&context.leaves==unsigned(enabled));
}

int main(){
 interleaving(true);
 interleaving(false);
 {sm20::ContextTransaction<FakeContext> scope(nullptr);}
 FakeContext context(true);
 try{sm20::ContextTransaction scope(&context);throw std::runtime_error("abort");}
 catch(const std::runtime_error&){}
 assert(context.enters==1&&context.leaves==1);
 bool released=false;
 std::thread observer([&]{released=context.mutex.try_lock();if(released)context.mutex.unlock();});
 observer.join();assert(released);
 std::cout<<"PASS: protected game context prevents interleaving; disabled/null contexts and exception release\n";
}
