"""Shared Windows cross-compiler selection (Zig or LLVM-MinGW)."""
import pathlib,subprocess

def arguments(parser):
 group=parser.add_mutually_exclusive_group(required=True)
 group.add_argument('--zig',help='Zig 0.14.1 executable')
 group.add_argument('--cxx',help='LLVM-MinGW x86_64-w64-mingw32-clang++ executable')

def forwarded(args):
 return ['--zig',str(pathlib.Path(args.zig).absolute())] if args.zig else ['--cxx',str(pathlib.Path(args.cxx).absolute())]

def command(args,output):
 if args.zig:return [str(pathlib.Path(args.zig).absolute()),'c++','-target','x86_64-windows-gnu']
 # Retain the target-prefixed driver name; resolving its symlink changes how
 # LLVM-MinGW discovers its sysroot and libraries.
 return [str(pathlib.Path(args.cxx).absolute()),'-target','x86_64-w64-windows-gnu','-D_WIN32_WINNT=0x0A00','-DWINVER=0x0A00','-g','-gcodeview','-static','-Wl,--pdb='+str(pathlib.Path(output).with_suffix('.pdb'))]

def identity(args):
 exe=forwarded(args)[1]
 return subprocess.check_output([exe,'version' if args.zig else '--version'],text=True).splitlines()[0]
