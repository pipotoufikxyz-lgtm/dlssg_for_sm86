#pragma once
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <initializer_list>
#include <limits>
#include <vector>
#include <type_traits>
namespace motion {
inline bool importRange(size_t offset,size_t bytes,size_t size){return offset<=size&&bytes<=size-offset;}
// Reader is an exact-copy operation. Native use calls ReadProcessMemory on
// this process; host tests inject inaccessible ranges and truncated reads.
// Cache one 4 KiB block so scanning an IAT does not need one system call per slot.
template<class Read> class ImportPageReader {
public:
 ImportPageReader(size_t size,Read read):size_(size),read_(read){}
 bool operator()(size_t at,void* out,size_t bytes){
  if(!importRange(at,bytes,size_))return false;
  auto* target=static_cast<unsigned char*>(out);
  while(bytes){
   const auto page=at&~size_t(4095);
   if(page!=cached_){
    cached_=std::numeric_limits<size_t>::max();
    const auto count=std::min<size_t>(4096,size_-page);
    if(!read_(page,cache_.data(),count))return false;
    cached_=page;
   }
   const auto count=std::min(bytes,size_t(4096)-(at-page));
   std::memcpy(target,cache_.data()+(at-page),count);at+=count;target+=count;bytes-=count;
  }
  return true;
 }
private:
 size_t size_,cached_=std::numeric_limits<size_t>::max();Read read_;std::array<unsigned char,4096> cache_{};
};
struct ImportSlot {
 size_t offset;std::uint64_t value;
 size_t dllName=0,lookup=0,index=0,imageSize=0;bool delayed=false;
};
struct ImportIdentity {std::array<char,128> dll{};std::array<char,256> symbol{};};
// Identity is supplementary: stripped/malformed name tables never invalidate
// an otherwise verified address-only scan and never grant named admission.
template<class Read> bool readImportIdentity(const ImportSlot& slot,Read& read,ImportIdentity& out){
 out={};
 auto copy=[&](size_t at,void* value,size_t bytes){return importRange(at,bytes,slot.imageSize)&&read(at,value,bytes);};
 if(!slot.lookup||slot.index>slot.imageSize/8)return false;
 const auto advance=slot.index*8;
 if(!importRange(slot.lookup,advance,slot.imageSize))return false;
 std::uint64_t name=0;if(!copy(slot.lookup+advance,&name,8)||!name||(name>>32))return false;
 auto text=[&](size_t at,auto& buffer){
  if(!at)return false;
  for(size_t i=0;i<buffer.size();++i){
   if(!importRange(at,i+1,slot.imageSize)||!copy(at+i,&buffer[i],1))return false;
   if(!buffer[i])return i!=0;
  }
  return false;
 };
 return importRange(static_cast<size_t>(name),2,slot.imageSize)&&text(slot.dllName,out.dll)&&text(static_cast<size_t>(name)+2,out.symbol);
}
constexpr size_t maxImportSlots=65536,maxImportDescriptors=4096;
// No visitor runs until BOTH normal and delay import tables have passed. A
// missing later terminator/read must not leave an earlier hook half-installed.
template<class Read,class Visit> bool visitImportSlotsReader(size_t available,Read&& read,Visit visit,
 std::initializer_list<const char*> excludedExports={}){
 auto copy=[&](size_t at,void* out,size_t bytes){return importRange(at,bytes,available)&&read(at,out,bytes);};
 auto u16=[](const unsigned char* p){std::uint16_t v;std::memcpy(&v,p,2);return v;};
 auto u32=[](const unsigned char* p){std::uint32_t v;std::memcpy(&v,p,4);return v;};
 std::array<unsigned char,128> header{};
 if(!copy(0,header.data(),64)||u16(header.data())!=0x5a4d)return false;
 const size_t nt=u32(header.data()+60);
 if(!copy(nt,header.data(),24)||u32(header.data())!=0x4550||u16(header.data()+4)!=0x8664)return false;
 const size_t optional=nt+24,optionalBytes=u16(header.data()+20);
 if(optionalBytes<112||!importRange(optional,optionalBytes,available)||!copy(optional,header.data(),112)||u16(header.data())!=0x20b)return false;
 const size_t size=u32(header.data()+56);
 const size_t directoryCount=u32(header.data()+108);
 if(size>available||size<optional+optionalBytes||directoryCount>(optionalBytes-112)/8)return false;
 struct Directory {size_t address=0,bytes=0;};
 auto getDirectory=[&](size_t index,Directory& out){
  if(index>=directoryCount)return true;
  std::array<unsigned char,8> data{};
  if(!copy(optional+112+index*8,data.data(),data.size()))return false;
  out={u32(data.data()),u32(data.data()+4)};return true;
 };
 Directory exported,normal,delayed;
 if(!getDirectory(0,exported)||!getDirectory(1,normal)||!getDirectory(13,delayed))return false;
 const size_t exports=exported.address,exportBytes=exported.bytes;
 // Identify loader/backend exports without asking GetProcAddress to read
 // potentially inaccessible PE export pages itself. PE name tables are sorted.
 if(excludedExports.size()&&(exports||exportBytes)){
  std::array<unsigned char,40> exp{};
  if(!exports||exportBytes<exp.size()||!importRange(exports,exportBytes,size)||!copy(exports,exp.data(),exp.size()))return false;
  const size_t count=u32(exp.data()+24),names=u32(exp.data()+32);
  if(count&&(!names||count>size/4||!importRange(names,count*4,size)))return false;
  for(const auto* wanted:excludedExports){
   size_t low=0,high=count;
   while(low<high){
    const auto middle=low+(high-low)/2;std::uint32_t name{};
    if(!copy(names+middle*4,&name,4)||!name||name>=size)return false;
    int order=0;
    // Compare only the target prefix. Long C++ export names are legitimate;
    // do not reject a module merely because an unrelated name is long.
    for(size_t n=0;;++n){
     unsigned char byte{};
     if(!importRange(name,n+1,size)||!copy(name+n,&byte,1))return false;
     const auto target=static_cast<unsigned char>(wanted[n]);
     if(byte!=target){order=byte<target?-1:1;break;}
     if(!byte)return true; // intentionally excluded
    }
    if(order<0)low=middle+1;else high=middle;
   }
  }
 }
 std::vector<ImportSlot> slots;
 auto collect=[&](size_t first,size_t dllName,size_t lookup,bool delayed){
  if(!first||first%8||!importRange(first,8,size))return false;
  bool terminated=false;
  for(size_t slot=first;importRange(slot,8,size);slot+=8){
   std::uint64_t value{};if(!copy(slot,&value,8))return false;
   if(!value){terminated=true;break;}
   if(slots.size()==maxImportSlots)return false;
   slots.push_back({slot,value,dllName,lookup,(slot-first)/8,size,delayed});
  }
  return terminated;
 };
 auto descriptors=[&](Directory directory,bool delay){
  if(!directory.address&&!directory.bytes)return true;
  const size_t stride=delay?32:20;
  if(!directory.address||!importRange(directory.address,directory.bytes,size)||
     directory.bytes<stride||directory.bytes/stride>maxImportDescriptors)return false;
  for(size_t n=0;n<directory.bytes/stride;++n){
   std::array<unsigned char,32> descriptor{};
   if(!copy(directory.address+n*stride,descriptor.data(),stride))return false;
   if(std::all_of(descriptor.begin(),descriptor.begin()+stride,[](auto byte){return byte==0;}))return true;
   if(delay&&u32(descriptor.data())!=1)return false; // PE32+ RVA form only.
   const size_t name=u32(descriptor.data()+(delay?4:12));
   if(!name||name>=size)return false;
   if(delay){
    // Optional handle/name/bound/unload tables must still point inside the
    // image. Only the active delay IAT is visited; never the unload copy.
    for(const size_t at:{size_t(8),size_t(16),size_t(20),size_t(24)}){
     const size_t rva=u32(descriptor.data()+at);
     if(rva&&(rva%8||!importRange(rva,8,size)))return false;
    }
   }
   if(!collect(u32(descriptor.data()+(delay?12:16)),name,u32(descriptor.data()+(delay?16:0)),delay))return false;
  }
  return false;
 };
 if(!descriptors(normal,false)||!descriptors(delayed,true))return false;
 for(const auto& slot:slots){
  if constexpr(std::is_invocable_v<Visit,const ImportSlot&>)visit(slot);
  else visit(slot.offset,slot.value);
 }
 return true;
}
template<class Visit> bool visitImportSlots(unsigned char* image,size_t available,Visit visit){
 if(!image)return false;
 return visitImportSlotsReader(available,[&](size_t at,void* out,size_t bytes){
  if(!importRange(at,bytes,available))return false;std::memcpy(out,image+at,bytes);return true;
 },visit);
}
}
