#pragma once
#include <algorithm>
#include <array>
#include <cstddef>
namespace motion {
inline bool supportedAPIs(unsigned bits){return !bits||(bits&3)!=0;}
inline bool dx12Queue(unsigned type,unsigned nodes,unsigned mask){return type==0&&nodes==1&&(mask==0||mask==1);}
inline bool dx12Buffers(unsigned count,unsigned index){return count>=2&&count<=16&&index<count;}
}
