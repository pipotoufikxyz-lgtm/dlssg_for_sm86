#include "import_slots.hpp"
#include <array>
#include <iostream>
#include <stdexcept>
#include <vector>
int main(){
 unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("Import bounds check "+std::to_string(checks));};
 std::vector<unsigned char> image(4096);
 auto set16=[&](size_t at,std::uint16_t value){std::memcpy(image.data()+at,&value,2);};
 auto set32=[&](size_t at,std::uint32_t value){std::memcpy(image.data()+at,&value,4);};
 auto set64=[&](size_t at,std::uint64_t value){std::memcpy(image.data()+at,&value,8);};
 set16(0,0x5a4d);set32(60,128);set32(128,0x4550);set16(132,0x8664);set16(148,240);set16(152,0x20b);set32(208,4096);set32(260,16);set32(272,512);set32(276,40);
 set32(524,768);set32(528,1024);set64(1024,0x12345678);set64(1032,0xabcdef);
 std::vector<size_t> slots;auto visit=[&](size_t slot,std::uint64_t){slots.push_back(slot);};
 check(motion::visitImportSlots(image.data(),image.size(),visit));check(slots==std::vector<size_t>{1024,1032});
 // OriginalFirstThunk may be absent in a valid loaded/bound image.
 check(image[512]==0);set64(1024,0xfeed);slots.clear();check(motion::visitImportSlots(image.data(),image.size(),visit));check(slots.size()==2);
 for(size_t size:{0u,10u,63u,151u,200u,511u,4095u})check(!motion::visitImportSlots(image.data(),size,visit));
 check(!motion::visitImportSlots(nullptr,4096,visit));
 set32(60,0xfffffff0);check(!motion::visitImportSlots(image.data(),image.size(),visit));set32(60,128);
 set16(152,0x10b);check(!motion::visitImportSlots(image.data(),image.size(),visit));set16(152,0x20b);
 set32(272,4090);check(!motion::visitImportSlots(image.data(),image.size(),visit));set32(272,512);
 set32(276,20);check(!motion::visitImportSlots(image.data(),image.size(),visit));set32(276,40);
 set32(528,4088);set64(4088,1);check(!motion::visitImportSlots(image.data(),image.size(),visit));set64(4088,0);check(motion::visitImportSlots(image.data(),image.size(),visit));
 set32(528,1025);check(!motion::visitImportSlots(image.data(),image.size(),visit));
 check(!motion::importRange(size_t(-4),8,size_t(-1)));check(motion::importRange(16,0,16));
 set32(528,1024);const auto good=image;
 // A malformed later descriptor cannot invoke even the first mutation visitor.
 set32(544,900);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());image=good;
 set32(532,1);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());image=good;
 set16(132,0x14c);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());image=good;
 // Fail each exact-copy step, including the terminator. None can be treated
 // as a zero-filled successful read or allow a partial patch.
 unsigned reads=0;
 auto reader=[&](size_t at,void* out,size_t bytes){check(motion::importRange(at,bytes,image.size()));++reads;std::memcpy(out,image.data()+at,bytes);return true;};
 slots.clear();check(motion::visitImportSlotsReader(image.size(),reader,visit));const auto totalReads=reads;
 for(unsigned failure=1;failure<=totalReads;++failure){
  reads=0;slots.clear();
  check(!motion::visitImportSlotsReader(image.size(),[&](size_t at,void* out,size_t bytes){if(++reads==failure)return false;std::memcpy(out,image.data()+at,bytes);return true;},visit));
  check(slots.empty());
 }
 // Export-based loader/backend exclusion is bounded and never calls the
 // operating system's raw export resolver on the scanned module.
 set32(264,600);set32(268,80);set32(624,1);set32(632,704);set32(704,800);
 const char marker[]="SmoothMotionGetStatus";std::memcpy(image.data()+800,marker,sizeof marker);
 slots.clear();check(motion::visitImportSlotsReader(image.size(),reader,visit,{"SmoothMotionGetStatus"}));check(slots.empty());
 slots.clear();check(motion::visitImportSlotsReader(image.size(),reader,visit,{"OtherExport"}));check(slots.size()==2);
 set32(704,2048);std::memcpy(image.data()+2048,marker,sizeof marker);
 std::memset(image.data()+2048+sizeof(marker)-1,'Z',1000);
 slots.clear();check(motion::visitImportSlotsReader(image.size(),reader,visit,{"SmoothMotionGetStatus"}));check(!slots.empty());image=good;
 set32(264,600);set32(268,80);set32(624,1);set32(632,704);set32(704,4095);image[4095]='S';
 slots.clear();check(!motion::visitImportSlotsReader(image.size(),reader,visit,{"SmoothMotionGetStatus"}));check(slots.empty());image=good;
 // Bounded work even when a large mapped image has no IAT terminator.
 image.resize(1024*1024);set32(208,image.size());
 for(size_t n=0;n<=motion::maxImportSlots;++n)set64(1024+n*8,1);
 slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 set32(276,(motion::maxImportDescriptors+1)*20);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());image=good;
 // Exercise native page caching across boundaries and after a failed copy.
 std::vector<unsigned char> pages(8200);for(size_t i=0;i<pages.size();++i)pages[i]=i%251;
 unsigned copies=0;bool deny=false;
 auto pageCopy=[&](size_t at,void* out,size_t bytes){++copies;check(motion::importRange(at,bytes,pages.size()));if(deny)return false;std::memcpy(out,pages.data()+at,bytes);return true;};
 motion::ImportPageReader cached(pages.size(),pageCopy);std::array<unsigned char,16> out{};
 check(cached(0,out.data(),8));check(cached(8,out.data(),8));check(copies==1);
 check(cached(4090,out.data(),16));check(copies==2);check(std::memcmp(out.data(),pages.data()+4090,16)==0);
 deny=true;check(!cached(0,out.data(),8));deny=false;check(cached(0,out.data(),8));check(copies==4);
 check(cached(8192,out.data(),8));check(!cached(8192,out.data(),9));check(!cached(size_t(-4),out.data(),8));
 // Delay-load DLLs are used by optional renderer modules. Visit only their
 // active IAT; bound and unload copies must not be patched.
 image=good;set32(368,1408);set32(372,64);
 set32(1408,1);set32(1412,1800);set32(1416,1816);set32(1420,1536);
 set32(1424,1600);set32(1428,1664);set32(1432,1728);
 set64(1536,0x12345678);set64(1544,0xabcdef);
 set64(1664,0x12345678);set64(1728,0x12345678);
 slots.clear();check(motion::visitImportSlots(image.data(),image.size(),visit));
 check(slots==std::vector<size_t>{1024,1032,1536,1544});
 const auto goodDelayed=image;
 set32(272,0);set32(276,0);slots.clear();check(motion::visitImportSlots(image.data(),image.size(),visit));
 check(slots==std::vector<size_t>{1536,1544});image=goodDelayed;
 // Unresolved thunks remain data to the visitor. Parsing never calls them;
 // the runtime can bind their exact ABI from validated import-name metadata.
 set64(1536,2048);slots.clear();check(motion::visitImportSlots(image.data(),image.size(),visit));check(slots.size()==4);image=goodDelayed;
 reads=0;slots.clear();check(motion::visitImportSlotsReader(image.size(),reader,visit));const auto delayReads=reads;
 for(unsigned failure=1;failure<=delayReads;++failure){
  reads=0;slots.clear();
  check(!motion::visitImportSlotsReader(image.size(),[&](size_t at,void* out,size_t bytes){if(++reads==failure)return false;std::memcpy(out,image.data()+at,bytes);return true;},visit));
  check(slots.empty());
 }
 for(const auto field:{size_t(1408),size_t(1412),size_t(1416),size_t(1420),size_t(1424),size_t(1428),size_t(1432)}){
  image=goodDelayed;set32(field,0xfffffff9);slots.clear();
  check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 }
 image=goodDelayed;set32(1408,0);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 image=goodDelayed;set32(372,32);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 image=goodDelayed;set32(1440,1);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 image=goodDelayed;set32(1420,4088);set64(4088,1);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 image=good;set32(260,0);slots.clear();check(motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 image=good;set32(260,17);slots.clear();check(!motion::visitImportSlots(image.data(),image.size(),visit));check(slots.empty());
 // Supplementary name metadata admits only bounded normal/delay names.
 image=good;set32(512,1280);set64(1280,1344);set64(1288,1400);
 std::strcpy(reinterpret_cast<char*>(image.data()+768),"dxgi.dll");
 std::strcpy(reinterpret_cast<char*>(image.data()+1346),"CreateDXGIFactory");
 std::strcpy(reinterpret_cast<char*>(image.data()+1402),"CreateDXGIFactory1");
 std::vector<motion::ImportSlot> identities;
 auto detail=[&](const motion::ImportSlot& slot){identities.push_back(slot);};
 check(motion::visitImportSlotsReader(image.size(),reader,detail));check(identities.size()==2);
 motion::ImportIdentity identity;
 check(motion::readImportIdentity(identities[0],reader,identity));
 check(std::string(identity.dll.data())=="dxgi.dll"&&std::string(identity.symbol.data())=="CreateDXGIFactory");
 check(!identities[0].delayed&&identities[1].index==1);
 const auto namesGood=image;
 for(auto value:{std::uint64_t{0},std::uint64_t{1}<<63,std::uint64_t{1}<<32,std::uint64_t{4095}}){
  set64(1280,value);check(!motion::readImportIdentity(identities[0],reader,identity));
 }
 image=namesGood;std::memset(image.data()+1346,'X',256);check(!motion::readImportIdentity(identities[0],reader,identity));
 image=namesGood;std::memset(image.data()+768,'X',128);check(!motion::readImportIdentity(identities[0],reader,identity));
 image=namesGood;auto forged=identities[0];forged.lookup=size_t(-7);check(!motion::readImportIdentity(forged,reader,identity));
 forged=identities[0];forged.index=size_t(-1);check(!motion::readImportIdentity(forged,reader,identity));
 for(unsigned fail=1;fail<35;++fail){
  unsigned n=0;auto partial=[&](size_t at,void* out,size_t count){return ++n!=fail&&reader(at,out,count);};
  auto valid=motion::readImportIdentity(identities[0],partial,identity);if(n>=fail)check(!valid);
 }
 image=goodDelayed;std::strcpy(reinterpret_cast<char*>(image.data()+1800),"d3d12.dll");
 set64(1600,1900);std::strcpy(reinterpret_cast<char*>(image.data()+1902),"D3D12CreateDevice");
 identities.clear();check(motion::visitImportSlotsReader(image.size(),reader,detail));
 check(identities[2].delayed&&motion::readImportIdentity(identities[2],reader,identity));
 check(std::string(identity.dll.data())=="d3d12.dll"&&std::string(identity.symbol.data())=="D3D12CreateDevice");
 // Deterministic malformed-header mutations under ASan/UBSan. Invalid input
 // must produce zero visitors; accepted visitors stay within the mapped image.
 std::uint32_t seed=0x86;
 for(unsigned mutation=0;mutation<5000;++mutation){
  image=mutation%2?goodDelayed:good;seed=seed*1664525u+1013904223u;const auto at=seed%image.size();seed=seed*1664525u+1013904223u;image[at]^=static_cast<unsigned char>(seed);
  slots.clear();const bool valid=motion::visitImportSlots(image.data(),image.size(),visit);
  if(!valid)check(slots.empty());for(auto slot:slots)check(motion::importRange(slot,8,image.size())&&slot%8==0);
 }
 std::cout<<checks<<" import checks: normal/delay tables validated together, active IAT only, exact-copy failures, export exclusion, bounded work, cached page boundaries; 5000 malformed mutations. Host memory only.\n";
}
