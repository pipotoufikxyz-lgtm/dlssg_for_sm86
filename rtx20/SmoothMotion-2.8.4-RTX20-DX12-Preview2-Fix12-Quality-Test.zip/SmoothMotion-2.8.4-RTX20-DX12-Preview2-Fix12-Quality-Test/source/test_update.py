#!/usr/bin/env python3
"""Portable production-code regressions; no Windows or game execution."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile,sys
p=argparse.ArgumentParser();p.add_argument("--nvp-reference",type=Path);p.add_argument("--nvp-61714",type=Path);options=p.parse_args()
ROOT=Path(__file__).resolve().parent.parent
cases=[('installation changes and upgrades','setup/file_plan_test.cpp'),('loader review and protocol','setup/plan_test.cpp'),('large PE and engine dependencies','setup/inspection_test.cpp'),('malformed PE inputs','diagnostic/pe_reader_test.cpp'),('artwork identities and JSON','manager/test/artwork.cpp'),('path and ownership protections','setup/policy_test.cpp'),('game identity and Steam metadata','manager/test/detection.cpp')]
cases.extend([('protected Xbox target and exact metadata architecture policy','setup/game_config_test.cpp'),('production executable picker and COM ownership','ui/file_picker_test.cpp')])
cases.append(('production Xbox collection and bounded folder scanner','manager/test/folder_scan.cpp'))
cases.append(('Trails/KCD II native presentation and untouched factory/overlay tables','native/presentation_profile_test.cpp'))
results=[]
cases.append(('owned per-game uninstall and receipt policy','setup/uninstall_test.cpp'))
cases.append(('stale menu selection during discovery','manager/selection_test.cpp'))
cases.append(('English and Simplified Chinese UI catalog','manager/localization_test.cpp'))
cases.append(('standalone version proxy Windows API forwarding','native/proxy_test.cpp'))
cases.append(('production import dispatch, provider forwarding and small caller stacks','native/import_dispatch_test.cpp'))
cases.append(('immutable provider registration and concurrent publication','native/provider_table_test.cpp'))
cases.append(('immutable named target bindings and ABI admission','native/target_bindings_test.cpp'))
cases.append(('nonblocking loader-sensitive initialization and publication','native/initialization_gate_test.cpp'))
cases.append(('bounded initializer exception records and fault policy','native/init_trace_test.cpp'))
cases.append(('production initializer trace registration, lifetime and exception forwarding','native/init_trace_lifecycle_test.cpp'))
cases.append(('bounded crash-event parsing and exact executable matching','diagnostic/crash_events_test.cpp'))
cases.append(('bounded mapped-PE import slots','motion/import_slots_test.cpp'))
cases.append(('native CUDA container bounds and ELF preservation','native/fatbin_test.cpp'))
cases.append(('CUDA image capture across readable regions','native/fatbin_capture_test.cpp'))
cases.append(('driver patch rollback under protection and cache failures','native/patch_transaction_test.cpp'))
cases.append(('bounded GPU fence waits and exact failure results','native/gpu_wait_test.cpp'))
cases.append(('bridge retry state survives resource reset','native/bridge_retry_test.cpp'))
cases.append(('CUDA pointer ownership and exact rollback','native/pointer_journal_test.cpp'))
cases.append(('graphics import/vtable compare-exchange rollback','native/slot_patch_test.cpp'))
cases.append(('late renderer discovery and resource-only load policy','native/module_watch_test.cpp'))
cases.append(('complete vtable groups and interface-extension rollback','native/hook_group_test.cpp'))
cases.append(('presentation failures, probes and CUDA activity windows','native/presentation_test.cpp'))
cases.append(('driver file layout and code fingerprints','native/driver_layout_test.cpp'))
cases.append(('exact driver model profile and output oracle','native/driver_profile_test.cpp'))
cases.append(('617.14 real binary acceptance, ELF ABI 8 profile and GP8 regression','native/driver61714_test.cpp'))
cases.append(('loaded model profile transaction failures','native/profile_transaction_test.cpp'))
cases.append(('CUDA module discovery versus execution failures','native/cuda_health_test.cpp'))
cases.append(('normal-mode CLI and graphics API restrictions','native/normal_policy_test.cpp'))
cases.append(('KCD II, Dead Space and Genshin ASI/standalone startup without a graphics callback','native/startup_bootstrap_test.cpp'))
cases.append(('first graphics caller configuration and initialization ordering','native/graphics_initialization_test.cpp'))
cases.append(('native presentation forwarding and shared-table wrapper detection','native/presentation_ownership_test.cpp'))
cases.append(('Manager helper lifetime, complete reports and bounded overflow','manager/test/process.cpp'))
with tempfile.TemporaryDirectory() as temp:
 for index,(label,name) in enumerate(cases):
  for config,flags in [('optimized',['-O2']),('asan-ubsan',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
   print(f'[{index+1}/{len(cases)}] {config}: {label}',file=sys.stderr,flush=True)
   exe=Path(temp)/f'{index}-{config}'
   threaded=name in ('native/startup_bootstrap_test.cpp','native/target_bindings_test.cpp','native/provider_table_test.cpp','native/proxy_test.cpp','native/import_dispatch_test.cpp','native/initialization_gate_test.cpp','native/init_trace_lifecycle_test.cpp','native/graphics_initialization_test.cpp','native/presentation_ownership_test.cpp')
   seams=['-I',str(ROOT/'source/native/test_support')] if name=='native/import_dispatch_test.cpp' else []
   if name=='native/init_trace_lifecycle_test.cpp':seams=['-I',str(ROOT/'source/native/include')]
   if name=='ui/file_picker_test.cpp':seams=['-I',str(ROOT/'source/ui/test_support')]
   if name=='manager/test/process.cpp':seams=['-I',str(ROOT/'source/manager/test/win32')]
   subprocess.run(['g++','-std=c++20' if name.startswith('native/') else '-std=c++17',*flags,*(['-pthread'] if threaded else []),*seams,str(ROOT/'source'/name),*(['-lcrypto'] if name in ('native/driver_layout_test.cpp','native/driver_profile_test.cpp','native/driver61714_test.cpp') else []),'-o',str(exe)],check=True)
   args=[str(exe)]+([str(ROOT/'source/manager/test/fixtures')] if name.endswith('detection.cpp') else [])
   if name=='native/import_dispatch_test.cpp' and config=='optimized':args.append('--small-stack')
   if options.nvp_reference and name in ('native/fatbin_test.cpp','native/driver_layout_test.cpp','native/driver_profile_test.cpp'):args.append(str(options.nvp_reference.resolve()))
   if options.nvp_61714 and name=='native/driver61714_test.cpp':args.append(str(options.nvp_61714.resolve()))
   r=subprocess.run(args,capture_output=True,text=True,check=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
   results.append({'test':label,'configuration':config,'result':'PASS','output':r.stdout.strip()})
identities=['source/native/test_reference/gp8_driver_profile.hpp','source/native/test_reference/gp8_driver_layout.hpp','source/manager/core.hpp','source/manager/folder_scan.hpp','source/setup/test_reference/gp7_game_config_policy.hpp','source/native/include/nvs30/startup_profile.hpp','source/native/test_reference/gp6_startup_bootstrap.hpp','source/native/include/nvs30/loader_context.hpp','source/native/include/nvs30/startup_bootstrap.hpp','source/native/include/nvs30/asi_entry.hpp','source/native/src/dllmain.cpp','source/setup/game_config_policy.hpp','source/setup/windows_game_target.hpp','source/setup/windows_pe.hpp','source/ui/file_picker.hpp','source/ui/test_support/windows.h','source/ui/test_support/shobjidl.h','source/ui/test_support/shlobj.h','source/manager/catalog.hpp','source/test_update.py',*[str(Path('source')/name) for _,name in cases],
 'source/manager/process.hpp','source/manager/test/win32/windows.h','source/native/include/nvs30/presentation_profile.hpp','source/native/include/nvs30/graphics_initialization.hpp','source/native/include/nvs30/presentation_ownership.hpp','source/native/include/nvs30/dxgi_hooks.hpp','source/native/src/d3d11_bridge.cpp','source/native/include/nvs30/d3d11_bridge.hpp',
 'source/manager/selection.hpp','source/ui/localization.hpp','source/native/src/version_proxy.cpp','source/native/proxy_windows_test.hpp','source/normal_policy.hpp','source/motion/identity.hpp',
 'source/motion/import_slots.hpp','source/native/include/nvs30/import_slots.hpp',
 'source/native/test_reference/gp4_module.hpp','source/native/include/nvs30/target_bindings.hpp','source/native/include/nvs30/import_identity.hpp','source/native/include/nvs30/loader_thunks.hpp','source/native/include/nvs30/provider_table.hpp','source/native/include/nvs30/provider_thunks.hpp','source/native/include/nvs30/library_hooks.hpp','source/native/include/nvs30/import_hooks.hpp','source/native/include/nvs30/module_origin.hpp','source/native/include/nvs30/factory_hooks.hpp','source/native/src/dxgi_hooks.cpp','source/native/include/nvs30/initialization_gate.hpp','source/native/test_support/tlhelp32.h',
 'source/native/include/nvs30/init_trace.hpp','source/native/src/init_trace.cpp',
 'source/native/trace_windows_test.hpp',
 'source/diagnostic/crash_events.hpp',
 'source/native/include/nvs30/gpu_wait.hpp','source/native/include/nvs30/bridge_retry.hpp','source/native/include/nvs30/pointer_journal.hpp','source/native/include/nvs30/slot_patch.hpp',
 'source/native/include/nvs30/module_watch.hpp','source/native/include/nvs30/hook_group.hpp',
 'source/native/include/nvs30/patch_transaction.hpp','source/native/include/nvs30/presentation_policy.hpp','source/native/include/nvs30/import_lookup.hpp','source/native/include/nvs30/driver_layout.hpp','source/native/include/nvs30/driver_profile.hpp','source/native/include/nvs30/profile_transaction.hpp','source/native/include/nvs30/cuda_health.hpp','source/native/include/nvs30/fatbin_core.hpp','source/native/include/nvs30/fatbin_capture.hpp','source/setup/file_plan.hpp','source/setup/uninstall_policy.hpp','source/setup/local_journal_policy.hpp','source/setup/local_uninstall.hpp','source/setup/payload_hashes.hpp']
report={'result':'PASS','suite_count':len(cases),'reference_sha256':hashlib.sha256(options.nvp_reference.read_bytes()).hexdigest() if options.nvp_reference else None,'driver61714_sha256':hashlib.sha256(options.nvp_61714.read_bytes()).hexdigest() if options.nvp_61714 else None,'native_windows_executed':False,'GPU_tested':False,'results':results,
 'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in identities}}
(ROOT/'validation').mkdir(exist_ok=True);(ROOT/'validation/portable-normal.json').write_text(json.dumps(report,indent=2)+'\n')
if options.nvp_61714:
 audit_path=ROOT/'validation/driver-61714-gp9.json'
 audit=json.loads(audit_path.read_text())
 assert audit['input_sha256']==report['driver61714_sha256']
 audit['profile_tested']=True
 audit['profile_regressions']=[r for r in results if r['test'].startswith('617.14 real binary')]
 assert len(audit['profile_regressions'])==2
 audit_path.write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(report,indent=2))
