#pragma once
#include <d2d1.h>
#include <vector>
#include "waterglass.hpp"
#include "windows_backdrop.hpp"

namespace waterglass {
class Painter {
    struct Cached { Rect box;float radius;Material material;ID2D1Bitmap* bitmap; };
    ID2D1RenderTarget* target_=nullptr;
    ID2D1Bitmap* background_=nullptr;
    std::vector<Cached> surfaces_;
    float width_=0,height_=0;
    bool dark_=false,desktop_=false,contrast_=false,resizing_=false,simplified_=false;
    size_t bytes_=0;
    static bool same(Rect a,Rect b){return a.left==b.left&&a.top==b.top&&a.right==b.right&&a.bottom==b.bottom;}
    ID2D1Bitmap* bitmap(const Image& image) {
        ID2D1Bitmap* result=nullptr;
        auto props=D2D1::BitmapProperties(D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,D2D1_ALPHA_MODE_PREMULTIPLIED),96,96);
        if(FAILED(target_->CreateBitmap(D2D1::SizeU(image.width,image.height),image.bgra.data(),image.width*4,props,&result)))return nullptr;
        return result;
    }
public:
    Painter()=default;
    Painter(const Painter&)=delete;
    Painter& operator=(const Painter&)=delete;
    ~Painter(){clear();}
    void clear() noexcept {
        for(auto& item:surfaces_)if(item.bitmap)item.bitmap->Release();
        surfaces_.clear();bytes_=0;
        if(background_){background_->Release();background_=nullptr;}
        target_=nullptr;
    }
    void begin(ID2D1RenderTarget* target,float w,float h,bool dark,Appearance appearance,bool resizing=false,bool simplified=false) {
        bool changed=simplified!=simplified_||target!=target_||dark!=dark_||appearance.backdrop!=desktop_||appearance.highContrast!=contrast_;
        if(changed||(!resizing&&(w!=width_||h!=height_||resizing_)))clear();
        target_=target;width_=w;height_=h;dark_=dark;desktop_=appearance.backdrop;contrast_=appearance.highContrast;resizing_=resizing;simplified_=simplified;
    }
    void backdrop(ID2D1SolidColorBrush* brush) {
        if(contrast_){target_->Clear(D2D1::ColorF(systemColor(COLOR_WINDOW)));return;}
        if(!background_&&!resizing_&&!simplified_)try{background_=bitmap(background(width_,height_,dark_,desktop_));}catch(...){}
        target_->Clear(desktop_?D2D1::ColorF(0,0,0,0):D2D1::ColorF(dark_?0x132238:0xe2edfa));
        if(background_)target_->DrawBitmap(background_,D2D1::RectF(0,0,width_,height_));
        else {brush->SetColor(D2D1::ColorF(dark_?0x152336:0xe4eef8,desktop_?.6f:1.f));target_->FillRectangle(D2D1::RectF(0,0,width_,height_),brush);}
    }
    void glass(D2D1_RECT_F box,float radius,Material material,ID2D1SolidColorBrush* brush,bool shadow=true) {
        if(box.right<=box.left||box.bottom<=box.top)return;
        auto shape=D2D1::RoundedRect(box,radius,radius);
        if(contrast_){
            brush->SetColor(D2D1::ColorF(systemColor(material==Material::Primary?COLOR_HIGHLIGHT:COLOR_WINDOW)));
            target_->FillRoundedRectangle(shape,brush);
            brush->SetColor(D2D1::ColorF(systemColor(COLOR_WINDOWTEXT)));target_->DrawRoundedRectangle(shape,brush,1.5f);return;
        }
        if(shadow&&!simplified_)for(int i=4;i>0;--i){
            float spread=static_cast<float>(i)*1.3f;
            auto r=D2D1::RectF(box.left-spread,box.top+spread*.7f,box.right+spread,box.bottom+spread*1.5f);
            brush->SetColor(D2D1::ColorF(0x10294b,dark_?.035f:.017f));
            target_->FillRoundedRectangle(D2D1::RoundedRect(r,radius+spread,radius+spread),brush);
        }
        Rect key{box.left,box.top,box.right,box.bottom};ID2D1Bitmap* texture=nullptr;
        for(const auto& entry:surfaces_)if(entry.radius==radius&&entry.material==material&&same(entry.box,key)){texture=entry.bitmap;break;}
        // Reuse existing lenses while the user drags the native window border.
        // Re-rasterize once sizing ends; no expensive refraction loop per drag.
        if(!texture&&resizing_)for(const auto& entry:surfaces_)if(entry.radius==radius&&entry.material==material){texture=entry.bitmap;break;}
        if(!texture&&!resizing_&&!simplified_&&surfaces_.size()<96&&bytes_<32u*1024u*1024u)try{
            auto image=surface(key,radius,width_,height_,dark_,desktop_,material);
            texture=bitmap(image);
            if(texture){
                try{surfaces_.push_back({key,radius,material,texture});bytes_+=image.bgra.size()*4;}
                catch(...){texture->Release();texture=nullptr;}
            }
        }catch(...){}
        if(texture)target_->DrawBitmap(texture,box,1,D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
        else {brush->SetColor(D2D1::ColorF(material==Material::Primary?primaryColor:dark_?0x223248:0xf1f5fb,1));target_->FillRoundedRectangle(shape,brush);}
    }
};
}
