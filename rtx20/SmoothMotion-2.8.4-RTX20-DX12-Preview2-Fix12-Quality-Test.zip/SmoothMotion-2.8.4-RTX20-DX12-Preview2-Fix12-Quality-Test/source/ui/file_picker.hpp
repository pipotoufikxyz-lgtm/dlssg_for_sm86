#pragma once
#include <windows.h>
#include <shobjidl.h>
#include <shlobj.h>
#include <string>
#include <stdexcept>
namespace file_picker {
template<class T>struct ComOwner{T* value=nullptr;~ComOwner(){if(value)value->Release();}ComOwner()=default;ComOwner(const ComOwner&)=delete;};
inline void require(HRESULT hr){if(FAILED(hr))throw std::runtime_error("Windows file selection failed (HRESULT "+std::to_string(static_cast<unsigned long>(hr))+")");}
// Select a path, not a readable document. Installation performs its own checks.
// Restore manifests deliberately retain the ordinary read-validation behavior.
inline DWORD options(DWORD original,bool executable){
 auto flags=original|FOS_FORCEFILESYSTEM|FOS_FILEMUSTEXIST|FOS_PATHMUSTEXIST|FOS_NOCHANGEDIR|FOS_DONTADDTORECENT;
 flags&=~(FOS_ALLOWMULTISELECT|FOS_PICKFOLDERS|FOS_ALLNONSTORAGEITEMS|FOS_NOREADONLYRETURN);
 return executable?(flags|FOS_NOVALIDATE|FOS_NODEREFERENCELINKS):(flags&~FOS_NOVALIDATE);
}
inline std::wstring choose(HWND owner,const std::wstring& title,const std::wstring& initial=L"",bool executable=true){
 const auto initialized=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
 require(initialized);struct Apartment{~Apartment(){CoUninitialize();}} apartment;
 ComOwner<IFileOpenDialog> dialog;require(CoCreateInstance(CLSID_FileOpenDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&dialog.value)));
 DWORD flags=0;require(dialog.value->GetOptions(&flags));require(dialog.value->SetOptions(options(flags,executable)));
 const COMDLG_FILTERSPEC filter={executable?L"Game executable (*.exe)":L"SM86 restore manifest (restore.tsv)",executable?L"*.exe":L"restore.tsv"};
 require(dialog.value->SetFileTypes(1,&filter));require(dialog.value->SetTitle(title.c_str()));
 if(!initial.empty()){ComOwner<IShellItem> folder;if(SUCCEEDED(SHCreateItemFromParsingName(initial.c_str(),nullptr,IID_PPV_ARGS(&folder.value))))require(dialog.value->SetFolder(folder.value));}
 const auto shown=dialog.value->Show(owner);if(shown==HRESULT_FROM_WIN32(ERROR_CANCELLED))return {};require(shown);
 ComOwner<IShellItem> item;require(dialog.value->GetResult(&item.value));PWSTR path=nullptr;require(item.value->GetDisplayName(SIGDN_FILESYSPATH,&path));
 struct FreePath{PWSTR value;~FreePath(){CoTaskMemFree(value);}} free{path};
 if(!path||!*path)throw std::runtime_error("Windows returned an empty selection");return path;
}
}
