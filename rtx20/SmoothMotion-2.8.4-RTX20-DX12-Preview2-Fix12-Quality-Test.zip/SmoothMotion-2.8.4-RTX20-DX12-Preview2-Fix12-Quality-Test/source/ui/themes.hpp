#pragma once
#include <array>
namespace installer_theme {
struct Theme {const wchar_t* name;bool dark;unsigned base,a,b,c,sheet,ink,muted;};
inline constexpr std::array<Theme,6> themes={{
 {L"Glacier",false,0xe4effb,0xaecfff,0xd9cff8,0xb9eee6,0xffffff,0x17283f,0x475d75},
 {L"Midnight",true,0x111d35,0x254995,0x463875,0x1e5765,0x172438,0xf1f5ff,0xb6c6dc},
 {L"Graphite",true,0x151719,0x363b42,0x41434a,0x242d34,0x202327,0xf4f5f7,0xbfc5cd},
 {L"Forest",true,0x101f1d,0x25594d,0x3a555d,0x31553b,0x182f28,0xf0faf5,0xb4d1c4},
 {L"Rose",false,0xf8e9ed,0xf2c4d4,0xe3d0ef,0xf4d3c1,0xfff8fb,0x40263a,0x73596c},
 {L"Sand",false,0xf4eddf,0xe9d3ac,0xe2d5c8,0xd2dfce,0xfffbf2,0x3d3428,0x71614e}
}};
inline constexpr std::array<const wchar_t*,5> accentNames={L"Blue",L"Violet",L"Teal",L"Amber",L"Coral"};
inline constexpr std::array<unsigned,5> accents={0x1265cd,0x7045ca,0x08766c,0x945609,0xb43d50};
inline constexpr std::array<unsigned,5> lightAccents={0x90c4ff,0xc8afff,0x6bdfca,0xf3ce85,0xffa7b6};
inline int clampTheme(int value){return value>=0&&value<int(themes.size())?value:0;}
inline int clampAccent(int value){return value>=0&&value<int(accents.size())?value:0;}
}
