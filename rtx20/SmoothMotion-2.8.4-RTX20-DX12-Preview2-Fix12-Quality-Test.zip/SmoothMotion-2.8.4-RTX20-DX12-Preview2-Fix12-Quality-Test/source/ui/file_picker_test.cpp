#include "file_picker.hpp"
#include <cstdlib>
#include <cwchar>
#include <iostream>
namespace {
unsigned checks=0,apartments=0,uninitializations=0,dialogReleases=0,itemReleases=0,freed=0,results=0;
DWORD chosenFlags=0;HRESULT initializeResult=S_OK,showResult=S_OK,optionsResult=S_OK;
bool readDenied=true,missing=false;std::wstring selected=L"D:\\XboxGames\\MARVEL Cosmic Invasion Demo\\Content\\Game.exe",filter,title,initial;
IFileOpenDialog dialog;IShellItem item,folder{true};
void check(bool b){++checks;if(!b)std::abort();}
template<class F>bool rejects(F f){try{f();return false;}catch(const std::exception&){return true;}}
}
HRESULT CoInitializeEx(void* p,DWORD flags){check(!p&&flags==COINIT_APARTMENTTHREADED);if(SUCCEEDED(initializeResult))++apartments;return initializeResult;}
void CoUninitialize(){++uninitializations;}
void CoTaskMemFree(void* p){++freed;std::free(p);}
HRESULT CoCreateInstance(int cls,void* outer,DWORD ctx,int,void** out){check(cls==CLSID_FileOpenDialog&&!outer&&ctx==CLSCTX_INPROC_SERVER);*out=&dialog;return S_OK;}
HRESULT SHCreateItemFromParsingName(const wchar_t* path,void*,int,void** out){initial=path;*out=&folder;return S_OK;}
void IShellItem::Release(){++itemReleases;}
HRESULT IShellItem::GetDisplayName(int mode,PWSTR* out){check(mode==SIGDN_FILESYSPATH);*out=static_cast<wchar_t*>(std::malloc((selected.size()+1)*sizeof(wchar_t)));std::wmemcpy(*out,selected.c_str(),selected.size()+1);return S_OK;}
void IFileOpenDialog::Release(){++dialogReleases;}
HRESULT IFileOpenDialog::GetOptions(DWORD* out){*out=FOS_NOREADONLYRETURN|FOS_ALLOWMULTISELECT;return S_OK;}
HRESULT IFileOpenDialog::SetOptions(DWORD flags){chosenFlags=flags;return optionsResult;}
HRESULT IFileOpenDialog::SetFileTypes(UINT count,const COMDLG_FILTERSPEC* spec){check(count==1&&spec->pszName);filter=spec->pszSpec;return S_OK;}
HRESULT IFileOpenDialog::SetTitle(const wchar_t* text){title=text;return S_OK;}
HRESULT IFileOpenDialog::SetFolder(IShellItem* value){check(value==&folder);return S_OK;}
HRESULT IFileOpenDialog::Show(HWND){if(showResult!=S_OK)return showResult;if(missing&&(chosenFlags&FOS_FILEMUSTEXIST))return HRESULT_FROM_WIN32(2);if(readDenied&&!(chosenFlags&FOS_NOVALIDATE))return E_ACCESSDENIED;return S_OK;}
HRESULT IFileOpenDialog::GetResult(IShellItem** out){++results;*out=&item;return S_OK;}
int main(){
 check(file_picker::choose(nullptr,L"Choose EXE",L"D:\\XboxGames") ==selected);
 check(filter==L"*.exe"&&title==L"Choose EXE"&&initial==L"D:\\XboxGames");
 check((chosenFlags&(FOS_FILEMUSTEXIST|FOS_PATHMUSTEXIST|FOS_NOVALIDATE|FOS_FORCEFILESYSTEM|FOS_NODEREFERENCELINKS))==(FOS_FILEMUSTEXIST|FOS_PATHMUSTEXIST|FOS_NOVALIDATE|FOS_FORCEFILESYSTEM|FOS_NODEREFERENCELINKS));
 check(!(chosenFlags&(FOS_NOREADONLYRETURN|FOS_ALLOWMULTISELECT|FOS_PICKFOLDERS)));
 check(apartments==uninitializations&&dialogReleases==1&&itemReleases==2&&freed==1);
 const auto before=results;showResult=HRESULT_FROM_WIN32(ERROR_CANCELLED);check(file_picker::choose(nullptr,L"Choose EXE").empty());check(results==before&&apartments==uninitializations);showResult=S_OK;
 check(rejects([]{file_picker::choose(nullptr,L"Restore",L"",false);}));check(!(chosenFlags&FOS_NOVALIDATE));check(results==before);
 readDenied=false;selected=L"D:\\\u6e38\u620f\\restore.tsv";check(file_picker::choose(nullptr,L"Restore",L"",false)==selected&&filter==L"restore.tsv");
 missing=true;check(rejects([]{file_picker::choose(nullptr,L"Choose EXE");}));missing=false;
 optionsResult=E_FAIL;check(rejects([]{file_picker::choose(nullptr,L"Choose EXE");}));optionsResult=S_OK;
 initializeResult=E_FAIL;check(rejects([]{file_picker::choose(nullptr,L"Choose EXE");}));check(apartments==uninitializations);
 initializeResult=S_FALSE;check(file_picker::choose(nullptr,L"Already initialized")==selected);check(apartments==uninitializations&&freed==results);
 std::cout<<"PASS: "<<checks<<" production picker checks; protected selection, cancellation, Unicode, filters, manifest access validation, failures and COM ownership. Windows dialog simulated.\n";
}
