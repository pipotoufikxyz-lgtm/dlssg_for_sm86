#pragma once
// UI text only. File names, paths, game titles, protocol keys and status tokens
// must never be passed through a substring-replacement translator.
#include <cstdint>
#include <initializer_list>
#include <string>
#include <string_view>

namespace manager_localization {
enum class Language : unsigned { Automatic = 0, English = 1, SimplifiedChinese = 2 };
constexpr Language clamp(unsigned value) noexcept {
    return value <= 2 ? static_cast<Language>(value) : Language::Automatic;
}
constexpr Language resolve(Language preferred, std::uint16_t windowsLanguage) noexcept {
    if (preferred == Language::English || preferred == Language::SimplifiedChinese) return preferred;
    // Windows PRIMARYLANGID == LANG_CHINESE. Simplified Chinese is the available
    // Chinese translation, including when Windows uses another Chinese locale.
    return (windowsLanguage & 0x03ffu) == 0x04u ? Language::SimplifiedChinese : Language::English;
}
constexpr const wchar_t* languageName(Language language) noexcept {
    switch (language) {
    case Language::English: return L"English";
    case Language::SimplifiedChinese: return L"简体中文";
    default: return L"Automatic / 自动";
    }
}
constexpr const wchar_t* locale(Language language) noexcept {
    return language == Language::SimplifiedChinese ? L"zh-CN" : L"en-US";
}
constexpr const wchar_t* fontFamily(Language language) noexcept {
    return language == Language::SimplifiedChinese ? L"Microsoft YaHei UI" : L"Segoe UI";
}
// Small, separate preference file avoids invalidating existing theme settings.
// Unknown or truncated input is not adopted; callers can keep Automatic.
inline bool readPreference(std::string_view bytes, Language& result) noexcept {
    constexpr std::string_view prefix = "SM86-LANGUAGE-1\n";
    if (bytes.size() != prefix.size() + 2 || bytes.substr(0, prefix.size()) != prefix ||
        bytes.back() != '\n' || bytes[prefix.size()] < '0' || bytes[prefix.size()] > '2') return false;
    result = static_cast<Language>(bytes[prefix.size()] - '0');
    return true;
}
inline std::string preference(Language language) {
    return std::string("SM86-LANGUAGE-1\n") + char('0' + unsigned(clamp(unsigned(language)))) + '\n';
}
inline bool commandLanguage(std::wstring_view value, Language& result) noexcept {
    if (value == L"auto") result = Language::Automatic;
    else if (value == L"en" || value == L"en-US") result = Language::English;
    else if (value == L"zh-CN" || value == L"zh-Hans") result = Language::SimplifiedChinese;
    else return false;
    return true;
}
constexpr const wchar_t* commandName(Language language) noexcept {
    return language == Language::SimplifiedChinese ? L"zh-CN" : language == Language::English ? L"en-US" : L"auto";
}

struct Entry { std::wstring_view english, chinese; };
inline constexpr Entry catalog[] = {
    {L"Home", L"主页"},
    {L"Games", L"游戏"},
    {L"Compatibility", L"兼容性"},
    {L"History", L"历史记录"},
    {L"Settings", L"设置"},
    {L"About", L"关于"},
    {L"Language", L"语言"},
    {L"Language / 语言", L"语言 / Language"},
    {L"Language changes immediately and is remembered for the next launch.", L"语言切换立即生效，并在下次启动时保留。"},
    {L"Some technical diagnostics remain in English. Game names and file paths are unchanged.", L"部分技术诊断信息仍使用英语。游戏名称和文件路径保持原样。"},
    {L"Ready", L"就绪"},
    {L"Working…", L"正在处理…"},
    {L"Ready to add a game", L"可以添加游戏"},
    {L"Set up Smooth Motion", L"设置 Smooth Motion"},
    {L"Choose your game. Review the changes. Install with a backup.", L"选择游戏，检查更改，然后安装。"},
    {L"Choose your game. Review the changes. Install with uninstall.bat.", L"选择游戏，检查更改，安装后可使用 uninstall.bat 卸载。"},
    {L"Install with uninstall.bat", L"安装并创建 uninstall.bat"},
    {L"Browse folder", L"选择文件夹"},
    {L"Browse EXE", L"选择 EXE"},
    {L"Discover games", L"扫描游戏"},
    {L"Add game", L"添加游戏"},
    {L"Your games", L"你的游戏"},
    {L"Your game library will appear here. Scanning never installs files.", L"你的游戏库将显示在这里。扫描不会安装任何文件。"},
    {L"Activity", L"活动"},
    {L"Recent activity", L"最近活动"},
    {L"No cover yet", L"暂无封面"},
    {L"Session active", L"会话已启动"},
    {L"Recovery mode", L"恢复模式"},
    {L"Backend disabled", L"后端已禁用"},
    {L"Mod installed", L"模组已安装"},
    {L"View game  ↗", L"查看游戏  ↗"},
    {L"‹ Previous", L"‹ 上一页"},
    {L"Next ›", L"下一页 ›"},
    {L"‹ Back", L"‹ 返回"},
    {L"‹ All games", L"‹ 所有游戏"},
    {L"Choose EXE", L"选择 EXE"},
    {L"Choose installed EXE", L"选择已安装的 EXE"},
    {L"Choose the executable beside the Smooth Motion files to remove", L"选择待删除的 Smooth Motion 文件旁的可执行文件"},
    {L"No files are eligible for removal beside this EXE. Choose installed EXE to review another folder.", L"此 EXE 旁没有可安全删除的文件。请选择已安装的 EXE，检查其他文件夹。"},
    {L"Only recognized Smooth Motion files are removed. Changed or unrelated files are preserved.", L"仅删除可识别的 Smooth Motion 文件。已更改或无关的文件将保留。"},
    {L"For an old install beside a launcher, choose that launcher EXE.", L"如果旧版本安装在启动器旁，请选择该启动器 EXE。"},
    {L"Choose EXE ({0})", L"选择 EXE（{0}）"},
    {L"Browse replacement EXE", L"更换 EXE"},
    {L"Selected by you", L"由你选择"},
    {L"Automatic selection (recommended)", L"自动选择（推荐）"},
    {L"Choose a game installation folder", L"选择游戏安装文件夹"},
    {L"Choose the actual 64-bit game executable", L"选择实际运行游戏的 64 位可执行文件"},
    {L"Choose the rendering executable", L"选择负责渲染的游戏可执行文件"},
    {L"Multiple rendering executables were found. Choose EXE before installing.", L"发现多个渲染程序。请先选择 EXE，再安装。"},
    {L"Unreal rendering executable (resolved from launcher)", L"虚幻引擎渲染程序（已从启动器定位）"},
    {L"01  CHOOSE GAME     /     02  REVIEW CHANGES     /     03  INSTALL & RECOVER", L"01  选择游戏     /     02  检查更改     /     03  安装与卸载"},
    {L"01  CHOOSE GAME     /     02  REVIEW CHANGES     /     03  INSTALL & UNINSTALL", L"01  选择游戏     /     02  检查更改     /     03  安装与卸载"},
    {L"SMOOTH MOTION  /  INSTALL & RECOVER", L"SMOOTH MOTION  /  安装与卸载"},
    {L"SMOOTH MOTION  /  INSTALL & UNINSTALL", L"SMOOTH MOTION  /  安装与卸载"},
    {L"Game files installed", L"游戏文件已安装"},
    {L"Files restored", L"文件已恢复"},
    {L"Installation needs attention", L"安装需要处理"},
    {L"Restore needs attention", L"恢复需要处理"},
    {L"Uninstall needs attention", L"卸载需要处理"},
    {L"Review installation", L"检查安装"},
    {L"Review replacement", L"检查更新"},
    {L"Review file restore", L"检查文件恢复"},
    {L"Review uninstall", L"检查卸载"},
    {L"FILE CHANGES", L"文件更改"},
    {L"FILE CHANGES  ·  {0}", L"文件更改  ·  {0}"},
    {L"{0}–{1} of {2}", L"第 {0}–{1} 项，共 {2} 项"},
    {L"The recorded files already match. Your current settings will be preserved.", L"记录中的文件已匹配。你的当前设置将保留。"},
    {L"RECOVERY", L"恢复"},
    {L"UNINSTALL", L"卸载"},
    {L"Restore the recorded game files", L"恢复记录中的游戏文件"},
    {L"The current files are backed up before restoring. Later modifications are protected.", L"恢复前会保存当前文件。之后修改过的文件会受到保护。"},
    {L"INSTALL OPTION", L"安装方式"},
    {L"ASI loader · Ultimate ASI Loader 9.7.4", L"ASI 加载器 · Ultimate ASI Loader 9.7.4"},
    {L"version.dll loads new.asi\nUltimate ASI Loader 9.7.4", L"version.dll 加载 new.asi\nUltimate ASI Loader 9.7.4"},
    {L"FRAME GENERATION", L"帧生成"},
    {L"Loader route needs testing", L"加载方式需要测试"},
    {L"DLL imported by EXE or engine", L"EXE 或引擎会导入此 DLL"},
    {L"Normal Smooth Motion. Driver initialization, CUDA loading and game presentation are reported separately in nvsmooth30.log.", L"普通 Smooth Motion。驱动初始化、CUDA 加载和游戏呈现状态分别记录在 nvsmooth30.log 中。"},
    {L"The restore plan is checked again before any file is changed.", L"更改文件前会再次检查恢复计划。"},
    {L"The uninstall plan is checked again before any file is changed.", L"更改文件前会再次检查卸载计划。"},
    {L"One build is installed at a time. Replaced files receive a restore backup.", L"一次只安装一个版本。被替换的文件会保存以便恢复。"},
    {L"Ready for the next step", L"可以进行下一步"},
    {L"Installer details", L"安装详情"},
    {L"Applying your reviewed plan…", L"正在应用已检查的计划…"},
    {L"Checking the game and package…", L"正在检查游戏和安装包…"},
    {L"Copy details for the complete error. Review a new plan after resolving the conflict.", L"复制详情可查看完整错误。解决冲突后，请重新检查计划。"},
    {L"Installation guide", L"安装指南"},
    {L"Copy details", L"复制详情"},
    {L"Refresh plan", L"刷新计划"},
    {L"Restore these files", L"恢复这些文件"},
    {L"Install these files", L"安装这些文件"},
    {L"Uninstall these files", L"卸载这些文件"},
    {L"Open folder", L"打开文件夹"},
    {L"Check again", L"重新检查"},
    {L"Open game folder", L"打开游戏文件夹"},
    {L"Open restore backup", L"打开恢复备份"},
    {L"CHOOSE THE LOADING ROUTE", L"选择加载方式"},
    {L"Choose an imported DLL carrier. Every carrier loads the same normal Smooth Motion ASI.", L"选择游戏会导入的 DLL。所有加载方式使用同一个普通 Smooth Motion ASI。"},
    {L"The version.dll carrier loads new.asi. Use the ASI route to choose dinput8.dll, winmm.dll or another carrier.", L"version.dll 用于加载 new.asi。选择 ASI 方式可使用 dinput8.dll、winmm.dll 或其他加载器名称。"},
    {L"Loader: {0}  ▾", L"加载器：{0}  ▾"},
    {L"Loader: version.dll + new.asi", L"加载器：version.dll + new.asi"},
    {L"Automatic", L"自动"},
    {L"Automatic (prefer a game import)", L"自动（优先选择游戏导入项）"},
    {L"Win32 only — incompatible with these x64 builds", L"仅限 Win32 — 与这些 x64 版本不兼容"},
    {L"Current mod files will be reviewed and backed up before replacement.", L"替换前会检查并保存现有模组文件。"},
    {L"A restore backup is created when files change.", L"更改文件时会创建恢复备份。"},
    {L"Protected launcher detected. Automatic installation is unavailable.", L"检测到受保护的启动器，无法自动安装。"},
    {L"These builds require a 64-bit game executable.", L"这些版本需要 64 位游戏可执行文件。"},
    {L"Restore files…", L"恢复文件…"},
    {L"Legacy restore…", L"恢复旧版备份…"},
    {L"Collect diagnostics", L"收集诊断信息"},
    {L"Refresh artwork", L"刷新封面"},
    {L"Remove from list", L"从列表移除"},
    {L"Remove game", L"移除游戏"},
    {L"Remove {0} from this list and hide it from discovery? Game files stay in place. Use Add game or Restore hidden games to show it again.", L"将 {0} 从列表中移除并在扫描时隐藏？游戏文件保持原样。使用“添加游戏”或“恢复隐藏的游戏”可重新显示。"},
    {L"The hidden list is full. Use Settings > Restore hidden games first.", L"隐藏列表已满。请先使用“设置 > 恢复隐藏的游戏”。"},
    {L"Could not save the game list. The card was kept.", L"无法保存游戏列表。游戏卡片已保留。"},
    {L"Game removed from the list. Its files were preserved.", L"游戏已从列表移除。其文件已保留。"},
    {L"Installation and compatibility", L"安装与兼容性"},
    {L"Two loading routes, one backend: version.dll + new.asi or an alternative carrier.", L"两种加载方式使用同一后端：version.dll + new.asi，或其他加载器。"},
    {L"One backend: standalone version.dll, or new.asi with an alternative carrier.", L"同一后端：独立版 version.dll，或通过其他加载器加载 new.asi。"},
    {L"ASI loader: all 19 official Win64 names, with file conflict checks.", L"ASI 加载器支持全部 19 个官方 Win64 文件名，并检查文件冲突。"},
    {L"Steam: deferred ASI loading is enabled; affected-game testing is outstanding.", L"Steam：已启用延迟 ASI 加载；受影响的游戏仍需实际测试。"},
    {L"Existing files: recognised old builds are backed up before replacement.", L"现有文件：替换前会保存已识别的旧版本。"},
    {L"Existing files: only recognised Smooth Motion builds are replaced; other mods are preserved.", L"现有文件：仅替换已识别的 Smooth Motion 版本；其他模组将保留。"},
    {L"Native DirectX 12 path and a restricted DirectX 11 bridge. No Vulkan or OpenGL backend.", L"支持原生 DirectX 12 路径和有限的 DirectX 11 桥接。不含 Vulkan 或 OpenGL 后端。"},
    {L"Normal NVIDIA Smooth Motion. Driver and game compatibility must be verified.", L"普通 NVIDIA Smooth Motion。驱动和游戏兼容性仍需验证。"},
    {L"Read compatibility notes", L"查看兼容性说明"},
    {L"Select a game and choose Restore files to review a backup.", L"选择游戏，再选择“恢复文件”以检查备份。"},
    {L"Theme", L"主题"},
    {L"Accent colour", L"强调色"},
    {L"Your theme and accent are remembered for the next launch.", L"主题和强调色将在下次启动时保留。"},
    {L"Restore hidden games ({0})", L"恢复隐藏的游戏（{0}）"},
    {L"Glacier", L"冰川"},
    {L"Midnight", L"午夜"},
    {L"Graphite", L"石墨"},
    {L"Forest", L"森林"},
    {L"Rose", L"玫瑰"},
    {L"Sand", L"沙丘"},
    {L"Blue", L"蓝色"},
    {L"Violet", L"紫色"},
    {L"Teal", L"青色"},
    {L"Amber", L"琥珀色"},
    {L"Coral", L"珊瑚色"},
    {L"Inspecting the selected game…", L"正在检查所选游戏…"},
    {L"Inspection finished. One card per installation; artwork loads in the background.", L"检查完成。每个游戏安装显示一张卡片；封面将在后台加载。"},
    {L"Detected {0} game installations. Artwork loads in the background.", L"已检测到 {0} 个游戏安装。封面将在后台加载。"},
    {L"No game executable could be inspected in:\n{0}", L"无法检查此目录中的游戏可执行文件：\n{0}"},
    {L"{0} folders reached scan limits. Select the game's own folder or EXE.", L"{0} 个目录已达到扫描上限。请选择游戏本身的目录或 EXE 文件。"},
    {L"{0} files or folders could not be inspected.", L"无法检查 {0} 个文件或目录。"},
    {L"Xbox game metadata", L"Xbox 游戏元数据"},
    {L"Finding installed games and their launch executables…", L"正在查找已安装的游戏和启动程序…"},
    {L"Scan cancelled. Your previous library is preserved.", L"扫描已取消。原有游戏库已保留。"},
    {L"Inspecting the game, package and existing mod files…", L"正在检查游戏、安装包和现有模组文件…"},
    {L"Preparing a restore plan…", L"正在准备恢复计划…"},
    {L"Preparing an installation plan…", L"正在准备安装计划…"},
    {L"Preparing an uninstall plan…", L"正在准备卸载计划…"},
    {L"Review the destination, loader and file changes before continuing.", L"继续前，请检查目标位置、加载器和文件更改。"},
    {L"Backing up the current state and restoring files…", L"正在保存当前状态并恢复文件…"},
    {L"Backing up existing files and installing Smooth Motion…", L"正在保存现有文件并安装 Smooth Motion…"},
    {L"Installing Smooth Motion and creating uninstall.bat…", L"正在安装 Smooth Motion 并创建 uninstall.bat…"},
    {L"Removing installed Smooth Motion files…", L"正在移除已安装的 Smooth Motion 文件…"},
    {L"Inspecting the replacement executable…", L"正在检查新的可执行文件…"},
    {L"Game executable corrected and pinned. Install uses the displayed EXE's folder.", L"游戏可执行文件已更新并固定。将安装到当前显示的 EXE 所在文件夹。"},
    {L"Select the 64-bit game executable. This backend cannot load in a 32-bit process.", L"请选择 64 位游戏可执行文件。此后端无法加载到 32 位进程中。"},
    {L"A protected launcher was detected. Choose the actual supported game executable and review its modding rules before installing.", L"检测到受保护的启动器。请选择实际受支持的游戏可执行文件，并在安装前查看游戏的模组规则。"},
    {L"Applying the selected action…", L"正在执行所选操作…"},
    {L"Diagnostics collection did not finish.", L"诊断信息收集未完成。"},
    {L"Diagnostics collected locally. No report was uploaded.", L"诊断信息已保存在本地。未上传任何报告。"},
    {L"No action selected.", L"未选择操作。"},
    {L"Refreshing full-size Steam artwork…", L"正在刷新 Steam 原尺寸封面…"},
    {L"Could not save the hidden game list.", L"无法保存隐藏的游戏列表。"},
    {L"Artwork can be retried with Discover games.", L"可使用“扫描游戏”重新加载封面。"},
    {L"The operation could not complete.", L"操作未能完成。"},
    {L"The operation stopped unexpectedly.", L"操作意外停止。"},
    {L"Could not start the background operation.", L"无法启动后台操作。"},
    {L"The background operation stopped. You can retry it.", L"后台操作已停止。你可以重试。"},
    {L"Operation did not complete", L"操作未完成"},
    {L"Manager ready. Looking for installed games and artwork…", L"管理器已就绪。正在查找已安装的游戏和封面…"},
    {L"Closing after the current operation stops. Finish or cancel any open setup dialog.", L"当前操作停止后将关闭。请完成或取消已打开的安装对话框。"},
    {L"Compatibility drawing enabled. Themes and installation remain available.", L"已启用兼容绘图模式。主题和安装功能仍可使用。"},
    {L"Drawing unavailable", L"绘图不可用"},
    {L"The manager could not create its software drawing surface. No game files were changed by this failure.", L"管理器无法创建软件绘图界面。此故障未更改任何游戏文件。"},
    {L"Smooth Motion Manager is already open.", L"Smooth Motion 管理器已打开。"},
    {L"Smooth Motion compatibility setup", L"Smooth Motion 兼容性安装"},
    {L"Review local file changes", L"检查本地文件更改"},
    {L"Uninstall Smooth Motion", L"卸载 Smooth Motion"},
    {L"Smooth Motion uninstalled", L"Smooth Motion 已卸载"},
    {L"Run uninstall.bat beside the game executable to remove Smooth Motion.", L"运行游戏可执行文件旁的 uninstall.bat，即可卸载 Smooth Motion。"},
    {L"Run uninstall.bat beside the installed game executable.", L"运行已安装游戏的可执行文件旁的 uninstall.bat。"},
    {L"Uninstall Smooth Motion from:\n", L"从以下位置卸载 Smooth Motion：\n"},
    {L"Only unchanged Smooth Motion files are removed. Logs, other mods, and older restore folders are preserved. The small uninstall tools remain available for repeat use.", L"仅移除未修改的 Smooth Motion 文件。日志、其他模组和旧版恢复文件夹将保留。小型卸载工具也会保留，以便再次使用。"},
    {L"Modified files are preserved:", L"已修改的文件将保留："},
    {L"Smooth Motion files removed. Logs and other mods were preserved.", L"Smooth Motion 文件已移除。日志和其他模组已保留。"},
    {L"Unchanged Smooth Motion files removed. Modified files were preserved; see the uninstall review.", L"未修改的 Smooth Motion 文件已移除。已修改的文件已保留；请查看卸载检查结果。"},
    {L"An uninstall.bat will be created beside the game executable. Continue?", L"将在游戏可执行文件旁创建 uninstall.bat。是否继续？"},
    {L"Review the installed files before removing Smooth Motion.", L"移除 Smooth Motion 前，请检查已安装的文件。"},
    {L"01  CHOOSE GAME     /     02  REVIEW CHANGES     /     03  APPLY", L"01  选择游戏     /     02  检查更改     /     03  应用"},
    {L"Remove Smooth Motion from this game", L"从此游戏中移除 Smooth Motion"},
    {L"Only recorded Smooth Motion files are removed. Files changed since installation are preserved.", L"仅移除有记录的 Smooth Motion 文件。安装后修改过的文件将保留。"},
    {L"Native backend in one DLL\nversion.dll (standalone)", L"原生后端集成于单个 DLL\nversion.dll（独立版）"},
    {L"The uninstall plan is checked again before any file is removed.", L"移除任何文件前会再次检查卸载计划。"},
    {L"The native backend runs inside version.dll. Use the ASI route to choose dinput8.dll, winmm.dll or another carrier.", L"原生后端直接运行于 version.dll 中。选择 ASI 方式可使用 dinput8.dll、winmm.dll 或其他加载器。"},
    {L"version.dll (standalone)", L"version.dll（独立版）"},
    {L"Select a game and choose Uninstall Smooth Motion to review removal.", L"选择游戏，再选择“卸载 Smooth Motion”以检查移除操作。"},
    {L"SM86 Manager 2.8.2-r3-gp9\nNormal", L"SM86 管理器 2.8.2-r3-gp9\n普通模式"},
    {L"Smooth Motion Manager 2.8.2-r3-gp9 Normal", L"Smooth Motion 管理器 2.8.2-r3-gp9 普通模式"},
    {L"Choose standalone version.dll or new.asi with an ASI loader. Each installation creates uninstall.bat beside the game executable.\n\nNormal NVIDIA Smooth Motion using the reworked NVSmooth30 compatibility backend.\n\nSix themes and five accent colours. Native glass interface.\n\nUltimate ASI Loader by ThirteenAG and contributors. Licence and release provenance are included.\n\nPer-game startup, displayed frame output and performance require hardware testing.", L"选择独立版 version.dll，或通过 ASI 加载器加载 new.asi。每次安装都会在游戏可执行文件旁创建 uninstall.bat。\n\n普通 NVIDIA Smooth Motion 使用重构后的 NVSmooth30 兼容性后端。\n\n提供六种主题、五种强调色和原生玻璃界面。\n\nUltimate ASI Loader 由 ThirteenAG 和贡献者开发。附带许可证和发布来源说明。\n\n各游戏的启动、实际显示帧和性能仍需要硬件测试。"},
    {L"Choose a backup's restore.tsv (files are reviewed before restore)", L"选择旧备份的 restore.tsv（恢复前将检查文件）"},
    {L"Restore backup\n{0}", L"恢复备份\n{0}"},
    {L"{0} games · One card per installation · Automatic covers", L"{0} 个游戏 · 每个安装一张卡片 · 自动加载封面"},
    {L"Scan limit reached", L"已达到扫描限制"},
    {L"Could not save the language preference. The language changed for this session only.", L"无法保存语言设置。本次会话已切换语言。"},
    {L"Could not change the display language. Your previous language is still active.", L"无法切换显示语言。仍使用原来的语言。"},
    {L"Choose version.dll or new.asi.", L"请选择 version.dll 或 new.asi。"},
    {L"Only normal NVIDIA Smooth Motion is available.", L"仅提供普通 NVIDIA Smooth Motion。"},
    {L"The game selection dialog failed.", L"游戏选择对话框打开失败。"},
    {L"Both supplied builds require a Windows x64 game. Select its 64-bit executable.", L"提供的版本均需要 Windows x64 游戏。请选择其 64 位可执行文件。"},
    {L"This backend requires DirectX 11 or DirectX 12. Select a compatible executable or launch mode. Vulkan, OpenGL and older DirectX APIs have no backend here.", L"此后端需要 DirectX 11 或 DirectX 12。请选择兼容的可执行文件或启动模式。不支持 Vulkan、OpenGL 或更早版本的 DirectX。"},
    {L"Files or installation choices changed after review. Nothing was installed. Refresh the plan first.", L"检查后文件或安装选项已更改。未安装任何内容。请先刷新计划。"},
    {L"This selection is already installed.", L"所选内容已安装。"},
    {L"Files installed. Start the game through its normal launcher. Use the restore backup to undo these changes.", L"文件已安装。请通过游戏原有启动器启动游戏。可使用恢复备份撤销这些更改。"},
    {L"Files installed. Start the game through its normal launcher. Run uninstall.bat beside the game executable to remove Smooth Motion.", L"文件已安装。请通过游戏原有启动器启动游戏。运行游戏可执行文件旁的 uninstall.bat 可卸载 Smooth Motion。"},
    {L"Normal Smooth Motion installed. Check nvsmooth30.log beside the game executable after launch. No multiplier configuration is required.", L"普通 Smooth Motion 已安装。启动后请查看游戏可执行文件旁的 nvsmooth30.log。无需配置帧倍率。"},
    {L"Setup stopped because of an unexpected error.", L"安装因意外错误而停止。"},
    {L"Install {0} for:\n{1}", L"为以下游戏安装 {0}：\n{1}"},
    {L"new.asi + selected loader", L"new.asi + 所选加载器"},
    {L"Replaced files will be backed up. Continue?", L"被替换的文件将保存以便恢复。是否继续？"},
    {L"Continue?", L"是否继续？"},
    {L"Add", L"添加"},
    {L"Remove", L"移除"},
    {L"Replace", L"替换"},
    {L"Back up and remove previous build", L"保存并移除旧版本"},
    {L"Back up and replace", L"保存并替换"},
    {L"Imported by game EXE", L"由游戏 EXE 导入"},
    {L"Imported by local engine DLL", L"由本地引擎 DLL 导入"},
    {L"Delay-imported by game EXE", L"由游戏 EXE 延迟导入"},
    {L"Delay-imported by local engine DLL", L"由本地引擎 DLL 延迟导入"},
    {L"Fallback: game loading must be tested", L"备用方式：需要测试游戏加载"}
};

inline std::wstring_view lookup(std::wstring_view key, Language language) noexcept {
    if (language == Language::SimplifiedChinese)
        for (const auto& entry : catalog) if (entry.english == key) return entry.chinese;
    return key;
}
inline std::wstring tr(std::wstring_view key, Language language) {
    return std::wstring(lookup(key, language));
}
inline bool known(std::wstring_view key) noexcept {
    for (const auto& entry : catalog) if (entry.english == key) return true;
    return false;
}
// Substitutions are performed once on a known template. Inserted file paths or
// game titles are opaque, including braces, percent signs and Chinese text.
inline std::wstring format(std::wstring_view key, Language language,
                           std::initializer_list<std::wstring_view> arguments) {
    if (!known(key)) return std::wstring(key);
    auto text = lookup(key, language);
    std::wstring output;
    for (std::size_t i = 0; i < text.size();) {
        if (i + 2 < text.size() && text[i] == L'{' && text[i + 2] == L'}' &&
            text[i + 1] >= L'0' && text[i + 1] <= L'9') {
            auto index = static_cast<std::size_t>(text[i + 1] - L'0');
            if (index < arguments.size()) { output.append(*(arguments.begin() + index)); i += 3; continue; }
        }
        output.push_back(text[i++]);
    }
    return output;
}
}
