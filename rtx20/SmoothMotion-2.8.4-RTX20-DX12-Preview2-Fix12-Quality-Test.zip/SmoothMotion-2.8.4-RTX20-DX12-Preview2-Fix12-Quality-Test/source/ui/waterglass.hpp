#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <vector>
#include "themes.hpp"

// Portable material renderer shared by the Windows UI and its visual preview.
// Refraction samples our own artwork. Desktop/game pixels belong to DWM and
// are never captured, sampled, or intercepted by this code.
namespace waterglass {
inline int styleIndex=0;
inline unsigned primaryColor=0x1265cd;
struct Rect { float left, top, right, bottom; };
struct RGB { float r, g, b; };
enum class Material { Sheet, Control, Primary, Disabled };
inline float clamp(float v) { return std::clamp(v, 0.f, 1.f); }
inline float smooth(float v) { v=clamp(v); return v*v*(3.f-2.f*v); }
inline RGB mix(RGB a, RGB b, float f) { return {a.r+(b.r-a.r)*f,a.g+(b.g-a.g)*f,a.b+(b.b-a.b)*f}; }
inline RGB rgb(unsigned c) { return {((c>>16)&255)/255.f,((c>>8)&255)/255.f,(c&255)/255.f}; }
inline float cloud(float x,float y,float cx,float cy,float rx,float ry) {
    float dx=(x-cx)/rx,dy=(y-cy)/ry;
    return smooth(1.f-(dx*dx+dy*dy));
}
inline RGB scene(float x,float y,float width,float height,bool dark) {
    float u=x/std::max(1.f,width),v=y/std::max(1.f,height);
    const auto& theme=installer_theme::themes[installer_theme::clampTheme(styleIndex)];
    RGB c=rgb(theme.base);
    c=mix(c,rgb(theme.a),cloud(u,v,.2f,.2f,.68f,.8f)*.75f);
    c=mix(c,rgb(theme.b),cloud(u,v,.83f,.12f,.7f,.74f)*.88f);
    c=mix(c,rgb(theme.c),cloud(u,v,.78f,.98f,.8f,.78f)*.75f);
    c=mix(c,rgb(dark?0x4a395b:0xffd8cc),cloud(u,v,1.03f,.48f,.5f,.6f)*.9f);
    const float wave=.53f+.145f*std::sin(u*5.2f-.55f);
    const float ribbon=std::exp(-std::pow((v-wave)/.035f,2.f));
    c=mix(c,rgb(dark?0x4a6696:0xffffff),ribbon*(dark?.32f:.62f));
    const float seam=std::exp(-std::pow((v-wave-.040f)/.008f,2.f));
    c=mix(c,rgb(dark?0x3869a0:0x6eabd9),seam*.26f);
    const float second=.76f-.12f*std::sin(u*4.7f+.4f);
    c=mix(c,rgb(dark?0x1b3950:0xc6f1ff),std::exp(-std::pow((v-second)/.1f,2.f))*.28f);
    return c;
}
inline std::uint32_t pixel(RGB c,float alpha) {
    const auto byte=[](float v){return static_cast<unsigned>(std::lround(clamp(v)*255.f));};
    unsigned a=byte(alpha);
    return (a<<24)|(std::min(a,byte(c.r*alpha))<<16)|
        (std::min(a,byte(c.g*alpha))<<8)|std::min(a,byte(c.b*alpha));
}
struct Image {
    unsigned width=0,height=0;
    std::vector<std::uint32_t> bgra;
};
inline Image allocate(float w,float h) {
    if(!std::isfinite(w)||!std::isfinite(h)||w<=0||h<=0||w>8192||h>8192)
        throw std::runtime_error("Glass surface bounds are invalid");
    unsigned width=static_cast<unsigned>(std::ceil(w)),height=static_cast<unsigned>(std::ceil(h));
    if(static_cast<std::uint64_t>(width)*height>8u*1024u*1024u)
        throw std::runtime_error("Glass surface exceeds its allocation limit");
    return {width,height,std::vector<std::uint32_t>(static_cast<size_t>(width)*height)};
}
inline Image background(float w,float h,bool dark,bool desktop) {
    auto im=allocate(w,h);
    for(unsigned y=0;y<im.height;++y)for(unsigned x=0;x<im.width;++x)
        im.bgra[size_t(y)*im.width+x]=pixel(scene(x+.5f,y+.5f,w,h,dark),desktop?.26f:1.f);
    return im;
}
inline Image surface(Rect box,float radius,float canvasWidth,float canvasHeight,
                     bool dark,bool desktop,Material material) {
    float w=box.right-box.left,h=box.bottom-box.top;
    auto im=allocate(w,h);radius=std::clamp(radius,1.f,std::min(w,h)*.5f);
    for(unsigned y=0;y<im.height;++y)for(unsigned x=0;x<im.width;++x) {
        float px=x+.5f,py=y+.5f,cx=px-w*.5f,cy=py-h*.5f;
        float qx=std::abs(cx)-(w*.5f-radius),qy=std::abs(cy)-(h*.5f-radius);
        float ox=std::max(0.f,qx),oy=std::max(0.f,qy),len=std::sqrt(ox*ox+oy*oy);
        float d=len+std::min(std::max(qx,qy),0.f)-radius;
        float coverage=clamp(.5f-d);
        if(coverage==0)continue;
        float nx=0,ny=0;
        if(len>0){nx=ox/len;ny=oy/len;}else if(qx>qy)nx=1;else ny=1;
        nx*=cx<0?-1.f:1.f;ny*=cy<0?-1.f:1.f;
        // A rounded lens has the steepest normal close to its perimeter.
        float rim=std::exp(-std::max(0.f,-d)/5.f);
        float bend=14.f*rim;
        float sx=box.left+w*.5f+cx*.992f-nx*bend;
        float sy=box.top+h*.5f+cy*.992f-ny*bend;
        RGB c=scene(sx,sy,canvasWidth,canvasHeight,dark);
        // Very restrained spectral separation at the thick, curved rim.
        c.r=scene(sx-nx*.65f*rim,sy-ny*.65f*rim,canvasWidth,canvasHeight,dark).r;
        c.b=scene(sx+nx*.65f*rim,sy+ny*.65f*rim,canvasWidth,canvasHeight,dark).b;
        float tint=material==Material::Sheet?.38f:.57f;
        c=mix(c,rgb(installer_theme::themes[installer_theme::clampTheme(styleIndex)].sheet),tint);
        if(material==Material::Primary)c=mix(c,rgb(primaryColor),.96f);
        if(material==Material::Disabled)c=mix(c,rgb(dark?0x263649:0xe7edf6),.58f);
        float light=clamp(-nx*.42f-ny*.76f+.15f);
        float edge=std::exp(-std::max(0.f,-d)/1.25f);
        float inner=std::exp(-std::pow((std::max(0.f,-d)-2.6f)/1.35f,2.f));
        c=mix(c,rgb(dark?0x0a1830:0x457bad),inner*clamp(nx*.25f+ny*.6f)*.16f);
        c=mix(c,rgb(0xffffff),edge*(.38f+.50f*light));
        c=mix(c,rgb(0xffffff),rim*std::pow(light,5.f)*.16f);
        c=mix(c,rgb(dark?0x7bc9f5:0xafdcff),rim*clamp(nx*.28f+ny*.38f)*.33f);
        c=mix(c,rgb(0xffffff),std::pow(clamp(1.f-py/std::max(1.f,h)),3.f)*(dark?.025f:.07f));
        float alpha=desktop?(material==Material::Sheet?.45f:.66f):1.f;
        if(material==Material::Primary)alpha=desktop?.96f:1.f;
        alpha=std::min(1.f,alpha+edge*.27f);
        im.bgra[size_t(y)*im.width+x]=pixel(c,alpha*coverage);
    }
    return im;
}
}
