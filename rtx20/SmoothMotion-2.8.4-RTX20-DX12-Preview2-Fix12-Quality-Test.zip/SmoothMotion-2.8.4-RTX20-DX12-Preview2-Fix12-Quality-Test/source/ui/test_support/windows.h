#pragma once
#ifdef _WIN32
#error Host fixture only
#endif
#include <cstdint>
#include <string>
using HRESULT=std::int32_t;using DWORD=std::uint32_t;using UINT=unsigned;using HWND=void*;using PWSTR=wchar_t*;
constexpr HRESULT S_OK=0,S_FALSE=1,E_FAIL=static_cast<HRESULT>(0x80004005),E_ACCESSDENIED=static_cast<HRESULT>(0x80070005);
constexpr DWORD ERROR_CANCELLED=1223,COINIT_APARTMENTTHREADED=2,CLSCTX_INPROC_SERVER=1;
constexpr bool FAILED(HRESULT h){return h<0;}constexpr bool SUCCEEDED(HRESULT h){return h>=0;}
constexpr HRESULT HRESULT_FROM_WIN32(DWORD n){return static_cast<HRESULT>(0x80070000|n);}
HRESULT CoInitializeEx(void*,DWORD);void CoUninitialize();void CoTaskMemFree(void*);
#define IID_PPV_ARGS(pp) 0,reinterpret_cast<void**>(pp)
