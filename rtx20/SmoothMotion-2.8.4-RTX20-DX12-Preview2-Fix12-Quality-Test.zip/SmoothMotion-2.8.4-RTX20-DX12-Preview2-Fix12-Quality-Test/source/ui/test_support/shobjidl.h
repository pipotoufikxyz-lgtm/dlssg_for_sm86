#pragma once
#include "windows.h"
constexpr DWORD FOS_FORCEFILESYSTEM=0x40,FOS_FILEMUSTEXIST=0x1000,FOS_PATHMUSTEXIST=0x800,FOS_NOCHANGEDIR=8,FOS_DONTADDTORECENT=0x02000000,FOS_ALLOWMULTISELECT=0x200,FOS_PICKFOLDERS=0x20,FOS_ALLNONSTORAGEITEMS=0x80,FOS_NOREADONLYRETURN=0x8000,FOS_NOVALIDATE=0x100,FOS_NODEREFERENCELINKS=0x100000;
constexpr int CLSID_FileOpenDialog=1,SIGDN_FILESYSPATH=2;
struct COMDLG_FILTERSPEC{const wchar_t* pszName;const wchar_t* pszSpec;};
struct IShellItem{bool folder=false;void Release();HRESULT GetDisplayName(int,PWSTR*);};
struct IFileOpenDialog{void Release();HRESULT GetOptions(DWORD*);HRESULT SetOptions(DWORD);HRESULT SetFileTypes(UINT,const COMDLG_FILTERSPEC*);HRESULT SetTitle(const wchar_t*);HRESULT SetFolder(IShellItem*);HRESULT Show(HWND);HRESULT GetResult(IShellItem**);};
HRESULT CoCreateInstance(int,void*,DWORD,int,void**);
