#pragma once
#include "shobjidl.h"
HRESULT SHCreateItemFromParsingName(const wchar_t*,void*,int,void**);
