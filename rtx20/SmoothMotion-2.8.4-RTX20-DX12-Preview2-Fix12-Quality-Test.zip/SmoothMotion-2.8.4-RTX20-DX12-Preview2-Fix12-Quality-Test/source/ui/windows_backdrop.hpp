#pragma once
#include <windows.h>
#include <dwmapi.h>

namespace waterglass {
struct Appearance { bool backdrop=false,highContrast=false,animate=true; };
inline Appearance applyBackdrop(HWND window,bool dark) {
    Appearance result;
    HIGHCONTRASTW contrast{};contrast.cbSize=sizeof contrast;
    if(SystemParametersInfoW(SPI_GETHIGHCONTRAST,sizeof contrast,&contrast,0))
        result.highContrast=(contrast.dwFlags&HCF_HIGHCONTRASTON)!=0;
    BOOL animate=TRUE;
    if(SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION,0,&animate,0))result.animate=animate!=FALSE;
    DWORD enabled=1,size=sizeof enabled;HKEY settings=nullptr;
    if(RegOpenKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",0,KEY_QUERY_VALUE,&settings)==ERROR_SUCCESS){
        DWORD type=0,value=1;
        if(RegQueryValueExW(settings,L"EnableTransparency",nullptr,&type,reinterpret_cast<BYTE*>(&value),&size)==ERROR_SUCCESS&&type==REG_DWORD&&size==sizeof value)enabled=value;
        RegCloseKey(settings);
    }
    BOOL composition=FALSE;DwmIsCompositionEnabled(&composition);
    BOOL useDark=dark?TRUE:FALSE;
    DwmSetWindowAttribute(window,DWMWA_USE_IMMERSIVE_DARK_MODE,&useDark,sizeof useDark);
    const DWM_WINDOW_CORNER_PREFERENCE corners=DWMWCP_ROUND;
    DwmSetWindowAttribute(window,DWMWA_WINDOW_CORNER_PREFERENCE,&corners,sizeof corners);
    // Documented Windows 11 22H2+ backdrop. Failure never leaves a transparent
    // black window: undo extension and use the fully opaque material renderer.
    if(!result.highContrast&&enabled&&composition){
        const DWM_SYSTEMBACKDROP_TYPE type=DWMSBT_TRANSIENTWINDOW;
        if(SUCCEEDED(DwmSetWindowAttribute(window,DWMWA_SYSTEMBACKDROP_TYPE,&type,sizeof type))){
            MARGINS margins{-1,-1,-1,-1};
            result.backdrop=SUCCEEDED(DwmExtendFrameIntoClientArea(window,&margins));
        }
    }
    if(!result.backdrop){
        const DWM_SYSTEMBACKDROP_TYPE none=DWMSBT_NONE;
        DwmSetWindowAttribute(window,DWMWA_SYSTEMBACKDROP_TYPE,&none,sizeof none);
        MARGINS margins{0,0,0,0};DwmExtendFrameIntoClientArea(window,&margins);
    }
    if(result.highContrast)result.animate=false;
    return result;
}
inline unsigned systemColor(int index) {
    COLORREF c=GetSysColor(index);
    return (unsigned(GetRValue(c))<<16)|(unsigned(GetGValue(c))<<8)|GetBValue(c);
}
}
