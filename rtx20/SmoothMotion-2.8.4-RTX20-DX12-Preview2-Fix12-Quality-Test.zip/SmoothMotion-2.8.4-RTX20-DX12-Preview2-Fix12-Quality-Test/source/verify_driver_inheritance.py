#!/usr/bin/env python3
"""Reuse GP9's driver specimen audit only when all driver/model code is identical.

This does not claim that the 617.14 specimen or a game was executed this run.
Only the explicitly listed presentation/startup files may differ from GP9.
"""
import argparse, hashlib, json
from pathlib import Path
import zipfile

BASELINE_SHA='b5d069c70d245e893af8b5e292edd26ffbf26fa95e2cad5b51d51e0cd270bf99'
PREFIX='SmoothMotion-2.8.2-R3-GP9-Driver-61714/'
DRIVER_SHA='1716d13d169320a2dc71486733202ed75127e8f39cd679a9193848fc1fa45e7f'
ALLOWED={
 'source/native/src/dxgi_hooks.cpp',
 'source/native/include/nvs30/factory_hooks.hpp',
 'source/native/include/nvs30/provider_thunks.hpp',
 'source/native/include/nvs30/startup_profile.hpp',
 'source/native/include/nvs30/presentation_profile.hpp',
}
def production(name):
 return name.startswith(('source/native/src/','source/native/include/nvs30/')) and Path(name).suffix in ('.cpp','.hpp','.h','.def')
def sha(data):return hashlib.sha256(data).hexdigest()
def validate_report(root):
 r=json.loads((root/'validation/driver-inheritance.json').read_text())
 assert r['result']=='PASS' and r['baseline_archive_sha256']==BASELINE_SHA
 assert r['driver_specimen_sha256']==DRIVER_SHA and r['driver_specimen_retested'] is False
 current={p.relative_to(root).as_posix() for p in (root/'source/native').rglob('*') if p.is_file() and production(p.relative_to(root).as_posix())}
 assert current==set(r['unchanged_source_sha256'])|set(r['presentation_source_sha256'])
 assert set(r['presentation_source_sha256'])==ALLOWED
 for group in ('unchanged_source_sha256','presentation_source_sha256'):
  for name,digest in r[group].items():assert sha((root/name).read_bytes())==digest,name
 assert 'source/native/src/nvpresent.cpp' in r['unchanged_source_sha256']
 assert sha((root/'validation/driver-61714-gp9.json').read_bytes())==r['baseline_audit_sha256']
 return r
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--baseline-package',type=Path,required=True);a=p.parse_args();root=a.root.resolve()
 assert sha(a.baseline_package.read_bytes())==BASELINE_SHA,'Not the pinned GP9 archive'
 with zipfile.ZipFile(a.baseline_package) as z:
  old={n[len(PREFIX):]:z.read(n) for n in z.namelist() if n.startswith(PREFIX) and production(n[len(PREFIX):])}
  current={p.relative_to(root).as_posix():p.read_bytes() for p in (root/'source/native').rglob('*') if p.is_file() and production(p.relative_to(root).as_posix())}
  assert set(old)<=set(current) and set(current)-set(old)<=ALLOWED
  unchanged={}
  for name,data in current.items():
   if name not in ALLOWED:
    assert old[name]==data,'Driver/model code changed: '+name
    unchanged[name]=sha(data)
  evidence=z.read(PREFIX+'validation/driver-61714-gp9.json');audit=json.loads(evidence)
  prior=json.loads(z.read(PREFIX+'validation/portable-normal.json'))
  assert prior['result']=='PASS' and prior['driver61714_sha256']==DRIVER_SHA
  assert audit['profile_tested'] and audit['input_sha256']==DRIVER_SHA
  assert len(audit['profile_regressions'])==2 and all(x['result']=='PASS' and 'real mutation cases=92' in x['output'] for x in audit['profile_regressions'])
  assert (root/'validation/driver-61714-gp9.json').read_bytes()==evidence
  report={'result':'PASS','baseline_archive_sha256':BASELINE_SHA,'driver_specimen_sha256':DRIVER_SHA,'driver_specimen_retested':False,'baseline_audit_sha256':sha(evidence),'unchanged_source_sha256':unchanged,'presentation_source_sha256':{n:sha(current[n]) for n in sorted(ALLOWED)},'note':'Historical GP9 specimen evidence; current host regressions are recorded separately. No Windows/GPU/game run.'}
  (root/'validation/driver-inheritance.json').write_text(json.dumps(report,indent=2)+'\n')
 validate_report(root)
 print('PASS: driver/model code unchanged from hash-pinned GP9; historical 617.14 specimen evidence retained explicitly.')
if __name__=='__main__':main()
