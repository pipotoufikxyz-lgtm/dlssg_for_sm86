import pathlib,runpy
runpy.run_path(str(pathlib.Path(__file__).resolve().parent/'rtx20/verify.py'),run_name='__main__')
