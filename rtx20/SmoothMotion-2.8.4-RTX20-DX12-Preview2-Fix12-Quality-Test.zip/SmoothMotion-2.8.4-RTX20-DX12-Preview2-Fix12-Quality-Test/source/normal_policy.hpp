#pragma once
#include <string>
namespace normal_motion {
inline constexpr const char* selection="native";
inline bool choice(const std::string& value){return value==selection;}
inline std::string label(const std::string& value){return choice(value)?"RTX20 Optical Flow (Preview)":"Unsupported selection";}
inline bool supportedAPIs(unsigned apis){return (apis&3)!=0;}
inline constexpr const wchar_t* oldConfigPath=L"SM86\\motion.ini";
}
