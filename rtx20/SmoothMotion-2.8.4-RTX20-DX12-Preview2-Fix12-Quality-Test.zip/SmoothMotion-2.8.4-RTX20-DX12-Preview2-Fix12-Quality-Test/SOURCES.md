# Fix12 source update

Fix12 changes the synthesis shader (exposure-compensated matching, robust
exposure estimate, crossing-object check, exposure-corrected occlusion fill)
and shader tests. `validation/DX12-Preview2-Fix12.patch` is the difference
from Fix11.

## Fix11

Fix11 adds adaptive half-resolution optical flow, GPU timestamp reporting and
the flow-resolution policy (source/rtx20/interpolator.cpp, policy.hpp,
performance.hpp, shaders.hlsl). `validation/DX12-Preview2-Fix11.patch` is the
difference from Fix10.

## Fix10

Fix10 changes the synthesis shaders (large-motion search, relative occluder
test, HUD overlay protection), release identities and shader tests. See
FIX10_NOTES.md and VALIDATION.md. `validation/DX12-Preview2-Fix10.patch` is the
source difference from Fix9; `validation/DX12-Preview2-Fix9.patch` is the
difference from the supplied Fix8 package.

# API references

- NVIDIA CUDA binary compatibility: https://docs.nvidia.com/cuda/ampere-compatibility-guide/index.html
- NVIDIA public NVOF CUDA API 2 headers: https://github.com/NVIDIA/NVIDIAOpticalFlowSDK
- NVIDIA NVOF programming guide: https://docs.nvidia.com/video-technologies/optical-flow-sdk/nvofa-programming-guide/index.html
- NVIDIA CUDA/D3D11 interop: https://docs.nvidia.com/cuda/cuda-driver-api/cuda_driver_api/group__CUDA__D3D11.html
- Microsoft context-state isolation: https://learn.microsoft.com/en-us/windows/win32/api/d3d11_1/nf-d3d11_1-id3d11device1-createdevicecontextstate

This build uses the public NVOF API and newly written synthesis code. It does
not use the separately licensed NvOFFRUC binary or the private NvPresent model.
The inherited CUDA API2 headers retain their existing notices. The private API5
header pair retains its NVIDIA license text intact; its source URLs, sizes and
hashes are recorded in `third_party/nvidia-optical-flow/d3d11-api5/provenance.json`.
The API5 mirror is a header source, not a hardware validation result. The original
NVSmooth30 and Ultimate ASI Loader notices are retained under third_party/.

DX12 implementation references (Microsoft):

- Shared committed resources and D3D11 compatibility: https://microsoft.github.io/DirectX-Specs/d3d/ResourceHeaps.html
- Opening shared resources: https://learn.microsoft.com/en-us/windows/win32/api/d3d11_1/nf-d3d11_1-id3d11device1-opensharedresource1
- Resource barriers: https://learn.microsoft.com/en-us/windows/win32/direct3d12/using-resource-barriers-to-synchronize-resource-states-in-direct3d-12
- Current backbuffer index: https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_4/nf-dxgi1_4-idxgiswapchain3-getcurrentbackbufferindex
- Queue replacement during resize: https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_4/nf-dxgi1_4-idxgiswapchain3-resizebuffers1

These API contracts informed the implementation. They are not hardware test results.

Fix5 uses the programming guide above for the native D3D11 API. The API5 pair is
compiled only inside `nvof_d3d11.cpp`; the matched common/D3D11 versions must stay
together and remain separate from CUDA2 structures. No NvOFFRUC or NVIDIA driver
binary is redistributed.
