# Fix 6 — correct native optical-flow input format

Fix5 did not activate its native D3D11 NVOF path in the supplied run. The log
explicitly rejects input format 28 (RGBA8) and selects the CUDA API2 fallback.
The native input should be format 87 (BGRA8). This is a code defect in Fix5,
not evidence of insufficient GPU performance or a broken transfer path.

Fix6 creates BGRA8 render-target/shader-resource inputs for native NVOF. If
native initialization is unavailable, it creates separate RGBA8 resources for
the CUDA fallback. The actual input format is recorded beside native readiness.
DirectX 11 games continue to use CUDA2; native API5 is for the DX12 bridge.

The supplied Fix5 log confirms GPU-fence transfer was selected successfully.
Across the F11-enabled portion, real-call activity was approximately 74.7/s and
generated Presents were accepted at approximately 74.6/s. The F11-disabled
intervals were approximately 164.5–174.8 real calls/s. These are interval-based
API/call rates with toggle times accounted for, not displayed FPS. The log
reports a 90 Hz display mode; submitted frames must not be equated with unique
visible refreshes. No Fix6 speed improvement has been measured here.

Install by closing the game and upgrading through the Manager, or replace the
existing manual ASI with `Manual/ASI_Only/new.asi` while retaining its loader.
Standalone installations use `Manual/Version/version.dll`. Keep one loading
route. Confirm version `2.8.4-rtx20-dx12-preview2-fix6` and look for both
`nvof_api=D3D11 API5 ready` and `input_format=87` in the new log. A CUDA fallback
line means the native optimization still did not initialize on that run.

The FAST preset can reduce optical-flow quality. Generated Present remains
VSync(1,0), while the real Present keeps the game's sync interval and flags.
A following interval-0 Present can shorten or discard the generated frame's
display duration. This is not fully uncapped frame generation and no doubled
displayed throughput is established.

This environment cross-compiles Windows binaries and runs host tests; it cannot
execute the target Windows/NVIDIA GPU. Run the DX12 smoke test and compare the
same scene/settings with F11 on/off. Native initialization, visible cadence,
image quality and performance still need confirmation on the target PC.
