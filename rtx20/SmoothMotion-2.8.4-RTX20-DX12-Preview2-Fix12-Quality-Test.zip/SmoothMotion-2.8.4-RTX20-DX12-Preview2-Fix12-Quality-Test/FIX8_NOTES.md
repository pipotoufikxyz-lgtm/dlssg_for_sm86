# Fix 8 — artifact reduction test

Runtime version: `2.8.4-rtx20-dx12-preview2-fix8-artifact-test`.

This update targets the broken patches around rooflines, the character and HUD
in the supplied Witcher 3 DX12 screenshot. It is a test build, not a verified
claim that all in-game artifacts are eliminated.

## What the evidence shows

Both supplied Fix7 sessions initialize native D3D11 NVOF API5 on an RTX 2080,
1920x1080, using the DX12 shared-texture bridge. Their final status samples report
zero transfer failures and zero RTX20 failures. The screenshot demonstrates
visible corruption despite successful API calls. That narrows the investigation
toward synthesis quality; it does not rule out game-specific presentation issues.

The old shader has three concrete weaknesses relevant to this result: a hard
per-pixel fallback to the unwarped current frame, no test that inverse warping
actually converged to the midpoint, and no test that the two reconstructed
endpoints belong to the same correspondence. Bilinear 4x4 optical flow can mix
foreground and background at object boundaries. Cycle consistency alone does
not make those mixed estimates safe to use.

## Changes

- Validate inverse-warp residual, full endpoint correspondence, forward/backward
  consistency, and all source/end coordinates before accepting a midpoint.
- Check RGB differences at both correspondence endpoints, including the current
  screen position. This last check prevents valid background motion from cutting
  into a newly appeared foreground object. A luma-only test misses color changes.
- Replace the hard cutover with a confidence-guided two-pass resolve. A private
  RGBA16F texture carries candidate color and confidence. Nearby uncertain pixels
  suppress isolated fragments, and the final fallback is feathered.
- Preserve stationary screen details using agreement between the two real frames
  at the same pixel, supported by a neighbor. This is a HUD heuristic, not access
  to the game's actual UI mask. Animated and translucent UI may still artifact.
- Reject extreme or out-of-frame motion. Uncertain regions use the real current
  image. Valid motion still produces a midpoint; interpolation is not globally
  disabled to hide the issue.
- Preserve current-frame alpha in the final output; confidence is internal only.
- Use MEDIUM optical-flow quality on both native API5 and CUDA API2 fallback.
- Recognize the exact attached Fix7 runtime hashes for managed upgrades. Rebuild
  both runtime carriers, installer, Manager, diagnostics and hardware test tools.

The uncapped generated Present policy remains interval 0 plus DO_NOT_WAIT, with
valid caller tearing flags preserved and the real frame restored/submitted with
its original parameters. No FPS cap or forced VSync was added.

## Install for the supplied Witcher 3 setup

1. Close the game and extract the complete updated package into a fresh folder.
2. For a managed install, use this package's `SmoothMotion_Manager.exe` to upgrade
   the same `witcher3.exe` and existing route. This preserves managed receipts.
3. For a manual standalone install, replace the installed `VERSION.dll` beside
   `H:\Games\The Witcher 3\bin\x64_dx12\witcher3.exe` with
   `Manual/Version/version.dll`. Keep a copy of the previous file for rollback.
   The supplied log identifies this carrier. If the setup is actually managed,
   prefer step 2. ASI installations instead replace `new.asi` from
   `Manual/ASI_Only/`, keeping their existing ASI loader.
4. Keep the same graphics, cap and VSync settings for the first comparison.
   Use windowed/borderless SDR and disable any separate in-game frame generator.
5. Check for the Fix8 version above, `MEDIUM preset` and
   `artifact_guard=conservative_v1` in the fresh log. Compare the same camera pan
   with F11 off/on, looking especially at rooflines, the character and quest text.
6. `Test/ShaderCheck.exe` compiles all four shader entry points using your Windows
   D3DCompiler47. The DX11/DX12 smoke tests check backend execution; they do not
   certify visual quality. If corruption persists, retain a fresh log and a short
   F11 off/on recording of the same movement.

## Cost and remaining limits

The additional intermediate costs about 15.8 MiB at 1080p (63.3 MiB at 4K), plus
an extra resolve pass and more texture reads. MEDIUM flow may increase GPU cost.
Actual frame-time impact on the RTX 2080 has not been measured here. Conservative
fallback may reduce local smoothing during fast movement and occlusion. There
are still no game depth, motion-vector, exposure or HUD buffers available.

Immediate back-to-back submissions can still be unevenly displayed or discarded.
The monitor in the supplied log is running at 60 Hz. Accepted Presents are not
proof of distinct displayed frames. `interpolation_verified` remains false.

## Validation

See `VALIDATION.md` and `validation/`. Current shader behavior is exercised using
production HLSL bodies with a CPU texture model, not a second implementation of
the interpolation equations. Windows/GPU execution and in-game visual quality
remain unverified.

NVIDIA's preset and flow representation contracts are documented in the bundled
SDK headers and the [NVOFA programming guide](https://docs.nvidia.com/video-technologies/optical-flow-sdk/nvofa-programming-guide/index.html).
No NVIDIA catalog skill specifically matched this custom D3D11/DX12 renderer.
