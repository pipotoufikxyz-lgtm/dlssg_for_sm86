@echo off
setlocal
set "SM20_DX12_FORCE_STAGING=1"
"%~dp0RTX20_DX12_SmokeTest.exe"
set "SM20_TEST_RESULT=%ERRORLEVEL%"
echo Staging test exit code: %SM20_TEST_RESULT%
pause
exit /b %SM20_TEST_RESULT%
