Debug symbols from this exact build, for crash analysis. Installation kits do not need these files.

Fix 4 also includes RTX20_TransferTest.pdb for the direct pixel-copy test.
