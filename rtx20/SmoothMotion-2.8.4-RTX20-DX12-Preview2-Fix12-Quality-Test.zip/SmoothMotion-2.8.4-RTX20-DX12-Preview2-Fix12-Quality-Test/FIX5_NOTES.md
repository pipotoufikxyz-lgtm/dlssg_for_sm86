# Fix 5 — RTX20 performance and mode recovery

## What the supplied Fix4 evidence establishes

Shared-texture initialization succeeds on the RTX 2070 SUPER in Resident Evil 3
Demo, including repeated resolution changes. The supplied logs show no DX12
transfer failures during their steady working periods. The earlier E_INVALIDARG
initialization failure is absent from those runs.

In the final 60.093-second interval of `nvsmooth30 (13).log`, 3,022 real and
2,377 generated Presents were accepted: 50.29 real + 39.56 generated = 89.84
accepted submissions per second. This is not a measurement of displayed FPS.
The supplied overlay showing 89 FPS and 41% GPU usage is consistent with that
cadence. The other screenshot shows approximately 146–147 FPS and 100% GPU use,
but the screenshots do not constitute a controlled benchmark.

`nvsmooth30 (12).log` later records `swapchain contract` / `0x887a0004` after a
display change. The rejected descriptor was not included in that log, so
exclusive fullscreen is a likely explanation, not a confirmed one.

## Changes

- For the DX12 bridge, prefer native D3D11 NVOF API 5 with directly registered
  frame/flow textures,
  FAST preset and one bidirectional execution. This avoids CUDA frame copies,
  graphics map/unmap and context synchronization on the native path. FAST can
  reduce optical-flow quality; visual comparison is still required.
- Preserve CUDA NVOF API 2 as an initialization fallback. A failed initialization
  does not imply support for the native route on every GPU/driver combination.
  DirectX 11 games retain CUDA2; native API5 uses only the DX12 bridge's private
  D3D11 context.
- Use optional D3D11/D3D12 shared-fence handoff where available, retaining the
  bounded CPU-query route otherwise. Remove duplicate copies in the frame path.
- Keep the generated Present at VSync(1,0). Preserve the game's sync interval
  and flags for the real Present. The remaining generated-frame VSync and any
  game/display limits still constrain cadence; this is not fully uncapped FG.
  An interval-0 real Present may discard or shorten display of the preceding
  generated frame. Displayed cadence remains unverified; no doubled displayed
  throughput is claimed.
- Preserve valid same-tick history instead of losing generation merely because
  two samples share a coarse timer tick.
- Permit reinitialization after a supported mode returns, while preserving the
  terminal handling of device loss or GPU work whose completion is uncertain.
- Add per-stage CPU wall timing to distinguish processing and Present waits.
- Recognize exact Fix4 ASI/proxy hashes in managed upgrades.

## Installation and comparison

Close the game and extract the complete ZIP into a fresh folder. Upgrade managed
installations through the included Manager. For the manual ASI route shown in
the supplied logs, replace the game's `new.asi` with `Manual/ASI_Only/new.asi`
while keeping its existing loader. A standalone proxy uses
`Manual/Version/version.dll`; do not combine those two loading routes.

The new session must identify `2.8.4-rtx20-dx12-preview2-fix5`. Start in
windowed/borderless SDR. Compare F11 on/off in the same scene and preserve the
same settings, limiter and display mode. Check native/fallback optical-flow
selection, transfer mode, handoff mode, failure counters and
`performance_cpu_wall_us`. Its phases overlap: prepare includes capture and
optical flow, so their cumulative totals must not be summed.

## Limits

This environment can cross-compile and run host policy tests; it cannot execute
Windows/NVIDIA driver 617.14 or measure an RTX20 display. Native API5 execution,
GPU-fence handoff, displayed frame pacing, image quality and speed must still
be tested on the target PC. The Fix4 measurements above are evidence about
Fix4 only, not a measured Fix5 improvement.
