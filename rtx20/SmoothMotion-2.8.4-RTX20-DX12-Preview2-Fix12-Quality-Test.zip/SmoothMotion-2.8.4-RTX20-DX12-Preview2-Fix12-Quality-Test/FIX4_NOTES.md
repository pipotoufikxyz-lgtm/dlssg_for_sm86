# Fix 4 — DX12 transfer rework

The supplied Fix3 log fails with E_INVALIDARG during transfer initialization,
before any capture or resource barriers execute. Its single error line does not
identify the failing API. Missing render-target capability in the shared texture
is a plausible cause, not a confirmed diagnosis of driver 617.14.

Changes:

- Shared textures use ALLOW_RENDER_TARGET plus ALLOW_SIMULTANEOUS_ACCESS.
- D3D12 shared handles keep GENERIC_ALL as required by Microsoft. The earlier
  suggested GENERIC_READ | GENERIC_WRITE substitution was incorrect.
- Each failed initialization step logs its API and HRESULT. Shared resources
  are committed only after both creation and D3D11 opening succeed.
- If sharing fails on healthy devices, a CPU staging path uses native D3D11
  textures, DX12 readback and two separate upload buffers. It retains the RTX20
  NVOF/synthesis backend and DX12 presentation, at potentially lower performance.
- Copies use actual row pitches, preserve original pixels across generated
  Present, reacquire the current buffer, and wait for D3D11/D3D12 completion.
- Fixed-state staging buffers are never given shared-texture barriers. GPU work
  with uncertain completion still prevents allocator reuse and resource release.
- The Manager recognizes the supplied Fix3 binaries for managed upgrades.

## Install

Extract the complete ZIP into a fresh folder. Close the game and use the included
Manager to upgrade the same game EXE and install route. For the manually installed
new.asi shown in the supplied log, replace that file using Manual/ASI_Only/new.asi
while retaining the existing ASI loader. Do not add a second loading route.
If the existing installation uses the standalone proxy, use Manual/Version/version.dll.
The next log must identify 2.8.4-rtx20-dx12-preview2-fix4.

Run Test/RTX20_DX12_SmokeTest.exe for the full NVOF backend check. If another failure
occurs, the line beginning [rtx20-dx12] API failed identifies where it happens.
The fallback can be exercised explicitly through Test/Test_DX12_Staging.cmd.
This process-local override does not change system settings.

## Evidence and limits

The package includes rebuilt Windows binaries, source and matching debug symbols.
Host tests and cross-compilation are separate from real GPU validation. No RTX20
or Windows/NVIDIA 617.14 runtime is available here; Blackwood compatibility,
displayed interpolation and performance must be confirmed on the target PC.
The fallback is a compatibility path; no performance improvement is claimed.

## Technical references

- Microsoft D3D12 CreateSharedHandle (GENERIC_ALL requirement):
  https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12device-createsharedhandle
- Microsoft D3D11.1 sharing capabilities:
  https://learn.microsoft.com/en-us/windows/win32/direct3d11/direct3d-11-1-features
- Microsoft D3D12 readback heaps and copy footprints:
  https://learn.microsoft.com/en-us/windows/win32/direct3d12/readback-data-using-heaps
  https://learn.microsoft.com/en-us/windows/win32/api/d3d12/nf-d3d12-id3d12device-getcopyablefootprints
- Analogous missing-bind-capability interop issue documented by DLSS5-Feeder:
  https://github.com/jlrouzies-fr/DLSS5-Feeder/blob/main/src/dlss5-feed.cpp
