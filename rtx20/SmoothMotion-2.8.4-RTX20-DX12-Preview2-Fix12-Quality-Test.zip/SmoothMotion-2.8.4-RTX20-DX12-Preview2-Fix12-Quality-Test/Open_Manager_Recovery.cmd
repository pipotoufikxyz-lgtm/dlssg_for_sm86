@echo off
cd /d "%~dp0"
start "" "%~dp0SmoothMotion_Manager.exe" --safe-ui
