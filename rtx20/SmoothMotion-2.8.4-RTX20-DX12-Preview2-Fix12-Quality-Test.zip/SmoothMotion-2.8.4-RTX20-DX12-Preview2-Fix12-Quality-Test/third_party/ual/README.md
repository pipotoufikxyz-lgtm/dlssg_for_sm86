# Ultimate ASI Loader

Author: ThirteenAG and contributors. Licence: MIT (see LICENSE.txt).

Release: [v9.7.4](https://github.com/ThirteenAG/Ultimate-ASI-Loader/releases/tag/v9.7.4).

The official NoPDB x64 release archive was fetched and verified against the SHA-256 digest published by GitHub's release API. Its dinput8.dll is byte-identical to this package's payload/loader/version.dll. The universal binary supports all 19 x64 carrier names listed in the release table; the installer renames that one binary to the selected name. Debug-symbol variants do not add another carrier or architecture.

This package's two supplied mod builds are x64. The menu lists upstream's Win32-only names separately as incompatible instead of installing a 32-bit loader into a 64-bit game.

Provenance, source URL and archive/binary hashes are recorded in provenance.json. The renderer's own source/licensing is separate from this loader.
