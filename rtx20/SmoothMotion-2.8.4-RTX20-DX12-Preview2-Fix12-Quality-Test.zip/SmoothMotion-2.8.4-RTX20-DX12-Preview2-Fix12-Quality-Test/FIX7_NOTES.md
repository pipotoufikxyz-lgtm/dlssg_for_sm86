# Fix 7 — uncapped submission test build

Version: `2.8.4-rtx20-dx12-preview2-fix7-uncapped-test`.

This test build removes the backend's forced VSync for generated submissions.
It does not implement a separate asynchronous display scheduler, unlock a
game engine's FPS limit, or establish doubled displayed FPS. Actual smoothing
without the user's 60 FPS cap is still unverified on Windows/NVIDIA hardware.

## Changes

- Generated frames use sync interval 0 plus DO_NOT_WAIT. A valid caller-provided
  ALLOW_TEARING flag is preserved; the backend does not invent tearing support.
- If the generated submission returns WAS_STILL_DRAWING, it is skipped. The
  real frame is restored and submitted once with the game's original settings.
  There is no retry loop, sleep, fixed 60/120 limiter, or synthetic VSync wait.
- Rejected generated submissions are counted separately in
  `generated_present_queue_busy`, not as accepted generated frames or pairs.
- Other errors/statuses and resize/fullscreen interruption safeguards remain.
- DX11 games now try the existing native D3D11 NVOF API5 path with BGRA8 inputs.
  It was previously gated to the DX12 bridge. Context state restoration and the
  game's existing multithread protection are used. Failed native initialization
  still falls back to separately allocated RGBA8 CUDA API2 resources.
- The Manager recognizes the exact supplied Fix6 ASI/proxy hashes for upgrades.
- The DX11 smoke test requests VSync for 10 seconds, then interval 0 for 10 seconds.

## Evidence from the supplied logs

The attached Fix5/Fix6 logs record `generated_vsync_original_game`, including
generated sync=1 when RE3DEMO requests sync=0 with ALLOW_TEARING. Sekiro's Fix6
sessions use CUDA API2. In log (18), PID 16848, cumulative optical-flow CPU wall
time averages about 24.45 ms per call; this includes waits and is not GPU time.
The newer Cyberpunk 2077 Fix6 sessions in log (20)(1) already initialize native
API5, but retain the same forced generated VSync setting.
These findings identify unnecessary synchronization and a slower fallback path;
they do not prove the complete cause of the user's capped-versus-uncapped result.

The `unsupported_mode` skips correspond to the source's exclusive-fullscreen
guard. That mode remains unsupported. Use windowed or borderless.

The logs report display modes from 59 to 92 Hz. Check the actual active Windows
refresh rate when comparing visible output. Accepted Presents are not refreshes.

## Install and test without a 60 FPS cap

1. Close the game. Keep the previous ZIP for rollback.
2. Upgrade a managed install using the included Manager, preserving its route.
   For a manual ASI install replace only `new.asi` with `Manual/ASI_Only/new.asi`;
   keep its existing loader. Standalone installs use `Manual/Version/version.dll`.
3. Use windowed/borderless SDR. Disable in-game frame generation and VSync, and
   remove the external 60 FPS limiter for this comparison. Driver overrides and
   any engine-level FPS lock still apply; this build does not modify them.
4. Check the version above in a fresh `nvsmooth30.log`. The new pacing value is
   `generated_immediate_nonblocking_original_game`; `runtime_fps_cap` is 0.
   `nvof_api=D3D11 API5 ready` identifies native flow, otherwise inspect fallback.
5. Compare the same moving scene with F11 off and on. Record the visual result
   and real-frame timings, not just the overlay's total Present count. Return the
   fresh log if uncapped motion is still uneven, unchanged, or slower.

## Limits and validation

Frame generation still consumes GPU resources. Capture/transfer and the original
Present may block. The real game request is preserved, so in-game/driver VSync
can still limit throughput. Saturated GPUs may have fewer generated submissions.

Immediate submissions may be discarded by DXGI/composition or displayed with
uneven spacing. Removing Present(1,0) is not sufficient to guarantee smooth
uncapped 2x output; a separate presentation scheduler may ultimately be needed.
`interpolation_verified` deliberately remains false. No measured FPS improvement
or successful Windows/GPU run is claimed in this package.

Host tests exercise queue saturation, original-frame restoration, callback and
counter decisions, errors, transitions, and preservation of caller flags. The
release build also runs the existing host suite, binary/source identity checks,
and archive verification. See `validation/host-tests.json` and `validation/package.json`.

References consulted (Microsoft):
- https://learn.microsoft.com/en-us/windows/win32/api/dxgi/nf-dxgi-idxgiswapchain-present
- https://learn.microsoft.com/en-us/windows/win32/direct3ddxgi/dxgi-present
