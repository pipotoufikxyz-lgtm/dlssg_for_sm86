#pragma once
namespace helper_identity {
inline constexpr char installer[]="a777805e9adbf5dbdeff289ab759853ecdce3ba5cf00cab68557f010dc83f7aa";
inline constexpr char collector[]="720735ecae361feb284cb6cadb8dd5ebd6784428f46f10cec7536ec7ae3bf408";
}
