# SmoothMotion 2.8.4 RTX20/RTX30 Fix 18 — RTX 30 support

Fix18 runs this package's own frame generation (NVIDIA optical-flow hardware
plus our synthesis: every quality, pacing and performance fix up to Fix17) on
RTX 30 (Ampere SM86) cards as well as RTX 20. It replaces the GP9 approach
for RTX 30, which ran NVIDIA's closed Smooth Motion model through driver
patches. See `FIX18_NOTES.md`.

Fix17 never lets frame generation lower the displayed frame rate: it
measures the game's own rate first and pauses generation when generating
shows fewer frames than native (for example a laptop RTX 2070 Max-Q in
Genshin Impact at 120 FPS). Rate measurements ignore loading hitches, which
caused 100 ms waits and stutter. See `FIX17_NOTES.md`.

Fix16 adds 10-bit SDR backbuffers (RGB10A2, used by God of War 2018), with
synthesis at full 10-bit precision. See `FIX16_NOTES.md`. Everything in Fix15
is included:

Fix15 removes the dark slivers that appeared ahead of moving roofs and walls
over sky. It keeps frame generation within a GPU budget (default 10% of the
real frame time), choosing SLOW, MEDIUM or half-resolution optical flow by
measured cost. Flat areas take a cheaper synthesis path. DX11 games using
sync interval 2–4 (30 FPS locks), exclusive fullscreen or multisampled
backbuffers are interpolated instead of passed through.

Read `FIX15_NOTES.md` for the diagnosis, settings (`GpuBudget`,
`ExclusiveFullscreen`) and limits. `FIX14_NOTES.md` covers spaced
presentation (`Pacing`, `FlowQuality`); `FIX11_NOTES.md` explains the optional
`nvsmooth30.ini`.
Host shader and policy tests pass, but Windows/GPU execution, in-game image
quality and performance still need verification on your PC.

This is Turing hardware optical flow with custom frame synthesis. NVIDIA's
proprietary Smooth Motion neural model has not been ported. The package contains
Windows x64 ASI/proxy binaries, Manager, installer, tests, source and symbols.

## Install and check

1. Extract the complete ZIP into a new folder and close the game.
2. For a managed installation, run `SmoothMotion_Manager.exe` and upgrade the
   same game EXE and install route. For an existing manual ASI installation,
   replace `new.asi` with `Manual/ASI_Only/new.asi` and keep the existing loader.
   Standalone installations use `Manual/Version/version.dll`. Choose one route.
3. Use DirectX 11 or DirectX 12 (windowed, borderless or exclusive fullscreen), SDR, HDR off, and in-game
   frame generation off. For uncapped testing remove the external limiter and
   disable in-game/driver VSync. Engine locks are not removed. F11 toggles interpolation.
4. Confirm `2.8.4-rtx20-rtx30-dx12-preview2-fix18-test`,
   `artifact_guard=occlusion_aware_v6`, a `GPU budget:`, a `presentation=` and a `spacing:` line in `nvsmooth30.log`. Compare F11 on/off
   in the same scene, resolution, graphics settings and limiter configuration.
5. Run `Test/RTX20_DX12_SmokeTest.exe` for its 24-second resize/queue test. Leave
   interpolation enabled. Read `Test/rtx20-dx12-test-report.txt`; backend-counter
   PASS is separate from displayed-frame and performance validation.

The Manager recognizes exact released Preview 1, Preview 2, Fix 1–15 and GP9
Fixes1 binaries. Managed upgrades preserve ownership, backup and uninstall
receipts. Manual copying does not update those receipts.

## Supported scope

| Item | Scope |
|---|---|
| GPU | NVIDIA Turing SM75 (RTX 2060/2070/2080) or, since Fix18, Ampere SM86 (RTX 3050–3090) on the game's adapter |
| OS/API | Windows 10/11 x64; DirectX 11 or DirectX 12 |
| Optical flow | DX11 and DX12 bridge: D3D11 NVOF API5 preferred, CUDA2 initialization fallback |
| Display | Windowed, borderless or exclusive fullscreen SDR, RGBA8/BGRA8 or RGB10A2; DX11 also multisampled backbuffers |
| Dimensions | 128–3840 wide, 128–2160 high, subject to driver capabilities |
| DX12 queue | Exact DIRECT presentation queue, one GPU node, same adapter |
| DX12 swapchain | Flip model, 2–16 buffers; query the current buffer for every copy |
| Pacing | Below the refresh rate the real Present waits until the generated frame has been visible for half a real-frame interval (timed or pipelined; the wait never deliberately lowers the game's frame rate). VSync games: both frames with interval 1. At or above the refresh rate: generation pauses. `Pacing=off`: Fix12 immediate presentation |
| Tearing | Only valid interval-0, windowed ALLOW_TEARING requests are admitted |
| Sync interval | 0–4; intervals 2–4 (30 FPS locks) share the game's refreshes between the generated and real frame |
| GPU budget | `GpuBudget` percent of the real frame time (default 10); `0` = unlimited |
| Unsupported | Vulkan, OpenGL, HDR/FP16, DX12 MSAA, partial/scroll presents, protected content, multiple presentation queues/GPU nodes, DX11 below feature level 11.0 |
| Validation | Fix16 Windows/GPU execution, displayed output and performance remain unverified |

No CUDA toolkit or Optical Flow SDK installation is required on the game PC.
The runtime loads its NVIDIA and shader-compiler DLLs from System32 and does
not patch or replace driver files. Unsupported modes keep normal presentation;
returning to a supported mode can initialize interpolation again. If submitted
GPU completion is uncertain, the affected session is retained and permanently
disabled. A device-reset result prevents unsafe game-buffer reuse when transfer
completion is uncertain.

## Transfer and optical flow

DX12 presentation is captured on its actual queue. A native D3D11 device uses
the same adapter and exchanges images through shared textures. When sharing
is unavailable, a CPU readback/upload path remains available. The log identifies
`mode=shared-texture` or `mode=cpu-staging`; staging may be slower.

Where supported, shared D3D11/D3D12 fences order transfer work on the GPU
(`handoff=gpu-fence`). Otherwise the bounded CPU completion path remains
(`handoff=cpu-query`). GPU handoff does not remove all CPU waits or guarantee
an increase in FPS. Reset and resource reuse still require safe completion.

For DX11 games and the DX12 bridge, the native optical-flow path registers private D3D11 textures directly and
requests both flow directions in one NVOF execution. It avoids the CUDA frame
copies, graphics map/unmap and context synchronization used by the fallback.
The CUDA API 2 headers and the matched D3D11 API 5 headers remain isolated.

The midpoint is written to the current backbuffer. After its extra Present,
the backend queries the new buffer index and restores the saved real frame.
Game buffers return to PRESENT; shared textures return to COMMON. CPU staging
uses fixed readback/upload heap states and a separate saved-original buffer.

Games that assume one buffer advance per game frame, pre-record future
backbuffer work, or depend on Present returning for GPU progress may still be
incompatible. Synthesis has no game motion vectors, depth or HUD mask; cuts,
UI, disocclusions, fast motion and transparency can show artifacts.

## Read the log

- `nvof_api=D3D11 API5 ready` with `input_format=87` identifies successful
  native initialization with BGRA8 input. Initialization failure
  can select the CUDA API 2 path; use its log line to identify the actual route.
- `dx12_sessions`, `dx12_captures`, `dx12_writes`, and `flow_pairs` describe
  backend activity, not physical display output.
- `generated_present_accepted` and `real_present_accepted` count successful
  submissions. Their deltas per second are accepted Present rates, not proof
  of displayed FPS or unique visible frames.
- `dx12_transfer_failures`, `rtx20_failures`, `present_skips`, and the exact API
  error lines identify failures and pass-through reasons.
- `performance_cpu_wall_us` reports cumulative `calls`, `total_us`, `max_us`
  for prepare, capture, optical_flow, synthesis, generated_write, original_write,
  generated_present and real_present. These are CPU wall times including waits;
  prepare contains nested phases, so do not add them together as total time.
- `generated_present_queue_busy` counts skipped synthetic submissions under
  queue pressure. These are not accepted generated frames.
- `presentation=timed|pipelined|vblank|immediate|paused` and `spacing:` lines,
  plus `presentation`, `spacing_us`, `reference_fps`, `timed_pairs`,
  `pipelined_pairs`, `paced_pairs`, `spacing_wait_us` and
  `generation_paused_frames` in the status, show how generated frames were
  presented and spaced.
- `flow_quality=` lines and `flow_pairs_high_quality` show when the SLOW
  optical-flow preset was used.
- `interpolation_verified` remains false; counters do not measure display output.

`Test/ShaderCheck.exe` checks runtime shader compilation. `Test/RTX20_SmokeTest.exe`
checks DX11. `Test/RTX20_TransferTest.exe` checks CPU-staging pixels without NVOF.
`Test/Test_DX12_Staging.cmd` forces staging for the full DX12 check.
For diagnostics, run `Collect_Diagnostics.exe` for the same game EXE. Nothing
is uploaded automatically. See VALIDATION.md, BUILD.md and Test/README.md.
