# Fix19 crosshair and HUD test

See FIX19_NOTES.md. Full-frame static overlay mask (opaque and translucent
HUD detail), scene behind overlays taken from the other frame, revealed-
behind-HUD content no longer kept as new. Exact Fix18 upgrades recognized.

# Fix18 RTX 20/30 test

See FIX18_NOTES.md. Ampere SM86 (RTX 30) accepted by the same NVOF +
synthesis backend; the Manager replaces owned GP9 (RTX 30 driver-model)
installations and exact Fix17 installations.

# Fix17 performance guard test

See FIX17_NOTES.md. Native-rate measurement without generation, a guard that
pauses generation when it lowers the displayed rate (retries back off from
30 s), hitch-proof median measurements (no more 100 ms waits), flow presets
chosen from the native rate, hybrid-laptop notice. Exact Fix16 upgrades are
recognized.

# Fix16 10-bit SDR test

See FIX16_NOTES.md. RGB10A2 UNORM backbuffers (God of War 2018 uses one in
SDR) are interpolated on DX11 and DX12; synthesis reads full-precision frame
copies. Exact Fix15 upgrades are recognized.

# Fix15 roofline, GPU budget and DX11 compatibility test

See FIX15_NOTES.md. No slivers of the next frame ahead of edges moving over
flat sky (HUD test requires two-frame contrast; flat, matching pixels are not
one-sided and fill the fallback). A GpuBudget (default 10% of the real frame
time) chooses SLOW, MEDIUM or half-resolution flow by measured cost, and
flat areas take a cheaper synthesis path. DX11/DX12 exclusive fullscreen,
DX11 multisampled backbuffers and sync intervals 2–4 are interpolated.
Exact Fix14 upgrades are recognized.

# Fix14 smooth presentation, quality and glass UI test

See FIX14_NOTES.md. Spaced presentation: the real frame waits until the
generated frame has been visible for half a real-frame interval (timed, or
pipelined with the next pair computed during the wait; Pacing=auto chooses).
Synthesis: validated occlusion fill, exposure gain model, thin-object and
crossing-line motion, sharp resampling, SLOW NVOF preset below 40 FPS.
Liquid-glass Manager interface. Exact Fix13 upgrades are recognized.

# Fix13 pacing and performance test

See FIX13_NOTES.md. Generated and real frames presented on consecutive
refreshes (sync interval 1, optional Pacing=off), generation paused while the
real frame rate reaches the display refresh (optional GenerateAboveRefresh=1),
and a synthesis pass with about 35% fewer texture fetches per pixel. Exact
Fix12 upgrades are recognized.

# Fix12 quality test

See FIX12_NOTES.md. Exposure-compensated motion matching with a robust local
estimate, exposure-corrected occlusion fill, and a stricter crossing-object
test. Exact Fix11 upgrades are recognized.

# Fix11 frame-generation performance test

See FIX11_NOTES.md. Adaptive half-resolution optical flow (automatic at 58+ real
FPS, optional nvsmooth30.ini FlowResolution=auto|full|half) and GPU stage
timing in the runtime status. Exact Fix10 upgrades are recognized.

# Fix10 fast-pan and HUD artifact test

See FIX10_NOTES.md. Motion candidates up to 256 px, motion-guided midpoint
projection, occluders judged by relative motion, and real-frame protection
around HUD text drawn over moving scenery. Exact Fix9 upgrades are recognized.

# Fix9 occlusion-aware synthesis test

See FIX9_NOTES.md. Per-pixel motion candidates with symmetric patch matching and
flow support replace the Fix8 current-frame cutover. A new midpoint projection
pass finds thin crossing objects. Occlusions are filled one-sided from the frame
that shows them, and unexplained current content stays intact. The fallback
feather narrows to about one pixel. Exact Fix8 upgrades are recognized.

# Fix8 artifact-reduction test

See FIX8_NOTES.md: correspondence/convergence checks, conservative two-pass resolve,
stationary-detail protection, preserved output alpha and MEDIUM flow quality.
Uncapped presentation is retained; exact Fix7 upgrades are recognized.

# Fix 6: correct native NVOF input format

- Correct the D3D11 input mapping from RGBA8/format 28 to BGRA8/format 87.
- Create native inputs with render-target and shader-resource bindings; if
  native initialization fails, recreate RGBA8 CUDA fallback resources.
- Log the actual input format with native readiness; preserve Fix5 GPU-fence
  transfer and its existing pacing/diagnostics.
- Recognize exact published Fix5 binaries for managed upgrades.

The supplied Fix5 run used CUDA fallback, not native API5. Fix6 performance and
native hardware execution remain unmeasured here. See FIX6_NOTES.md.

# Fix 5: native optical flow, transfer overhead and mode recovery

- Native D3D11 NVOF API5 directly registers textures and requests both flow
  directions in one execution; CUDA API2 remains an initialization fallback.
- FAST optical-flow preset trades potential quality for speed. Hardware and
  visual validation are outstanding.
- Optional GPU fence handoff, reduced duplicate copies and same-tick history.
- Generated Present remains VSync(1,0); the real Present preserves the caller's
  interval and flags. This is not a fully uncapped presentation path.
- Recovery when a supported display mode returns; uncertain GPU work remains
  terminal. Per-stage CPU wall timing separates work from Present stalls.
- Exact Fix4 migration identities and updated package/source provenance checks.

See FIX5_NOTES.md for supplied Fix4 measurements and validation limits.

# Fix 4: DX12 transfer rework

Shared RT-capable textures, exact initialization API diagnostics, CPU staging
fallback, correct fixed-state buffer barriers and independent original-frame
restoration. GENERIC_ALL retained. Added row-layout regression coverage and
Fix3 installer migration identities. See FIX4_NOTES.md for limitations.

# RTX20 DX12 Preview 2 Fix 3 changes

A second code review found defects beyond the original tearing admission gate:

- A resize or fullscreen transition completing during a generated Present could
  send the old snapshot to the new swapchain. A size mismatch then produced a
  synthetic device-reset failure; a still-active transition also produced one.
  Frame pairs now track a transition revision, discard stale history and stop
  the pair when interrupted. Actual copy failures still use the existing error
  path. The next eligible request recreates the resources after the transition.
- DX11's optional context protection locked individual API calls but did not
  protect the complete state-swap/draw/restore transaction. The mod now honors
  the game's existing protection across that sequence, without enabling it or
  changing the private DX12 device's locking policy.
- Runtime initialization status was written during startup and read by the
  diagnostic worker without synchronization. The published pointer is atomic.
- The DX12 smoke test could return success after rendering all phases with no
  interpolation. It now checks runtime counters per phase, including session
  recreation, frame captures, flow, generated submissions and tearing admission
  where supported; backend failures prevent a pass.
- Exact Fix 2 DLL/ASI identities are recognized for managed upgrades. Fix 1,
  earlier RTX20 releases and the existing install/uninstall workflow remain.

Version: `2.8.4-rtx20-dx12-preview2-fix3`. These are code and host-test findings,
not proof of displayed output. Windows/RTX20 execution remains required. The
hardware test report now distinguishes a verified counter result from a window
that merely rendered. See VALIDATION.md for completed build checks.

---

# RTX20 DX12 Preview 2 Fix 2 changes

The supplied Blackwood Fix 1 log now shows successful swapchain registration
and DX12 queue capture, but all 12,335 intercepted Present calls passed through.
No DX12 session, captures, optical-flow pairs or generated Presents were recorded.

A definite admission defect was found: Fix 1 required `flags == 0`, rejecting
`DXGI_PRESENT_ALLOW_TEARING` (0x200). The logged windowed swapchain has creation
flags 0x842, including ALLOW_TEARING (0x800), so this is a plausible cause of the
reported bypass. The log did not capture Present flags or sync intervals and
cannot prove that this was its actual trigger. It also cannot establish a crash
cause; the helper-process entries contain no crash stack.

- Admit full-frame tearing requests only for interval 0, a windowed swapchain,
  and its ALLOW_TEARING creation flag. Other control flags remain pass-through.
- When a midpoint is generated, submit both frames with interval 1 and flags 0.
  This avoids the invalid combination of VSync and ALLOW_TEARING on the original
  frame. Without generation, preserve the application's interval and flags.
- Handle every TEST-bit combination before swapchain adoption or resource work.
- Log the first occurrence of each bypass reason, including interval, flags and
  partial-update state. Schema 15 adds `present_skips`, `present_eligible` and
  `present_tearing_eligible` so the next game log can identify any remaining gate.
- DX12 smoke test uses tearing / VSync / tearing phases when available, preserves
  the swapchain flag through both resize APIs, and reports capability and counts.
- Manager/installer recognize the exact supplied Fix 1 ASI and standalone DLL.
- Rebuild both runtime carriers, installer, Manager, collector and all three test
  programs, with matching symbols and manual kits. Host policies cover 196,608
  admission cases, 12,288 unchanged requests and 64 presentation failure cases.

Version: `2.8.4-rtx20-dx12-preview2-fix2`. Windows/GPU execution and Blackwood
behavior remain unverified here. See VALIDATION.md. The earlier overlay
registration repair remains included.

DXGI contract reference:
https://learn.microsoft.com/en-us/windows/win32/direct3ddxgi/dxgi-present

---

# RTX20 DX12 Preview 2 Fix 1 changes

Fixes the Blackwood (Unity, DX12) report: the runtime initialized from
`UnityPlayer.dll`, but no swapchain was registered, so `present_calls`,
`dx12_sessions` and `flow_pairs` stayed at 0 (`graphics_excluded=1`).

- Cause: an overlay patched the shared DXGI factory table after Smooth Motion
  (for example NVIDIA's capture DLL in System32, or the Steam overlay). The game's
  `CreateSwapChainForHwnd` then reached our hook with the overlay as the immediate
  caller. That caller is correctly barred from initializing the runtime, but the
  game's real swapchain was discarded with it, so Present was never hooked.
- Once the runtime is ready, a swapchain returned through such a forwarding hook
  is now registered for presentation. Excluded callers still cannot initialize it.
- A swapchain reaching a hooked Present without registration is adopted once;
  its DX12 queue comes from DXGI `GetDevice`, with the same DIRECT/node checks.
- `D3D12CreateDevice` now hooks the DXGI factory table, as D3D11 already did.
- d3d11.dll's nested factory call inside `D3D11CreateDeviceAndSwapChain` is not
  registered twice; duplicate registrations of one chain are ignored.
- New log lines: factory hook outcome, forwarded/unregistered swapchain callers
  (module + RVA), and Present-time adoption.
- Manager/installer recognize the exact Preview 2 `new.asi` and `version.dll`
  bytes for in-place upgrades. Version string: `2.8.4-rtx20-dx12-preview2-fix1`.

Windows/GPU execution remains unverified; see VALIDATION.md.

---

# RTX20 DX12 Preview 2 changes

- Implemented DX12 capture and presentation through same-adapter shared textures
  and a native D3D11/CUDA optical-flow session.
- Captured actual swapchain creation queues; validated device identity, DIRECT
  type and single-node operation.
- Added PRESENT/COMMON transitions, bounded completion waits, uncertain-session
  retention, and current-buffer queries for every transfer.
- Added ResizeBuffers session recreation and ResizeBuffers1 queue updates.
- Enabled DX12 in the Manager/installer and pinned Preview 1 upgrade identities.
- Added a compiled DX12 smoke test with resize and queue-change phases, runtime
  transfer counters, host fault tests and matching symbols.
- Retained the DX11 path and F11 toggle.

Windows/GPU execution and game compatibility remain unverified. See VALIDATION.md.

---

# RTX20 Preview 1 changes

- New Turing backend using the public NVOF CUDA API with bidirectional 4x4 flow.
- New frame-synthesis shader with inverse warping and consistency-based occlusion handling.
- D3D11 pipeline-state preservation, adapter matching, CUDA context preservation,
  frame-history resets, supported-format checks, and original-frame restoration.
- Generated pairs use VSync; F11 toggles interpolation.
- Standalone version.dll and ASI built from the same RTX20 backend.
- Manager/installer updated for DX11 admission and exact GP9 Fixes1 upgrades.
- Hardware/shader test executables, source and debug symbols included.

Scope: experimental D3D11 SDR windowed/borderless implementation. The private
NVIDIA Smooth Motion neural model has not been ported. DX12 and GPU/game
validation remain outside the implemented/tested scope of this preview.
