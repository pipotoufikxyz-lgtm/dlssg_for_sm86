#pragma once
namespace helper_identity {
inline constexpr char installer[]="b187f4b128d2c0bbb9039cbe5d32a7ff53896079a6a0bdc944f86e304c9a1cc3";
inline constexpr char collector[]="3e82991131bc1dd7fb25c126c6c7d9bdb34bb3c00ab3d4fd393c216b7390e690";
}
