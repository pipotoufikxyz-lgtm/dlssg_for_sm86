# Rebuild the RTX20 preview (DX12 Preview 2 Fix 19 RTX 20/30 Test)

Use Python 3, Zig **0.14.1** or LLVM-MinGW, glslangValidator, and g++ for host tests.
No NVIDIA SDK download, CUDA toolkit, Windows SDK installation or driver binary
is required to cross-compile the package. The CUDA API2 headers, small CUDA
Driver ABI declarations, and matched private D3D11 NVOF API5 headers are included.

From the package root:

```sh
python source/build_release.py --zig /absolute/path/to/zig --glslang /absolute/path/to/glslangValidator
python source/package_release.py --output /absolute/path/to/SmoothMotion-2.8.4-RTX20-RTX30-DX12-Preview2-Fix19-Test.zip
```

The first command builds both runtime carriers, diagnostics, installer, Manager,
DX11/DX12 hardware tests, shader checker and transfer-pixel test. It stages manual
kits and nine symbol files, runs host tests, then verifies source/binary hashes,
payload/helper identities, API5 header provenance and PDB identities.
The second command verifies again, writes SHA256SUMS.txt, and validates the ZIP.

`source/rtx20/` is the active backend. `nvof_d3d11.cpp` isolates API5 headers from
the existing CUDA API2 structures in `interpolator.cpp`. Include both private
headers from `third_party/nvidia-optical-flow/d3d11-api5/` together; retain their
license notices and `provenance.json`. `performance.hpp` records CPU wall times.

`source/native/` supplies inherited loader, proxy and import-hook utilities and
retains the old SM86 renderer as reference. The RTX20 build excludes that renderer
and driver patcher. Do not use historical `source/native/build.py` to build RTX20.

The backend report includes hashes of all runtime/native sources and NVIDIA
headers, including the private API5 pair. Rebuild after source/test/verifier edits;
otherwise package verification correctly rejects stale artifacts. The archive's
SHA256SUMS covers all files, including third-party provenance and license records.

HLSL is embedded as text and compiled by Windows D3DCompiler47 at runtime.
Run `Test/ShaderCheck.exe` for that PC's shader compiler, then the DX11/DX12 and
pixel checks described in Test/README.md. Cross-compilation and host tests do
not validate native NVOF execution, displayed frames or performance.

## LLVM-MinGW alternative

Use `--cxx /absolute/path/to/x86_64-w64-mingw32-clang++` instead of `--zig`.
Keep the target-prefixed driver filename. On Linux, if the dynamic loader cannot
resolve the bundled compiler libraries, set `LD_LIBRARY_PATH` to that toolchain's
`lib` directory. Fix8 was built using LLVM-MinGW 20260922 (UCRT); Fix9 to Fix19
were built using LLVM-MinGW 20250924 (UCRT), as recorded in the build reports.

Use `--ubsan-only` only when the inherited ASan runtime is incompatible with the
host environment. It runs optimized + UBSan inherited tests and records the ASan
coverage limitation explicitly. The dedicated shader behavior tests still run
optimized and ASan/UBSan. See VALIDATION.md for this build's baseline reproduction.

`source/rtx20/test_shader.py` runs the production shader body through a CPU sampler
model; `source/rtx20/validate_shaders.py` checks HLSL syntax separately. Neither is
a Windows shader execution test. `Test/ShaderCheck.exe` checks all nine entries.
