# Fix10 shader validation

Run `ShaderCheck.exe` first: it must report PASS for Fullscreen, Capture,
Project, Synthesize and Resolve. This checks native shader compilation only.
CPU behavior tests and their limitations are documented in `../VALIDATION.md`.

# Fix7 uncapped submission testing

The DX11 test now runs 10 seconds with game VSync, then 10 seconds with game
Present interval 0. Both phases use generated interval 0 + DO_NOT_WAIT. Check
native NVOF initialization on DX11 and compare motion, not just counters.
`generated_present_queue_busy` records optional generated frames skipped when
the queue is busy. No fixed 60 FPS limiter is included. See ../FIX7_NOTES.md.

The instructions below describe the retained hardware tests. Mentions of Fix6
are historical; verify the Fix7 uncapped-test version in the current log.

# RTX20 checks

1. Run `ShaderCheck.exe` from a terminal. Three PASS lines indicate that this
   PC's D3DCompiler47 compiled the shaders.
2. Run `RTX20_DX12_SmokeTest.exe` for DX12. It runs for 24 seconds: three buffers,
   then a resize to two buffers after 8 seconds, then a new DIRECT presentation
   queue and three buffers after 16 seconds. Leave F11 enabled throughout the automated run. When
   supported, the first and third phases request tearing; the middle phase uses
   VSync. Otherwise all phases use VSync, and the report marks tearing untested.
3. Read **Backend execution: PASS / FAIL / INCONCLUSIVE** in
   `rtx20-dx12-test-report.txt` and inspect `nvsmooth30.log`. PASS requires a new
   session and positive backend progress in every phase, with zero recorded
   backend/transfer/Present errors. With interpolation on,
   `dx12_captures`, `dx12_writes`, `flow_pairs`, and
   `generated_present_accepted` should increase across all phases;
   `dx12_transfer_failures` should remain zero. `present_tearing_eligible` should
   increase in tearing phases. If no session starts, check `Present bypass`
   log lines and `present_skips` for the reason.
4. Run `RTX20_SmokeTest.exe` for the 20-second DX11 test. It writes
   `rtx20-test-report.txt`.

The DX12 test enables the optional D3D12 debug layer when Windows Graphics Tools
is already installed. ERROR/CORRUPTION messages prevent a PASS. It also runs
without that component and explicitly reports that debug validation is unavailable.
Closing early or turning interpolation off can produce INCONCLUSIVE.
Exit code 0 means backend-counter PASS; every incomplete/failed result is nonzero.

The tests load adjacent `new.asi` directly. Keep the Test folder separate from
games. They do not install files or modify drivers. API counters are evidence
of processing/submission; visually compare F11 on/off and check display cadence.

## Transfer checks retained from Fix 4

Run `RTX20_TransferTest.exe` to verify actual pixel copies through the forced CPU
staging path. It does not require CUDA/NVOF and is separate from the full backend
test above. It covers original-frame restoration after the extra Present.

Run `Test_DX12_Staging.cmd` to force the full NVOF test through the fallback.
For normal operation, run `RTX20_DX12_SmokeTest.exe` directly; its log reports
`mode=shared-texture` or `mode=cpu-staging`. Staging may reduce performance.

## Fix 6 path and performance checks

Confirm the Fix6 version in the runtime log. A native session identifies
`nvof_api=D3D11 API5 ready` with `input_format=87` on the DX12 bridge;
this confirms native BGRA8 input initialization. Fix5 rejected format 28 in the
supplied log and used CUDA instead. Initialization can still fall back to
CUDA API2. DirectX 11 games retain CUDA2. Check
`handoff=gpu-fence` or `handoff=cpu-query` and the transfer mode to identify which
paths this hardware exercised. A run on one path does not validate the others.

Generated frames still use `Present(1,0)`. The real frame preserves the caller's
sync interval and flags, including valid tearing requests. Tests count accepted
Presents; they do not prove displayed output or that interpolation is uncapped.
A following interval-0 real Present may discard or shorten display of the
generated frame, so accepted counts do not establish doubled visible throughput.

Compare F11 on/off in the same scene with identical settings and display mode.
The FAST preset can affect motion quality. Inspect `performance_cpu_wall_us`:
prepare, capture, optical_flow, synthesis, generated_write, original_write,
generated_present and real_present each report calls, total_us and max_us.
These are CPU wall times including waits, not GPU durations. Prepare contains
nested stages, so do not sum stage totals.

Separately test leaving an unsupported display mode and returning to windowed/
borderless SDR. Check for renewed backend progress and no new error counters.
