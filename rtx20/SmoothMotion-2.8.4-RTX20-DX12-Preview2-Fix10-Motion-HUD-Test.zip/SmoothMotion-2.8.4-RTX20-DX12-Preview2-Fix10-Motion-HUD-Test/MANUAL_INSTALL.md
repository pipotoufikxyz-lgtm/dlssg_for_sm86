# Manual installation

Close the game and copy exactly one `Manual/` kit beside its actual x64 EXE.
`Version` contains standalone `version.dll`; `Dinput8` and `Winmm` contain their
ASI loader, INI and `new.asi`; `ASI_Only` is for an existing compatible ASI loader.
The game must load the chosen carrier before graphics creation. Never rename
the standalone proxy to another DLL name or combine it with `new.asi`.
Use the Manager to upgrade a managed installation so its ownership receipt and
uninstaller remain correct. Manual copying does not create an uninstall receipt.
See README.md for the DirectX 11 / DirectX 12 SDR requirements and F11 toggle.

For this release, confirm `2.8.4-rtx20-dx12-preview2-fix10-motion-hud-test` in the log.
Generated frames use interval 0 + DO_NOT_WAIT; real frames preserve game settings.
For the first artifact comparison keep your existing limiter/VSync settings; use borderless.
No fixed cap is added. Look for artifact_guard=occlusion_aware_v3. See FIX10_NOTES.md for the quality changes and test limits.
