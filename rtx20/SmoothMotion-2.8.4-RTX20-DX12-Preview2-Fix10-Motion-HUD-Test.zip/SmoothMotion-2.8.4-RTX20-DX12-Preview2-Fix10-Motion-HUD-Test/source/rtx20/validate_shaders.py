#!/usr/bin/env python3
"""Compile every HLSL entry to SPIR-V as a syntax check, not a DXBC/GPU test."""
import argparse,hashlib,json,pathlib,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--glslang',default='glslangValidator');a=p.parse_args()
src=pathlib.Path(__file__).resolve().parent;root=src.parents[1]
results=[]
with tempfile.TemporaryDirectory() as directory:
 for entry,stage in [('Fullscreen','vert'),('Capture','frag'),('Project','frag'),('Synthesize','frag'),('Resolve','frag')]:
  cmd=[a.glslang,'-D','-V','--auto-map-bindings','-S',stage,'-e',entry,str(src/'shaders.hlsl'),'-o',str(pathlib.Path(directory)/(entry+'.spv'))]
  result=subprocess.run(cmd,capture_output=True,text=True)
  if result.returncode:print(result.stdout,result.stderr);result.check_returncode()
  results.append({'entry':entry,'result':'PASS','output':result.stdout.strip()});print('PASS HLSL syntax:',entry,flush=True)
report={'shader_sha256':hashlib.sha256((src/'shaders.hlsl').read_bytes()).hexdigest(),'syntax_compiler':subprocess.check_output([a.glslang,'--version'],text=True).splitlines()[0]+'; HLSL -> SPIR-V syntax only, runtime uses D3DCompiler47 -> DXBC','results':results,'cuda_abi':'Inherited CUDA ABI header unchanged from supplied Fix7; previous ABI assertions not rerun','cuda_header_sha256':hashlib.sha256((src/'include/cuda.h').read_bytes()).hexdigest(),'windows_shader_execution':False,'GPU_tested':False,'validation_origin':'Fix10 motion/HUD test, current HLSL source'}
(root/'validation/shader-and-abi.json').write_text(json.dumps(report,indent=2)+'\n')
