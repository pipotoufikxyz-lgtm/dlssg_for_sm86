#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>

namespace sm20::performance {
enum class Phase { prepare, capture, optical_flow, synthesis, generated_write, original_write, generated_present, real_present, count };
struct Sample {std::atomic_ullong calls{},total_us{},max_us{};};
inline std::array<Sample,static_cast<unsigned>(Phase::count)> samples{};
inline constexpr const char* names[]={"prepare","capture","optical_flow","synthesis","generated_write","original_write","generated_present","real_present"};
struct Scope {
 using Clock=std::chrono::steady_clock;
 Phase phase;Clock::time_point start=Clock::now();
 explicit Scope(Phase p):phase(p){}
 ~Scope(){
  const auto elapsed=std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
  const auto us=static_cast<unsigned long long>(elapsed<0?0:elapsed);
  auto& s=samples[static_cast<unsigned>(phase)];s.total_us.fetch_add(us,std::memory_order_relaxed);s.calls.fetch_add(1,std::memory_order_relaxed);
  auto old=s.max_us.load(std::memory_order_relaxed);
  while(old<us&&!s.max_us.compare_exchange_weak(old,us,std::memory_order_relaxed)){}
 }
};
// Cumulative CPU wall time, including waits. These are not GPU durations or
// displayed FPS. Snapshot deltas can separate processing from Present stalls.
inline void json(char* buffer,std::size_t size){
 if(!size)return;buffer[0]=0;std::size_t used=0;
 for(unsigned i=0;i<samples.size();++i){
  const auto& s=samples[i];const int n=std::snprintf(buffer+used,size-used,
   "%s\"%s\":{\"calls\":%llu,\"total_us\":%llu,\"max_us\":%llu}",i?",":"",names[i],
   s.calls.load(std::memory_order_relaxed),s.total_us.load(std::memory_order_relaxed),s.max_us.load(std::memory_order_relaxed));
  if(n<0||static_cast<std::size_t>(n)>=size-used){buffer[0]=0;return;}used+=static_cast<std::size_t>(n);
 }
}
}
