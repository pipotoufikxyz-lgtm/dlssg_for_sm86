#pragma once
#include <cstdint>
namespace sm20 {
// Control flags and dirty/scroll updates keep their original presentation.
inline constexpr unsigned present_test=0x1, present_allow_tearing=0x200, swapchain_allow_tearing=0x800;
enum class Admission { eligible, test, partial, interval, flags, tearing_contract };
inline Admission request_admission(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) {
 if(flags&present_test)return Admission::test;
 if(partial)return Admission::partial;
 if(sync>1)return Admission::interval;
 if(flags==0)return Admission::eligible;
 if(flags!=present_allow_tearing)return Admission::flags;
 return sync==0&&windowed&&(swapFlags&swapchain_allow_tearing)?Admission::eligible:Admission::tearing_contract;
}
inline bool supported_gpu(unsigned vendor,int major,int minor) { return vendor==0x10de && major==7 && minor==5; }
inline bool supported_format(unsigned f) { return f==28 || f==29 || f==87 || f==91; }
inline bool interpolate_request(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) { return request_admission(sync,flags,partial,windowed,swapFlags)==Admission::eligible; }
inline bool fresh_history(std::uint64_t previous,std::uint64_t now) { return previous && now>=previous && now-previous<=250; }
inline unsigned grid_extent(unsigned n) { return (n+3)/4; }
inline bool dimensions(unsigned w,unsigned h) { return w>=128 && h>=128 && w<=3840 && h<=2160; }
}
