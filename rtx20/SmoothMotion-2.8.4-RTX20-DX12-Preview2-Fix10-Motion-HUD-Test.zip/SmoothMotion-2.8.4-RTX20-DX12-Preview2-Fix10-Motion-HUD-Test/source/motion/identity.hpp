#pragma once
#include <string>
#include <array>
namespace motion {
inline constexpr const char* previousRenderer="ae841953e4fd9f6a0bb21b86113d59e281cb98e46d4d6ca0d440cc7bc6b4dcbe";
inline constexpr const char* release18Renderer="eff1165d6879b60a49429bd1db0e1adda26943bcfdbc2f1697deb247b7cd4c31";
inline constexpr const char* release181Renderer="0c57d44b4eb146b26b8f814393b2500f4a0db73936a25e3fe474116a54f376e0";
inline constexpr const char* release20Renderer="d963f23df32284b03b9c1df6839521af5622f009c927b62b2f75f30a12784945";
inline constexpr const char* release21Native="db1160a758bd58f31330ea4367c19fa5422a48ff90cde7f29b5808d0c95caf9a";
inline constexpr const char* release22Native="cff02eb3ebf876bf6fa4c0bb5c4d9e822a178b30945994726a03adefe7db674d";
inline constexpr const char* release23Native="eba6ed18950b284856e60279c7539bb302031f30fa7023dd2d71b4cd20450fc6";
inline constexpr const char* release24Native="773bdc882f6376d7ccd6b2f7f537d48562a0ba878e82aafd0766c0ad0b4effc8";
inline constexpr const char* release25Native="4b6c23341e73dac153271caff46a55553423c317befefb29d8af1a63a9e58155";
inline constexpr const char* release26Native="5df6064aa7253a98f0dd0b80dcbbbb0bce5ac2f0c6d1ddcb237bb9d0ba46eed5";
// Pinned to released 2.7 archive bytes, never to a subsequently rebuilt DLL.
inline constexpr const char* release27Native="e6b822c18c60368a736e8b94cf6ff6b5d2127adb8ced933a03a3523d63ee6e2b";
inline constexpr const char* release27NativeProxy="0b34907a5c5c134f27047dc4d7ebb06a2b2eab3fbaea2a178c4762ff33a0826c";
// Released 2.8 package identities; diagnostic rebuilds must not replace these.
inline constexpr const char* release28Native="36dd40e72c6cb3f341dd305b83d4e01f4234149ba8b485b365de4fa753d5671f";
inline constexpr const char* release28NativeProxy="d807037caac7a2a47a3c8a6a8c2573f0226f9d54771027987c13d42178bdd83f";
// Pinned to SmoothMotion-2.8.1-Init-Diagnostics.zip (996352 / 1002496 bytes).
inline constexpr const char* release281Native="9e46f6805dc8c83faa857dc7294f31359f5e93a6656ebd7dae9375627fcd512b";
inline constexpr const char* release281NativeProxy="ce58ca02f57f56667bfcacbdb5c96767c63dee7a235204231f5cecb0968fba42";
// Exact published builds; migration identities are independent of current builds.
inline constexpr const char* release282Native="c0ca52ec257c2f0cd83a90737d89cd5b84879c27e0be507d097ded972c127a2d";
inline constexpr const char* release282NativeProxy="1295eba2e2d7097c1d88254d23f29e1de359c07ad9728c52464bb685b2925e00";
inline constexpr const char* release283Native="bd537feb8211eebe7b9e61b2b50fb35bdc6ea1d702ce98f29dbf298136e21602";
inline constexpr const char* release283NativeProxy="8098ad9ed661102e9d18accf937bfa71b3f4f5ce8dfcc537ef700b161ef82cc2";
inline constexpr const char* release282R1Native="3c6acfa78bf89b25c3380b237457cb910f8c5fff6670555ceae1512db1b344c6";
inline constexpr const char* release282R1NativeProxy="c326985f77a8b285b85711eb7ce7bd52649347c699fffe41211d47225a393eea";
inline constexpr const char* release282R2Native="48f46f5dfdea06448f48d573b7b6504d55c15852dde7775a64a1db2a13ac3c2f";
inline constexpr const char* release282R2NativeProxy="0911a9f146db1589f4c95817420c17088e94b8ff2d294cb4ddd4b811bc98b3d1";
inline constexpr const char* release30Native="eaf72ea43d0423516618d85b86448710a4283d026640f5a05a8202aba9bc52c5";
inline constexpr const char* release30NativeProxy="a2856f98ec0d0dea4cf5e3ed46b924130052e178aa7d20c23dd2804ce673b123";
// Pinned to the attached R3 and previously delivered R4 archives.
inline constexpr const char* release282R3Native="cdc3bff71825660dce7516b7e762590f905ec2a99ccd6a40723a6da3ddd38f48";
inline constexpr const char* release282R3NativeProxy="3e31f50f36f3d3e63ccda9a91b5f7cff720a68a3584efed39a79b52c86f237d4";
inline constexpr const char* release282R4Native="e0fd56279c24a65999fe79fa5388d1388e31efd5685f11f4903195b814bb6485";
inline constexpr const char* release282R4NativeProxy="b75bdff67af524956d81f9b91e7177e9be6a693ec29294a8783c42acb6b915d0";
// Exact GP1 bytes also shipped unchanged in the confirmed GP2 package.
inline constexpr const char* release282GP1Native="b7f55fda312ff8a5d0e5b96f257359fccf5c493247037b409ffe9b07051d2ad1";
inline constexpr const char* release282GP1NativeProxy="d7dedce171e8a630f6bb7ea7583507c3395b92b487100ded144fe072542c8da2";
// Exact GP3 bytes confirmed by the attached Dead Space diagnostic report.
inline constexpr const char* release282GP3Native="b3b14b3c29ccfc959976e3fca683b799e3aed308d0cb9e58704bb89bb8ba4804";
inline constexpr const char* release282GP3NativeProxy="383d729b667f560449c4345b25380dad58f15cdd51aba14988790b6a73eaf0f9";
// Exact GP4 runtime files from the follow-up Dead Space report.
inline constexpr const char* release282GP4Native="cd302f788de970116706110d94210c8317bad80b7993c9cc6543bd34e1f3b74e";
inline constexpr const char* release282GP4NativeProxy="6ef9da2203858d39b22d45bf385fd13f866d5b34dbc78c0c1328d6f2f023d89a";
// Exact GP5 bytes from the 18:54 follow-up report and published package.
inline constexpr const char* release282GP5Native="2b90132535dc3a499a23c1388f9a12664fa64e771b3ad988d65e2150f55c04dc";
inline constexpr const char* release282GP5NativeProxy="6c369e425355de7e86815d18c832538b08ccdf7716955a5fa9b4cc7a2fc94d42";
// Exact GP6 artifacts; the user confirmed this build works in Dead Space.
inline constexpr const char* release282GP6Native="faf52de694d82af0948b1d5eb53840d631969cc4511335f20308b8e7595faa73";
inline constexpr const char* release282GP6NativeProxy="9b8fd46b661fc025a2be8d08a6876acd1604feca54d31ef13ac540d6183c503b";
// Exact GP7 runtime bytes were also shipped unchanged in GP8.
inline constexpr const char* release282GP7Native="367fa8f41530a1d28c354ddd7c5cbc2be7e3918a14bba995bf7870d1d76d0c37";
inline constexpr const char* release282GP7NativeProxy="61b17dbd09743bfd0eb8064fa40d8d652167ad006343ec3ecb4f28e00fd1813c";
inline constexpr const char* release282GP9Native="4d777ac3baf473376fec1e91ce23d876f3ca540a79ad6032586e96ea6a81cdd3";
inline constexpr const char* release282GP9NativeProxy="d91177e7bb52eba8dc96e2fbb8b93a475939a145c37dbd4cbc0e4ae704dffa61";
inline constexpr const char* release282GP9Fixes1Native="f36d34ce22f4ee7e74aa78c149458c9e9c089db2a653339bae802cae99e434de";
inline constexpr const char* release282GP9Fixes1NativeProxy="3b9ebeb3d0944a8233671eb19ed61f2e08011b89829d2c13397fae66dcd82305";
// Exact RTX20 Preview 1 release bytes for in-place upgrades.
inline constexpr const char* releaseRTX20Preview1Native="1c4d27d7bcc0f98b86bedf0a51cc537cce6fb1768ba7e4daa0c84467b7512257";
inline constexpr const char* releaseRTX20Preview1NativeProxy="4055e5efcefdce19790c67352ee78c94c2685faeee9427c07694cbe15801e774";
// Exact RTX20 DX12 Preview 2 release bytes (Blackwood report install).
inline constexpr const char* releaseRTX20Preview2Native="7d7b5164b05660232821e8f20929142b60862beab3acf2e82132c527860968a1";
inline constexpr const char* releaseRTX20Preview2NativeProxy="3a102c6eb3afd681d23739c55f14424f97873fb626a1698fb7c94c8396aadd32";
// Exact supplied RTX20 DX12 Preview 2 Fix 1 bytes for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix1Native="f2072d783d0dafcc8a1e5556e9a38cd2d008cce6091eafd7b275df70f48b8534";
inline constexpr const char* releaseRTX20Preview2Fix1NativeProxy="af9b06093599564749fb961e90bd97a2c456b81af4f922dbb7bcfd3647dc9eda";
// Exact RTX20 DX12 Preview 2 Fix 2 bytes for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix2Native="1065e55edc3ec7233978c40ef5441e1b4e3cf562c3cd5e1f3876dd237f1f829b";
inline constexpr const char* releaseRTX20Preview2Fix2NativeProxy="d9dff76a12ac14d5b5f1e4b33725b55c836e3ba04e7d17e032659de81b601f47";
// Exact attached RTX20 DX12 Preview 2 Fix 3 binaries for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix3Native="7736b15b1d12de189085576f9c480084dfc3ab5bb65545c057885c0852e0a2f6";
inline constexpr const char* releaseRTX20Preview2Fix3NativeProxy="0ce394ae84725f15f039875b9b1a273aeabb6ba1566602744874352d50c0dca8";
// Exact released RTX20 DX12 Preview 2 Fix 4 binaries for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix4Native="e50cc4dbe4befcaa1d52425e437aff2dc106cee4e5f230460159ccc4bc8c8aa9";
inline constexpr const char* releaseRTX20Preview2Fix4NativeProxy="c13e3a0310eea77625a0f2f8d94cb2897c0de7b125df5facc5bdaa23b69b77a6";
// Exact released RTX20 DX12 Preview 2 Fix 5 binaries, verified against its ZIP.
inline constexpr const char* releaseRTX20Preview2Fix5Native="b255dc9bbe0bd9d3be05e796c1e841cab834f78bbc079c3c3269c34ba85c5edd";
inline constexpr const char* releaseRTX20Preview2Fix5NativeProxy="6888fdc0036ef53eb7943ece9173cbdd661aa0152b700c3aa289e9d457494c91";
// Exact attached Fix6 bytes, retained for managed upgrade ownership.
inline constexpr const char* releaseRTX20Preview2Fix6Native="724981df1f826c704ca28e2d6beb6c0d494870fe637afc28fe6786d5ad07447b";
inline constexpr const char* releaseRTX20Preview2Fix6NativeProxy="5d7ba2fa5a2457bc1fa594633d1564404df94c721766c22ece72d67abf600b67";
// Exact attached Fix7 bytes retained for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix7Native="2b562de242efcfdbf6509986be920e22f16172af28015ae48c08ecdc4d433b50";
inline constexpr const char* releaseRTX20Preview2Fix7NativeProxy="851d450c191f2aff13c9c6bdc4e338f66a7bcf2205e3c67e323f6ba5bab8996a";
// Exact attached Fix8 bytes retained for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix8Native="7af847b99eabc0a716d014e4a256458355e487ebcb4adc4a19b91daa9fd34b3e";
inline constexpr const char* releaseRTX20Preview2Fix8NativeProxy="2e8e8b89029ede5bfc42bf5e25133dc0b8e412b17fd9d92e05d6cc1cdbd964da";
// Exact attached Fix9 bytes retained for managed upgrades.
inline constexpr const char* releaseRTX20Preview2Fix9Native="fdd09fad6377e6a36e4ab02d71deb3ff5117fae2352389839d03eb3b15e987d2";
inline constexpr const char* releaseRTX20Preview2Fix9NativeProxy="db9c51e8a209b65331fa971b973c18b73908507df5b160b01c84c96d4037d590";
inline constexpr std::array<const char*,29> previousNativeProxies{{releaseRTX20Preview2Fix9NativeProxy,releaseRTX20Preview2Fix8NativeProxy,releaseRTX20Preview2Fix7NativeProxy,releaseRTX20Preview2Fix6NativeProxy,releaseRTX20Preview2Fix5NativeProxy,releaseRTX20Preview2Fix4NativeProxy,releaseRTX20Preview2Fix3NativeProxy,releaseRTX20Preview2Fix2NativeProxy,releaseRTX20Preview2Fix1NativeProxy,releaseRTX20Preview2NativeProxy,releaseRTX20Preview1NativeProxy,release282GP9Fixes1NativeProxy,release282GP9NativeProxy,release282GP7NativeProxy,release282GP6NativeProxy,release282GP5NativeProxy,release282GP4NativeProxy,release282GP3NativeProxy,release282GP1NativeProxy,release282R3NativeProxy,release282R4NativeProxy,release282NativeProxy,release283NativeProxy,release282R1NativeProxy,release282R2NativeProxy,release30NativeProxy,release27NativeProxy,release28NativeProxy,release281NativeProxy}};
inline constexpr std::array<const char*,39> previousPlugins{{releaseRTX20Preview2Fix9Native,releaseRTX20Preview2Fix8Native,releaseRTX20Preview2Fix7Native,releaseRTX20Preview2Fix6Native,releaseRTX20Preview2Fix5Native,releaseRTX20Preview2Fix4Native,releaseRTX20Preview2Fix3Native,releaseRTX20Preview2Fix2Native,releaseRTX20Preview2Fix1Native,releaseRTX20Preview2Native,releaseRTX20Preview1Native,release282GP9Fixes1Native,release282GP9Native,release282GP7Native,release282GP6Native,release282GP5Native,release282GP4Native,release282GP3Native,release282GP1Native,release282R3Native,release282R4Native,release282Native,release283Native,release282R1Native,release282R2Native,release30Native,previousRenderer,release18Renderer,release181Renderer,release20Renderer,release21Native,release22Native,release23Native,release24Native,release25Native,release26Native,release27Native,release28Native,release281Native}};
inline bool ownedPlugin(const std::string& hash,const std::string& current){
 if(hash.empty())return false;if(hash==current)return true;
 for(const auto* previous:previousPlugins)if(hash==previous)return true;return false;
}
// The Manager and installer draw ownership from the same list.
template<class Match> inline bool installedPlugin(const char* current,const char* upstream,Match&& match){
 if(match(current)||match(upstream))return true;
 for(const auto* previous:previousPlugins)if(match(previous))return true;return false;
}
inline bool ownedNativeProxy(const std::string& hash,const std::string& current){
 if(hash.empty()||hash=="-")return false;if(hash==current)return true;
 for(const auto* previous:previousNativeProxies)if(hash==previous)return true;return false;
}
template<class Match> inline bool installedNativeProxy(const char* current,const char* legacy,Match&& match){
 if(match(current)||match(legacy))return true;
 for(const auto* previous:previousNativeProxies)if(match(previous))return true;return false;
}

}
