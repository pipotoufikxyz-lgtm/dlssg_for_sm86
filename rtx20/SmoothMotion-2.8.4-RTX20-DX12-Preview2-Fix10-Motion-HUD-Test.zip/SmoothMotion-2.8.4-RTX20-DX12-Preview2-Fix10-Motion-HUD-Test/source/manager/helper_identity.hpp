#pragma once
namespace helper_identity {
inline constexpr char installer[]="94c2468fbde2d3fd89733726eefde72357f5cfe97c7061a10647dcf3bb4f8e92";
inline constexpr char collector[]="a7770223f9e513add51821c95b999fab16f92500dbb70cc73728ed152262790a";
}
