#pragma once
namespace helper_identity {
inline constexpr char installer[]="e2ee72f03ce4f6e473bcdec9174ea8513e64e096aec80eb8fda53a2767e0cb30";
inline constexpr char collector[]="80a59deb4f5949a646230f6046aaad2a80285a0c39615098966caa668a1f6447";
}
