# SmoothMotion 2.8.4 RTX20 Fix 13 — pacing and performance test

Fix13 makes generated frames count on screen. The generated frame and the
real frame after it are shown on consecutive refreshes instead of back to
back. Generation pauses while the game already reaches the display refresh
rate. The synthesis shader does about 35% less texture work per pixel. Fix12
quality, Fix11 half-resolution flow and Fix10 fast-pan/HUD changes are
included.

Read `FIX13_NOTES.md` for the diagnosis, settings (`Pacing`,
`GenerateAboveRefresh`) and limits. `FIX12_NOTES.md` covers the quality
changes; `FIX11_NOTES.md` explains adaptive half-resolution flow and the
optional `nvsmooth30.ini`.
Host shader tests pass, but Windows/GPU execution, in-game image quality and
performance still need verification on your PC.

This is Turing hardware optical flow with custom frame synthesis. NVIDIA's
proprietary Smooth Motion neural model has not been ported. The package contains
Windows x64 ASI/proxy binaries, Manager, installer, tests, source and symbols.

## Install and check

1. Extract the complete ZIP into a new folder and close the game.
2. For a managed installation, run `SmoothMotion_Manager.exe` and upgrade the
   same game EXE and install route. For an existing manual ASI installation,
   replace `new.asi` with `Manual/ASI_Only/new.asi` and keep the existing loader.
   Standalone installations use `Manual/Version/version.dll`. Choose one route.
3. Use DirectX 11 or DirectX 12, windowed/borderless SDR, HDR off, and in-game
   frame generation off. For uncapped testing remove the external limiter and
   disable in-game/driver VSync. Engine locks are not removed. F11 toggles interpolation.
4. Confirm `2.8.4-rtx20-dx12-preview2-fix13-pacing-test`,
   `artifact_guard=occlusion_aware_v4` and a `presentation=` line in `nvsmooth30.log`. Compare F11 on/off
   in the same scene, resolution, graphics settings and limiter configuration.
5. Run `Test/RTX20_DX12_SmokeTest.exe` for its 24-second resize/queue test. Leave
   interpolation enabled. Read `Test/rtx20-dx12-test-report.txt`; backend-counter
   PASS is separate from displayed-frame and performance validation.

The Manager recognizes exact released Preview 1, Preview 2, Fix 1–12 and GP9
Fixes1 binaries. Managed upgrades preserve ownership, backup and uninstall
receipts. Manual copying does not update those receipts.

## Supported scope

| Item | Scope |
|---|---|
| GPU | NVIDIA Turing SM75 on the game's adapter; RTX 2060/2070/2080 families |
| OS/API | Windows 10/11 x64; DirectX 11 or DirectX 12 |
| Optical flow | DX11 and DX12 bridge: D3D11 NVOF API5 preferred, CUDA2 initialization fallback |
| Display | Windowed/borderless SDR, RGBA8/BGRA8, single-sample backbuffer |
| Dimensions | 128–3840 wide, 128–2160 high, subject to driver capabilities |
| DX12 queue | Exact DIRECT presentation queue, one GPU node, same adapter |
| DX12 swapchain | Flip model, 2–16 buffers; query the current buffer for every copy |
| Pacing | Below the refresh rate: generated and real Present both use interval 1 (one refresh each, game held at half the refresh rate). At or above it: generation pauses. `Pacing=off`: generated interval 0 + DO_NOT_WAIT, real Present preserves caller parameters |
| Tearing | Only valid interval-0, windowed ALLOW_TEARING requests are admitted |
| Unsupported | Vulkan, OpenGL, HDR/10-bit/float, exclusive fullscreen, MSAA, partial/scroll presents, protected content, multiple presentation queues/GPU nodes |
| Validation | Fix13 Windows/GPU execution, displayed output and performance remain unverified |

No CUDA toolkit or Optical Flow SDK installation is required on the game PC.
The runtime loads its NVIDIA and shader-compiler DLLs from System32 and does
not patch or replace driver files. Unsupported modes keep normal presentation;
returning to a supported mode can initialize interpolation again. If submitted
GPU completion is uncertain, the affected session is retained and permanently
disabled. A device-reset result prevents unsafe game-buffer reuse when transfer
completion is uncertain.

## Transfer and optical flow

DX12 presentation is captured on its actual queue. A native D3D11 device uses
the same adapter and exchanges images through shared textures. When sharing
is unavailable, a CPU readback/upload path remains available. The log identifies
`mode=shared-texture` or `mode=cpu-staging`; staging may be slower.

Where supported, shared D3D11/D3D12 fences order transfer work on the GPU
(`handoff=gpu-fence`). Otherwise the bounded CPU completion path remains
(`handoff=cpu-query`). GPU handoff does not remove all CPU waits or guarantee
an increase in FPS. Reset and resource reuse still require safe completion.

For DX11 games and the DX12 bridge, the native optical-flow path registers private D3D11 textures directly and
requests both flow directions in one NVOF execution. It avoids the CUDA frame
copies, graphics map/unmap and context synchronization used by the fallback.
The CUDA API 2 headers and the matched D3D11 API 5 headers remain isolated.

The midpoint is written to the current backbuffer. After its extra Present,
the backend queries the new buffer index and restores the saved real frame.
Game buffers return to PRESENT; shared textures return to COMMON. CPU staging
uses fixed readback/upload heap states and a separate saved-original buffer.

Games that assume one buffer advance per game frame, pre-record future
backbuffer work, or depend on Present returning for GPU progress may still be
incompatible. Synthesis has no game motion vectors, depth or HUD mask; cuts,
UI, disocclusions, fast motion and transparency can show artifacts.

## Read the log

- `nvof_api=D3D11 API5 ready` with `input_format=87` identifies successful
  native initialization with BGRA8 input. Initialization failure
  can select the CUDA API 2 path; use its log line to identify the actual route.
- `dx12_sessions`, `dx12_captures`, `dx12_writes`, and `flow_pairs` describe
  backend activity, not physical display output.
- `generated_present_accepted` and `real_present_accepted` count successful
  submissions. Their deltas per second are accepted Present rates, not proof
  of displayed FPS or unique visible frames.
- `dx12_transfer_failures`, `rtx20_failures`, `present_skips`, and the exact API
  error lines identify failures and pass-through reasons.
- `performance_cpu_wall_us` reports cumulative `calls`, `total_us`, `max_us`
  for prepare, capture, optical_flow, synthesis, generated_write, original_write,
  generated_present and real_present. These are CPU wall times including waits;
  prepare contains nested phases, so do not add them together as total time.
- `generated_present_queue_busy` counts skipped synthetic submissions under
  queue pressure. These are not accepted generated frames.
- `presentation=paced|immediate|paused` lines, `paced_pairs` and
  `generation_paused_frames` show how generated frames were presented, and
  how many real frames ran without generation because the game already
  reached the refresh rate.
- `interpolation_verified` remains false; counters do not measure display output.

`Test/ShaderCheck.exe` checks runtime shader compilation. `Test/RTX20_SmokeTest.exe`
checks DX11. `Test/RTX20_TransferTest.exe` checks CPU-staging pixels without NVOF.
`Test/Test_DX12_Staging.cmd` forces staging for the full DX12 check.
For diagnostics, run `Collect_Diagnostics.exe` for the same game EXE. Nothing
is uploaded automatically. See VALIDATION.md, BUILD.md and Test/README.md.
