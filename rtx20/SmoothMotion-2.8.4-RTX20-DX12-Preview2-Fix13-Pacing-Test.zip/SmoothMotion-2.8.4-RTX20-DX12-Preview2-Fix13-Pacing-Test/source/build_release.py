#!/usr/bin/env python3
"""Build and verify the complete RTX20 DX12 Preview 2 Fix 13 Pacing Test release."""
import argparse,pathlib,subprocess,sys,shutil
import build_toolchain
r=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();build_toolchain.arguments(p);p.add_argument('--glslang',default='glslangValidator');p.add_argument('--ubsan-only',action='store_true');a=p.parse_args();compiler_args=build_toolchain.forwarded(a)
def run(script,*args):subprocess.run([sys.executable,str(r/script),*map(str,args)],cwd=r,check=True)
run('source/rtx20/validate_shaders.py','--glslang',a.glslang)
run('source/rtx20/build.py',*compiler_args)
run('source/diagnostic/build.py',*compiler_args);shutil.copy2(r/'source/diagnostic/Collect_Diagnostics.exe',r/'Collect_Diagnostics.exe')
run('source/setup/build.py',*compiler_args,'--package-root',r)
run('source/manager/build.py',*compiler_args,'--package-root',r)
(r/'Test').mkdir(exist_ok=True)
for source,name,libraries in [('smoke_test.cpp','RTX20_SmokeTest.exe',['-ld3d11','-ldxgi','-ldxguid','-luser32']),('shader_check.cpp','ShaderCheck.exe',[]),('dx12_smoke_test.cpp','RTX20_DX12_SmokeTest.exe',['-ld3d12','-ldxgi','-ldxguid','-luser32'])]:
 subprocess.run([*build_toolchain.command(a,r/'Test'/name),'-std=c++20','-O2','-static','-DUNICODE','-D_UNICODE',str(r/'source/rtx20'/source),*libraries,'-o',str(r/'Test'/name)],check=True)
subprocess.run([*build_toolchain.command(a,r/'Test/RTX20_TransferTest.exe'),'-std=c++20','-O2','-static','-DUNICODE','-D_UNICODE','-DWIN32_LEAN_AND_MEAN','-DNOMINMAX',
 '-I'+str(r/'source/native/include'),str(r/'source/rtx20/transfer_smoke_test.cpp'),str(r/'source/rtx20/dx12_transfer.cpp'),
 '-ld3d11','-ld3d12','-ldxgi','-ldxguid','-luser32','-o',str(r/'Test/RTX20_TransferTest.exe')],check=True)
run('source/stage_manual.py');run('source/rtx20/test_shader.py');run('source/rtx20/test.py',*(['--ubsan-only'] if a.ubsan_only else []));run('source/rtx20/verify.py')
