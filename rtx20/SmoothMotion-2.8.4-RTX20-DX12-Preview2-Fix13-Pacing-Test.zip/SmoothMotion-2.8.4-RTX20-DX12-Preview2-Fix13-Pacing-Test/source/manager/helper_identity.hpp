#pragma once
namespace helper_identity {
inline constexpr char installer[]="1be4809b41c3b85d6189afe59aaafc16b099738313c78ad099382e8cbd97057b";
inline constexpr char collector[]="38dd04dc74933d06d755e96dedc6a0617774a95c8292b06c657fc20c31e2384a";
}
