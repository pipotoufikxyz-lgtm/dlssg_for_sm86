#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>

namespace sm20::performance {
enum class Phase { prepare, capture, optical_flow, synthesis, generated_write, original_write, generated_present, real_present, count };
struct Sample {std::atomic_ullong calls{},total_us{},max_us{};};
inline std::array<Sample,static_cast<unsigned>(Phase::count)> samples{};
inline constexpr const char* names[]={"prepare","capture","optical_flow","synthesis","generated_write","original_write","generated_present","real_present"};
struct Scope {
 using Clock=std::chrono::steady_clock;
 Phase phase;Clock::time_point start=Clock::now();
 explicit Scope(Phase p):phase(p){}
 ~Scope(){
  const auto elapsed=std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
  const auto us=static_cast<unsigned long long>(elapsed<0?0:elapsed);
  auto& s=samples[static_cast<unsigned>(phase)];s.total_us.fetch_add(us,std::memory_order_relaxed);s.calls.fetch_add(1,std::memory_order_relaxed);
  auto old=s.max_us.load(std::memory_order_relaxed);
  while(old<us&&!s.max_us.compare_exchange_weak(old,us,std::memory_order_relaxed)){}
 }
};
// GPU durations from D3D11 timestamp queries, read back a few frames later
// without stalling. Stages: capture (+ half-resolution copy), optical flow,
// synthesis (projection, synthesis and resolve). Also counts pairs per flow
// resolution so logs show which mode produced the timings.
enum class GpuPhase { capture, optical_flow, synthesis, count };
inline std::array<Sample,static_cast<unsigned>(GpuPhase::count)> gpu_samples{};
inline constexpr const char* gpu_names[]={"capture","optical_flow","synthesis"};
inline std::atomic_ullong full_flow_pairs{},half_flow_pairs{};
inline void add_gpu(GpuPhase phase,unsigned long long us){
 auto& s=gpu_samples[static_cast<unsigned>(phase)];s.total_us.fetch_add(us,std::memory_order_relaxed);s.calls.fetch_add(1,std::memory_order_relaxed);
 auto old=s.max_us.load(std::memory_order_relaxed);
 while(old<us&&!s.max_us.compare_exchange_weak(old,us,std::memory_order_relaxed)){}
}
// Generated/real pairs presented on consecutive refreshes, frames where
// generation was paused because the real rate already reached the display
// refresh, and whether paired-refresh pacing is configured.
inline std::atomic_ullong paced_pairs{},paused_frames{};
inline std::atomic_bool pacing_enabled{true};
inline void gpu_json(char* buffer,std::size_t size){
 if(!size)return;buffer[0]=0;std::size_t used=0;
 for(unsigned i=0;i<gpu_samples.size();++i){
  const auto& s=gpu_samples[i];const int n=std::snprintf(buffer+used,size-used,
   "\"%s\":{\"calls\":%llu,\"total_us\":%llu,\"max_us\":%llu},",gpu_names[i],
   s.calls.load(std::memory_order_relaxed),s.total_us.load(std::memory_order_relaxed),s.max_us.load(std::memory_order_relaxed));
  if(n<0||static_cast<std::size_t>(n)>=size-used){buffer[0]=0;return;}used+=static_cast<std::size_t>(n);
 }
 const int n=std::snprintf(buffer+used,size-used,"\"flow_pairs_full\":%llu,\"flow_pairs_half\":%llu},\"pacing_enabled\":%s,\"paced_pairs\":%llu,\"generation_paused_frames\":%llu",
  full_flow_pairs.load(std::memory_order_relaxed),half_flow_pairs.load(std::memory_order_relaxed),pacing_enabled.load()?"true":"false",
  paced_pairs.load(std::memory_order_relaxed),paused_frames.load(std::memory_order_relaxed));
 if(n<0||static_cast<std::size_t>(n)>=size-used)buffer[0]=0;
}
// Cumulative CPU wall time, including waits. These are not GPU durations or
// displayed FPS. Snapshot deltas can separate processing from Present stalls.
inline void json(char* buffer,std::size_t size){
 if(!size)return;buffer[0]=0;std::size_t used=0;
 for(unsigned i=0;i<samples.size();++i){
  const auto& s=samples[i];const int n=std::snprintf(buffer+used,size-used,
   "%s\"%s\":{\"calls\":%llu,\"total_us\":%llu,\"max_us\":%llu}",i?",":"",names[i],
   s.calls.load(std::memory_order_relaxed),s.total_us.load(std::memory_order_relaxed),s.max_us.load(std::memory_order_relaxed));
  if(n<0||static_cast<std::size_t>(n)>=size-used){buffer[0]=0;return;}used+=static_cast<std::size_t>(n);
 }
}
}
