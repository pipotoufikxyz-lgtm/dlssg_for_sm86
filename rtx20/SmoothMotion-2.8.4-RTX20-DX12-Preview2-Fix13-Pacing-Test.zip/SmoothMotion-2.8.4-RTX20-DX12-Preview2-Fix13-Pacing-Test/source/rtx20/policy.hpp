#pragma once
#include <algorithm>
#include <cstdint>
namespace sm20 {
// Control flags and dirty/scroll updates keep their original presentation.
inline constexpr unsigned present_test=0x1, present_allow_tearing=0x200, swapchain_allow_tearing=0x800;
enum class Admission { eligible, test, partial, interval, flags, tearing_contract };
inline Admission request_admission(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) {
 if(flags&present_test)return Admission::test;
 if(partial)return Admission::partial;
 if(sync>1)return Admission::interval;
 if(flags==0)return Admission::eligible;
 if(flags!=present_allow_tearing)return Admission::flags;
 return sync==0&&windowed&&(swapFlags&swapchain_allow_tearing)?Admission::eligible:Admission::tearing_contract;
}
inline bool supported_gpu(unsigned vendor,int major,int minor) { return vendor==0x10de && major==7 && minor==5; }
inline bool supported_format(unsigned f) { return f==28 || f==29 || f==87 || f==91; }
inline bool interpolate_request(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) { return request_admission(sync,flags,partial,windowed,swapFlags)==Admission::eligible; }
inline bool fresh_history(std::uint64_t previous,std::uint64_t now) { return previous && now>=previous && now-previous<=250; }
inline unsigned grid_extent(unsigned n) { return (n+3)/4; }
inline bool dimensions(unsigned w,unsigned h) { return w>=128 && h>=128 && w<=3840 && h<=2160; }
// Optical-flow resolution. Full-resolution NVOF (4-pixel cells) preserves thin
// detail; half resolution (8-pixel cells) costs about a quarter of the flow
// GPU time. Automatic mode uses half resolution only when the real frame rate
// is already high: motion per frame is then small and GPU time decides the
// generated frame rate. Hysteresis avoids switching back and forth.
enum class FlowResolution { automatic, full, half };
inline FlowResolution parse_flow_resolution(const wchar_t* value) {
 if(!value)return FlowResolution::automatic;
 auto same=[&](const wchar_t* word){const wchar_t* a=value;const wchar_t* b=word;
  for(;*a&&*b;++a,++b){wchar_t c=*a;if(c>=L'A'&&c<=L'Z')c=wchar_t(c-L'A'+L'a');if(c!=*b)return false;}return !*a&&!*b;};
 if(same(L"full"))return FlowResolution::full;
 if(same(L"half"))return FlowResolution::half;
 return FlowResolution::automatic;
}
inline constexpr double half_flow_enter_fps=58, half_flow_leave_fps=45;
inline bool use_half_flow(FlowResolution setting,bool available,bool current,double realFps) {
 if(!available||setting==FlowResolution::full)return false;
 if(setting==FlowResolution::half)return true;
 return realFps>=(current?half_flow_leave_fps:half_flow_enter_fps);
}
// Exponential average of the real frame interval; gaps longer than the
// history window (pauses, F11, loading) restart the measurement.
inline double update_frame_interval(double average,double seconds) {
 if(!(seconds>0)||seconds>0.25)return 0;
 return average>0?average+(seconds-average)*0.1:seconds;
}
// Generated frames beyond the display refresh rate are never shown: they only
// add tearing, latency and GPU load. While generating, the measured real
// rate already includes generation cost; pause once it reaches the refresh
// rate, and resume only when the native rate drops clearly below it.
inline bool generation_useful(bool generating,double realFps,double refreshHz) {
 if(!(refreshHz>1)||!(realFps>0))return true;
 return realFps<refreshHz*(generating?1.02:0.9);
}
// Presentation of generated frames. Both frames of a pair are submitted from
// the game's Present, so the GPU completes them back to back: presented
// immediately, the generated frame is replaced within about a millisecond
// (or dropped by composition) and motion does not look smoother. Paced mode
// presents both with sync interval 1, so the generated frame occupies one
// refresh and the real frame the next; the game then runs at half the
// refresh rate with even motion at the full rate.
//   measuring: generate unpaced for ~0.75 s to measure the real rate;
//   paced:     generate, both frames on consecutive refreshes;
//   immediate: generate unpaced (Pacing=off);
//   paused:    real rate already at/above refresh, generated frames would
//              not be visible; resume (via measuring) below 90% of refresh.
enum class Presentation { measuring, paced, immediate, paused };
struct PresentationPolicy {
 bool pacing{true},generateAboveRefresh{};double refreshHz{};
 Presentation state{Presentation::measuring};
 double measureStart{-1};unsigned measureFrames{};
 void reset(){state=Presentation::measuring;measureStart=-1;measureFrames=0;}
 // Once per real frame; realFps is the running average of the real rate.
 Presentation update(double now,double realFps){
  const bool visible=generateAboveRefresh||generation_useful(state!=Presentation::paused,realFps,refreshHz);
  switch(state){
   case Presentation::measuring:
    if(measureStart<0){measureStart=now;measureFrames=0;}
    if(++measureFrames>=20&&now-measureStart>=0.75){
     measureStart=-1;
     state=!visible?Presentation::paused:pacing?Presentation::paced:Presentation::immediate;
    }
    break;
   case Presentation::immediate:
    if(!visible)state=Presentation::paused;
    break;
   case Presentation::paused:
    if(visible)reset();
    break;
   case Presentation::paced:
    break;
  }
  return state;
 }
 bool generating() const {return state!=Presentation::paused;}
 bool paced() const {return state==Presentation::paced;}
};
}
