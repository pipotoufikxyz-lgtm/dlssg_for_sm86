#pragma once
#include "nvs30/common.hpp"
#include <memory>
namespace sm20 {
bool load_runtime();
const char* runtime_status();
extern std::atomic_ullong flow_pairs,generated_submissions,real_submissions,failures;
class Interpolator {
 struct Impl; std::unique_ptr<Impl> impl_;
 bool failed_{},retryBlocked_{};
 HRESULT terminal_{};
 bool write(IDXGISwapChain*,bool generated);
public:
 Interpolator(); ~Interpolator();
 Interpolator(const Interpolator&)=delete;
 // DX12 requires the exact presentation queue captured at creation/resize.
 bool prepare(IDXGISwapChain* swap,ID3D12CommandQueue* queue=nullptr);
 HRESULT terminal_error()const{return terminal_;}
 bool write_generated(IDXGISwapChain* swap);
 bool write_original(IDXGISwapChain* swap);
 void accepted();
 void discard_history();
 void reset(bool retry=true);
 bool ready() const;
 // Present the generated/real pair on consecutive refreshes (sync interval 1).
 bool paced() const;
};
}
