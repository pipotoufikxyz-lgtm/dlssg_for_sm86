#pragma once
namespace helper_identity {
inline constexpr char installer[]="a61783cb94905c8e41584c6c8b4427f9418d7efd46991ba9df3d19dfca0da540";
inline constexpr char collector[]="ea1c5d531b7509273565ad48317a4b4f0a877f0ca48e5ebb18108f9bbb30b5cf";
}
