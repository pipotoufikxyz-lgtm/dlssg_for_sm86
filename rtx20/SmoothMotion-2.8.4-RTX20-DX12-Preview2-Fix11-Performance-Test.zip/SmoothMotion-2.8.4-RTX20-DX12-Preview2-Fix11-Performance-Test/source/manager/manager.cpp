#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <d2d1.h>
#include <dwrite.h>
#include <dwmapi.h>
#include <functional>
#include <thread>
#include <cstdio>
#include "core.hpp"
#include "../ui/file_picker.hpp"
#include "artwork.hpp"
#include "selection.hpp"
#include "startup_log.hpp"
#include "../ui/native_glass.hpp"
#include "../setup/protocol.hpp"
#include "../setup/install_modes.hpp"
#include "../normal_policy.hpp"
#include "../ui/themes.hpp"
#include "../ui/localization.hpp"
namespace {
namespace language=manager_localization;
template<class T>void release(T*& p){if(p){p->Release();p=nullptr;}}
struct Hit{D2D1_RECT_F rect;int id;bool enabled;};
enum class SetupState{Planning,Review,Applying,Done,Blocked};
struct SetupResult{SetupState state=SetupState::Blocked;artwork::Json plan;std::wstring message,backup;};
struct SetupView{bool open=false,restore=false,uninstall=false;std::wstring mode;std::string frameGeneration="native";int offset=0;SetupState state=SetupState::Planning;manager::Game game;artwork::Json plan;std::wstring manifest,message,backup;};
struct Completion{std::vector<manager::Game> games;std::wstring message;bool replace=false,error=false;std::vector<catalog::Hidden> hide{};std::shared_ptr<SetupResult> setup{};};
struct ArtUpdate{manager::Game game;size_t generation=0;};
struct App {
 HWND hwnd=nullptr;SetupView setup;std::wstring package,data;std::vector<manager::Game> games;std::vector<catalog::Hidden> hidden;std::vector<std::wstring> activity;
 int page=0,selected=-1,start=0,focus=-1,hover=-1,pressed=-1;int theme=0,accentChoice=0;std::wstring mode=L"asi",loader;bool errorShowing=false,safeUi=false,dark=false,busy=false,renderFailed=false,resizing=false;std::atomic_bool cancel{false};
 std::shared_ptr<std::atomic_bool> artCancel;size_t artGeneration=0,artJobs=0;bool closing=false;
 bool fgMenu=false;
 language::Language languagePreference=language::Language::Automatic,uiLanguage=language::Language::English;
 float width=1280,height=800,dpi=96,monitorDpi=96;std::vector<Hit> hits;
 ID2D1Factory* factory=nullptr;ID2D1HwndRenderTarget* target=nullptr;ID2D1SolidColorBrush* brush=nullptr;IDWriteFactory* writing=nullptr;
 IDWriteTextFormat *h1=nullptr,*h2=nullptr,*body=nullptr,*small=nullptr,*brand=nullptr;
 artwork::Images images;waterglass::Painter glass;waterglass::Appearance appearance;
 std::wstring current=L"Ready to add a game";
} app;
std::wstring tr(std::wstring_view key){return language::tr(key,app.uiLanguage);}
std::wstring textFormat(std::wstring_view key,std::initializer_list<std::wstring_view> values){return language::format(key,app.uiLanguage,values);}
int uiMessage(HWND window,const wchar_t* text,const wchar_t* title,UINT flags) noexcept {
 try{auto translated=tr(text?text:L""),caption=tr(title?title:L"");return MessageBoxW(window,translated.c_str(),caption.c_str(),flags);}
 catch(...){return MessageBoxW(window,text,title,flags);}
}
void reloadFonts(language::Language selected);
bool languagePreferences(bool load){try{
 auto path=manager::join(app.data,L"language.txt");auto old=manager::read(path,128);language::Language stored=language::Language::Automatic;
 const bool valid=language::readPreference(old,stored);
 if(load){app.languagePreference=valid?stored:language::Language::Automatic;app.uiLanguage=language::resolve(app.languagePreference,GetUserDefaultUILanguage());return true;}
 if(GetFileAttributesW(path.c_str())!=INVALID_FILE_ATTRIBUTES&&(!manager::ordinary(path)||!valid))return false;
 auto tmp=path+L".tmp-"+std::to_wstring(GetTickCount64());manager::writeNew(tmp,language::preference(app.languagePreference));
 if(!MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(tmp.c_str());return false;}return true;
}catch(...){if(load){app.languagePreference=language::Language::Automatic;app.uiLanguage=language::resolve(app.languagePreference,GetUserDefaultUILanguage());}return false;}}
void clearSelection(){manager_selection::clear(app.selected,app.fgMenu,app.focus,app.hover,app.pressed);app.hits.clear();}
const wchar_t* nav[]={L"Home",L"Games",L"Compatibility",L"History",L"Settings",L"About"};
void preferences(bool load){try{
 auto path=manager::join(app.data,L"preferences.txt");auto old=manager::read(path,128);
 if(load){
  int theme=0,accent=0;
  if(old.rfind("SM86-PREFS-2\n",0)==0&&std::sscanf(old.c_str()+13,"%d\n%d",&theme,&accent)==2){app.theme=installer_theme::clampTheme(theme);app.accentChoice=installer_theme::clampAccent(accent);}
  else if(old.rfind("SM86-PREFS-1\n",0)==0&&old.size()>13)app.theme=old[13]=='1'?1:0;
  app.dark=installer_theme::themes[app.theme].dark;return;
 }
 if(GetFileAttributesW(path.c_str())!=INVALID_FILE_ATTRIBUTES&&(!manager::ordinary(path)||(old.rfind("SM86-PREFS-1\n",0)!=0&&old.rfind("SM86-PREFS-2\n",0)!=0)))return;
 auto tmp=path+L".tmp-"+std::to_wstring(GetTickCount64());
 manager::writeNew(tmp,"SM86-PREFS-2\n"+std::to_string(app.theme)+"\n"+std::to_string(app.accentChoice)+"\n");
 if(!MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))DeleteFileW(tmp.c_str());
}catch(...) {}}

bool persist(){try{
 std::string s="SM86-MANAGER-4\n";for(auto& g:app.games){std::vector<std::wstring> fields={g.exe,g.title,g.store,g.steamId,g.steamRoot,g.cover,g.hero,g.installRoot,g.storeId,g.pinnedExe};bool first=true;for(auto field:fields){for(auto& c:field)if(c==L'\r'||c==L'\n'||c==L'\t')c=L' ';if(!first)s+='\t';s+=manager::toUtf8(field);first=false;}s+='\n';}
 for(const auto& h:app.hidden){if(h.root.find_first_of(L"\r\n\t")!=h.root.npos||h.exe.find_first_of(L"\r\n\t")!=h.exe.npos)throw std::runtime_error("Invalid hidden game path");s+="!hidden\t"+manager::toUtf8(h.root)+"\t"+manager::toUtf8(h.exe)+"\n";}
 auto tmp=manager::join(app.data,L"games.tmp-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64()));manager::writeNew(tmp,s);auto dest=manager::join(app.data,L"games.txt");if(GetFileAttributesW(dest.c_str())!=INVALID_FILE_ATTRIBUTES&&!manager::ordinary(dest)){DeleteFileW(tmp.c_str());return false;}if(!MoveFileExW(tmp.c_str(),dest.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(tmp.c_str());return false;}return true;
 }catch(...) {return false;}}
void activity(const std::wstring& message){SYSTEMTIME now{};GetLocalTime(&now);wchar_t clock[32];std::swprintf(clock,32,L"%02u:%02u:%02u  ",now.wHour,now.wMinute,now.wSecond);app.activity.insert(app.activity.begin(),std::wstring(clock)+message);if(app.activity.size()>200)app.activity.resize(200);app.current=message;try{auto path=manager::join(app.data,L"activity.log");if(GetFileAttributesW(path.c_str())!=INVALID_FILE_ATTRIBUTES&&!manager::ordinary(path))return;HANDLE file=CreateFileW(path.c_str(),FILE_APPEND_DATA,FILE_SHARE_READ,nullptr,OPEN_ALWAYS,0,nullptr);if(file!=INVALID_HANDLE_VALUE){auto text=manager::toUtf8(app.activity.front())+"\r\n";DWORD wrote=0;WriteFile(file,text.data(),static_cast<DWORD>(text.size()),&wrote,nullptr);CloseHandle(file);}}catch(...) {}}
std::vector<manager::Game> loadGames(){std::vector<manager::Game> out;auto text=manager::read(manager::join(app.data,L"games.txt"));bool v4=text.rfind("SM86-MANAGER-4\n",0)==0,v3=v4||text.rfind("SM86-MANAGER-3\n",0)==0,v2=text.rfind("SM86-MANAGER-2\n",0)==0;if(!v3&&!v2&&text.rfind("SM86-MANAGER-1\n",0)!=0)return out;
 size_t at=text.find('\n')+1;while(at<text.size()){auto end=text.find('\n',at);if(end==text.npos)break;auto line=text.substr(at,end-at);at=end+1;std::vector<std::wstring> fields;try{size_t pos=0;for(;;){auto tab=line.find('\t',pos);fields.push_back(manager::fromUtf8(line.substr(pos,tab==line.npos?line.size()-pos:tab-pos)));if(tab==line.npos)break;pos=tab+1;if(fields.size()>10)break;}if(v4&&fields.size()==3&&fields[0]==L"!hidden"){if(app.hidden.size()<600)app.hidden.push_back({fields[1],fields[2]});continue;}if(out.size()>=600||fields.size()!=(v3?10u:v2?7u:3u))continue;manager::Game g;g.exe=fields[0];g.title=fields[1];g.store=fields[2];if(v2||v3){g.steamId=fields[3];g.steamRoot=fields[4];g.cover=fields[5];g.hero=fields[6];}if(v3){g.installRoot=fields[7];g.storeId=fields[8];g.pinnedExe=fields[9];}else if(g.store==L"Steam"){g.installRoot=catalog::legacySteamRoot(g.exe);g.storeId=g.steamId;}if(g.installRoot.empty())g.installRoot=manager::parent(g.exe);if(manager::ordinary(g.installRoot,true)){g.installRoot=manager::canonical(g.installRoot);manager::add(out,std::move(g));}}catch(...) {}}return out;
}
std::wstring activityCaption(const std::wstring& message){
 // Activity entries have an internal HH:MM:SS prefix; translate only the known
 // complete UI message after it, preserving timestamps and technical details.
 if(message.size()>=10&&message[2]==L':'&&message[5]==L':'&&message[8]==L' '&&message[9]==L' ')return message.substr(0,10)+tr(std::wstring_view(message).substr(10));
 return tr(message);
}
void cancelArtwork(){if(app.artCancel)*app.artCancel=true;++app.artGeneration;}
void startArtwork(bool force=false){
 cancelArtwork();if(app.games.empty()||app.closing)return;auto generation=app.artGeneration;auto cancelled=std::make_shared<std::atomic_bool>(false);app.artCancel=cancelled;auto games=app.games;auto data=app.data;auto window=app.hwnd;++app.artJobs;
 try{std::thread([window,data,generation,cancelled,force,games=std::move(games)]()mutable{
  try{artwork::enrich(games,data,*cancelled,[&](const manager::Game& game){auto update=std::make_unique<ArtUpdate>();update->game=game;update->generation=generation;if(PostMessageW(window,WM_APP+3,0,reinterpret_cast<LPARAM>(update.get())))update.release();},force);}catch(...){}
  PostMessageW(window,WM_APP+4,static_cast<WPARAM>(generation),0);
 }).detach();}catch(...){--app.artJobs;activity(L"Artwork can be retried with Discover games.");}
}
void begin(const std::wstring& label,std::function<Completion()> task){if(app.busy||app.closing)return;app.busy=true;app.cancel=false;activity(label);InvalidateRect(app.hwnd,nullptr,FALSE);HWND window=app.hwnd;
 try{std::thread([window,task=std::move(task)](){
  try{auto result=std::make_unique<Completion>();
   try{*result=task();}catch(const std::exception& e){result->error=true;try{result->message=manager::fromUtf8(e.what());}catch(...){result->message=L"The operation could not complete.";}}catch(...){result->message=L"The operation stopped unexpectedly.";result->error=true;}
   if(PostMessageW(window,WM_APP+1,0,reinterpret_cast<LPARAM>(result.get())))result.release();
  }catch(...){manager_startup::record("background_exception",ERROR_UNHANDLED_EXCEPTION);PostMessageW(window,WM_APP+5,0,0);}
 }).detach();}catch(...){app.busy=false;activity(L"Could not start the background operation.");}}
std::wstring choose(bool folder,bool manifest=false,std::wstring initial=L"",bool uninstall=false){
 if(folder){IFileOpenDialog* dialog=nullptr;std::wstring result;if(SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&dialog)))){DWORD flags=0;dialog->GetOptions(&flags);dialog->SetOptions(flags|FOS_PICKFOLDERS|FOS_FORCEFILESYSTEM|FOS_PATHMUSTEXIST|FOS_NOCHANGEDIR);dialog->SetTitle(tr(L"Choose a game installation folder").c_str());if(SUCCEEDED(dialog->Show(app.hwnd))){IShellItem* item=nullptr;if(SUCCEEDED(dialog->GetResult(&item))){PWSTR path=nullptr;if(SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH,&path))){result=path;CoTaskMemFree(path);}item->Release();}}dialog->Release();}return result;}
 auto title=tr(manifest?L"Choose a backup's restore.tsv (files are reviewed before restore)":uninstall?L"Choose the executable beside the Smooth Motion files to remove":L"Choose the actual 64-bit game executable");
 try{return file_picker::choose(app.hwnd,title,initial,!manifest);}catch(const std::exception& e){activity(manager::fromUtf8(e.what()));return L"";}
}
std::wstring scanDetails(const manager::ScanStats& stats){
 std::wstring message;
 if(stats.limited)message+=L"\n"+textFormat(L"{0} folders reached scan limits. Select the game's own folder or EXE.",{std::to_wstring(stats.limited)});
 if(stats.unreadable)message+=L"\n"+textFormat(L"{0} files or folders could not be inspected.",{std::to_wstring(stats.unreadable)});
 for(const auto& issue:stats.issues)message+=L"\n"+issue.path+L"\n"+manager::fromUtf8(issue.message);
 return message;
}
void addPath(std::wstring p){if(app.busy||p.empty())return;cancelArtwork();auto games=app.games;begin(L"Inspecting the selected game…",[games=std::move(games),p=std::move(p)]()mutable{
 if(manager::ordinary(p,true)){
  manager::ScanStats stats;manager::scanFolder(games,p,app.cancel,stats);
  if(app.cancel)return Completion{{},tr(L"Scan cancelled. Your previous library is preserved."),false,false};
  auto message=stats.detected?textFormat(L"Detected {0} game installations. Artwork loads in the background.",{std::to_wstring(stats.detected)}):textFormat(L"No game executable could be inspected in:\n{0}",{p});
  message+=scanDetails(stats);
  return Completion{std::move(games),message,stats.detected!=0,stats.detected==0};
 }
 else {auto g=manager::inspectSelection(p,app.cancel);for(auto& old:games)if(catalog::within(g.exe,old.installRoot)){g.installRoot=old.installRoot;g.antiCheat|=old.antiCheat;break;}manager::add(games,std::move(g));}
 return Completion{std::move(games),L"Inspection finished. One card per installation; artwork loads in the background.",true,false};});}
void discover(){if(app.busy)return;cancelArtwork();auto previous=app.games;auto hidden=app.hidden;begin(L"Finding installed games and their launch executables…",[previous=std::move(previous),hidden=std::move(hidden)]()mutable{
 manager::ScanStats stats;auto games=manager::rescan(previous,app.cancel,stats);catalog::filterHidden(games,hidden);if(app.cancel)return Completion{{},L"Scan cancelled. Your previous library is preserved.",false,false};auto count=games.size();auto message=L"Library ready · "+std::to_wstring(count)+L" games · "+std::to_wstring(stats.excluded)+L" helper/editor executables filtered. Artwork loads in the background.";
 message+=scanDetails(stats);
 return Completion{std::move(games),message,true,false};});}

artwork::Json setupResponse(const manager::Result& result){
 if(result.outputTruncated)throw std::runtime_error("The helper report exceeded 2 MiB and was not parsed (exit "+std::to_string(result.code)+"). Check the game folder before retrying an install or uninstall.");
 if(result.output.empty())throw std::runtime_error("The installer returned no result (exit "+std::to_string(result.code)+"). Extract the full 2.0 preview package and retry.");
 artwork::Json json;try{json=artwork::Parser(result.output).parse();}catch(const std::exception&){throw std::runtime_error("The installer returned an unreadable result. Extract the complete matching package and retry.");}
 if(json.at("schema").value!="1")throw std::runtime_error("Installer protocol mismatch. Extract the complete matching release.");
 return json;
}
Completion setupCompletion(SetupState state,const std::wstring& message,const artwork::Json& plan={},const std::wstring& backup=L""){
 Completion done;done.message=message;done.setup=std::make_shared<SetupResult>();done.setup->state=state;done.setup->message=message;done.setup->plan=plan;done.setup->backup=backup;return done;
}
void prepareSetup(const manager::Game& game,const std::wstring& proxy=L"",const std::wstring& manifest=L"",bool uninstall=false){
 if(app.busy)return;app.setup.open=true;app.setup.game=game;app.setup.mode=app.mode;app.setup.restore=!manifest.empty();app.setup.uninstall=uninstall;app.setup.manifest=manifest;app.setup.state=SetupState::Planning;app.setup.offset=0;app.setup.plan={};app.setup.message=L"Inspecting the game, package and existing mod files…";app.setup.backup.clear();
 app.fgMenu=false;app.setup.frameGeneration="native";
 if(!uninstall&&manifest.empty()&&(game.targetChoiceRequired||game.antiCheat)){app.setup.state=SetupState::Blocked;app.setup.message=game.targetChoiceRequired?L"Multiple rendering executables were found. Choose EXE before installing.":L"Protected launcher detected. Automatic installation is unavailable.";return;}
 auto mode=app.mode;auto carrier=proxy.empty()?app.loader:proxy;auto fg=app.setup.frameGeneration;
 auto package=app.package;auto requestedLanguage=std::wstring(language::commandName(app.uiLanguage));
 begin(uninstall?L"Preparing an uninstall plan…":app.setup.restore?L"Preparing a restore plan…":L"Preparing an installation plan…",[game,mode,carrier,fg,manifest,package,uninstall,requestedLanguage](){
  auto selected=game;
  if(!uninstall&&manifest.empty()){selected=manager::inspectSelection(game.exe,app.cancel,game.title,game.store);if(selected.targetChoiceRequired||selected.antiCheat)return setupCompletion(SetupState::Blocked,selected.targetChoiceRequired?L"Multiple rendering executables were found. Choose EXE before installing.":L"Protected launcher detected. Automatic installation is unavailable.");}
  std::vector<std::wstring> args=uninstall?std::vector<std::wstring>{L"--uninstall-plan",game.exe}:manifest.empty()?std::vector<std::wstring>{L"--plan",selected.exe,mode,carrier,manager::fromUtf8(fg)}:std::vector<std::wstring>{L"--restore-plan",manifest};
  args.push_back(L"--language");args.push_back(requestedLanguage);
  auto result=manager::run(manager::join(package,L"Install.exe"),helper_identity::installer,args,true);auto json=setupResponse(result);
  if(result.code||json.at("status").value!="ready")return setupCompletion(SetupState::Blocked,manager::fromUtf8(json.at("message").value)+(json.at("win32").value!="0"&&!json.at("win32").value.empty()?L"\nWindows error "+manager::fromUtf8(json.at("win32").value):L""));
  if(!setup_protocol::validToken(json.at("token").value)||json.at("target").value.empty()||(!uninstall&&manifest.empty()&&json.at("frame_generation").value!=fg))throw std::runtime_error("The installer returned an incomplete review plan.");
  return setupCompletion(SetupState::Review,uninstall?L"Review the installed files before removing Smooth Motion.":L"Review the destination, loader and file changes before continuing.",json);
 });
}
void applySetup(){
 if(app.busy||app.setup.state!=SetupState::Review)return;
 auto view=app.setup;auto package=app.package;auto requestedLanguage=std::wstring(language::commandName(app.uiLanguage));
 app.setup.state=SetupState::Applying;app.setup.message=view.uninstall?L"Removing installed Smooth Motion files…":view.restore?L"Backing up the current state and restoring files…":L"Installing Smooth Motion and creating uninstall.bat…";
 begin(app.setup.message,[view,package,requestedLanguage](){
  auto proxy=manager::fromUtf8(view.plan.at("proxy").value),token=manager::fromUtf8(view.plan.at("token").value);
  auto args=view.uninstall?std::vector<std::wstring>{L"--uninstall-apply",view.game.exe,token}:view.restore?std::vector<std::wstring>{L"--restore-apply",view.manifest,token}:std::vector<std::wstring>{L"--apply",view.game.exe,view.mode,proxy,token,manager::fromUtf8(view.frameGeneration)};
  args.push_back(L"--language");args.push_back(requestedLanguage);
  auto result=manager::run(manager::join(package,L"Install.exe"),helper_identity::installer,args,true);auto json=setupResponse(result);
  const auto expected=view.uninstall?"uninstalled":view.restore?"restored":"installed";
  if(result.code||json.at("status").value!=expected)return setupCompletion(SetupState::Blocked,manager::fromUtf8(json.at("message").value)+(json.at("win32").value!="0"&&!json.at("win32").value.empty()?L"\nWindows error "+manager::fromUtf8(json.at("win32").value):L""));
  auto message=manager::fromUtf8(json.at("message").value),restorePoint=manager::fromUtf8(json.at("backup").value);
  return setupCompletion(SetupState::Done,message,{},restorePoint);
 });
}
void copyDetails(const std::wstring& text){
 if(!OpenClipboard(app.hwnd))return;HGLOBAL memory=GlobalAlloc(GMEM_MOVEABLE,(text.size()+1)*sizeof(wchar_t));
 if(memory){auto data=GlobalLock(memory);if(data){memcpy(data,text.c_str(),(text.size()+1)*sizeof(wchar_t));GlobalUnlock(memory);EmptyClipboard();if(!SetClipboardData(CF_UNICODETEXT,memory))GlobalFree(memory);}else GlobalFree(memory);}CloseClipboard();
}
void loaderMenu(){
 if(app.busy||app.mode!=L"asi")return;
 HMENU menu=CreatePopupMenu();if(!menu)return;
 const auto choices=app.setup.open&&!app.setup.restore&&!app.setup.uninstall?app.setup.plan.at("choices").array:std::vector<artwork::Json>{};
 AppendMenuW(menu,MF_STRING|MF_CHECKED*(app.loader.empty()),790,tr(L"Automatic (prefer a game import)").c_str());
 AppendMenuW(menu,MF_SEPARATOR,0,nullptr);
 for(size_t i=0;i<install_modes::carriers.size();++i){
  auto name=std::string(install_modes::carriers[i]);auto title=manager::fromUtf8(name);bool available=true;
  for(const auto& choice:choices)if(choice.at("name").value==name){available=choice.at("available").value=="true";title+=L"  ·  "+tr(manager::fromUtf8(choice.at("reason").value));break;}
  AppendMenuW(menu,MF_STRING|(available?0:MF_GRAYED)|(app.loader==manager::fromUtf8(name)?MF_CHECKED:0),800+UINT(i),title.c_str());
 }
 HMENU legacy=CreatePopupMenu();if(legacy){for(const auto* name:install_modes::win32Only)AppendMenuW(legacy,MF_STRING|MF_GRAYED,0,manager::fromUtf8(name).c_str());AppendMenuW(menu,MF_SEPARATOR,0,nullptr);AppendMenuW(menu,MF_POPUP,reinterpret_cast<UINT_PTR>(legacy),tr(L"Win32 only — incompatible with these x64 builds").c_str());}
 POINT point{};GetCursorPos(&point);auto chosen=TrackPopupMenu(menu,TPM_RETURNCMD,point.x,point.y,0,app.hwnd,nullptr);DestroyMenu(menu);
 if(chosen==790||(chosen>=800&&size_t(chosen)<800+install_modes::carriers.size())){
  app.loader=chosen==790?L"":manager::fromUtf8(install_modes::carriers[chosen-800]);
  if(app.setup.open&&!app.setup.restore&&!app.setup.uninstall)prepareSetup(app.setup.game,app.loader);
  InvalidateRect(app.hwnd,nullptr,FALSE);
 }
}
void setupAction(int id){
 if(app.busy)return;
 if(id==40)applySetup();
 else if(id==41)app.setup.open=false;
 else if(id==42)loaderMenu();
 else if(id==44)prepareSetup(app.setup.game,app.setup.restore||app.setup.uninstall?L"":manager::fromUtf8(app.setup.plan.at("proxy").value),app.setup.manifest,app.setup.uninstall);
 else if(id==45){auto text=app.setup.game.exe+L"\n"+app.setup.message+L"\n"+manager::fromUtf8(app.setup.plan.at("warning").value)+L"\n"+app.setup.backup;if(!app.setup.restore&&!app.setup.uninstall)text+=L"\nFrame generation: "+manager::fromUtf8(app.setup.plan.at("frame_generation_label").value);for(const auto& change:app.setup.plan.at("changes").array)text+=L"\n"+manager::fromUtf8(change.at("action").value+": "+change.at("path").value);copyDetails(text);}
 else if(id==46)ShellExecuteW(app.hwnd,L"open",(app.setup.backup.empty()?manager::parent(app.setup.game.exe):app.setup.backup).c_str(),nullptr,nullptr,SW_SHOWNORMAL);
 else if(id==47){auto path=choose(false,false,manager::parent(app.setup.game.exe),app.setup.uninstall);if(!path.empty()){auto game=app.setup.game;game.exe=path;game.targetChoiceRequired=false;prepareSetup(game,L"",L"",app.setup.uninstall);}}
 else if(id==48)ShellExecuteW(app.hwnd,L"open",manager::join(app.package,L"MANUAL_INSTALL.md").c_str(),nullptr,nullptr,SW_SHOWNORMAL);
 else if(id==49)app.setup.offset=std::max(0,app.setup.offset-5);
 else if(id==50)app.setup.offset=std::min(std::max(0,(int(app.setup.plan.at("changes").array.size())-1)/5*5),app.setup.offset+5);
}
void doGame(int id){if(app.busy||app.selected<0||app.selected>=static_cast<int>(app.games.size()))return;auto g=app.games[app.selected];auto package=app.package;
 if(id==34){
  if(uiMessage(app.hwnd,textFormat(L"Remove {0} from this list and hide it from discovery? Game files stay in place. Use Add game or Restore hidden games to show it again.",{g.title}).c_str(),L"Remove game",MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)!=IDYES)return;
  if(app.hidden.size()>=600){uiMessage(app.hwnd,L"The hidden list is full. Use Settings > Restore hidden games first.",L"Remove game",MB_OK);return;}
  cancelArtwork();auto previous=app.games;auto oldHidden=app.hidden;app.hidden.push_back({g.installRoot,g.exe});app.games.erase(app.games.begin()+app.selected);
  if(!persist()){app.games=std::move(previous);app.hidden=std::move(oldHidden);uiMessage(app.hwnd,L"Could not save the game list. The card was kept.",L"Remove game",MB_OK|MB_ICONERROR);return;}
  app.selected=-1;app.start=0;app.images.clear();activity(L"Game removed from the list. Its files were preserved.");startArtwork();return;
 }
 if(id==30){
  auto path=choose(false,false,manager::parent(g.exe));if(path.empty())return;cancelArtwork();auto games=app.games;auto index=app.selected;
  begin(L"Inspecting the replacement executable…",[games=std::move(games),index,path,g]()mutable{
   auto fresh=manager::inspectSelection(path,app.cancel,g.title,g.store);auto pin=fresh.pinnedExe;catalog::carryPreferences(fresh,g);fresh.pinnedExe=pin;fresh.storeId=g.storeId;
   if(catalog::within(fresh.exe,g.installRoot)){fresh.installRoot=g.installRoot;fresh.antiCheat|=g.antiCheat;}
   bool moved=catalog::pathKey(fresh.installRoot)!=catalog::pathKey(g.installRoot);
   games.erase(games.begin()+index);manager::add(games,std::move(fresh));
   Completion result{std::move(games),L"Game executable corrected and pinned. Install uses the displayed EXE's folder.",true,false,{}};
   if(moved)result.hide.push_back({g.installRoot,g.exe});return result;
  });return;
 }
 if(id==29){HMENU menu=CreatePopupMenu();if(!menu)return;AppendMenuW(menu,MF_STRING,700,tr(L"Automatic selection (recommended)").c_str());AppendMenuW(menu,MF_SEPARATOR,0,nullptr);for(size_t i=0;i<g.choices.size();++i){auto& c=g.choices[i];auto name=catalog::within(c.exe,g.installRoot)?c.exe.substr(g.installRoot.size()+1):c.exe;name+=L"  ·  "+manager::apiName(c.api)+(c.x64?L"":L"  ·  32-bit");for(auto& ch:name)if(ch==L'&')ch=L'_';AppendMenuW(menu,MF_STRING|(manager::equal(c.exe,g.exe)?MF_CHECKED:0),701+i,name.c_str());}POINT point{static_cast<LONG>((app.width-235)*app.dpi/96),static_cast<LONG>(117*app.dpi/96)};ClientToScreen(app.hwnd,&point);UINT chosen=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_LEFTALIGN|TPM_TOPALIGN,point.x,point.y,0,app.hwnd,nullptr);DestroyMenu(menu);if(!chosen)return;auto index=chosen==700?0:size_t(chosen-701);if(index>=g.choices.size())return;
  try{auto fresh=manager::inspect(g.choices[index].exe,g.title,g.store);auto found=std::find_if(app.games.begin(),app.games.end(),[&](const manager::Game& item){return catalog::sameInstall(item,g);});if(found==app.games.end())return;auto& current=*found;manager::Choice choice{fresh.exe,chosen==700?g.choices[index].reason:L"Selected by you",fresh.api,fresh.indirect,fresh.x64,g.choices[index].rank,fresh.protectedExe};if(chosen==700)manager::resolveChoices(current);else manager::selectChoice(current,choice);current.pinnedExe=chosen==700||current.targetChoiceRequired?L"":current.exe;persist();activity(current.targetChoiceRequired?L"Choose the rendering executable":L"Selected executable: "+manager::base(current.exe));}catch(const std::exception& e){activity(manager::fromUtf8(e.what()));}return;}
 if(id==26){ShellExecuteW(app.hwnd,L"open",manager::parent(g.exe).c_str(),nullptr,nullptr,SW_SHOWNORMAL);return;}
 if(id==23){auto manifest=choose(false,true,manager::parent(g.exe));if(!manifest.empty())prepareSetup(g,L"",manifest);return;}
 if(id==24){prepareSetup(g,L"",L"",true);return;}
 if(id==20){
  if(!g.x64||g.antiCheat){app.setup.open=true;app.setup.game=g;app.setup.state=SetupState::Blocked;app.setup.plan={};app.setup.restore=false;app.setup.uninstall=false;app.setup.manifest.clear();app.setup.message=!g.x64?L"Select the 64-bit game executable. This backend cannot load in a 32-bit process.":L"A protected launcher was detected. Choose the actual supported game executable and review its modding rules before installing.";return;}
  prepareSetup(g);return;
 }
 begin(L"Applying the selected action…",[=](){
    if(id==27){auto r=manager::run(manager::join(package,L"Collect_Diagnostics.exe"),helper_identity::collector,{g.exe});return Completion{{},r.code?L"Diagnostics collection did not finish.":L"Diagnostics collected locally. No report was uploaded.",false,r.code!=0};}
    return Completion{{},L"No action selected.",false,false};
 });
}
void updateAppearance(){
 if(app.safeUi){app.appearance={};MARGINS margins{};DwmExtendFrameIntoClientArea(app.hwnd,&margins);const DWM_SYSTEMBACKDROP_TYPE none=DWMSBT_NONE;DwmSetWindowAttribute(app.hwnd,DWMWA_SYSTEMBACKDROP_TYPE,&none,sizeof none);}
 else app.appearance=waterglass::applyBackdrop(app.hwnd,app.dark);
 app.glass.clear();InvalidateRect(app.hwnd,nullptr,FALSE);
}
void appearanceMenu(bool colors){
 HMENU menu=CreatePopupMenu();if(!menu)return;
 size_t size=colors?installer_theme::accentNames.size():installer_theme::themes.size();
 for(size_t i=0;i<size;++i){const auto* name=colors?installer_theme::accentNames[i]:installer_theme::themes[i].name;AppendMenuW(menu,MF_STRING|(int(i)==(colors?app.accentChoice:app.theme)?MF_CHECKED:0),900+UINT(i),tr(name).c_str());}
 POINT p{};GetCursorPos(&p);auto choice=TrackPopupMenu(menu,TPM_RETURNCMD,p.x,p.y,0,app.hwnd,nullptr);DestroyMenu(menu);
 if(choice>=900&&size_t(choice)<900+size){if(colors)app.accentChoice=int(choice-900);else app.theme=int(choice-900);app.dark=installer_theme::themes[app.theme].dark;preferences(false);updateAppearance();}
}
void languageMenu(){
 if(app.busy)return;HMENU menu=CreatePopupMenu();if(!menu)return;
 for(unsigned i=0;i<3;++i)AppendMenuW(menu,MF_STRING|(unsigned(app.languagePreference)==i?MF_CHECKED:0),950+i,language::languageName(static_cast<language::Language>(i)));
 POINT p{};GetCursorPos(&p);auto choice=TrackPopupMenu(menu,TPM_RETURNCMD,p.x,p.y,0,app.hwnd,nullptr);DestroyMenu(menu);
 if(choice<950||choice>952)return;auto selected=static_cast<language::Language>(choice-950),resolved=language::resolve(selected,GetUserDefaultUILanguage());
 try{reloadFonts(resolved);}catch(...){activity(L"Could not change the display language. Your previous language is still active.");return;}
 app.languagePreference=selected;app.uiLanguage=resolved;
 if(!languagePreferences(false))activity(L"Could not save the language preference. The language changed for this session only.");
 app.focus=app.hover=app.pressed=-1;app.hits.clear();InvalidateRect(app.hwnd,nullptr,FALSE);
}
void action(int id){
 if(id==55){languageMenu();return;}
 if(id==31||id==54){appearanceMenu(id==54);return;}
 if(id>=60&&id<66){app.theme=id-60;app.dark=installer_theme::themes[app.theme].dark;preferences(false);updateAppearance();return;}
 if(id==51||id==52){if(app.busy)return;app.mode=id==51?L"version":L"asi";if(app.setup.open&&!app.setup.restore&&!app.setup.uninstall)prepareSetup(app.setup.game,app.loader);InvalidateRect(app.hwnd,nullptr,FALSE);return;}
 if(id==53){loaderMenu();return;}
 if(id>=40&&id<=50){setupAction(id);InvalidateRect(app.hwnd,nullptr,FALSE);return;}
 if(app.setup.open){if(app.busy)return;app.setup.open=false;}
 if(id>=100&&id<106){app.page=id-100;clearSelection();app.start=0;}
 else if(id>=1000){if(static_cast<size_t>(id-1000)>=app.games.size())return;app.selected=id-1000;app.page=1;app.focus=-1;}
 else if(id==10)addPath(choose(true));else if(id==11)addPath(choose(false));else if(id==12)discover();
 else if(id==13)app.start=std::min(app.start+6,std::max(0,static_cast<int>(app.games.size())-1));else if(id==14)app.start=std::max(0,app.start-6);else if(id==15)app.selected=-1;
 else if(id==36&&!app.busy){app.images.clear();startArtwork(true);activity(L"Refreshing full-size Steam artwork…");}
 else if(id==35&&!app.busy){auto old=app.hidden;app.hidden.clear();if(persist())discover();else{app.hidden=std::move(old);activity(L"Could not save the hidden game list.");}}
 else if(id==33)ShellExecuteW(app.hwnd,L"open",manager::join(app.package,L"COMPATIBILITY.md").c_str(),nullptr,nullptr,SW_SHOWNORMAL);
 else doGame(id);InvalidateRect(app.hwnd,nullptr,FALSE);
}

D2D1_COLOR_F color(unsigned rgb,float alpha=1){return D2D1::ColorF(rgb,alpha);}
unsigned ink(){return app.appearance.highContrast?waterglass::systemColor(COLOR_WINDOWTEXT):installer_theme::themes[app.theme].ink;}
unsigned muted(){return app.appearance.highContrast?waterglass::systemColor(COLOR_WINDOWTEXT):installer_theme::themes[app.theme].muted;}
unsigned accent(){return app.appearance.highContrast?waterglass::systemColor(COLOR_HIGHLIGHT):app.dark?installer_theme::lightAccents[app.accentChoice]:installer_theme::accents[app.accentChoice];}
unsigned panel(){return installer_theme::themes[app.theme].sheet;}
void fill(D2D1_RECT_F r,unsigned rgb,float radius=20,float alpha=1){
 if(rgb==panel()&&alpha>.9f){app.glass.glass(r,radius,waterglass::Material::Sheet,app.brush);return;}
 app.brush->SetColor(color(rgb,alpha));app.target->FillRoundedRectangle(D2D1::RoundedRect(r,radius,radius),app.brush);
}
void stroke(D2D1_RECT_F r,unsigned rgb,float radius=20,float alpha=1){app.brush->SetColor(color(rgb,alpha));app.target->DrawRoundedRectangle(D2D1::RoundedRect(r,radius,radius),app.brush,1);}
void label(const std::wstring& s,D2D1_RECT_F r,IDWriteTextFormat* format,unsigned rgb,bool center=false){IDWriteTextLayout* layout=nullptr;if(FAILED(app.writing->CreateTextLayout(s.data(),static_cast<UINT32>(s.size()),format,std::max(1.f,r.right-r.left),std::max(1.f,r.bottom-r.top),&layout)))return;layout->SetTextAlignment(center?DWRITE_TEXT_ALIGNMENT_CENTER:DWRITE_TEXT_ALIGNMENT_LEADING);DWRITE_TRIMMING trim{DWRITE_TRIMMING_GRANULARITY_CHARACTER,0,0};IDWriteInlineObject* ellipsis=nullptr;if(SUCCEEDED(app.writing->CreateEllipsisTrimmingSign(format,&ellipsis))){layout->SetTrimming(&trim,ellipsis);ellipsis->Release();}app.brush->SetColor(color(rgb));app.target->DrawTextLayout(D2D1::Point2F(r.left,r.top),layout,app.brush,D2D1_DRAW_TEXT_OPTIONS_CLIP);layout->Release();}
void labelUi(const std::wstring& s,D2D1_RECT_F r,IDWriteTextFormat* format,unsigned rgb,bool center=false){label(tr(s),r,format,rgb,center);}
void icon(int type,float x,float y,unsigned rgb){
 app.brush->SetColor(color(rgb));
 auto segment=[&](float a,float b,float c,float d){app.target->DrawLine({x+a,y+b},{x+c,y+d},app.brush,1.5f);};
 if(type==0){segment(0,7,8,0);segment(8,0,16,7);segment(3,6,3,15);segment(13,6,13,15);segment(3,15,13,15);}
 else if(type==1){for(int row=0;row<2;++row)for(int col=0;col<2;++col)stroke({x+col*9.f,y+row*9.f,x+col*9.f+6,y+row*9.f+6},rgb,2);}
 else if(type==2){stroke({x+1,y+1,x+15,y+15},rgb,5);segment(4,8,7,11);segment(7,11,12,5);}
 else if(type==3){app.target->DrawEllipse(D2D1::Ellipse({x+8,y+8},7,7),app.brush,1.5f);segment(8,4,8,8);segment(8,8,12,10);}
 else if(type==4){for(int i=0;i<3;++i){float yy=2+i*6.f;segment(0,yy,16,yy);float xx=i==1?11.f:5.f;app.target->FillEllipse(D2D1::Ellipse({x+xx,y+yy},2,2),app.brush);}}
 else {app.target->DrawEllipse(D2D1::Ellipse({x+8,y+8},7,7),app.brush,1.5f);segment(8,7,8,12);app.target->FillEllipse(D2D1::Ellipse({x+8,y+4},.8f,.8f),app.brush);}
}
void button(D2D1_RECT_F r,const std::wstring& text,int id,bool primary=false,bool enabled=true){
 enabled=enabled&&(!app.busy||id>=100||id==31);app.hits.push_back({r,id,enabled});
 bool hot=id==app.hover,pressed=id==app.pressed;float radius=(r.bottom-r.top)*.5f;
 auto material=!enabled?waterglass::Material::Disabled:primary?waterglass::Material::Primary:waterglass::Material::Control;
 app.glass.glass(r,radius,material,app.brush);
 if((hot||pressed)&&enabled){fill(r,pressed?0x153456:0xffffff,radius,pressed?.10f:.14f);stroke(r,app.dark?0xc2e1ff:0xffffff,radius,.75f);}
 unsigned textColor=!enabled?muted():primary?(app.appearance.highContrast?waterglass::systemColor(COLOR_HIGHLIGHTTEXT):0xffffff):ink();
 float down=pressed?1.f:0.f;label(tr(text),{r.left+12,r.top+11+down,r.right-12,r.bottom-5},app.body,textColor,true);
 if(app.focus>=0&&app.focus<static_cast<int>(app.hits.size())&&app.hits[app.focus].id==id)stroke({r.left-3,r.top-3,r.right+3,r.bottom+3},accent(),radius+3);
}
bool picture(const std::wstring& path,D2D1_RECT_F r,bool isIcon=false,bool contain=false,float opacity=1,artwork::ImageRole role=artwork::ImageRole::Any){
 if(app.safeUi||path.empty())return false;auto* bitmap=app.images.get(app.target,path,isIcon,role);if(!bitmap)return false;auto size=bitmap->GetSize();if(size.width<=0||size.height<=0)return false;
 ID2D1RoundedRectangleGeometry* geometry=nullptr;ID2D1Layer* layer=nullptr;float radius=isIcon?12.f:14.f;
 if(FAILED(app.factory->CreateRoundedRectangleGeometry(D2D1::RoundedRect(r,radius,radius),&geometry)))return false;
 if(FAILED(app.target->CreateLayer(&layer))){geometry->Release();return false;}
 app.target->PushLayer(D2D1::LayerParameters(D2D1::InfiniteRect(),geometry),layer);
 float sx=(r.right-r.left)/size.width,sy=(r.bottom-r.top)/size.height,scale=contain?std::min(sx,sy):std::max(sx,sy),w=size.width*scale,h=size.height*scale;
 float cx=(r.left+r.right)*.5f,cy=(r.top+r.bottom)*.5f;app.target->DrawBitmap(bitmap,{cx-w/2,cy-h/2,cx+w/2,cy+h/2},opacity,D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);app.target->PopLayer();layer->Release();geometry->Release();return true;
}
void card(const manager::Game& g,D2D1_RECT_F r,int index){
 fill(r,panel(),24);float coverWidth=(r.bottom-r.top-24)*2/3;auto imageRect=D2D1::RectF(r.left+12,r.top+12,r.left+12+coverWidth,r.bottom-12);
 app.glass.glass(imageRect,14,waterglass::Material::Control,app.brush,false);
 bool shown=picture(g.cover,imageRect,false,false,1,artwork::ImageRole::Cover);
 if(!shown){
  if(!g.hero.empty())picture(g.hero,imageRect,false,false,.18f,artwork::ImageRole::Header);
  float cy=(imageRect.top+imageRect.bottom)*.5f;
  label(g.title.substr(0,2),{imageRect.left+10,cy-32,imageRect.right-10,cy+12},app.h1,accent(),true);
  labelUi(L"No cover yet",{imageRect.left+8,cy+20,imageRect.right-8,cy+58},app.small,muted(),true);
 }

 float x=imageRect.right+16;label(g.title,{x,r.top+20,r.right-14,r.top+78},app.h2,ink());
 label(g.store,{x,r.top+82,r.right-14,r.top+104},app.small,accent());
 label(manager::apiName(g.api)+(g.x64?L"":L" · 32-bit"),{x,r.top+107,r.right-14,r.top+142},app.small,muted());
 labelUi(g.sessionActive?L"Session active":g.recovery?L"Recovery mode":g.disabled?L"Backend disabled":g.installed?L"Mod installed":L"View game  ↗",{x,r.bottom-34,r.right-14,r.bottom-10},app.small,g.recovery?0x976016:muted());
 app.hits.push_back({r,1000+index,true});if(app.hover==1000+index)stroke(r,accent(),24,.65f);
}
void setupScreen(float left,float right){
 const auto& view=app.setup;bool review=view.state==SetupState::Review,done=view.state==SetupState::Done,blocked=view.state==SetupState::Blocked;
 auto targetPath=manager::fromUtf8(view.plan.at("target").value);if(targetPath.empty())targetPath=view.game.exe;
 labelUi(L"01  CHOOSE GAME     /     02  REVIEW CHANGES     /     03  APPLY",{left,78,right,105},app.small,accent());
 labelUi(done?(view.uninstall?L"Smooth Motion uninstalled":view.restore?L"Files restored":L"Game files installed"):blocked?(view.uninstall?L"Uninstall needs attention":view.restore?L"Restore needs attention":L"Installation needs attention"):view.uninstall?L"Review uninstall":view.restore?L"Review file restore":L"Review installation",{left,119,right,160},app.h1,ink());
 label(targetPath,{left,174,right,222},app.body,muted());
 float bottom=app.height-135;fill({left,239,right,bottom},panel(),28);
 if(review){
  float split=right-324,x=left+24;const auto& changes=view.plan.at("changes").array;
  label(textFormat(L"FILE CHANGES  ·  {0}",{std::to_wstring(changes.size())}),{x,263,split-20,290},app.small,accent());
  if(changes.empty())labelUi(view.uninstall?L"No files are eligible for removal beside this EXE. Choose installed EXE to review another folder.":L"The recorded files already match. Your current settings will be preserved.",{x,315,split-24,449},app.body,ink());
  for(size_t i=size_t(view.offset);i<changes.size()&&i<size_t(view.offset+5);++i){float y=309+float(i-view.offset)*52;
   label(manager::fromUtf8(changes[i].at("path").value),{x,y,split-20,y+23},app.body,ink());
   labelUi(manager::fromUtf8(changes[i].at("action").value),{x,y+24,split-20,y+45},app.small,muted());
  }
  if(changes.size()>5){button({x,579,x+110,620},L"‹ Previous",49,false,view.offset>0);button({x+122,579,x+232,620},L"Next ›",50,false,size_t(view.offset+5)<changes.size());label(textFormat(L"{0}–{1} of {2}",{std::to_wstring(view.offset+1),std::to_wstring(std::min(changes.size(),size_t(view.offset+5))),std::to_wstring(changes.size())}),{x+248,591,split-16,617},app.small,muted());}
  x=split+16;
  if(view.uninstall){
   labelUi(L"UNINSTALL",{x,263,right-24,290},app.small,accent());
   labelUi(L"Remove Smooth Motion from this game",{x,309,right-24,375},app.h2,ink());
   labelUi(L"Only recognized Smooth Motion files are removed. Changed or unrelated files are preserved.",{x,392,right-24,491},app.body,muted());
   labelUi(L"For an old install beside a launcher, choose that launcher EXE.",{x,503,right-24,554},app.small,muted());
   button({x,566,right-24,610},L"Choose installed EXE",47);
  }else if(view.restore){
   labelUi(L"RECOVERY",{x,263,right-24,290},app.small,accent());
   labelUi(L"Restore the recorded game files",{x,309,right-24,357},app.h2,ink());
   labelUi(L"The current files are backed up before restoring. Later modifications are protected.",{x,377,right-24,498},app.body,muted());
  }else{
   labelUi(L"INSTALL OPTION",{x,263,right-24,290},app.small,accent());
   float half=(right-24-x-10)/2;
   button({x,301,x+half,343},L"version.dll",51,view.mode==L"version");
   button({x+half+10,301,right-24,343},L"new.asi",52,view.mode==L"asi");
   if(view.mode==L"asi"){
    labelUi(L"ASI loader · Ultimate ASI Loader 9.7.4",{x,352,right-24,376},app.small,muted());
    button({x,382,right-24,424},manager::fromUtf8(view.plan.at("proxy").value)+L"  ▾",42);
   }else labelUi(L"Native backend in one DLL\nversion.dll (standalone)",{x,360,right-24,420},app.body,ink());
   labelUi(L"FRAME GENERATION",{x,438,right-24,462},app.small,accent());
   labelUi(L"RTX20 Optical Flow",{x,476,right-24,508},app.body,ink());
   bool fallback=view.plan.at("fallback").value=="true";
   labelUi(fallback?L"Loader route needs testing":L"DLL imported by EXE or engine",{x,524,right-24,547},app.small,fallback?0xbd843a:accent());
   labelUi(L"RTX20 preview. Optical-flow pairs and accepted generated Present calls are reported in nvsmooth30.log.",{x,556,right-24,623},app.small,muted());

  }
  labelUi(view.uninstall?L"The uninstall plan is checked again before any file is removed.":view.restore?L"The restore plan is checked again before any file is changed.":L"Run uninstall.bat beside the game executable to remove Smooth Motion.",{left+24,bottom-29,right-24,bottom-8},app.small,muted());
 }else{
  auto heading=done?L"Ready for the next step":blocked?L"Installer details":view.state==SetupState::Applying?L"Applying your reviewed plan…":L"Checking the game and package…";
  labelUi(heading,{left+26,270,right-26,311},app.h2,done?accent():ink());
  labelUi(view.message,{left+26,325,right-26,bottom-95},app.body,muted());
  if(done&&!view.backup.empty())label(textFormat(L"Restore backup\n{0}",{view.backup}),{left+26,bottom-88,right-26,bottom-20},app.small,accent());
  else if(blocked){labelUi(L"Copy details for the complete error. Review a new plan after resolving the conflict.",{left+26,bottom-65,right-208,bottom-17},app.small,muted());button({right-184,bottom-70,right-24,bottom-27},L"Installation guide",48);}
 }
 float y=app.height-111;
 button({left,y,left+114,y+44},L"‹ Back",41,false,!app.busy);
 if(review){button({left+126,y,left+256,y+44},L"Copy details",45);button({right-356,y,right-216,y+44},L"Refresh plan",44);button({right-204,y,right,y+44},view.uninstall?L"Uninstall these files":view.restore?L"Restore these files":L"Install these files",40,true);}
 else if(blocked){button({left+126,y,left+249,y+44},L"Copy details",45);button({left+261,y,left+395,y+44},view.uninstall?L"Choose installed EXE":L"Choose EXE",47,false,!view.restore);button({left+407,y,left+543,y+44},L"Open folder",46);button({right-156,y,right,y+44},L"Check again",44,true);}
 else if(done){button({left+126,y,left+270,y+44},L"Copy details",45);button({right-204,y,right,y+44},view.backup.empty()?L"Open game folder":L"Open restore backup",46,true);}
}
void detail(float left,float right){
 auto& g=app.games[app.selected];
 button({left,72,left+135,114},L"‹ All games",15);button({right-435,72,right-225,114},L"Browse replacement EXE",30);button({right-214,72,right,114},textFormat(L"Choose EXE ({0})",{std::to_wstring(g.choices.size())}),29,false,!g.choices.empty());
 picture(g.hero,{right-254,135,right,221});label(g.title,{left,139,g.hero.empty()?right:right-270,181},app.h1,ink());label(g.exe,{left,190,g.hero.empty()?right:right-270,230},app.small,muted());label(tr(g.reason)+(g.limited?L" · "+tr(L"Scan limit reached"):L""),{left,234,right,253},app.small,accent());
 fill({left,266,right,app.height-133},panel(),30);float x=left+25,half=(right-left-62)/2;
 labelUi(L"CHOOSE THE LOADING ROUTE",{x,286,right-25,313},app.small,accent());
 button({x,326,x+half,374},L"version.dll",51,app.mode==L"version");
 button({x+half+12,326,right-25,374},L"new.asi",52,app.mode==L"asi");
 labelUi(app.mode==L"asi"?L"Choose an imported DLL carrier. Every carrier loads the same RTX20 preview ASI.":L"The native backend runs inside version.dll. Use the ASI route to choose dinput8.dll, winmm.dll or another carrier.",{x,395,right-25,440},app.body,ink());
 if(app.mode==L"asi")button({x,453,x+half,499},textFormat(L"Loader: {0}  ▾",{app.loader.empty()?tr(L"Automatic"):app.loader}),53);
 else labelUi(L"version.dll (standalone)",{x,463,x+half,501},app.body,muted());
 labelUi(L"RTX20 Optical Flow",{x+half+24,466,right-37,499},app.body,ink());
 std::wstring state=L"Run uninstall.bat beside the game executable to remove Smooth Motion.";
 if(g.antiCheat)state=L"Protected launcher detected. Automatic installation is unavailable.";else if(!g.x64)state=L"These builds require a 64-bit game executable.";else if(g.targetChoiceRequired)state=L"Multiple rendering executables were found. Choose EXE before installing.";
 labelUi(state,{x,521,right-25,562},app.body,muted());
 const float w=(right-left-70)/3;float by=app.height-218;
 button({x,by,x+w,by+46},g.installed?L"Review replacement":L"Review installation",20,true,g.x64&&!g.antiCheat&&!g.targetChoiceRequired);
 button({x+w+10,by,x+2*w+10,by+46},L"Uninstall Smooth Motion",24);
 button({x+2*w+20,by,right-25,by+46},L"Collect diagnostics",27);
 button({left,app.height-112,left+160,app.height-68},L"Open game folder",26);button({left+174,app.height-112,left+334,app.height-68},L"Legacy restore…",23);button({left+348,app.height-112,left+508,app.height-68},L"Refresh artwork",36);button({right-186,app.height-112,right,app.height-68},L"Remove from list",34);
}

bool target(){
 if(app.target)return true;RECT rect{};GetClientRect(app.hwnd,&rect);
 for(unsigned attempt=0;attempt<2;++attempt){
  auto alpha=app.safeUi?D2D1_ALPHA_MODE_IGNORE:D2D1_ALPHA_MODE_PREMULTIPLIED;
  HRESULT hr=app.factory->CreateHwndRenderTarget(D2D1::RenderTargetProperties(D2D1_RENDER_TARGET_TYPE_SOFTWARE,D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,alpha),app.dpi,app.dpi),D2D1::HwndRenderTargetProperties(app.hwnd,D2D1::SizeU(std::max<LONG>(1,rect.right),std::max<LONG>(1,rect.bottom))),&app.target);
  if(SUCCEEDED(hr))hr=app.target->CreateSolidColorBrush(color(0),&app.brush);
  if(SUCCEEDED(hr)){app.target->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_GRAYSCALE);return true;}
  manager_startup::record("drawing_surface_failed",DWORD(hr));app.images.clear();app.glass.clear();release(app.brush);release(app.target);
  if(app.safeUi)break;app.safeUi=true;updateAppearance();
 }
 return false;
}
void draw(){if(!target()){if(!app.renderFailed){app.renderFailed=true;PostMessageW(app.hwnd,WM_APP+2,0,0);}return;}app.hits.clear();app.target->BeginDraw();waterglass::styleIndex=app.theme;waterglass::primaryColor=installer_theme::accents[app.accentChoice];app.glass.begin(app.target,app.width,app.height,app.dark,app.appearance,app.resizing,app.safeUi);app.glass.backdrop(app.brush);
 // Rounded lenses sample the shared artwork; DWM owns the live backdrop.
 fill({14,14,207,app.height-14},panel(),30);
 app.glass.glass({35,39,83,87},18,waterglass::Material::Primary,app.brush);
 labelUi(L"SM",{36,51,82,82},app.h2,0xffffff,true);labelUi(L"SMOOTH",{94,43,194,66},app.h2,ink());labelUi(L"MOTION",{94,70,191,90},app.small,muted());
 for(int i=0;i<6;++i){float y=123.f+i*53;auto r=D2D1::RectF(28,y,193,y+43);if(app.page==i)app.glass.glass(r,22,waterglass::Material::Control,app.brush);else if(app.hover==100+i)fill(r,app.dark?0xffffff:0xffffff,22,.10f);
  icon(i,43,y+13,app.page==i?accent():muted());labelUi(nav[i],{72,y+12,181,y+38},app.body,app.page==i?ink():muted());app.hits.push_back({r,100+i,true});}
 app.glass.glass({28,app.height-130,193,app.height-31},23,waterglass::Material::Control,app.brush,false);
 fill({44,app.height-105,51,app.height-98},app.busy?0xe5a93f:0x26a585,4);labelUi(app.busy?L"Working…":L"Ready",{59,app.height-111,180,app.height-83},app.body,ink());
 labelUi(L"RTX20 Manager 2.8.4-p2-fix11-test\nTuring",{45,app.height-77,185,app.height-36},app.small,muted());
 float left=233,right=app.width-28;labelUi(L"SMOOTH MOTION  /  INSTALL & UNINSTALL",{left,24,right-200,51},app.small,muted());button({right-178,16,right,57},tr(installer_theme::themes[app.theme].name)+L"  ▾",31);
 if(app.setup.open)setupScreen(left,right);else if(app.selected>=0&&app.selected<static_cast<int>(app.games.size()))detail(left,right);
 else if(app.page==0||app.page==1){
  if(app.page==0){fill({left,78,right,326},panel(),32);float mid=(left+right)/2;app.glass.glass({mid-32,96,mid+32,160},32,waterglass::Material::Control,app.brush);stroke({mid-16,118,mid+17,141},accent(),5);labelUi(L"Set up Smooth Motion",{left+30,165,right-30,205},app.h1,ink(),true);labelUi(L"Choose your game. Review the changes. Install with uninstall.bat.",{left+25,213,right-25,243},app.body,muted(),true);button({mid-246,259,mid-90,303},L"Browse folder",10,true);button({mid-78,259,mid+78,303},L"Browse EXE",11);button({mid+90,259,mid+246,303},L"Discover games",12);
   labelUi(L"Your games",{left,354,right,385},app.h2,ink());float w=(right-left-28)/3;for(size_t i=0;i<std::min<size_t>(3,app.games.size());++i)card(app.games[i],{left+i*(w+14),399,left+i*(w+14)+w,574},static_cast<int>(i));if(app.games.empty())labelUi(L"Your game library will appear here. Scanning never installs files.",{left,424,right,470},app.body,muted());
   labelUi(L"Activity",{left,607,right,637},app.h2,ink());fill({left,650,right,app.height-57},panel(),26);for(size_t i=0;i<std::min<size_t>(std::min<size_t>(3,app.activity.size()),static_cast<size_t>(std::max(0.f,(app.height-726)/26)));++i)label(activityCaption(app.activity[i]),{left+20,669+i*26.f,right-20,695+i*26.f},app.small,muted());
  }else{labelUi(L"Games",{left,83,right-340,127},app.h1,ink());button({right-325,79,right-171,122},L"Add game",10,true);button({right-158,79,right,122},L"Discover games",12);label(textFormat(L"{0} games · One card per installation · Automatic covers",{std::to_wstring(app.games.size())}),{left,142,right,174},app.body,muted());float w=(right-left-28)/3;for(int i=0;i<6&&app.start+i<static_cast<int>(app.games.size());++i){int col=i%3,row=i/3;card(app.games[app.start+i],{left+col*(w+14),199+row*220.f,left+col*(w+14)+w,399+row*220.f},app.start+i);}button({left,app.height-118,left+125,app.height-74},L"‹ Previous",14,false,app.start>0);button({right-125,app.height-118,right,app.height-74},L"Next ›",13,false,app.start+6<static_cast<int>(app.games.size()));}
 }else{labelUi(nav[app.page],{left,83,right,130},app.h1,ink());fill({left,158,right,app.height-82},panel(),30);float x=left+28;
  if(app.page==2){
   labelUi(L"Installation and compatibility",{x,184,right-28,223},app.h2,ink());
   const wchar_t* rows[]={L"One backend: standalone version.dll, or new.asi with an alternative carrier.",L"ASI loader: all 19 official Win64 names, with file conflict checks.",L"Steam: deferred ASI loading is enabled; affected-game testing is outstanding.",L"Existing files: only recognised Smooth Motion builds are replaced; other mods are preserved.",L"DirectX 11 and DirectX 12 SDR, windowed or borderless. HDR, Vulkan and OpenGL are unsupported.",L"Turing optical-flow preview. Actual GPU output and game compatibility are unverified."};
   for(int i=0;i<6;++i)labelUi(rows[i],{x,243+i*57.f,right-28,295+i*57.f},app.body,ink());
   button({x,app.height-149,x+220,app.height-105},L"Read compatibility notes",33);
  }
  if(app.page==3){labelUi(L"Recent activity",{x,185,right-28,219},app.h2,ink());for(size_t i=0;i<std::min<size_t>(10,app.activity.size());++i)label(activityCaption(app.activity[i]),{x,237+i*42.f,right-28,276+i*42.f},app.small,muted());labelUi(L"Select a game and choose Uninstall Smooth Motion to review removal.",{x,app.height-137,right-28,app.height-99},app.body,ink());}
  if(app.page==4){
   labelUi(L"Theme",{x,192,right-28,225},app.h2,ink());float w=(right-x-52)/3;
   for(int i=0;i<6;++i){float bx=x+(i%3)*(w+12),by=245+(i/3)*64.f;button({bx,by,bx+w,by+46},installer_theme::themes[i].name,60+i,app.theme==i);}
   labelUi(L"Accent colour",{x,389,x+290,423},app.h2,ink());
   button({x,434,x+280,480},tr(installer_theme::accentNames[app.accentChoice])+L"  ▾",54);
   const float languageX=x+310;
   labelUi(L"Language / 语言",{languageX,389,right-28,423},app.h2,ink());
   button({languageX,434,right-28,480},std::wstring(language::languageName(app.languagePreference))+L"  ▾",55);
   labelUi(L"Language changes immediately and is remembered for the next launch.",{x,501,right-28,543},app.body,muted());
   labelUi(L"Some technical diagnostics remain in English. Game names and file paths are unchanged.",{x,551,right-28,590},app.small,muted());
   button({x,620,x+300,666},textFormat(L"Restore hidden games ({0})",{std::to_wstring(app.hidden.size())}),35,false,!app.hidden.empty());
  }
  if(app.page==5){labelUi(L"Smooth Motion Manager 2.8.4-rtx20-dx12-preview2-fix11-performance-test",{x,195,right-28,235},app.h1,ink());labelUi(L"Choose standalone version.dll or new.asi with an ASI loader. Each installation creates uninstall.bat beside the game executable.\n\nRTX 20-series optical flow with custom frame synthesis. DirectX 11 and DirectX 12 SDR preview; not NVIDIA's proprietary Smooth Motion model.\n\nSix themes and five accent colours. Native glass interface.\n\nUltimate ASI Loader by ThirteenAG and contributors. Licence and release provenance are included.\n\nPer-game startup, displayed frame output and performance require hardware testing.",{x,258,right-35,563},app.body,muted());}

 }
 labelUi(app.current,{233,app.height-35,app.width-28,app.height-8},app.small,muted());HRESULT hr=app.target->EndDraw();if(FAILED(hr)){
  manager_startup::record("end_draw_failed",DWORD(hr));app.images.clear();app.glass.clear();release(app.brush);release(app.target);
  if(hr==D2DERR_RECREATE_TARGET)InvalidateRect(app.hwnd,nullptr,FALSE);
  else if(!app.safeUi){app.safeUi=true;updateAppearance();app.current=L"Compatibility drawing enabled. Themes and installation remain available.";}
  else if(!app.renderFailed){app.renderFailed=true;PostMessageW(app.hwnd,WM_APP+2,0,0);}
 }
}
void fitWindow(){RECT r{};GetClientRect(app.hwnd,&r);float scale=std::min({app.monitorDpi/96.f,r.right/1100.f,r.bottom/800.f});scale=std::max(.25f,scale);app.dpi=96*scale;app.width=r.right/scale;app.height=r.bottom/scale;if(app.target)app.target->SetDpi(app.dpi,app.dpi);}
LRESULT dispatch(HWND window,UINT message,WPARAM wp,LPARAM lp){switch(message){
 case WM_CREATE:app.hwnd=window;DragAcceptFiles(window,TRUE);return 0;
 case WM_GETMINMAXINFO:{auto* m=reinterpret_cast<MINMAXINFO*>(lp);m->ptMinTrackSize.x=660;m->ptMinTrackSize.y=520;return 0;}
 case WM_ENTERSIZEMOVE:app.resizing=true;return 0;
 case WM_EXITSIZEMOVE:app.resizing=false;app.glass.clear();InvalidateRect(window,nullptr,FALSE);return 0;
 case WM_SIZE:if(wp==SIZE_MINIMIZED)return 0;fitWindow();if(app.target&&FAILED(app.target->Resize(D2D1::SizeU(LOWORD(lp),HIWORD(lp))))){app.images.clear();app.glass.clear();release(app.brush);release(app.target);}InvalidateRect(window,nullptr,FALSE);return 0;
 case WM_SETTINGCHANGE:case WM_THEMECHANGED:case WM_DWMCOMPOSITIONCHANGED:updateAppearance();return 0;
 case WM_DPICHANGED:{app.monitorDpi=static_cast<float>(HIWORD(wp));auto* r=reinterpret_cast<RECT*>(lp);SetWindowPos(window,nullptr,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER|SWP_NOACTIVATE);return 0;}
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{struct Paint{HWND window;PAINTSTRUCT ps{};explicit Paint(HWND w):window(w){BeginPaint(window,&ps);}~Paint(){EndPaint(window,&ps);}} paint(window);draw();return 0;}
 case WM_MOUSELEAVE:app.hover=-1;InvalidateRect(window,nullptr,FALSE);return 0;
 case WM_CAPTURECHANGED:app.pressed=-1;InvalidateRect(window,nullptr,FALSE);return 0;
 case WM_MOUSEMOVE:{TRACKMOUSEEVENT track{sizeof track,TME_LEAVE,window,0};TrackMouseEvent(&track);float x=GET_X_LPARAM(lp)*96.f/app.dpi,y=GET_Y_LPARAM(lp)*96.f/app.dpi;int hover=-1;for(auto h:app.hits)if(h.enabled&&x>=h.rect.left&&x<h.rect.right&&y>=h.rect.top&&y<h.rect.bottom)hover=h.id;if(hover!=app.hover){app.hover=hover;InvalidateRect(window,nullptr,FALSE);}SetCursor(LoadCursorW(nullptr,hover>=0?IDC_HAND:IDC_ARROW));return 0;}
 case WM_LBUTTONDOWN:{float x=GET_X_LPARAM(lp)*96.f/app.dpi,y=GET_Y_LPARAM(lp)*96.f/app.dpi;app.pressed=-1;for(auto h:app.hits)if(h.enabled&&x>=h.rect.left&&x<h.rect.right&&y>=h.rect.top&&y<h.rect.bottom){app.pressed=h.id;SetCapture(window);break;}InvalidateRect(window,nullptr,FALSE);return 0;}
 case WM_LBUTTONUP:{int pressed=app.pressed;app.pressed=-1;if(GetCapture()==window)ReleaseCapture();float x=GET_X_LPARAM(lp)*96.f/app.dpi,y=GET_Y_LPARAM(lp)*96.f/app.dpi;for(auto h:app.hits)if(h.id==pressed&&h.enabled&&x>=h.rect.left&&x<h.rect.right&&y>=h.rect.top&&y<h.rect.bottom){action(h.id);break;}InvalidateRect(window,nullptr,FALSE);return 0;}
 case WM_KEYDOWN:if(wp==VK_ESCAPE&&app.fgMenu){app.fgMenu=false;app.focus=-1;InvalidateRect(window,nullptr,FALSE);return 0;}if(wp==VK_TAB&&!app.hits.empty()){int step=GetKeyState(VK_SHIFT)&0x8000?-1:1;for(size_t tries=0;tries<app.hits.size();++tries){app.focus=(app.focus+step+static_cast<int>(app.hits.size()))%static_cast<int>(app.hits.size());if(app.hits[app.focus].enabled)break;}InvalidateRect(window,nullptr,FALSE);return 0;}if((wp==VK_RETURN||wp==VK_SPACE)&&app.focus>=0&&app.focus<static_cast<int>(app.hits.size())&&app.hits[app.focus].enabled){action(app.hits[app.focus].id);return 0;}if(wp==VK_ESCAPE&&app.setup.open&&!app.busy){app.setup.open=false;InvalidateRect(window,nullptr,FALSE);return 0;}if(wp==VK_ESCAPE&&!app.busy&&app.selected>=0){app.selected=-1;InvalidateRect(window,nullptr,FALSE);return 0;}break;
 case WM_DROPFILES:{HDROP drop=reinterpret_cast<HDROP>(wp);wchar_t p[32768];if(DragQueryFileW(drop,0,p,32768)&&!app.busy&&!app.fgMenu){app.setup.open=false;addPath(p);}DragFinish(drop);return 0;}
 case WM_APP+2:uiMessage(window,L"The manager could not create its software drawing surface. No game files were changed by this failure.",L"Drawing unavailable",MB_OK|MB_ICONERROR);app.closing=true;app.cancel=true;cancelArtwork();if(!app.busy&&!app.artJobs)DestroyWindow(window);return 0;
 case WM_APP+5:app.busy=false;activity(L"The background operation stopped. You can retry it.");InvalidateRect(window,nullptr,FALSE);if(app.closing&&!app.artJobs)DestroyWindow(window);return 0;
 case WM_APP+1:{manager_startup::checkpoint("operation_complete");std::unique_ptr<Completion> done(reinterpret_cast<Completion*>(lp));app.busy=false;if(done->setup){app.setup.state=done->setup->state;app.setup.plan=std::move(done->setup->plan);app.setup.message=done->setup->message;app.setup.backup=done->setup->backup;if(app.setup.state==SetupState::Review)app.setup.game.exe=manager::fromUtf8(app.setup.plan.at("target").value);}else if(app.setup.open&&done->error){app.setup.state=SetupState::Blocked;app.setup.message=done->message;}if(done->replace){clearSelection();for(const auto& h:done->hide)if(app.hidden.size()<600)app.hidden.push_back(h);app.images.clear();app.games=std::move(done->games);for(const auto& g:app.games)catalog::reveal(app.hidden,g);app.selected=-1;app.start=0;if(!persist()){done->error=true;done->message+=L" Could not save the game list; check access to LocalAppData/SM86Manager.";}}for(auto& g:app.games)manager::refresh(g);activity(done->message);InvalidateRect(window,nullptr,FALSE);if(done->error&&!app.closing&&!app.setup.open)uiMessage(window,done->message.c_str(),L"Operation did not complete",MB_OK|MB_ICONWARNING);if(done->replace&&!app.closing)startArtwork();if(app.closing&&!app.artJobs)DestroyWindow(window);return 0;}
 case WM_APP+3:{std::unique_ptr<ArtUpdate> update(reinterpret_cast<ArtUpdate*>(lp));if(update->generation!=app.artGeneration||app.closing)return 0;for(auto& g:app.games)if(catalog::sameInstall(g,update->game)){g.cover=update->game.cover;g.hero=update->game.hero;g.steamId=update->game.steamId;if(g.title.rfind(L"appid_",0)==0)g.title=update->game.title;app.images.clear();InvalidateRect(window,nullptr,FALSE);break;}return 0;}
 case WM_APP+4:if(app.artJobs)--app.artJobs;if(static_cast<size_t>(wp)==app.artGeneration){persist();size_t count=0;for(auto& g:app.games)if(!g.cover.empty()||!g.hero.empty())++count;if(!app.busy&&!app.closing)activity(L"Artwork ready · "+std::to_wstring(count)+L" of "+std::to_wstring(app.games.size())+L" games have store images.");InvalidateRect(window,nullptr,FALSE);}if(app.closing&&!app.busy&&!app.artJobs)DestroyWindow(window);return 0;
 case WM_CLOSE:app.closing=true;app.cancel=true;cancelArtwork();if(app.busy||app.artJobs){activity(L"Closing after the current operation stops. Finish or cancel any open setup dialog.");InvalidateRect(window,nullptr,FALSE);return 0;}DestroyWindow(window);return 0;
 case WM_TIMER:if(!app.busy&&GetForegroundWindow()==window){if(app.selected>=0&&app.selected<static_cast<int>(app.games.size()))manager::refresh(app.games[app.selected]);else for(size_t i=0;i<std::min<size_t>(app.games.size(),6);++i)manager::refresh(app.games[i]);InvalidateRect(window,nullptr,FALSE);}return 0;
 case WM_DESTROY:KillTimer(window,1);persist();PostQuitMessage(0);return 0;
 }return DefWindowProcW(window,message,wp,lp);}
LRESULT CALLBACK procedure(HWND window,UINT message,WPARAM wp,LPARAM lp) noexcept {
 try{return dispatch(window,message,wp,lp);}
 catch(...){
  manager_startup::record("window_callback_exception",message);
  // No C++ exception may unwind through a Windows callback. A failed paint
  // discards its resources; the next paint builds a fresh drawing surface.
  if(message==WM_PAINT){app.images.clear();app.glass.clear();release(app.brush);release(app.target);if(!app.safeUi){app.safeUi=true;updateAppearance();}}
  app.fgMenu=false;app.focus=app.hover=app.pressed=-1;app.hits.clear();
  if(message==WM_APP+1||message==WM_APP+5)app.busy=false;
  if(!app.errorShowing){app.errorShowing=true;uiMessage(window,L"The current operation could not finish. Details were saved in LocalAppData\\SM86Manager\\startup-*.log. You can retry the operation.",L"Smooth Motion Manager",MB_OK|MB_ICONWARNING);app.errorShowing=false;}
  if(message!=WM_PAINT)InvalidateRect(window,nullptr,FALSE);
  return message==WM_CREATE?-1:0;
 }
}
void reloadFonts(language::Language selected){
 const wchar_t* family=language::fontFamily(selected);IDWriteFontCollection* collection=nullptr;
 if(SUCCEEDED(app.writing->GetSystemFontCollection(&collection))){UINT32 index=0;BOOL found=FALSE;
  if(FAILED(collection->FindFamilyName(family,&index,&found))||!found)family=L"Segoe UI";collection->Release();}
 // DirectWrite's system fallback supplies missing glyphs. Build the complete
 // set before replacing the current formats so an error keeps the UI usable.
 IDWriteTextFormat* formats[4]{};const float sizes[]={28,17,14,12};
 try{for(unsigned i=0;i<4;++i){if(FAILED(app.writing->CreateTextFormat(family,nullptr,i<2?DWRITE_FONT_WEIGHT_SEMI_BOLD:DWRITE_FONT_WEIGHT_NORMAL,DWRITE_FONT_STYLE_NORMAL,DWRITE_FONT_STRETCH_NORMAL,sizes[i],language::locale(selected),&formats[i])))throw std::runtime_error("Windows text rendering could not initialize");formats[i]->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP);}}
 catch(...){for(auto*& f:formats)release(f);throw;}
 release(app.h1);release(app.h2);release(app.body);release(app.small);app.h1=formats[0];app.h2=formats[1];app.body=formats[2];app.small=formats[3];
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR command,int){try{
 app.safeUi=command&&std::wstring(command)==L"--safe-ui";
 SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);HRESULT com=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);if(FAILED(com))throw std::runtime_error("Windows folder dialogs could not initialize");
 wchar_t path[32768];DWORD n=GetModuleFileNameW(nullptr,path,32768);if(!n||n>=32768)throw std::runtime_error("Cannot locate manager");app.package=manager::parent(std::wstring(path,n));PWSTR local=nullptr;if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&local)))throw std::runtime_error("Cannot locate local application data");app.data=manager::join(local,L"SM86Manager");CoTaskMemFree(local);if(!CreateDirectoryW(app.data.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)throw std::runtime_error("Cannot create local application data");if(!manager::ordinary(app.data,true))throw std::runtime_error("Application data directory is linked or invalid");
 manager_startup::open(app.data);
 languagePreferences(true);
 // Per-user singleton prevents simultaneous actions against the same backup.
 HANDLE mutex=CreateMutexW(nullptr,TRUE,L"Local\\SM86.Manager.1");if(!mutex)throw std::runtime_error("Cannot create manager session");if(GetLastError()==ERROR_ALREADY_EXISTS){uiMessage(nullptr,L"Smooth Motion Manager is already open.",L"Smooth Motion Manager",MB_OK);CloseHandle(mutex);return 0;}
 manager_startup::checkpoint("drawing_services");
 if(FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED,&app.factory))||FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),reinterpret_cast<IUnknown**>(&app.writing))))throw std::runtime_error("Windows drawing services are unavailable");reloadFonts(app.uiLanguage);
 WNDCLASSEXW wc{};wc.cbSize=sizeof wc;wc.hInstance=instance;wc.lpfnWndProc=procedure;wc.lpszClassName=L"SM86_Manager_Window_1";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hIcon=LoadIconW(nullptr,IDI_APPLICATION);if(!RegisterClassExW(&wc))throw std::runtime_error("Cannot register manager window");HWND window=CreateWindowExW(0,wc.lpszClassName,L"Smooth Motion Manager",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1320,885,nullptr,nullptr,instance,nullptr);if(!window)throw std::runtime_error("Cannot create manager window");app.monitorDpi=static_cast<float>(GetDpiForWindow(window));MONITORINFO monitor{};monitor.cbSize=sizeof monitor;if(GetMonitorInfoW(MonitorFromWindow(window,MONITOR_DEFAULTTONEAREST),&monitor)){int w=std::min<LONG>(static_cast<int>(1320*app.monitorDpi/96),monitor.rcWork.right-monitor.rcWork.left-24),h=std::min<LONG>(static_cast<int>(885*app.monitorDpi/96),monitor.rcWork.bottom-monitor.rcWork.top-24);SetWindowPos(window,nullptr,monitor.rcWork.left+12,monitor.rcWork.top+12,w,h,SWP_NOZORDER|SWP_NOACTIVATE);}fitWindow();int corners=2;DwmSetWindowAttribute(window,33,&corners,sizeof corners);
 preferences(true);updateAppearance();manager_startup::checkpoint("saved_library");app.games=loadGames();activity(L"Manager ready. Looking for installed games and artwork…");ShowWindow(window,SW_SHOWNORMAL);manager_startup::checkpoint("first_paint");UpdateWindow(window);manager_startup::checkpoint("discovery");SetTimer(window,1,1500,nullptr);discover();MSG message{};while(GetMessageW(&message,nullptr,0,0)>0){TranslateMessage(&message);DispatchMessageW(&message);}app.images.clear();app.glass.clear();release(app.brush);release(app.target);release(app.h1);release(app.h2);release(app.body);release(app.small);release(app.writing);release(app.factory);ReleaseMutex(mutex);CloseHandle(mutex);manager_startup::checkpoint("normal_exit");CoUninitialize();return 0;
 }catch(const std::exception& e){manager_startup::record("startup_exception",ERROR_UNHANDLED_EXCEPTION);MessageBoxA(nullptr,e.what(),"Smooth Motion Manager",MB_OK|MB_ICONERROR);return 1;}catch(...){manager_startup::record("startup_exception",ERROR_UNHANDLED_EXCEPTION);uiMessage(nullptr,L"Startup stopped. See LocalAppData\\SM86Manager\\startup-*.log for details.",L"Smooth Motion Manager",MB_OK|MB_ICONERROR);return 1;}}
