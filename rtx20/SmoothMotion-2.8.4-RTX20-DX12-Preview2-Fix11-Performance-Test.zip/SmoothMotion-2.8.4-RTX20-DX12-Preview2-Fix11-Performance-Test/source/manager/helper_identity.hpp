#pragma once
namespace helper_identity {
inline constexpr char installer[]="ca0d15b4aaf79ded40bc45babaf4cb5d5d38a2fba2e86e3d840e43be7a4ec679";
inline constexpr char collector[]="8c24b172caa03ece5cce371848f8467798ebf8f253179b6d3cb98f9b6e50d829";
}
