#include "shader_test_support.hpp"
#include "shader_under_test.hpp"
#include <cassert>
#include <iostream>
#include <random>
#include <string>
Texture2D<float4> output;
Vertex pixel(int x,int y){return {float4(x+0.5f,y+0.5f,0,1),float2((x+0.5f)/ImageSize.x,(y+0.5f)/ImageSize.y)};}
// Flow cell size in output pixels: 4 = full-resolution NVOF (grid 4),
// 8 = NVOF on the half-resolution copy (grid 4 there, vectors in half pixels).
int block=4;
void setup(int w=128,int h=80){
 ImageSize={float(w),float(h)};InvImageSize={1.f/w,1.f/h};
 FlowBlock=float(block);FlowGain=block==4?1/32.f:2/32.f;
 const int gw=(w+block-1)/block,gh=(h+block-1)/block;
 Previous.reset(w,h);Current.reset(w,h);Reprojection.reset(w,h);output.reset(w,h);
 Forward.reset(gw,gh);Backward.reset(gw,gh);Projected.reset(gw,gh);
}
// Output-pixel motion to stored NVOF S10.5 units at the current flow scale.
float2 stored(float2 v){return {std::round(v.x/FlowGain),std::round(v.y/FlowGain)};}
void render(){
 // Same order as the runtime: midpoint projection on the flow grid first.
 for(int y=0;y<Projected.height;++y)for(int x=0;x<Projected.width;++x){
  auto value=Project(pixel(x,y));
  for(int c=0;c<4;++c)assert(std::isfinite(value[c]));
  Projected.at(x,y)=value;
 }
 for(int y=0;y<Current.height;++y)for(int x=0;x<Current.width;++x){
  auto value=Synthesize(pixel(x,y));
  for(int c=0;c<4;++c)value[c]=float((_Float16)value[c]);
  Reprojection.at(x,y)=value;
 }
 for(int y=0;y<Current.height;++y)for(int x=0;x<Current.width;++x){
  auto c=Resolve(pixel(x,y));output.at(x,y)=c;
  for(int n=0;n<4;++n)assert(std::isfinite(c[n])&&c[n]>=-0.0001&&c[n]<=1.0001);
  assert(std::abs(c.w-Current.at(x,y).w)<0.00002);
 }
}
float error(float4 a,float4 b){return colorError(a.rgb(),b.rgb());}
void expect_current(float tolerance=0.0001f){
 for(int y=0;y<Current.height;++y)for(int x=0;x<Current.width;++x)
  assert(error(output.at(x,y),Current.at(x,y))<tolerance);
}
// Each channel lies on the blend between two acceptable answers (feathering).
bool between(float4 value,float4 a,float4 b){
 for(int c=0;c<3;++c)if(value[c]<std::min(a[c],b[c])-0.002f||value[c]>std::max(a[c],b[c])+0.002f)return false;
 return true;
}
float4 pattern(float x,float y){
 return {0.45f+0.25f*std::sin(x*0.16f),0.45f+0.25f*std::cos((x+y)*0.12f),0.45f+0.22f*std::sin((x-y)*0.10f),0.37f};
}
float4 texture2(float x,float y){
 return {0.12f+0.1f*std::sin(x*0.7f+y*0.3f),0.08f+0.06f*std::cos(y*0.9f),0.06f+0.05f*std::sin((x+y)*0.5f),0.37f};
}
// Two independently moving layers with antialiased edges and NVOF-like 4x4
// block vectors: each block reports the motion of the layer covering most of
// it in its own source frame. Mixed blocks at edges are the realistic case.
template<class Shape> float4 layers(Shape inside,float x,float y,float t,float2 front,float2 back){
 float4 sum(0);
 for(int j=0;j<3;++j)for(int i=0;i<3;++i){
  float sx=x+(i+0.5f)/3,sy=y+(j+0.5f)/3,fx=sx-front.x*t,fy=sy-front.y*t;
  sum=sum+(inside(fx,fy)?texture2(fx,fy):pattern(sx-back.x*t-0.5f,sy-back.y*t-0.5f));
 }
 return sum/9.f;
}
template<class Shape> void parallax(Shape inside,float2 front,float2 back,Texture2D<float4>& truth){
 truth.reset(Current.width,Current.height);
 for(int y=0;y<Current.height;++y)for(int x=0;x<Current.width;++x){
  Previous.at(x,y)=layers(inside,x,y,0,front,back);Current.at(x,y)=layers(inside,x,y,1,front,back);
  truth.at(x,y)=layers(inside,x,y,0.5f,front,back);
 }
 for(int by=0;by<Forward.height;++by)for(int bx=0;bx<Forward.width;++bx){
  int previous=0,current=0;
  for(int j=0;j<block;++j)for(int i=0;i<block;++i){
   float x=bx*block+i+0.5f,y=by*block+j+0.5f;previous+=inside(x,y);current+=inside(x-front.x,y-front.y);
  }
  float2 f=previous*2>=block*block?front:back,b=current*2>=block*block?front:back;
  Forward.at(bx,by)=stored(f);
  Backward.at(bx,by)=stored(float2(0,0)-b);
 }
}
void translate(float dx,float dy=0){
 for(int y=0;y<Current.height;++y)for(int x=0;x<Current.width;++x){Previous.at(x,y)=pattern(x,y);Current.at(x,y)=pattern(x-dx,y-dy);}
 for(auto& p:Forward.pixels)p=stored({dx,dy});
 for(auto& p:Backward.pixels)p=stored({-dx,-dy});
}
int main(){
 std::cout<<std::unitbuf;
 unsigned passed=0;
 auto pass=[&](const char* name){++passed;std::cout<<"PASS "<<name<<'\n';};
 setup(129,83);translate(0);render();expect_current();pass("identity, odd dimensions and alpha");
 // Independent analytical midpoint; reject a blanket current-frame fallback.
 for(auto d:std::vector<float2>{{8,0},{-8,0},{4,4},{0,-6},{7,3}}){
  setup();translate(d.x,d.y);render();double mse=0,baseline=0;unsigned count=0;
  for(int y=20;y<60;++y)for(int x=24;x<104;++x){
   auto target=pattern(x-d.x*0.5f,y-d.y*0.5f);
   float a=error(output.at(x,y),target),b=error(Current.at(x,y),target);mse+=a*a;baseline+=b*b;++count;
  }
  std::cout<<"translation "<<d.x<<","<<d.y<<" rmse="<<std::sqrt(mse/count)<<" current_rmse="<<std::sqrt(baseline/count)<<'\n';
  assert(mse<baseline*0.05); // >95% reduction of midpoint squared error.
 }
 pass("bidirectional and diagonal midpoint motion");
 setup();translate(8);
 // Stationary 1-pixel text-like strokes over moving imagery; deliberately
 // supply background flow through the HUD to reproduce the failure mode.
 for(int y=16;y<64;++y)for(int x=20;x<100;++x)if(x%11==0||y%13==0)
  Previous.at(x,y)=Current.at(x,y)={0.97f,0.96f,0.93f,0.37f};
 render();
 for(int y=17;y<63;++y)for(int x=21;x<99;++x)if(x%11==0||y%13==0)
  assert(error(output.at(x,y),Current.at(x,y))<0.0002);
 pass("stationary thin HUD under incorrect background motion");
 setup();translate(8);
 // A newly appearing occluder has no valid previous-frame correspondence,
 // although the flow claims background motion through it. It must stay
 // complete where the real frame shows it: neither cut by background nor
 // smeared outside. Next to it, only the true background midpoint, the
 // current frame, or their feathered blend are acceptable.
 const float4 red{0.98f,0.02f,0.04f,0.37f};
 for(int y=0;y<80;++y)for(int x=48;x<84;++x)Current.at(x,y)=red;
 render();
 for(int y=8;y<72;++y)for(int x=40;x<92;++x){
  if(x>=48&&x<84)assert(error(output.at(x,y),Current.at(x,y))<0.001);
  else assert(between(output.at(x,y),Current.at(x,y),pattern(x-4,y)));
 }
 pass("newly appearing object kept intact without current-frame margins");
 setup();translate(8);
 // Equal-luminance colors defeated the old permissive luma-based gate.
 for(auto& p:Previous.pixels)p={1,0,0,0.25f};
 for(auto& p:Current.pixels)p={0,0.299f/0.587f,0,0.75f};
 render();expect_current();pass("chromatic scene cut");
 setup();translate(8);
 for(auto& p:Forward.pixels)p={32000,-32000};
 for(auto& p:Backward.pixels)p={-32000,32000};
 render();expect_current();pass("off-screen and extreme motion fallback");
 setup();translate(8);
 for(auto& p:Backward.pixels)p={256,0}; // Both directions cannot point right.
 render();expect_current();pass("nonreciprocal motion rejection");
 setup();translate(8);render();
 // Content entering or leaving at a border is visible in one frame only; the
 // other endpoint is off-screen. Clamped sampling must not pass as a match,
 // and the one visible endpoint gives the exact midpoint.
 for(int y=0;y<80;++y)for(int x:std::vector<int>{0,1,2,125,126,127})
  assert(error(output.at(x,y),pattern(x-4,y))<0.002);
 pass("screen edge endpoint validation");
 setup();translate(8);
 // A single falsely confident sample in an invalid region must not produce a shard.
 Reprojection.reset(128,80,float4(1,0,1,0));Reprojection.at(64,40).w=1;
 assert(error(Resolve(pixel(64,40)),Current.at(64,40))<0.0001);
 pass("isolated confidence island suppression");
 setup();translate(8);
 // Sweep confidence through the resolve; no binary photometric cutover.
 float previousValue=-1;
 for(int i=0;i<=100;++i){
  Reprojection.reset(128,80,float4(0.95f,0.7f,0.3f,float(i)/100));
  auto value=Resolve(pixel(64,40));
  if(i)assert(std::abs(value.x-previousValue)<0.025f);
  previousValue=value.x;
 }
 pass("continuous fallback weights");
 // Foreground and background moving in opposite directions: occlusion and
 // disocclusion bands on both sides, block flow mixed at the edges. Fix8 fell
 // back to the unwarped current frame here and cut misplaced blocks into the
 // midpoint; the reported broken rooflines and outlines have this geometry.
 for(auto motion:std::vector<std::pair<float2,float2>>{{{12,0},{-4,0}},{{-9,4},{3,0}},{{0,0},{10,0}},{{5,3},{-6,-2}}}){
  setup(160,112);Texture2D<float4> truth;
  auto box=[](float x,float y){return x>60&&x<100&&y>28&&y<84;};
  parallax(box,motion.first,motion.second,truth);render();
  double mse=0,baseline=0;unsigned count=0,bad=0;
  for(int y=8;y<104;++y)for(int x=8;x<152;++x){
   float a=error(output.at(x,y),truth.at(x,y)),b=error(Current.at(x,y),truth.at(x,y));
   mse+=a*a;baseline+=b*b;bad+=a>0.12f;++count;
  }
  std::cout<<"parallax "<<motion.first.x<<","<<motion.first.y<<" over "<<motion.second.x<<","<<motion.second.y
           <<" rmse="<<std::sqrt(mse/count)<<" current_rmse="<<std::sqrt(baseline/count)<<" bad="<<bad<<'/'<<count<<'\n';
  // Remaining errors are a one to two pixel antialiasing fringe. Fix8 fails
  // both limits in every case (bad 791..1515 of 13824 pixels).
  assert(mse<baseline*0.1&&bad<count/25);
 }
 pass("parallax occlusion bands without current-frame cut-ins");
 {
  // A pole narrower than a flow block crosses the background. Background
  // points on both sides still match perfectly, so the crossing motion must
  // win or the pole vanishes from every generated frame.
  setup(160,112);Texture2D<float4> truth;
  auto pole=[](float x,float y){return x>70&&x<73.5f&&y>6;};
  parallax(pole,{6,0},{-6,0},truth);render();
  unsigned count=0,visible=0;
  for(int y=12;y<104;++y)for(int x=74;x<76;++x){++count;visible+=error(output.at(x,y),truth.at(x,y))<0.12f;}
  std::cout<<"thin pole visible "<<visible<<'/'<<count<<'\n'; // Fix8: 0/184
  assert(visible*10>=count*9);
 }
 pass("thin crossing object stays visible at the midpoint");
 {
  // Quest text over a panning scene (Witcher 3 report): opaque glyph cores,
  // a semi-transparent dark outline and antialiased edges. Only the cores
  // are identical in both frames; outline and edges blend with the moving
  // background, and the flow follows the background through the text.
  setup(160,96);translate(10,-3);
  // Stem spacing 13: with a 10-pixel pan, spacing 9 or 11 would map stems
  // exactly onto neighbouring stems, which is genuinely explained motion.
  auto glyph=[](int x,int y){return y>=40&&y<52&&x>=30&&x<130&&((x-30)%13<2||y==40||y==41);};
  for(int y=0;y<96;++y)for(int x=0;x<160;++x){
   bool core=glyph(x,y),edge=false,outline=false;
   for(int j=-2;j<=2;++j)for(int i=-2;i<=2;++i)if(glyph(x+i,y+j)){if(std::abs(i)<=1&&std::abs(j)<=1)edge=true;else outline=true;}
   for(auto* frame:{&Previous,&Current}){
    float4 back=frame->at(x,y);
    if(core)frame->at(x,y)={0.93f,0.91f,0.86f,0.37f};
    else if(edge)frame->at(x,y)=lerp(back,float4(0.4f,0.38f,0.35f,0.37f),0.7f);
    else if(outline)frame->at(x,y)=lerp(back,float4(0,0,0,0.37f),0.45f);
   }
  }
  render();unsigned count=0,intact=0;
  for(int y=38;y<54;++y)for(int x=28;x<132;++x){
   bool text=false;
   for(int j=-2;j<=2;++j)for(int i=-2;i<=2;++i)text|=glyph(x+i,y+j);
   if(text){++count;intact+=error(output.at(x,y),Current.at(x,y))<0.02f;}
  }
  std::cout<<"overlay text intact "<<intact<<'/'<<count<<'\n';
  assert(intact*50>=count*49);
 }
 pass("HUD text with blended edges over a panning scene");
 {
  // A fast pan at a 30 FPS base: background moves 90 pixels per real frame,
  // a thin pole 70 pixels. Fix9 faded confidence out above 64 pixels and its
  // projection window reached only about 40 pixels of motion.
  setup(320,112);Texture2D<float4> truth;
  auto pole=[](float x,float y){return x>150&&x<153.5f&&y>6;};
  parallax(pole,{-70,0},{-90,0},truth);render();
  double mse=0,baseline=0;unsigned count=0,visible=0,poles=0;
  for(int y=8;y<104;++y)for(int x=100;x<220;++x){
   float a=error(output.at(x,y),truth.at(x,y)),b=error(Current.at(x,y),truth.at(x,y));
   mse+=a*a;baseline+=b*b;++count;
  }
  for(int y=12;y<104;++y)for(int x=116;x<118;++x){++poles;visible+=error(output.at(x,y),truth.at(x,y))<0.12f;}
  std::cout<<"fast pan rmse="<<std::sqrt(mse/count)<<" current_rmse="<<std::sqrt(baseline/count)<<" pole visible "<<visible<<'/'<<poles<<'\n';
  assert(mse<baseline*0.05&&visible*10>=poles*9);
 }
 pass("fast pan with a thin pole");
 {
  // Half-resolution optical flow (8-pixel cells, vectors in half pixels),
  // used automatically only at high real frame rates to cut flow GPU time.
  // Motion, HUD text and occlusion bands must still work; detail thinner
  // than a cell may lose its own motion (documented tradeoff).
  block=8;
  for(auto d:std::vector<float2>{{8,0},{-6,3},{7,3}}){
   setup();translate(d.x,d.y);render();double mse=0,baseline=0;
   for(int y=20;y<60;++y)for(int x=24;x<104;++x){
    auto target=pattern(x-d.x*0.5f,y-d.y*0.5f);
    float a=error(output.at(x,y),target),b=error(Current.at(x,y),target);mse+=a*a;baseline+=b*b;
   }
   assert(mse<baseline*0.05);
  }
  for(auto motion:std::vector<std::pair<float2,float2>>{{{12,0},{-4,0}},{{-9,4},{3,0}},{{0,0},{10,0}},{{5,3},{-6,-2}}}){
   setup(160,112);Texture2D<float4> truth;
   auto box=[](float x,float y){return x>60&&x<100&&y>28&&y<84;};
   parallax(box,motion.first,motion.second,truth);render();
   double mse=0,baseline=0;unsigned count=0,bad=0;
   for(int y=8;y<104;++y)for(int x=8;x<152;++x){
    float a=error(output.at(x,y),truth.at(x,y)),b=error(Current.at(x,y),truth.at(x,y));
    mse+=a*a;baseline+=b*b;bad+=a>0.12f;++count;
   }
   std::cout<<"half-resolution parallax rmse="<<std::sqrt(mse/count)<<" current_rmse="<<std::sqrt(baseline/count)<<" bad="<<bad<<'/'<<count<<'\n';
   assert(mse<baseline*0.15&&bad<count/20);
  }
  setup(160,96);translate(10,-3);
  auto glyph=[](int x,int y){return y>=40&&y<52&&x>=30&&x<130&&((x-30)%13<2||y==40||y==41);};
  for(int y=0;y<96;++y)for(int x=0;x<160;++x){
   bool core=glyph(x,y),edge=false,outline=false;
   for(int j=-2;j<=2;++j)for(int i=-2;i<=2;++i)if(glyph(x+i,y+j)){if(std::abs(i)<=1&&std::abs(j)<=1)edge=true;else outline=true;}
   for(auto* frame:{&Previous,&Current}){
    float4 back=frame->at(x,y);
    if(core)frame->at(x,y)={0.93f,0.91f,0.86f,0.37f};
    else if(edge)frame->at(x,y)=lerp(back,float4(0.4f,0.38f,0.35f,0.37f),0.7f);
    else if(outline)frame->at(x,y)=lerp(back,float4(0,0,0,0.37f),0.45f);
   }
  }
  render();unsigned count=0,intact=0;
  for(int y=38;y<54;++y)for(int x=28;x<132;++x){
   bool text=false;
   for(int j=-2;j<=2;++j)for(int i=-2;i<=2;++i)text|=glyph(x+i,y+j);
   if(text){++count;intact+=error(output.at(x,y),Current.at(x,y))<0.02f;}
  }
  std::cout<<"half-resolution overlay text intact "<<intact<<'/'<<count<<'\n';
  assert(intact*50>=count*49);
  setup(131,81);translate(8);std::mt19937 rng(7);
  for(auto& p:Forward.pixels)p={float(int(rng()%2049)-1024),float(int(rng()%2049)-1024)};
  for(auto& p:Backward.pixels)p={float(int(rng()%2049)-1024),float(int(rng()%2049)-1024)};
  render();
  block=4;
 }
 pass("half-resolution flow: motion, occlusion bands, HUD text, corrupted fields");
 // Corrupted boundary fields must not cause NaN/Inf, OOB loads or alpha damage.
 setup(131,81);translate(8);std::mt19937 rng(42);
 for(auto& p:Forward.pixels)p={float(int(rng()%2049)-1024),float(int(rng()%2049)-1024)};
 for(auto& p:Backward.pixels)p={float(int(rng()%2049)-1024),float(int(rng()%2049)-1024)};
 render();pass("adversarial flow field and odd-sized grids");
 std::cout<<passed<<" shader behavior groups passed\n";
}
