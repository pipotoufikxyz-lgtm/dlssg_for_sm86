#pragma once
namespace helper_identity {
inline constexpr char installer[]="2468e6a82c18c1902a71252b58e050ab8383fa76ce5f3eaba2335fdae6b847c0";
inline constexpr char collector[]="9bf4b11ab83ff0f5aad0b3e076e10c5e51ecb369647c115919bfc531bd01c457";
}
