#include "interpolator.hpp"
#include "policy.hpp"
#include "performance.hpp"
#include "dx12_transfer.hpp"
#include "nvof_d3d11.hpp"
#include "context_transaction.hpp"
#include "pacing_clock.hpp"
#include "nvs30/log.hpp"
#include "nvOpticalFlowCuda.h"
#include <d3dcompiler.h>
#include <stdexcept>
#include "shader_source.hpp"
namespace sm20 {
using nvs30::ComPtr; using nvs30::logf;
std::atomic_ullong flow_pairs{},generated_submissions{},real_submissions{},failures{};
namespace {
struct Cuda {
 HMODULE module{}; HMODULE optical{}; HMODULE compiler{};
 CUresult(WINAPI* init)(unsigned){};
 CUresult(WINAPI* d3dDevice)(CUdevice*,IDXGIAdapter*){};
 CUresult(WINAPI* attribute)(int*,int,CUdevice){};
 CUresult(WINAPI* create)(CUcontext*,unsigned,CUdevice){};
 CUresult(WINAPI* destroy)(CUcontext){};
 CUresult(WINAPI* push)(CUcontext){};
 CUresult(WINAPI* pop)(CUcontext*){};
 CUresult(WINAPI* sync)(){};
 CUresult(WINAPI* reg)(CUgraphicsResource*,ID3D11Resource*,unsigned){};
 CUresult(WINAPI* unreg)(CUgraphicsResource){};
 CUresult(WINAPI* map)(unsigned,CUgraphicsResource*,CUstream){};
 CUresult(WINAPI* unmap)(unsigned,CUgraphicsResource*,CUstream){};
 CUresult(WINAPI* array)(CUarray*,CUgraphicsResource,unsigned,unsigned){};
 CUresult(WINAPI* copy)(const CUDA_MEMCPY2D*){};
 decltype(&D3DCompile) compile{};
 NV_OF_CUDA_API_FUNCTION_LIST of{};
 bool loaded{},cudaOfReady{}; std::atomic<const char*> status{"not_initialized"};
} cuda;
std::once_flag loading;
void require(HRESULT hr,const char* what){if(FAILED(hr)){logf("[rtx20] %s failed: HRESULT=0x%08lx\n",what,(unsigned long)hr);throw std::runtime_error(what);}}
void cu(CUresult rc,const char* what){if(rc){logf("[rtx20] %s failed: CUDA=%d\n",what,rc);throw std::runtime_error(what);}}
void of(NV_OF_STATUS rc,const char* what){if(rc!=NV_OF_SUCCESS){logf("[rtx20] %s failed: NVOF=%d\n",what,int(rc));throw std::runtime_error(what);}}
struct CurrentContext {
 bool active{};
 explicit CurrentContext(CUcontext c){cu(cuda.push(c),"cuCtxPushCurrent");active=true;}
 ~CurrentContext(){if(active){CUcontext c{};cuda.pop(&c);}}
};
struct Pipeline {
 ContextTransaction<ID3D11Multithread> transaction;
 ID3D11DeviceContext1* ctx; ComPtr<ID3DDeviceContextState> previous;
 Pipeline(ID3D11DeviceContext1* c,ID3DDeviceContextState* s,ID3D11Multithread* multithread):transaction(multithread),ctx(c){ctx->SwapDeviceContextState(s,&previous);}
 ~Pipeline(){ctx->SwapDeviceContextState(previous.Get(),nullptr);}
};
struct Mapped {
 std::array<CUgraphicsResource,4> resources; bool active{};
 explicit Mapped(std::array<CUgraphicsResource,4> r):resources(r){cu(cuda.map(4,resources.data(),nullptr),"cuGraphicsMapResources");active=true;}
 void close(){if(active){auto rc=cuda.unmap(4,resources.data(),nullptr);active=false;cu(rc,"cuGraphicsUnmapResources");}}
 ~Mapped(){if(active)cuda.unmap(4,resources.data(),nullptr);}
};
// Settings: environment variable first, else [RTX20] in nvsmooth30.ini beside
// the game executable, else the default.
std::wstring read_setting(const wchar_t* environment,const wchar_t* key,const wchar_t* fallback){
 wchar_t value[32]{};
 DWORD n=GetEnvironmentVariableW(environment,value,32);
 if(n&&n<32)return value;
 std::wstring module(32768,L'\0');n=GetModuleFileNameW(nullptr,module.data(),static_cast<DWORD>(module.size()));
 if(!n||n>=module.size())return fallback;
 module.resize(n);
 const auto ini=std::filesystem::path(module).parent_path()/L"nvsmooth30.ini";
 GetPrivateProfileStringW(L"RTX20",key,fallback,value,32,ini.c_str());
 return value;
}
bool setting_on(const std::wstring& value){
 return value==L"1"||_wcsicmp(value.c_str(),L"on")==0||_wcsicmp(value.c_str(),L"true")==0||_wcsicmp(value.c_str(),L"yes")==0;
}
FlowQuality read_quality_setting(){
 return parse_flow_quality(read_setting(L"SM86_FLOW_QUALITY",L"FlowQuality",L"auto").c_str());
}
double read_gpu_budget(){
 return parse_gpu_budget(read_setting(L"SM86_GPU_BUDGET",L"GpuBudget",L"auto").c_str());
}
FlowResolution read_flow_setting(){
 return parse_flow_resolution(read_setting(L"SM86_FLOW_RESOLUTION",L"FlowResolution",L"auto").c_str());
}
const char* flow_setting_name(FlowResolution setting){
 return setting==FlowResolution::full?"full":setting==FlowResolution::half?"half":"auto";
}
void copy_array(CUarray source,CUarray destination,unsigned widthBytes,unsigned height){
 if(!source||!destination)throw std::runtime_error("null CUDA array");
 CUDA_MEMCPY2D c{};c.srcMemoryType=CU_MEMORYTYPE_ARRAY;c.srcArray=source;
 c.dstMemoryType=CU_MEMORYTYPE_ARRAY;c.dstArray=destination;c.WidthInBytes=widthBytes;c.Height=height;
 cu(cuda.copy(&c),"cuMemcpy2D");
}
}
bool load_runtime(){
 std::call_once(loading,[]{
  cuda.module=LoadLibraryExW(L"nvcuda.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  cuda.optical=LoadLibraryExW(L"nvofapi64.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  cuda.compiler=LoadLibraryExW(L"d3dcompiler_47.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  if(!cuda.module||!cuda.optical||!cuda.compiler){cuda.status="missing_nvidia_driver_or_d3dcompiler47";return;}
  #define RESOLVE(member,name) cuda.member=reinterpret_cast<decltype(cuda.member)>(GetProcAddress(cuda.module,name));if(!cuda.member){cuda.status="missing_cuda_entry";return;}
  RESOLVE(init,"cuInit");RESOLVE(d3dDevice,"cuD3D11GetDevice");RESOLVE(attribute,"cuDeviceGetAttribute");
  RESOLVE(create,"cuCtxCreate_v2");RESOLVE(destroy,"cuCtxDestroy_v2");RESOLVE(push,"cuCtxPushCurrent_v2");RESOLVE(pop,"cuCtxPopCurrent_v2");
  RESOLVE(sync,"cuCtxSynchronize");RESOLVE(reg,"cuGraphicsD3D11RegisterResource");RESOLVE(unreg,"cuGraphicsUnregisterResource");
  RESOLVE(map,"cuGraphicsMapResources");RESOLVE(unmap,"cuGraphicsUnmapResources");RESOLVE(array,"cuGraphicsSubResourceGetMappedArray");RESOLVE(copy,"cuMemcpy2D_v2");
  #undef RESOLVE
  cuda.compile=reinterpret_cast<decltype(cuda.compile)>(GetProcAddress(cuda.compiler,"D3DCompile"));
  auto create=reinterpret_cast<decltype(&NvOFAPICreateInstanceCuda)>(GetProcAddress(cuda.optical,"NvOFAPICreateInstanceCuda"));
  if(!cuda.compile||cuda.init(0)!=0){cuda.status="runtime_initialization_failed";return;}
  cuda.cudaOfReady=create&&create(NV_OF_API_VERSION,&cuda.of)==NV_OF_SUCCESS&&
     cuda.of.nvCreateOpticalFlowCuda&&cuda.of.nvOFInit&&cuda.of.nvOFExecute&&cuda.of.nvOFGetCaps&&
     cuda.of.nvOFCreateGPUBufferCuda&&cuda.of.nvOFGPUBufferGetCUarray&&cuda.of.nvOFDestroyGPUBufferCuda&&cuda.of.nvOFDestroy;
  if(!cuda.cudaOfReady&&!NvofD3D11::available()){cuda.status="nvof_d3d11_api5_and_cuda_api2_unavailable";return;}
  cuda.loaded=true;cuda.status="ready_waiting_for_turing_d3d11_or_d3d12";
 });
 return cuda.loaded;
}
const char* runtime_status(){return cuda.status.load();}
bool exclusive_fullscreen_allowed(){
 static const bool allowed=setting_on(read_setting(L"SM86_EXCLUSIVE_FULLSCREEN",L"ExclusiveFullscreen",L"1"));
 return allowed;
}
struct Interpolator::Impl {
 std::unique_ptr<DX12Transfer> dx12;
 struct Texture {
  ComPtr<ID3D11Texture2D> texture;ComPtr<ID3D11ShaderResourceView> srv;ComPtr<ID3D11RenderTargetView> rtv;
  CUgraphicsResource graphics{};NvOFGPUBufferHandle ofBuffer{};bool inputReady{};
 } frames[2],flows[2],halfFrames[2],halfFlows[2],saved[2],projected,reprojected,generated,colors[2],overlayRaw,overlayNear;
 ComPtr<ID3D11Device> device;ComPtr<ID3D11Device1> device1;
 ComPtr<ID3D11DeviceContext> context;ComPtr<ID3D11DeviceContext1> context1;
 ComPtr<ID3D11Multithread> gameMultithread;
 ComPtr<ID3DDeviceContextState> pipeline;
 ComPtr<ID3D11VertexShader> vertex;ComPtr<ID3D11PixelShader> capture,project,synthesize,resolve,overlayMask,overlayGrow;
 ComPtr<ID3D11ShaderResourceView> snapshotViews[2];
 ComPtr<ID3D11SamplerState> sampler;ComPtr<ID3D11Buffer> constants,halfConstants;
 CUcontext cuContext{};NvOFHandle optical{};
 std::unique_ptr<NvofD3D11> nativeFlow,halfFlow,qualityFlow;
 // Half-resolution optical flow (native API5 only): a second NVOF session on
 // 2x2-averaged copies of the frames, selected per pair by use_half_flow().
 unsigned halfWidth{},halfHeight{};
 FlowResolution flowSetting{FlowResolution::automatic};
 bool halfMode{};
 // Full-resolution SLOW-preset session sharing the full-resolution textures.
 FlowQuality qualitySetting{FlowQuality::automatic};
 bool qualityMode{};
 // Flow mode actually used, chosen per pair within the GPU budget.
 FlowBudget budget;FlowMode flowMode{FlowMode::medium};
 // DX11 generated-frame visibility wait; skipped while GPU-bound (Fix20).
 VisibilityWait visibility;
 // DX11 multisampled backbuffer (Fix15): captured by resolving, written by
 // a draw (every sample receives the pixel) instead of CopyResource.
 bool msaa{},srgb{};ComPtr<ID3D11PixelShader> blit;
 // 10-bit SDR backbuffer (Fix16, e.g. God of War): optical flow still takes
 // the 8-bit BGRA copies, but synthesis and resolve read full-precision
 // copies (colors), so generated frames keep the game's 10-bit gradients
 // instead of banding against the real frames around them.
 bool deep{};
 // Display refresh (0 if unknown) and generated-frame presentation state.
 double refreshHz{};PresentationPolicy presentation;
 // Spaced presentation: the plan for the current Present; a two-slot ring of
 // captured real frames (the pipelined order restores the previous one);
 // whether the generated texture holds a pair still to be presented; and a
 // D3D11 event marking when the GPU reached the generated Present.
 PairPlan plan{};FrameRing ring;FrameRing::Step step{};
 bool pipelineAvailable{},pipelined{};
 ComPtr<ID3D11Query> shown;
 double lastSpacingLog{};unsigned loggedSpacingUs{};
 double frameInterval{};std::chrono::steady_clock::time_point lastAcceptedTime{};
 // Non-blocking GPU timestamps: capture, optical flow, synthesis.
 struct GpuTimer {ComPtr<ID3D11Query> disjoint;std::array<ComPtr<ID3D11Query>,4> stamps;bool pending{};FlowMode mode{FlowMode::medium};bool paired{};};
 std::array<GpuTimer,4> timers;unsigned timerSlot{};bool timersReady{};GpuTimer* pendingTimer{};
 unsigned width{},height{};DXGI_FORMAT format{};
 bool history{},captured{},generatedReady{},cudaFault{};
 std::uint64_t lastAccepted{};
 void texture(Texture& t,unsigned w,unsigned h,DXGI_FORMAT f,bool render,bool shader=true,unsigned extraBind=0){
  D3D11_TEXTURE2D_DESC d{};d.Width=w;d.Height=h;d.MipLevels=d.ArraySize=1;d.Format=f;d.SampleDesc.Count=1;d.Usage=D3D11_USAGE_DEFAULT;
  d.BindFlags=(shader?D3D11_BIND_SHADER_RESOURCE:0)|(render?D3D11_BIND_RENDER_TARGET:0)|extraBind;
  require(device->CreateTexture2D(&d,nullptr,&t.texture),"CreateTexture2D");
  if(shader)require(device->CreateShaderResourceView(t.texture.Get(),nullptr,&t.srv),"CreateSRV");
  if(render)require(device->CreateRenderTargetView(t.texture.Get(),nullptr,&t.rtv),"CreateRTV");
 }
 ComPtr<ID3DBlob> shader(const char* entry,const char* profile){
  ComPtr<ID3DBlob> code,error;auto hr=cuda.compile(shader_source,sizeof(shader_source)-1,"sm20.hlsl",nullptr,nullptr,entry,profile,D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);
  if(error)logf("[rtx20] shader %s: %s\n",entry,static_cast<const char*>(error->GetBufferPointer()));require(hr,"D3DCompile");return code;
 }
 void initialize(IDXGISwapChain* swap,ID3D12CommandQueue* queue){
  ComPtr<ID3D11Texture2D> back;
  if(queue){dx12=std::make_unique<DX12Transfer>();require(dx12->initialize(swap,queue),"DX12 transfer initialization");back=dx12->snapshot();device=dx12->device();}
  else{require(swap->GetBuffer(0,IID_PPV_ARGS(&back)),"D3D11 backbuffer");require(swap->GetDevice(IID_PPV_ARGS(&device)),"D3D11 device");}
  DXGI_SWAP_CHAIN_DESC chain{};require(swap->GetDesc(&chain),"GetDesc");
  D3D11_TEXTURE2D_DESC d{};back->GetDesc(&d);
  // Fix15: exclusive fullscreen (ExclusiveFullscreen=0 restores the Fix14
  // pass-through) and, for DX11, multisampled backbuffers are accepted.
  if(!chain.Windowed&&!exclusive_fullscreen_allowed())throw std::runtime_error("exclusive fullscreen disabled by ExclusiveFullscreen=0");
  if(d.SampleDesc.Count!=1&&queue)throw std::runtime_error("DX12 multisampled backbuffers are unsupported");
  if(!supported_format(d.Format)||!dimensions(d.Width,d.Height)){
   logf("[rtx20] Unsupported backbuffer: %ux%u format=%u (supported: RGBA8/BGRA8 UNORM or sRGB, RGB10A2 UNORM, 128..3840 x 128..2160).\n",d.Width,d.Height,unsigned(d.Format));
   throw std::runtime_error("requires RGBA8/BGRA8/RGB10A2 128..3840 x 128..2160");
  }
  msaa=!queue&&d.SampleDesc.Count>1;
  srgb=d.Format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB||d.Format==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB;
  deep=d.Format==DXGI_FORMAT_R10G10B10A2_UNORM;
  if(deep)logf("[rtx20] 10-bit SDR backbuffer (R10G10B10A2): optical flow on 8-bit copies, synthesis at full 10-bit precision. HDR output (PQ) is untested.\n");
  if(!chain.Windowed)logf("[rtx20] Exclusive fullscreen swapchain: interpolation enabled (ExclusiveFullscreen=0 passes it through).\n");
  if(msaa)logf("[rtx20] Multisampled DX11 backbuffer (%u samples): frames are resolved for capture and drawn back into every sample.\n",d.SampleDesc.Count);
  // sRGB transfer is preserved by treating both snapshots as UNORM bytes.
  // GetBuffer SRVs use the source format; explicit UNORM views below avoid a
  // decode/encode mismatch for sRGB swapchains.
  width=d.Width;height=d.Height;format=d.Format;
  ComPtr<IDXGIOutput> output;DXGI_OUTPUT_DESC outputDesc{};DEVMODEW mode{};mode.dmSize=sizeof mode;
  if(SUCCEEDED(swap->GetContainingOutput(&output))&&SUCCEEDED(output->GetDesc(&outputDesc))&&
     EnumDisplaySettingsW(outputDesc.DeviceName,ENUM_CURRENT_SETTINGS,&mode)){
   refreshHz=mode.dmDisplayFrequency>1?mode.dmDisplayFrequency:0;
   ComPtr<IDXGIAdapter> displayAdapter;DXGI_ADAPTER_DESC displayDesc{},renderDesc{};ComPtr<IDXGIDevice> renderDxgi;ComPtr<IDXGIAdapter> renderAdapter;
   if(SUCCEEDED(output->GetParent(IID_PPV_ARGS(&displayAdapter)))&&SUCCEEDED(displayAdapter->GetDesc(&displayDesc))&&
      SUCCEEDED(device.As(&renderDxgi))&&SUCCEEDED(renderDxgi->GetAdapter(&renderAdapter))&&SUCCEEDED(renderAdapter->GetDesc(&renderDesc))&&
      (displayDesc.AdapterLuid.LowPart!=renderDesc.AdapterLuid.LowPart||displayDesc.AdapterLuid.HighPart!=renderDesc.AdapterLuid.HighPart))
    logf("[rtx20] Display is driven by another adapter (%ls; hybrid laptop): every Present is copied across adapters, and generated frames double those copies. The guard pauses generation if it lowers the displayed rate.\n",displayDesc.Description);
   logf("[rtx20] Display: %ls %lux%lu refresh=%lu Hz; windowed=%u; generated frames presented per the presentation line below; no fixed FPS cap.\n",
        outputDesc.DeviceName,mode.dmPelsWidth,mode.dmPelsHeight,mode.dmDisplayFrequency,unsigned(chain.Windowed));
  }
  require(device.As(&device1),"D3D11.1 device");
  device->GetImmediateContext(&context);require(context.As(&context1),"D3D11.1 context");
  if(!dx12)context.As(&gameMultithread);
  ComPtr<IDXGIDevice> dxgi;ComPtr<IDXGIAdapter> adapter;require(device.As(&dxgi),"DXGI device");require(dxgi->GetAdapter(&adapter),"GetAdapter");
  DXGI_ADAPTER_DESC ad{};require(adapter->GetDesc(&ad),"AdapterDesc");
  if(ad.VendorId!=0x10de)throw std::runtime_error("selected game adapter is not NVIDIA");
  CUdevice gpu{};cu(cuda.d3dDevice(&gpu,adapter.Get()),"cuD3D11GetDevice");int major{},minor{};
  cu(cuda.attribute(&major,75,gpu),"compute major");cu(cuda.attribute(&minor,76,gpu),"compute minor");
  if(!supported_gpu(ad.VendorId,major,minor))throw std::runtime_error("requires Turing SM75 (RTX 20) or Ampere SM86 (RTX 30)");
  D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_1,D3D_FEATURE_LEVEL_11_0},selected{};
  require(device1->CreateDeviceContextState((device->GetCreationFlags()&D3D11_CREATE_DEVICE_SINGLETHREADED)?D3D11_1_CREATE_DEVICE_CONTEXT_STATE_SINGLETHREADED:0,levels,2,D3D11_SDK_VERSION,__uuidof(ID3D11Device),&selected,&pipeline),"CreateDeviceContextState");
  // NVIDIA's D3D11 ABGR8 buffer maps to BGRA8; CUDA2 still requires the
  // existing RGBA byte layout. Typed RTV/SRV access preserves shader colors.
  // Native inputs need RT+SRV only; BGRA typed UAV support is not assumed.
  // Both the DX12 bridge and DX11 game expose an owning immediate context.
  // Pipeline saves/restores game state and borrows its existing multithread
  // protection. Native OF therefore need not be restricted to the DX12 bridge.
  if(NvofD3D11::available()){
   try{
    for(auto& t:frames)texture(t,width,height,NvofD3D11::input_format(),true);
    for(auto& t:flows)texture(t,grid_extent(width),grid_extent(height),DXGI_FORMAT_R16G16_SINT,false,true,D3D11_BIND_RENDER_TARGET|D3D11_BIND_UNORDERED_ACCESS);
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    auto candidate=std::make_unique<NvofD3D11>();
    ID3D11Texture2D* input[]={frames[0].texture.Get(),frames[1].texture.Get()};
    ID3D11Texture2D* output[]={flows[0].texture.Get(),flows[1].texture.Get()};
    if(candidate->initialize(device.Get(),context.Get(),width,height,input,output))nativeFlow=std::move(candidate);
   }catch(const std::exception& e){
    logf("[rtx20-nvof] Native texture setup unavailable: %s; recreating RGBA8 CUDA inputs.\n",e.what());
   }
  }
  flowSetting=read_flow_setting();
  qualitySetting=read_quality_setting();
  budget.fraction=read_gpu_budget();
  performance::gpu_budget_permille=static_cast<unsigned>(budget.fraction*1000+0.5);
  if(budget.fraction>0)logf("[rtx20] GPU budget: frame generation may use %.0f%% of each real frame's time; SLOW, MEDIUM or half-resolution flow is chosen by measured cost (GpuBudget=0 disables the limit).\n",budget.fraction*100);
  else logf("[rtx20] GPU budget: unlimited (GpuBudget=0).\n");
  if(nativeFlow&&qualitySetting!=FlowQuality::medium){
   // Optional: failure (driver refuses SLOW or a second registration) leaves
   // MEDIUM in use.
   try{
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    auto candidate=std::make_unique<NvofD3D11>();
    ID3D11Texture2D* input[]={frames[0].texture.Get(),frames[1].texture.Get()};
    ID3D11Texture2D* output[]={flows[0].texture.Get(),flows[1].texture.Get()};
    if(candidate->initialize(device.Get(),context.Get(),width,height,input,output,true))qualityFlow=std::move(candidate);
   }catch(const std::exception& e){logf("[rtx20-nvof] High-quality flow unavailable: %s; MEDIUM only.\n",e.what());}
  }
  logf("[rtx20] flow_quality setting=%s; high-quality (SLOW preset) flow %s.\n",flow_quality_name(qualitySetting),
       !qualityFlow?"unavailable or disabled":qualitySetting==FlowQuality::high?"ready, always used at full resolution":"ready, automatic below 40 real FPS at full resolution");
  presentation.generateAboveRefresh=setting_on(read_setting(L"SM86_GENERATE_ABOVE_REFRESH",L"GenerateAboveRefresh",L"0"));
  presentation.pacing=parse_pacing(read_setting(L"SM86_PACING",L"Pacing",L"auto").c_str());
  presentation.refreshHz=refreshHz;
  presentation.minimumBase=parse_minimum_base(read_setting(L"SM86_MINIMUM_BASE_RATE",L"MinimumBaseRate",L"auto").c_str());
  performance::pacing_setting=pacing_name(presentation.pacing);
  logf("[rtx20] presentation: display %.0f Hz; pause when the real rate reaches it %s; Pacing=%s (auto/low_latency/smooth show each generated frame for half a real-frame interval).\n",refreshHz,
       presentation.generateAboveRefresh?"disabled (GenerateAboveRefresh=1)":"enabled",pacing_name(presentation.pacing));
  if(nativeFlow&&flowSetting!=FlowResolution::full){
   // Optional: failure leaves full-resolution flow in use.
   try{
    halfWidth=(width+1)/2;halfHeight=(height+1)/2;
    for(auto& t:halfFrames)texture(t,halfWidth,halfHeight,NvofD3D11::input_format(),true);
    for(auto& t:halfFlows)texture(t,grid_extent(halfWidth),grid_extent(halfHeight),DXGI_FORMAT_R16G16_SINT,false,true,D3D11_BIND_RENDER_TARGET|D3D11_BIND_UNORDERED_ACCESS);
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    auto candidate=std::make_unique<NvofD3D11>();
    ID3D11Texture2D* input[]={halfFrames[0].texture.Get(),halfFrames[1].texture.Get()};
    ID3D11Texture2D* output[]={halfFlows[0].texture.Get(),halfFlows[1].texture.Get()};
    if(candidate->initialize(device.Get(),context.Get(),halfWidth,halfHeight,input,output))halfFlow=std::move(candidate);
   }catch(const std::exception& e){
    logf("[rtx20-nvof] Half-resolution flow unavailable: %s; full resolution only.\n",e.what());
   }
   if(!halfFlow){for(auto& t:halfFrames)t=Texture{};for(auto& t:halfFlows)t=Texture{};}
  }
  if(!nativeFlow){
   // The unsuccessful candidate has unregistered all native resources before
   // entering this block. No capture or optical-flow execution has occurred.
   // Release both complete and partially allocated native sets before CUDA
   // registration, so BGRA bytes can never reach the RGBA CUDA copy path.
   for(auto& t:frames)t=Texture{};
   for(auto& t:flows)t=Texture{};
   for(auto& t:frames)texture(t,width,height,DXGI_FORMAT_R8G8B8A8_UNORM,true);
   for(auto& t:flows)texture(t,grid_extent(width),grid_extent(height),DXGI_FORMAT_R16G16_SINT,false);
   if(!cuda.cudaOfReady)throw std::runtime_error("native NVOF unavailable and CUDA API2 fallback missing");
  cu(cuda.create(&cuContext,4,gpu),"cuCtxCreate");CUcontext popped{};cu(cuda.pop(&popped),"cuCtxPopCurrent after create");
  CurrentContext current(cuContext);
  of(cuda.of.nvCreateOpticalFlowCuda(cuContext,&optical),"nvCreateOpticalFlowCuda");
  for(auto cap:{NV_OF_CAPS_WIDTH_MIN,NV_OF_CAPS_HEIGHT_MIN,NV_OF_CAPS_WIDTH_MAX,NV_OF_CAPS_HEIGHT_MAX}){
   std::uint32_t value{},size=1;of(cuda.of.nvOFGetCaps(optical,cap,&value,&size),"nvOFGetCaps");
   unsigned requested=(cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_WIDTH_MAX)?width:height;
   if((cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_HEIGHT_MIN)?requested<value:requested>value)throw std::runtime_error("dimensions outside NVOF capabilities");
  }
  NV_OF_INIT_PARAMS p{};p.width=width;p.height=height;p.outGridSize=NV_OF_OUTPUT_VECTOR_GRID_SIZE_4;p.mode=NV_OF_MODE_OPTICALFLOW;p.perfLevel=NV_OF_PERF_LEVEL_MEDIUM;
  of(cuda.of.nvOFInit(optical,&p),"nvOFInit");
  for(auto& t:frames){
   cu(cuda.reg(&t.graphics,t.texture.Get(),0),"register input D3D11 texture");
   NV_OF_BUFFER_DESCRIPTOR bd{width,height,NV_OF_BUFFER_USAGE_INPUT,NV_OF_BUFFER_FORMAT_ABGR8};
   of(cuda.of.nvOFCreateGPUBufferCuda(optical,&bd,NV_OF_CUDA_BUFFER_TYPE_CUARRAY,&t.ofBuffer),"allocate NVOF input");
  }
  for(auto& t:flows){
   cu(cuda.reg(&t.graphics,t.texture.Get(),0),"register flow D3D11 texture");
   NV_OF_BUFFER_DESCRIPTOR bd{grid_extent(width),grid_extent(height),NV_OF_BUFFER_USAGE_OUTPUT,NV_OF_BUFFER_FORMAT_SHORT2};
   of(cuda.of.nvOFCreateGPUBufferCuda(optical,&bd,NV_OF_CUDA_BUFFER_TYPE_CUARRAY,&t.ofBuffer),"allocate NVOF flow");
  }
   logf("[rtx20-nvof] nvof_api=CUDA API2 fallback ready: input_format=28 RGBA8, MEDIUM preset, cached previous input, bidirectional execute.\n");
  }
  DXGI_FORMAT plain=(format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB)?DXGI_FORMAT_R8G8B8A8_UNORM:(format==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB)?DXGI_FORMAT_B8G8R8A8_UNORM:format;
  if(dx12){
   for(unsigned i=0;i<dx12->slots();++i)require(device->CreateShaderResourceView(dx12->snapshot(i),nullptr,&snapshotViews[i]),"Create DX12 snapshot SRV");
   pipelineAvailable=dx12->slots()==2;
  }else if(msaa){
   // Resolve targets must share the backbuffer's format family; a typeless
   // texture with a UNORM view keeps sRGB bytes undecoded, as above.
   const DXGI_FORMAT typeless=(plain==DXGI_FORMAT_B8G8R8A8_UNORM)?DXGI_FORMAT_B8G8R8A8_TYPELESS:(plain==DXGI_FORMAT_R10G10B10A2_UNORM)?DXGI_FORMAT_R10G10B10A2_TYPELESS:DXGI_FORMAT_R8G8B8A8_TYPELESS;
   for(auto& t:saved){
    D3D11_TEXTURE2D_DESC td{};td.Width=width;td.Height=height;td.MipLevels=td.ArraySize=1;td.Format=typeless;td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
    require(device->CreateTexture2D(&td,nullptr,&t.texture),"CreateTexture2D(resolve)");
    D3D11_SHADER_RESOURCE_VIEW_DESC vd{};vd.Format=plain;vd.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D;vd.Texture2D.MipLevels=1;
    require(device->CreateShaderResourceView(t.texture.Get(),&vd,&t.srv),"CreateSRV(resolve)");
   }
   pipelineAvailable=true;
  }else{for(auto& t:saved)texture(t,width,height,plain,false);pipelineAvailable=true;}
  D3D11_QUERY_DESC shownDesc{D3D11_QUERY_EVENT,0};if(FAILED(device->CreateQuery(&shownDesc,&shown)))shown.Reset();
  // Grid of the two distinct motions crossing each 4x4 cell at the midpoint.
  texture(projected,grid_extent(width),grid_extent(height),DXGI_FORMAT_R32G32B32A32_FLOAT,true);
  texture(reprojected,width,height,DXGI_FORMAT_R16G16B16A16_FLOAT,true);
  // Static overlay masks (Fix19): raw, and grown by two pixels.
  texture(overlayRaw,width,height,DXGI_FORMAT_R8_UNORM,true);texture(overlayNear,width,height,DXGI_FORMAT_R8_UNORM,true);
  texture(generated,width,height,plain,true);
  if(deep)for(auto& t:colors)texture(t,width,height,DXGI_FORMAT_R10G10B10A2_UNORM,false);
  auto vs=shader("Fullscreen","vs_5_0"),ps=shader("Capture","ps_5_0"),js=shader("Project","ps_5_0"),ms=shader("Synthesize","ps_5_0"),rs=shader("Resolve","ps_5_0");
  require(device->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,&vertex),"CreateVertexShader");
  require(device->CreatePixelShader(ps->GetBufferPointer(),ps->GetBufferSize(),nullptr,&capture),"CreateCaptureShader");
  require(device->CreatePixelShader(js->GetBufferPointer(),js->GetBufferSize(),nullptr,&project),"CreateProjectionShader");
  require(device->CreatePixelShader(ms->GetBufferPointer(),ms->GetBufferSize(),nullptr,&synthesize),"CreateSynthesisShader");
  require(device->CreatePixelShader(rs->GetBufferPointer(),rs->GetBufferSize(),nullptr,&resolve),"CreateResolveShader");
  auto os=shader("OverlayMask","ps_5_0"),gs=shader("OverlayGrow","ps_5_0");
  require(device->CreatePixelShader(os->GetBufferPointer(),os->GetBufferSize(),nullptr,&overlayMask),"CreateOverlayMaskShader");
  require(device->CreatePixelShader(gs->GetBufferPointer(),gs->GetBufferSize(),nullptr,&overlayGrow),"CreateOverlayGrowShader");
  if(msaa){auto bs=shader(srgb?"BlitSrgb":"Blit","ps_5_0");require(device->CreatePixelShader(bs->GetBufferPointer(),bs->GetBufferSize(),nullptr,&blit),"CreateBlitShader");}
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;sd.ComparisonFunc=D3D11_COMPARISON_NEVER;
  require(device->CreateSamplerState(&sd,&sampler),"CreateSamplerState");
  // ImageSize, InvImageSize, FlowBlock (output pixels per flow cell), FlowGain.
  float settings[]={float(width),float(height),1.f/width,1.f/height,4.f,1.f/32,0,0};D3D11_BUFFER_DESC cb{};cb.ByteWidth=sizeof settings;cb.Usage=D3D11_USAGE_IMMUTABLE;cb.BindFlags=D3D11_BIND_CONSTANT_BUFFER;D3D11_SUBRESOURCE_DATA data{settings,0,0};
  require(device->CreateBuffer(&cb,&data,&constants),"CreateConstantBuffer");
  if(halfFlow){settings[4]=8.f;settings[5]=2.f/32;require(device->CreateBuffer(&cb,&data,&halfConstants),"CreateConstantBuffer(half flow)");}
  D3D11_QUERY_DESC disjointDesc{D3D11_QUERY_TIMESTAMP_DISJOINT,0},stampDesc{D3D11_QUERY_TIMESTAMP,0};timersReady=true;
  for(auto& t:timers){
   if(FAILED(device->CreateQuery(&disjointDesc,&t.disjoint)))timersReady=false;
   for(auto& q:t.stamps)if(FAILED(device->CreateQuery(&stampDesc,&q)))timersReady=false;
  }
  logf("[rtx20] flow_resolution setting=%s; half-resolution flow %s%s.\n",flow_setting_name(flowSetting),halfFlow?"ready ":"unavailable",
       halfFlow?(std::to_string(halfWidth)+"x"+std::to_string(halfHeight)+" (8-pixel cells), automatic above "+std::to_string(int(half_flow_enter_fps))+" real FPS").c_str():"");
  logf("[rtx20] %s backend ready: adapter=%ls SM%d%d %ux%u; NVOF %s MEDIUM/SLOW presets, bidirectional flow, 2x SDR synthesis; artifact_guard=occlusion_aware_v7 (static overlay mask for crosshairs/HUD, flat-region fill and fast path, two-frame HUD contrast, exposure gain matching, validated occlusion fill, thin-object and crossing-line motion, sharp resampling, motion-guided midpoint projection up to 256 px, HUD overlay and stationary-detail protection). Display output remains unverified.\n",major==8?"Ampere":"Turing",ad.Description,major,minor,width,height,nativeFlow?"D3D11 API5":"CUDA API2");
 }
 bool quiesce(){
  if(cudaFault)return false;
  if(dx12&&!dx12->quiesce())return false;
  ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
  const bool full=!nativeFlow||nativeFlow->quiesce();
  const bool half=!halfFlow||halfFlow->quiesce();
  const bool quality=!qualityFlow||qualityFlow->quiesce();
  return full&&half&&quality;
 }
 // Read finished timestamp sets without waiting; unfinished sets stay pending.
 void collect_timers(){
  for(auto& t:timers){
   if(!t.pending)continue;
   D3D11_QUERY_DATA_TIMESTAMP_DISJOINT d{};
   if(context->GetData(t.disjoint.Get(),&d,sizeof d,D3D11_ASYNC_GETDATA_DONOTFLUSH)!=S_OK)continue;
   UINT64 stamp[4]{};bool ready=true;
   for(unsigned i=0;i<4&&ready;++i)ready=context->GetData(t.stamps[i].Get(),&stamp[i],sizeof stamp[i],D3D11_ASYNC_GETDATA_DONOTFLUSH)==S_OK;
   if(!ready)continue;
   t.pending=false;
   if(d.Disjoint||!d.Frequency)continue;
   auto us=[&](unsigned a,unsigned b){return stamp[b]>stamp[a]?(stamp[b]-stamp[a])*1000000ull/d.Frequency:0ull;};
   performance::add_gpu(performance::GpuPhase::capture,us(0,1));
   performance::add_gpu(performance::GpuPhase::optical_flow,us(1,2));
   performance::add_gpu(performance::GpuPhase::synthesis,us(2,3));
   // Optical flow runs on its own engine and synthesis waits for it, so only
   // the sum is a reliable per-pair cost.
   if(t.paired){budget.observe(t.mode,double(us(1,2)+us(2,3))/1e6,pacing::now());publish_budget();}
  }
 }
 void publish_budget(){
  auto us=[&](FlowMode m){const double e=budget.estimate[FlowBudget::index(m)];return e>0?static_cast<unsigned>(e*1e6):0u;};
  performance::pair_gpu_us_slow=us(FlowMode::slow);performance::pair_gpu_us_medium=us(FlowMode::medium);performance::pair_gpu_us_half=us(FlowMode::half);
 }
 void stamp(GpuTimer* timer,unsigned index){
  if(!timer)return;
  ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
  context->End(timer->stamps[index].Get());
  if(index==3){context->End(timer->disjoint.Get());timer->pending=true;}
 }
 void draw(ID3D11PixelShader* ps,ID3D11RenderTargetView* target,const std::array<ID3D11ShaderResourceView*,8>& srvs,unsigned targetWidth=0,unsigned targetHeight=0,ID3D11Buffer* settings=nullptr){
  // Protect swap/draw/restore as one transaction if the game already enabled
  // multithread protection. The private DX12 context and CUDA waits are outside.
  Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
  context->ClearState();
  context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  context->VSSetShader(vertex.Get(),nullptr,0);context->PSSetShader(ps,nullptr,0);
  context->PSSetShaderResources(0,static_cast<UINT>(srvs.size()),srvs.data());auto s=sampler.Get();context->PSSetSamplers(0,1,&s);
  auto cb=settings?settings:constants.Get();context->PSSetConstantBuffers(0,1,&cb);
  D3D11_VIEWPORT vp{0,0,float(targetWidth?targetWidth:width),float(targetHeight?targetHeight:height),0,1};context->RSSetViewports(1,&vp);context->OMSetRenderTargets(1,&target,nullptr);
  context->Draw(3,0);context->ClearState();
 }
 void log_presentation(Presentation before,double realFps){
  const auto state=presentation.state;
  const unsigned wait=static_cast<unsigned>(presentation.wait_seconds()*1e6);
  performance::presentation_state=presentation_name(state);
  performance::reference_us=presentation.reference>0?static_cast<unsigned>(presentation.reference*1e6):0;
  performance::spacing_us=wait;
  const double now=pacing::now();
  const double reference=presentation.reference>0?1/presentation.reference:0,ideal=presentation.ideal()*1000;
  if(state!=before){
   logf("[rtx20] presentation=%s at %.0f real FPS, %.0f Hz display%s.\n",presentation_name(state),realFps,refreshHz,
        state==Presentation::native?"; measuring the game's own rate without generation":
        state==Presentation::paused&&presentation.counterproductive?"; generation lowered the displayed rate (see the guard line)":
        state==Presentation::paused?"; generated frames would not be visible (GenerateAboveRefresh=1 overrides)":
        state==Presentation::timed?"; generated frame, then the real frame half a real-frame interval later":
        state==Presentation::pipelined?"; previous pair shown with even spacing while the next pair is computed (one real frame more latency)":
        state==Presentation::vblank?"; generated and real frame on consecutive refreshes":"");
   if(presentation.spaced())logf("[rtx20] spacing: reference %.1f real FPS, wait %.1f ms (ideal %.1f ms).\n",reference,wait/1000.0,ideal);
   if(state==Presentation::measuring&&before==Presentation::native)logf("[rtx20] native rate: %.1f FPS without generation.\n",presentation.nativeFps);
   if(state==Presentation::paused&&presentation.counterproductive)
    logf("[rtx20] guard: generation paused; %.0f real / %.0f displayed FPS with it vs %.0f native (needs %.0f%% more displayed and at least %.0f%% of native real, MinimumBaseRate). Retry in %.0f s or when the game gets much slower (GenerateAboveRefresh=1 disables the guard).\n",
         presentation.lastReal,presentation.lastDisplayed,presentation.displayed(presentation.nativeFps),(PresentationPolicy::minimum_gain-1)*100,presentation.minimumBase*100,presentation.pausedUntil-now);
   lastSpacingLog=now;loggedSpacingUs=wait;
  }else if(presentation.spaced()&&now-lastSpacingLog>=10){
   const unsigned change=wait>loggedSpacingUs?wait-loggedSpacingUs:loggedSpacingUs-wait;
   if(change>1000&&change*5>loggedSpacingUs){
    logf("[rtx20] spacing: wait %.1f ms (%.0f%% of ideal %.1f ms) at %.1f real FPS, reference %.1f.\n",wait/1000.0,presentation.spacing()*100,ideal,realFps,reference);
    lastSpacingLog=now;loggedSpacingUs=wait;
   }
  }
 }
 // Capture the real frame into the next slot and decide this Present's plan.
 // Timed (and unspaced) presentation also computes the pair here; the
 // pipelined order computes the next pair in after_generated().
 bool prepare(IDXGISwapChain* swap,unsigned sync){
  const bool vsync=sync!=0;
  plan=PairPlan{};
  const double realFps=frameInterval>0?1/frameInterval:0;
  const auto before=presentation.state;
  presentation.update(pacing::now(),realFps,!vsync);
  log_presentation(before,realFps);
  const bool fresh=history&&fresh_history(lastAccepted,GetTickCount64());
  if(fresh&&presentation.state==Presentation::paused)++performance::paused_frames;
  performance::native_fps_x10=static_cast<unsigned>(presentation.nativeFps*10+0.5);performance::guard_pauses=presentation.pauses;
  const bool interpolating=fresh&&presentation.generating();
  const bool pipe=pipelineAvailable&&presentation.pipelined()&&!vsync;
  if(pipe!=pipelined){pipelined=pipe;ring.reset();}
  step=ring.begin(pipelined,fresh,interpolating,pipelineAvailable);
  const unsigned slot=step.capture;
  captured=generatedReady=false;
  ComPtr<ID3D11Texture2D> back;
  if(dx12){performance::Scope timing(performance::Phase::capture);require(dx12->capture(swap,slot),"DX12 snapshot");back=dx12->snapshot(slot);}
  else require(swap->GetBuffer(0,IID_PPV_ARGS(&back)),"GetBuffer");
  D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);
  if(desc.Width!=width||desc.Height!=height||desc.Format!=format)throw std::runtime_error("swapchain changed without resize notification");
  // The pipelined order computes later (after_generated), which may not
  // happen; its timer starts there instead.
  GpuTimer* timer=nullptr;
  if(timersReady&&interpolating&&!pipelined){
   ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
   collect_timers();
   auto& t=timers[timerSlot%timers.size()];
   if(!t.pending){timer=&t;timer->paired=false;++timerSlot;context->Begin(t.disjoint.Get());context->End(t.stamps[0].Get());}
  }
  if(dx12)dx12->mark_d3d11_work();
  if(!dx12){
   if(msaa)context->ResolveSubresource(saved[slot].texture.Get(),0,back.Get(),0,format);
   else context->CopyResource(saved[slot].texture.Get(),back.Get());
  }
  draw(capture.Get(),frames[1].rtv.Get(),{dx12?snapshotViews[slot].Get():saved[slot].srv.Get(),nullptr,nullptr,nullptr,nullptr,nullptr});
  // The half-resolution copy is kept current every frame so either flow
  // resolution has valid history; a 2x2 box average via one bilinear tap.
  if(halfFlow)draw(capture.Get(),halfFrames[1].rtv.Get(),{frames[1].srv.Get(),nullptr,nullptr,nullptr,nullptr,nullptr},halfWidth,halfHeight);
  // Same bytes as the backbuffer (typeless MSAA resolve targets included).
  if(deep)context->CopyResource(colors[1].texture.Get(),dx12?dx12->snapshot(slot):saved[slot].texture.Get());
  frames[1].inputReady=false;captured=true;ring.captured();
  stamp(timer,1);
  const double wait=vsync?0:presentation.wait_seconds();
  plan.paced=presentation.paced()||(presentation.spaced()&&vsync);
  if(plan.paced){const auto intervals=paired_intervals(sync);plan.generatedInterval=intervals.generated;plan.realInterval=intervals.real;}
  if(pipelined){
   // Present the pair computed at the previous Present (its generated frame,
   // then that real frame); the next pair is computed during the wait.
   plan.restore=step.restoreReal;plan.generated=step.generated;plan.compute=step.compute;
   plan.spacing=plan.generated?wait:0;
   generatedReady=plan.generated;pendingTimer=timer;
   if(plan.generated)++performance::pipelined_pairs;
   return plan.generated;
  }
  if(!interpolating)return false;
  compute_pair(timer,false);
  plan.generated=true;plan.spacing=presentation.spaced()?wait:0;
  if(plan.spacing>0)++performance::timed_pairs;
  if(plan.paced)++performance::paced_pairs;
  return true;
 }
 // Optical flow and synthesis of the pair (frames[0], frames[1]).
 void compute_pair(GpuTimer* timer,bool restamp){
  if(restamp&&!timer&&timersReady){
   ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
   collect_timers();
   auto& t=timers[timerSlot%timers.size()];
   if(!t.pending){timer=&t;++timerSlot;context->Begin(t.disjoint.Get());context->End(t.stamps[0].Get());}
  }
  if(restamp)stamp(timer,1);
  if(dx12)dx12->mark_d3d11_work();
  // Flow rules follow the game's own rate when it is known: a rate lowered
  // by generation itself must not select the slower SLOW preset (Fix17).
  const double fps=std::max(frameInterval>0?1/frameInterval:0.0,presentation.nativeFps);
  const FlowMode mode=nativeFlow?choose_flow_mode(flowSetting,halfFlow!=nullptr,qualitySetting,qualityFlow!=nullptr,flowMode,fps,frameInterval,budget,pacing::now()):FlowMode::medium;
  if(mode!=flowMode){
   auto ms=[&](FlowMode m){const double e=budget.estimate[FlowBudget::index(m)];return e>0?e*1000:0.0;};
   logf("[rtx20] flow=%s at %.0f real FPS (resolution=%s quality=%s; GPU per pair: SLOW %.1f ms, MEDIUM %.1f ms, half %.1f ms (0 = not measured yet); budget %.1f ms).\n",
        flow_mode_name(mode),fps,flow_setting_name(flowSetting),flow_quality_name(qualitySetting),ms(FlowMode::slow),ms(FlowMode::medium),ms(FlowMode::half),budget.limit(frameInterval)*1000);
   flowMode=mode;
  }
  halfMode=mode==FlowMode::half;qualityMode=mode==FlowMode::slow;
  performance::flow_mode=flow_mode_name(mode);
  if(timer){timer->mode=mode;timer->paired=true;}
  if(!nativeFlow)context->Flush();
  try{
   performance::Scope timing(performance::Phase::optical_flow);
   if(nativeFlow){
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    if(halfMode){
     ID3D11Texture2D* output[]={halfFlows[0].texture.Get(),halfFlows[1].texture.Get()};
     require(halfFlow->execute(halfFrames[0].texture.Get(),halfFrames[1].texture.Get(),output),"native D3D11 NVOF execute (half resolution)");
    }else{
     ID3D11Texture2D* output[]={flows[0].texture.Get(),flows[1].texture.Get()};
     auto& session=qualityMode?qualityFlow:nativeFlow;
     require(session->execute(frames[0].texture.Get(),frames[1].texture.Get(),output),qualityMode?"native D3D11 NVOF execute (SLOW)":"native D3D11 NVOF execute");
    }
   }else{
   CurrentContext current(cuContext);
   Mapped map({frames[0].graphics,frames[1].graphics,flows[0].graphics,flows[1].graphics});
   CUarray images[4]{};for(unsigned i=0;i<4;++i)cu(cuda.array(images+i,map.resources[i],0,0),"get mapped CUDA array");
   for(unsigned i=0;i<2;++i)if(!frames[i].inputReady){
    copy_array(images[i],cuda.of.nvOFGPUBufferGetCUarray(frames[i].ofBuffer),width*4,height);frames[i].inputReady=true;
   }
   for(unsigned direction=0;direction<2;++direction){
    NV_OF_EXECUTE_INPUT_PARAMS in{};in.inputFrame=frames[direction].ofBuffer;in.referenceFrame=frames[1-direction].ofBuffer;in.disableTemporalHints=NV_OF_TRUE;
    NV_OF_EXECUTE_OUTPUT_PARAMS out{};out.outputBuffer=flows[direction].ofBuffer;
    of(cuda.of.nvOFExecute(optical,&in,&out),"nvOFExecute");
   }
   cu(cuda.sync(),"NVOF completion");
   for(unsigned i=0;i<2;++i)copy_array(cuda.of.nvOFGPUBufferGetCUarray(flows[i].ofBuffer),images[i+2],grid_extent(width)*4,grid_extent(height));
   // cuGraphicsUnmapResources orders prior CUDA work before subsequent D3D11
   // work. An extra context-wide CPU synchronization after unmap is redundant.
   map.close();
   }
   ++flow_pairs;++(halfMode?performance::half_flow_pairs:performance::full_flow_pairs);
   if(qualityMode&&!halfMode)++performance::quality_flow_pairs;
  }catch(...){cudaFault=true;throw;}
  stamp(timer,2);
  {performance::Scope timing(performance::Phase::synthesis);
   const auto& flow=halfMode?halfFlows:flows;
   ID3D11Buffer* settings=halfMode?halfConstants.Get():constants.Get();
   const unsigned gridWidth=grid_extent(halfMode?halfWidth:width),gridHeight=grid_extent(halfMode?halfHeight:height);
   draw(project.Get(),projected.rtv.Get(),{nullptr,nullptr,flow[0].srv.Get(),flow[1].srv.Get(),nullptr,nullptr},gridWidth,gridHeight,settings);
   const auto& color=deep?colors:frames;
   draw(overlayMask.Get(),overlayRaw.rtv.Get(),{color[0].srv.Get(),color[1].srv.Get(),flow[0].srv.Get(),flow[1].srv.Get(),nullptr,nullptr,nullptr,nullptr},0,0,settings);
   draw(overlayGrow.Get(),overlayNear.rtv.Get(),{nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,overlayRaw.srv.Get(),nullptr},0,0,settings);
   draw(synthesize.Get(),reprojected.rtv.Get(),{color[0].srv.Get(),color[1].srv.Get(),flow[0].srv.Get(),flow[1].srv.Get(),nullptr,projected.srv.Get(),overlayRaw.srv.Get(),overlayNear.srv.Get()},0,0,settings);
   draw(resolve.Get(),generated.rtv.Get(),{color[0].srv.Get(),color[1].srv.Get(),nullptr,nullptr,reprojected.srv.Get(),nullptr},0,0,settings);}
  stamp(timer,3);
  generatedReady=true;
 }
 // After the generated Present (or its queue-busy skip): compute the next pair
 // in the pipelined order and return when the generated frame became visible
 // (steady-clock seconds), or -1 when none was shown.
 double after_generated(bool shownOk){
  double visible=shownOk?pacing::now():-1;
  bool marked=false;
  // Only a spaced pair needs the visibility time; unspaced and VSync-paired
  // presentation must not wait for the GPU here.
  if(shownOk&&!dx12&&shown&&plan.spacing>0&&visibility.measure_now()){
   // DX11 work is queued: the generated frame appears when the GPU reaches
   // its Present. DX12 copies completed before the Present.
   ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
   context->End(shown.Get());context->Flush();marked=true;
  }
  if(pipelined&&plan.compute){
   compute_pair(pendingTimer,true);pendingTimer=nullptr;ring.computed();
   // Start the GPU work now; it runs during the spacing wait.
   ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());context->Flush();
  }
  if(marked){
   const double start=pacing::now();
   for(;;){
    BOOL done=FALSE;HRESULT hr;
    {ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());hr=context->GetData(shown.Get(),&done,sizeof done,D3D11_ASYNC_GETDATA_DONOTFLUSH);}
    if(FAILED(hr)||(hr==S_OK&&done)||pacing::now()-start>0.05)break;
    SwitchToThread();
   }
   visible=pacing::now();
   if(visibility.observe(visible-start))
    logf(visibility.skipping?"[rtx20] GPU-bound: waiting for the GPU to show the generated frame averaged %.1f ms and stalled the game; spacing is now timed from the Present call (re-checked every %u pairs).\n":
                             "[rtx20] No longer GPU-bound (visibility wait %.1f ms): spacing timed from GPU visibility again (every %u pairs).\n",visibility.average*1000,VisibilityWait::probe_every);
  }
  return visible;
 }
 bool write(IDXGISwapChain* swap,Texture& source){
  ComPtr<ID3D11Texture2D> back;if(FAILED(swap->GetBuffer(0,IID_PPV_ARGS(&back))))return false;
  if(msaa){
   // No view or buffer reference outlives this call: ResizeBuffers requires
   // every backbuffer reference to be released.
   ComPtr<ID3D11RenderTargetView> view;D3D11_RENDER_TARGET_VIEW_DESC vd{};vd.Format=format;vd.ViewDimension=D3D11_RTV_DIMENSION_TEXTURE2DMS;
   if(FAILED(device->CreateRenderTargetView(back.Get(),&vd,&view)))return false;
   draw(blit.Get(),view.Get(),{source.srv.Get(),nullptr,nullptr,nullptr,nullptr,nullptr});
  }else context->CopyResource(back.Get(),source.texture.Get());
  return SUCCEEDED(device->GetDeviceRemovedReason());
 }
 ~Impl(){
  if(!cuContext)return;
  if(cuda.push(cuContext)==0){
   for(auto& t:frames){if(t.graphics)cuda.unreg(t.graphics);if(t.ofBuffer)cuda.of.nvOFDestroyGPUBufferCuda(t.ofBuffer);}
   for(auto& t:flows){if(t.graphics)cuda.unreg(t.graphics);if(t.ofBuffer)cuda.of.nvOFDestroyGPUBufferCuda(t.ofBuffer);}
   if(optical)cuda.of.nvOFDestroy(optical);CUcontext old{};cuda.pop(&old);
  }
  cuda.destroy(cuContext);
 }
};
Interpolator::Interpolator()=default;
Interpolator::~Interpolator(){reset(false);}
void Interpolator::reset(bool retry){
 // On a CUDA failure the driver's ownership of resources is uncertain. Keep a
 // single failed session alive until process exit; never reuse it.
 if(impl_&&!impl_->quiesce()){
  // A timeout after submission is not safe passthrough: the game buffer may
  // still be referenced by queued work. Keep the complete session alive.
  if(impl_->dx12&&impl_->dx12->uncertain())terminal_=DXGI_ERROR_DEVICE_RESET;
  (void)impl_.release();failed_=retryBlocked_=true;return;
 }
 impl_.reset();
 if(retry&&!terminal_&&!retryBlocked_)failed_=false;
}
bool Interpolator::prepare(IDXGISwapChain* swap,ID3D12CommandQueue* queue,unsigned sync){
 if(deferredFailure_){deferredFailure_=false;failed_=true;reset(false);return false;}
 if(failed_||!load_runtime())return false;
 try{
  if(!impl_){impl_=std::make_unique<Impl>();impl_->initialize(swap,queue);}
  return impl_->prepare(swap,sync);
 }catch(const std::exception& e){++failures;logf("[rtx20] Session disabled: %s; fallback is allowed only after completed GPU work.\n",e.what());failed_=true;reset(false);return false;}
 catch(...){++failures;failed_=true;reset(false);return false;}
}
double Interpolator::after_generated(bool shown){
 if(!impl_||failed_)return -1;
 try{return impl_->after_generated(shown);}
 // Keep the session until the real frame is restored; disable it at the next
 // Present (resources are released only after completed GPU work).
 catch(const std::exception& e){++failures;deferredFailure_=true;impl_->ring.pending=false;logf("[rtx20] Pair computation failed: %s; session disabled after this Present.\n",e.what());return -1;}
 catch(...){++failures;deferredFailure_=true;impl_->ring.pending=false;return -1;}
}
bool Interpolator::write(IDXGISwapChain* s,bool generated){
 if(!impl_||failed_)return false;
 // The pipelined order restores the real frame captured at the previous Present.
 const unsigned source=impl_->step.restore;
 if(generated?!impl_->generatedReady:!(impl_->captured&&impl_->ring.valid[source&1u]))return false;
 const auto hr=impl_->dx12?(generated?impl_->dx12->write_generated(s,impl_->generated.texture.Get()):impl_->dx12->write_original(s,source)):
     (impl_->write(s,generated?impl_->generated:impl_->saved[source&1u])?S_OK:DXGI_ERROR_DEVICE_RESET);
 if(SUCCEEDED(hr))return true;
 ++failures;failed_=true;
 if(!generated||!impl_->dx12||impl_->dx12->uncertain())terminal_=DXGI_ERROR_DEVICE_RESET;
 logf("[rtx20] %s copy failed hr=0x%08lx terminal=0x%08lx.\n",generated?"generated":"original",(unsigned long)hr,(unsigned long)terminal_);
 reset(false);return false;
}
bool Interpolator::write_generated(IDXGISwapChain* s){return write(s,true);}
bool Interpolator::write_original(IDXGISwapChain* s){return write(s,false);}
void Interpolator::accepted(){
 if(!impl_||!impl_->captured)return;
 std::swap(impl_->frames[0],impl_->frames[1]);std::swap(impl_->halfFrames[0],impl_->halfFrames[1]);std::swap(impl_->colors[0],impl_->colors[1]);
 impl_->history=true;impl_->captured=false;impl_->lastAccepted=GetTickCount64();
 const auto now=std::chrono::steady_clock::now();
 if(impl_->lastAcceptedTime.time_since_epoch().count())
  impl_->frameInterval=update_frame_interval(impl_->frameInterval,std::chrono::duration<double>(now-impl_->lastAcceptedTime).count());
 impl_->lastAcceptedTime=now;
}
void Interpolator::break_pipeline(){if(impl_){impl_->ring.reset();}}
void Interpolator::discard_history(){
 if(!impl_)return;
 impl_->history=impl_->captured=impl_->generatedReady=false;impl_->ring.reset();impl_->plan=PairPlan{};
 impl_->presentation.reset();
}
bool Interpolator::ready()const{return impl_&&!failed_;}
PairPlan Interpolator::plan()const{return impl_&&!failed_?impl_->plan:PairPlan{};}
}
