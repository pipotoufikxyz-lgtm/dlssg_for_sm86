#!/usr/bin/env python3
import argparse,pathlib,subprocess,hashlib,sys,zipfile
r=pathlib.Path(__file__).resolve().parents[1]
archive_root='SmoothMotion-2.8.4-RTX20-RTX30-DX12-Preview2-Fix21-Test'
p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
subprocess.run([sys.executable,str(r/'source/rtx20/verify.py')],check=True)
files=[f for f in sorted(r.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.name!='SHA256SUMS.txt']
manifest=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(r))+'\n' for f in files)
(r/'SHA256SUMS.txt').write_text(manifest);files.append(r/'SHA256SUMS.txt')
a.output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,archive_root+'/'+str(f.relative_to(r)))
with zipfile.ZipFile(a.output) as z:
 assert z.testzip() is None
 for line in manifest.splitlines():
  digest,relative=line.split('  ',1);assert hashlib.sha256(z.read(archive_root+'/'+relative)).hexdigest()==digest,relative
print(a.output, a.output.stat().st_size, 'bytes; archive checksums PASS')
