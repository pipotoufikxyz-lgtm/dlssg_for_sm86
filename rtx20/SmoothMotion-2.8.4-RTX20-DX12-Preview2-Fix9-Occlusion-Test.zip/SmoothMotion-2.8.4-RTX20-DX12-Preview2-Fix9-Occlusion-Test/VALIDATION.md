# Fix9 validation and limits

All results below refer to the current Fix9 sources. Reports contain source and
binary hashes; the package verifier rejects stale reports and carriers.

- Five HLSL entry points (`Fullscreen`, `Capture`, `Project`, `Synthesize`,
  `Resolve`) pass glslang syntax compilation to SPIR-V. During development they
  also compiled cleanly with Microsoft DXC 1.8.2407 in strict mode (`-Ges`) for
  HLSL 2016 and 2021 (DXIL). Runtime DXBC compilation uses Windows D3DCompiler47
  and has not been executed here: run `Test/ShaderCheck.exe`.
- Thirteen shader behavior groups pass in optimized and ASan/UBSan host builds.
  Tests execute the production HLSL function bodies after syntax-only C++
  translation. The model uses bilinear sampling, the midpoint projection pass and
  half-float intermediate rounding. Groups:
  - identity/alpha;
  - analytical translations, requiring more than 95% lower midpoint error than
    copying the current frame;
  - thin static HUD strokes under wrong background flow;
  - a newly appearing object that must stay intact, without current-frame
    margins;
  - chromatic cuts, extreme motion and nonreciprocal flow;
  - exact border midpoints;
  - isolated confidence islands and continuous fallback weights;
  - corrupted flow on odd-sized grids.
- Two groups are new. Four parallax cases move an antialiased textured object
  and background in different directions with NVOF-like 4x4 block vectors,
  checked against the rendered true midpoint. Fix9 has 164–395 visibly wrong
  pixels (>0.12) of 13,824 per case, and midpoint RMSE is 15–27% of copying the
  current frame. Fix8 fails the same limits with 791–1515 wrong pixels. In a
  3.5-pixel crossing pole, 184/184 midpoint pole pixels are visible; Fix8 shows
  0/184.
- Fix8 required the current frame on screen borders and in a 2-pixel margin
  around a new object. Those expectations were replaced with exact midpoint (or
  feathered midpoint/current) expectations, because that margin policy produced
  the reported blocks. The new object must still stay intact.
- The 21 inherited host suites run in optimized and full ASan/UBSan builds (42
  executions, all PASS; `validation/host-tests.json`).
- Nine Windows x64 PE/PDB pairs, runtime source/binary hashes, embedded shader
  bytes, private NVIDIA header provenance, installer payloads, Manager helper
  hashes, and all manual/test carrier copies are checked by the package verifier.
- The completed ZIP is read back and every file is checked against SHA256SUMS.

These checks do not execute NVIDIA optical flow, Direct3D, DXGI presentation or
the game. They do not establish FPS, GPU cost, latency, display cadence or
complete artifact removal. Run `Test/ShaderCheck.exe` and compare F11 off/on
in-game.
