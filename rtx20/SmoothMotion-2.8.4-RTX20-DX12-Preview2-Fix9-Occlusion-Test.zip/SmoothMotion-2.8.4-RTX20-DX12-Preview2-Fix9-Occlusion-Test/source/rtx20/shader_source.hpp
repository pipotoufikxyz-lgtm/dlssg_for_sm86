#pragma once
inline constexpr char shader_source[]=R"SM20HLSL(
Texture2D<float4> Previous : register(t0);
Texture2D<float4> Current : register(t1);
Texture2D<int2> Forward : register(t2);
Texture2D<int2> Backward : register(t3);
// Private RGBA16F intermediate: RGB is the midpoint, A is confidence.
// Confidence must never reach the game's backbuffer alpha channel.
Texture2D<float4> Reprojection : register(t4);
// Private RGBA32F grid: two distinct motions crossing each 4x4 cell at t=0.5.
Texture2D<float4> Projected : register(t5);
SamplerState LinearClamp : register(s0);
cbuffer Settings : register(b0) { float2 ImageSize; float2 InvImageSize; };
struct Vertex { float4 position : SV_Position; float2 uv : TEXCOORD0; };
Vertex Fullscreen(uint id : SV_VertexID) {
 Vertex v; v.uv=float2((id<<1)&2,id&2);
 v.position=float4(v.uv*float2(2,-2)+float2(-1,1),0,1); return v;
}
float4 Capture(Vertex v) : SV_Target { return Previous.SampleLevel(LinearClamp,v.uv,0); }
// NVOF signed S10.5 displacement of one 4x4 block. Cells are clamped so any
// corrupted vector can only select a valid grid location.
float2 cellFlow(int2 c,bool backward) {
 int2 maximum=int2(ceil(ImageSize*0.25))-1;
 c=clamp(c,int2(0,0),maximum);
 if(backward)return Backward.Load(int3(c,0))/32.0;
 return Forward.Load(int3(c,0))/32.0;
}
// Bilinear flow at p, the smallest deviation of its four cells from the
// expected motion, and the most different cell. The minimum keeps a boundary
// pixel supported by the object it belongs to, and the most different cell is
// the unmixed occluder; bilinear mixing of foreground and background is neither.
struct Probe { float2 flow; float support; float2 other; float deviation; };
Probe probe(float2 p,float2 expected,bool backward) {
 float2 q=(p-1.5)*0.25;
 int2 i=int2(floor(q)); float2 t=frac(q);
 float2 va=cellFlow(i,backward), vb=cellFlow(i+int2(1,0),backward);
 float2 vc=cellFlow(i+int2(0,1),backward), vd=cellFlow(i+int2(1,1),backward);
 float da=length(va-expected), db=length(vb-expected);
 float dc=length(vc-expected), dd=length(vd-expected);
 Probe r;
 r.flow=lerp(lerp(va,vb,t.x),lerp(vc,vd,t.x),t.y);
 r.support=min(min(da,db),min(dc,dd));
 r.other=va; r.deviation=da;
 if(db>r.deviation){r.other=vb;r.deviation=db;}
 if(dc>r.deviation){r.other=vc;r.deviation=dc;}
 if(dd>r.deviation){r.other=vd;r.deviation=dd;}
 return r;
}
float2 flowAt(float2 p,bool backward) { return probe(p,float2(0,0),backward).flow; }
// Carry every block vector to the grid cell it crosses at the midpoint. Thin
// objects are found here even when their flow lies several pixels away from
// where they appear, which gathering at the output pixel alone cannot do.
// The nearest crossing and the nearest clearly different crossing are kept.
float4 Project(Vertex v) : SV_Target {
 int2 cell=int2(floor(v.position.xy));
 int2 maximum=int2(ceil(ImageSize*0.25))-1;
 float2 center=float2(cell)*4+1.5;
 float2 first=float2(0,0), second=float2(0,0);
 float firstDistance=1e9, secondDistance=1e9;
 [loop] for(int y=-5;y<=5;++y)
  [loop] for(int x=-5;x<=5;++x){
   int2 source=cell+int2(x,y);
   if(!all(source>=0)||!all(source<=maximum))continue;
   float2 origin=float2(source)*4+1.5;
   [unroll] for(int side=0;side<2;++side){
    float2 m=side==0?cellFlow(source,false):float2(0,0)-cellFlow(source,true);
    float d=length((side==0?origin+0.5*m:origin-0.5*m)-center);
    if(d<firstDistance){
     if(length(m-first)>2){second=first;secondDistance=firstDistance;}
     first=m;firstDistance=d;
    }else if(d<secondDistance&&length(m-first)>2){second=m;secondDistance=d;}
   }
  }
 if(secondDistance>=1e9)second=first;
 return float4(first,second);
}
float colorError(float3 a,float3 b) {
 float3 d=abs(a-b); return max(d.x,max(d.y,d.z));
}
bool inside(float2 p) { return all(p>=0)&&all(p<=ImageSize-1); }
float3 previousAt(float2 p) { return Previous.SampleLevel(LinearClamp,(p+0.5)*InvImageSize,0).rgb; }
float3 currentAt(float2 p) { return Current.SampleLevel(LinearClamp,(p+0.5)*InvImageSize,0).rgb; }
// Symmetric block match: previous at p-h against current at p+h. A small
// cross patch (center weighted) rejects coincidental single-pixel matches.
float matchCost(float2 p,float2 h) {
 float cost=2*colorError(previousAt(p-h),currentAt(p+h));
 cost+=colorError(previousAt(p-h+float2(1,0)),currentAt(p+h+float2(1,0)));
 cost+=colorError(previousAt(p-h-float2(1,0)),currentAt(p+h-float2(1,0)));
 cost+=colorError(previousAt(p-h+float2(0,1)),currentAt(p+h+float2(0,1)));
 cost+=colorError(previousAt(p-h-float2(0,1)),currentAt(p+h-float2(0,1)));
 return cost/6;
}
// Smallest difference between a color and the previous (or current) frame
// within one pixel of q; tolerates sub-pixel flow error on edges and texture.
float3 frameAt(float2 q,bool current) { return current?currentAt(q):previousAt(q); }
float nearestIn(float3 c,float2 q,bool current) {
 float e=colorError(c,frameAt(q,current));
 e=min(e,colorError(c,frameAt(q+float2(1,0),current)));
 e=min(e,colorError(c,frameAt(q-float2(1,0),current)));
 e=min(e,colorError(c,frameAt(q+float2(0,1),current)));
 return min(e,colorError(c,frameAt(q-float2(0,1),current)));
}
float nearestMatch(float3 c,float2 q) { return nearestIn(c,q,false); }
float motionTolerance(float speed) { return 1.5+0.08*speed; }
// An occluder explains a one-sided pixel only if its own motion is reliable:
// forward/backward cycle consistent and photometrically matched. Both tests
// tolerate edge sampling because the occluder is found at its own boundary.
float occluder(float2 p,float2 motion,bool backward) {
 float2 end=p+motion;
 if(!inside(p)||!inside(end))return 0;
 // Unmixed cells: the occluder is usually sampled right at its own edge.
 float cycle=probe(end,float2(0,0)-motion,!backward).support;
 float tolerance=motionTolerance(length(motion));
 float photo=nearestIn(frameAt(p,backward),end,!backward);
 return (1-smoothstep(tolerance,2.5*tolerance,cycle))*(1-smoothstep(0.04,0.16,photo));
}
// Three best distinct candidate motions by a cheap one-sample match. Vectors
// within a pixel of a better entry are duplicates; the list stays sorted.
struct Ranking { float2 m0; float2 m1; float2 m2; float c0; float c1; float c2; };
Ranking rank(Ranking r,float2 m,float c) {
 bool near0=r.c0<1e8&&length(m-r.m0)<1, near1=r.c1<1e8&&length(m-r.m1)<1;
 bool near2=r.c2<1e8&&length(m-r.m2)<1;
 if((near0&&r.c0<=c)||(near1&&r.c1<=c)||(near2&&r.c2<=c))return r;
 if(near0){r.m0=m;r.c0=c;}
 else if(near1){r.m1=m;r.c1=c;}
 else if(near2||c<r.c2){r.m2=m;r.c2=c;}
 float2 tm; float tc;
 if(r.c1<r.c0){tm=r.m0;r.m0=r.m1;r.m1=tm;tc=r.c0;r.c0=r.c1;r.c1=tc;}
 if(r.c2<r.c1){tm=r.m1;r.m1=r.m2;r.m2=tm;tc=r.c1;r.c1=r.c2;r.c2=tc;}
 if(r.c1<r.c0){tm=r.m0;r.m0=r.m1;r.m1=tm;tc=r.c0;r.c0=r.c1;r.c1=tc;}
 return r;
}
// One-sided result: only one frame shows this midpoint pixel. The visible
// side must support the motion; the hidden side must be covered by a clearly
// different motion, or lie off-screen.
struct Side { float score; float3 color; float2 occluderAt; float2 occluder; bool edge; };
// Full validation of one candidate motion m. Flow probes are shared by the
// two-sided match and both one-sided (occlusion) interpretations.
struct Evaluation { float score; float confidence; float3 color; Side fromCurrent; Side fromPrevious; };
Evaluation evaluate(float2 p,float2 m,float2 reference,bool twoSided) {
 float2 h=0.5*m, pa=p-h, pb=p+h;
 float speed=length(m), tolerance=motionTolerance(speed);
 float limit=1-smoothstep(64.0,128.0,speed);
 bool insideA=inside(pa), insideB=inside(pb);
 // Previous pixel should move by m; current pixel should move back by m.
 Probe forward=probe(pa,m,false), backward=probe(pb,float2(0,0)-m,true);
 float supportA=1-smoothstep(tolerance,2.5*tolerance,forward.support);
 float supportB=1-smoothstep(tolerance,2.5*tolerance,backward.support);
 float3 colorA=previousAt(pa), colorB=currentAt(pb);
 Evaluation r;
 r.score=4; r.confidence=0; r.color=0.5*(colorA+colorB);
 if(twoSided&&insideA&&insideB){
  // Both directions must agree: a photometric match with contradictory
  // flow is treated as unreliable rather than guessed.
  float support=min(supportA,supportB)*limit;
  float cost=matchCost(p,h);
  r.confidence=(1-smoothstep(0.04,0.16,cost))*support;
  // A second, clearly different motion supported by the flow at both ends
  // means an object crosses a still-visible background point, and occludes
  // it at the midpoint. Prefer it even with a looser match (sub-pixel flow
  // error on thin detail); otherwise poles and wires vanish.
  float crossing=support*(1-smoothstep(0.06,0.25,cost))*saturate((length(m-reference)-2)*0.25);
  r.score=(1-r.confidence)+0.25*cost-0.6*crossing;
  r.confidence=max(r.confidence,crossing);
 }
 // Off-screen hidden side: its clamped border cells must still agree, which
 // holds for a real pan and rejects one-directional (corrupted) flow.
 r.fromCurrent.score=insideB?supportB*limit*(insideA?smoothstep(2*tolerance,4*tolerance,forward.deviation):supportA):0;
 r.fromCurrent.color=colorB; r.fromCurrent.occluderAt=pa; r.fromCurrent.occluder=forward.other; r.fromCurrent.edge=!insideA;
 r.fromPrevious.score=insideA?supportA*limit*(insideB?smoothstep(2*tolerance,4*tolerance,backward.deviation):supportB):0;
 r.fromPrevious.color=colorA; r.fromPrevious.occluderAt=pb; r.fromPrevious.occluder=backward.other; r.fromPrevious.edge=!insideB;
 return r;
}
float4 Synthesize(Vertex v) : SV_Target {
 float2 p=v.position.xy-0.5, a=p, b=p;
 [unroll] for(int i=0;i<3;++i){a=p-0.5*flowAt(a,false);b=p-0.5*flowAt(b,true);}
 float4 original=Current.SampleLevel(LinearClamp,v.uv,0);
 float2 forwardMotion=flowAt(a,false), backwardMotion=float2(0,0)-flowAt(b,true);
 float2 reference=0.5*(forwardMotion+backwardMotion);
 int2 maximum=int2(ceil(ImageSize*0.25))-1;
 int2 cellA=int2(floor((a-1.5)*0.25)), cellB=int2(floor((b-1.5)*0.25));
 int2 cellP=int2(floor((p-1.5)*0.25));
 // Candidates: unmixed block vectors around both midpoint correspondences,
 // motions projected through this cell, and zero. Per-pixel selection makes
 // object edges follow image content instead of the 4x4 flow grid.
 Ranking ranking;
 ranking.m0=ranking.m1=ranking.m2=float2(0,0); ranking.c0=ranking.c1=ranking.c2=1e9;
 // The best clearly deviating flow vector is always validated as well: a thin
 // crossing object can rank below background duplicates after flow noise.
 float2 deviating=float2(0,0); float deviatingCost=1e9;
 float spread=0;
 [loop] for(int k=0;k<17;++k){
  float2 m=float2(0,0);
  if(k<4)m=cellFlow(cellA+int2(k&1,k>>1),false);
  else if(k<8)m=float2(0,0)-cellFlow(cellB+int2(k&1,(k>>1)&1),true);
  else if(k<16){
   float4 pair=Projected.Load(int3(clamp(cellP+int2(k&1,(k>>1)&1),int2(0,0),maximum),0));
   m=(k&4)?float2(pair.z,pair.w):float2(pair.x,pair.y);
  }
  float2 h=0.5*m;
  if(k<16)spread=max(spread,length(m-reference));
  if(length(m)<128&&inside(p-h)&&inside(p+h)){
   float c=colorError(previousAt(p-h),currentAt(p+h));
   ranking=rank(ranking,m,c);
   if(k<16&&length(m-reference)>3&&c<deviatingCost){deviating=m;deviatingCost=c;}
  }
 }
 // Fast path for uniformly moving regions, most of a typical frame: every
 // flow vector nearby agrees, the match is confident and the current pixel
 // itself moves with that motion (no thin or new detail to protect).
 [branch] if(spread<1){
  Evaluation steady=evaluate(p,reference,reference,true);
  if(steady.confidence>0.95&&nearestMatch(original.rgb,p-reference)<0.05)return float4(steady.color,1);
 }
 float bestScore=4, bestConfidence=0; float3 bestColor=original.rgb;
 Side fromCurrent, fromPrevious;
 fromCurrent.score=fromPrevious.score=0; fromCurrent.color=fromPrevious.color=original.rgb;
 fromCurrent.occluderAt=fromPrevious.occluderAt=p; fromCurrent.occluder=fromPrevious.occluder=float2(0,0);
 fromCurrent.edge=fromPrevious.edge=false;
 // Ranked motions plus the vectors reached from each side's own midpoint
 // correspondence (interpolated and nearest unmixed cell), which are the
 // usual visible-background motions in occlusion bands.
 [loop] for(int n=0;n<8;++n){
  float2 m=forwardMotion; bool ranked=n<4;
  if(n==0)m=ranking.m0; else if(n==1)m=ranking.m1; else if(n==2)m=ranking.m2; else if(n==3)m=deviating;
  else if(n==5)m=backwardMotion;
  else if(n==6)m=cellFlow(int2(floor((a-1.5)*0.25+0.5)),false);
  else if(n==7)m=float2(0,0)-cellFlow(int2(floor((b-1.5)*0.25+0.5)),true);
  float rankedCost=n==0?ranking.c0:(n==1?ranking.c1:(n==2?ranking.c2:(n==3?deviatingCost:0)));
  if(rankedCost<1e8){
   Evaluation e=evaluate(p,m,reference,ranked);
   if(ranked&&e.score<bestScore){bestScore=e.score;bestConfidence=e.confidence;bestColor=e.color;}
   if(e.fromCurrent.score>fromCurrent.score)fromCurrent=e.fromCurrent;
   if(e.fromPrevious.score>fromPrevious.score)fromPrevious=e.fromPrevious;
  }
 }
 // Screen borders are valid one-sided evidence; otherwise require a real,
 // self-consistent occluder. This rejects fabricated or scene-cut flow.
 if(!fromCurrent.edge)fromCurrent.score*=occluder(fromCurrent.occluderAt,fromCurrent.occluder,false);
 if(!fromPrevious.edge)fromPrevious.score*=occluder(fromPrevious.occluderAt,fromPrevious.occluder,true);
 float oneSided=max(fromCurrent.score,fromPrevious.score);
 float3 oneColor=fromCurrent.score>=fromPrevious.score?fromCurrent.color:fromPrevious.color;
 float weightB=bestConfidence, weightO=(1-bestConfidence)*oneSided;
 float valid=weightB+weightO;
 float3 color=valid>0.001?(weightB*bestColor+weightO*oneColor)/valid:original.rgb;
 // Current content without any correspondence (a new object, or detail too
 // thin for the 4x4 flow grid) stays where the real frame shows it instead of
 // breaking into fragments. Each unmixed block vector is tested separately;
 // revealed background is excluded because its previous-frame location is
 // covered by a different, occluding motion.
 float here=nearestMatch(original.rgb,p);
 float keep=smoothstep(0.08,0.2,here);
 // A candidate motion that explains the current pixel from the previous frame
 // (e.g. a thin object found through the projected motions) also counts.
 keep*=smoothstep(0.08,0.2,nearestMatch(original.rgb,p-ranking.m0));
 if(deviatingCost<1e8)keep*=smoothstep(0.08,0.2,nearestMatch(original.rgb,p-deviating));
 [unroll] for(int j=0;j<4;++j){
  float2 u=cellFlow(cellP+int2(j&1,j>>1),true), q=p+u;
  float uTolerance=motionTolerance(length(u));
  float revealed=inside(q)?smoothstep(uTolerance,2.5*uTolerance,
   length(cellFlow(int2(floor((q-1.5)*0.25+0.5)),false)+u)):1;
  keep*=smoothstep(0.08,0.2,nearestMatch(original.rgb,q))*(1-revealed);
 }
 // Thin detail present at this pixel in both frames (within a pixel) but
 // replaced by a background match: no flow describes it, so keep it too.
 float3 left=currentAt(p-float2(1,0)), right=currentAt(p+float2(1,0));
 float3 up=currentAt(p-float2(0,1)), down=currentAt(p+float2(0,1));
 float thin=max(smoothstep(0.08,0.16,min(colorError(original.rgb,left),colorError(original.rgb,right))),
                smoothstep(0.08,0.16,min(colorError(original.rgb,up),colorError(original.rgb,down))));
 keep=max(keep,(1-smoothstep(0.03,0.08,here))*smoothstep(0.1,0.2,colorError(color,original.rgb))*thin);
 color=lerp(color,original.rgb,keep);
 return float4(color,max(valid,keep));
}
float stationaryError(float2 uv) {
 return colorError(Previous.SampleLevel(LinearClamp,uv,0).rgb,
                   Current.SampleLevel(LinearClamp,uv,0).rgb);
}
float4 Resolve(Vertex v) : SV_Target {
 float4 original=Current.SampleLevel(LinearClamp,v.uv,0);
 float4 candidate=Reprojection.SampleLevel(LinearClamp,v.uv,0);
 // Neighborhood support removes isolated confident samples and feathers the
 // fallback by about one pixel. Unlike a wide minimum filter it does not cut
 // current-frame blocks, misplaced by half the motion, into the midpoint.
 float support=0;
 [unroll] for(int y=-1;y<=1;++y)
  [unroll] for(int x=-1;x<=1;++x)
   support+=Reprojection.SampleLevel(LinearClamp,v.uv+float2(x,y)*InvImageSize,0).w;
 float confidence=smoothstep(0.2,0.9,min(candidate.w,support*(1.25/9)));
 // Screen-stationary detail is often UI. Require support from at least one
 // neighboring pixel to avoid pinning isolated color coincidences in motion.
 float nearby=min(min(stationaryError(v.uv+float2(1,0)*InvImageSize),
                      stationaryError(v.uv-float2(1,0)*InvImageSize)),
                  min(stationaryError(v.uv+float2(0,1)*InvImageSize),
                      stationaryError(v.uv-float2(0,1)*InvImageSize)));
 float stationary=1-smoothstep(0.004,0.016,max(stationaryError(v.uv),nearby));
 confidence*=1-stationary;
 return float4(lerp(original.rgb,candidate.rgb,confidence),original.w);
}
)SM20HLSL";
