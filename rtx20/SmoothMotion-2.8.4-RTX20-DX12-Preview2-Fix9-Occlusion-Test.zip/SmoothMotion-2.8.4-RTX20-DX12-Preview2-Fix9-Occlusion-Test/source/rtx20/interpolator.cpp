#include "interpolator.hpp"
#include "policy.hpp"
#include "performance.hpp"
#include "dx12_transfer.hpp"
#include "nvof_d3d11.hpp"
#include "context_transaction.hpp"
#include "nvs30/log.hpp"
#include "nvOpticalFlowCuda.h"
#include <d3dcompiler.h>
#include <stdexcept>
#include "shader_source.hpp"
namespace sm20 {
using nvs30::ComPtr; using nvs30::logf;
std::atomic_ullong flow_pairs{},generated_submissions{},real_submissions{},failures{};
namespace {
struct Cuda {
 HMODULE module{}; HMODULE optical{}; HMODULE compiler{};
 CUresult(WINAPI* init)(unsigned){};
 CUresult(WINAPI* d3dDevice)(CUdevice*,IDXGIAdapter*){};
 CUresult(WINAPI* attribute)(int*,int,CUdevice){};
 CUresult(WINAPI* create)(CUcontext*,unsigned,CUdevice){};
 CUresult(WINAPI* destroy)(CUcontext){};
 CUresult(WINAPI* push)(CUcontext){};
 CUresult(WINAPI* pop)(CUcontext*){};
 CUresult(WINAPI* sync)(){};
 CUresult(WINAPI* reg)(CUgraphicsResource*,ID3D11Resource*,unsigned){};
 CUresult(WINAPI* unreg)(CUgraphicsResource){};
 CUresult(WINAPI* map)(unsigned,CUgraphicsResource*,CUstream){};
 CUresult(WINAPI* unmap)(unsigned,CUgraphicsResource*,CUstream){};
 CUresult(WINAPI* array)(CUarray*,CUgraphicsResource,unsigned,unsigned){};
 CUresult(WINAPI* copy)(const CUDA_MEMCPY2D*){};
 decltype(&D3DCompile) compile{};
 NV_OF_CUDA_API_FUNCTION_LIST of{};
 bool loaded{},cudaOfReady{}; std::atomic<const char*> status{"not_initialized"};
} cuda;
std::once_flag loading;
void require(HRESULT hr,const char* what){if(FAILED(hr)){logf("[rtx20] %s failed: HRESULT=0x%08lx\n",what,(unsigned long)hr);throw std::runtime_error(what);}}
void cu(CUresult rc,const char* what){if(rc){logf("[rtx20] %s failed: CUDA=%d\n",what,rc);throw std::runtime_error(what);}}
void of(NV_OF_STATUS rc,const char* what){if(rc!=NV_OF_SUCCESS){logf("[rtx20] %s failed: NVOF=%d\n",what,int(rc));throw std::runtime_error(what);}}
struct CurrentContext {
 bool active{};
 explicit CurrentContext(CUcontext c){cu(cuda.push(c),"cuCtxPushCurrent");active=true;}
 ~CurrentContext(){if(active){CUcontext c{};cuda.pop(&c);}}
};
struct Pipeline {
 ContextTransaction<ID3D11Multithread> transaction;
 ID3D11DeviceContext1* ctx; ComPtr<ID3DDeviceContextState> previous;
 Pipeline(ID3D11DeviceContext1* c,ID3DDeviceContextState* s,ID3D11Multithread* multithread):transaction(multithread),ctx(c){ctx->SwapDeviceContextState(s,&previous);}
 ~Pipeline(){ctx->SwapDeviceContextState(previous.Get(),nullptr);}
};
struct Mapped {
 std::array<CUgraphicsResource,4> resources; bool active{};
 explicit Mapped(std::array<CUgraphicsResource,4> r):resources(r){cu(cuda.map(4,resources.data(),nullptr),"cuGraphicsMapResources");active=true;}
 void close(){if(active){auto rc=cuda.unmap(4,resources.data(),nullptr);active=false;cu(rc,"cuGraphicsUnmapResources");}}
 ~Mapped(){if(active)cuda.unmap(4,resources.data(),nullptr);}
};
void copy_array(CUarray source,CUarray destination,unsigned widthBytes,unsigned height){
 if(!source||!destination)throw std::runtime_error("null CUDA array");
 CUDA_MEMCPY2D c{};c.srcMemoryType=CU_MEMORYTYPE_ARRAY;c.srcArray=source;
 c.dstMemoryType=CU_MEMORYTYPE_ARRAY;c.dstArray=destination;c.WidthInBytes=widthBytes;c.Height=height;
 cu(cuda.copy(&c),"cuMemcpy2D");
}
}
bool load_runtime(){
 std::call_once(loading,[]{
  cuda.module=LoadLibraryExW(L"nvcuda.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  cuda.optical=LoadLibraryExW(L"nvofapi64.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  cuda.compiler=LoadLibraryExW(L"d3dcompiler_47.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  if(!cuda.module||!cuda.optical||!cuda.compiler){cuda.status="missing_nvidia_driver_or_d3dcompiler47";return;}
  #define RESOLVE(member,name) cuda.member=reinterpret_cast<decltype(cuda.member)>(GetProcAddress(cuda.module,name));if(!cuda.member){cuda.status="missing_cuda_entry";return;}
  RESOLVE(init,"cuInit");RESOLVE(d3dDevice,"cuD3D11GetDevice");RESOLVE(attribute,"cuDeviceGetAttribute");
  RESOLVE(create,"cuCtxCreate_v2");RESOLVE(destroy,"cuCtxDestroy_v2");RESOLVE(push,"cuCtxPushCurrent_v2");RESOLVE(pop,"cuCtxPopCurrent_v2");
  RESOLVE(sync,"cuCtxSynchronize");RESOLVE(reg,"cuGraphicsD3D11RegisterResource");RESOLVE(unreg,"cuGraphicsUnregisterResource");
  RESOLVE(map,"cuGraphicsMapResources");RESOLVE(unmap,"cuGraphicsUnmapResources");RESOLVE(array,"cuGraphicsSubResourceGetMappedArray");RESOLVE(copy,"cuMemcpy2D_v2");
  #undef RESOLVE
  cuda.compile=reinterpret_cast<decltype(cuda.compile)>(GetProcAddress(cuda.compiler,"D3DCompile"));
  auto create=reinterpret_cast<decltype(&NvOFAPICreateInstanceCuda)>(GetProcAddress(cuda.optical,"NvOFAPICreateInstanceCuda"));
  if(!cuda.compile||cuda.init(0)!=0){cuda.status="runtime_initialization_failed";return;}
  cuda.cudaOfReady=create&&create(NV_OF_API_VERSION,&cuda.of)==NV_OF_SUCCESS&&
     cuda.of.nvCreateOpticalFlowCuda&&cuda.of.nvOFInit&&cuda.of.nvOFExecute&&cuda.of.nvOFGetCaps&&
     cuda.of.nvOFCreateGPUBufferCuda&&cuda.of.nvOFGPUBufferGetCUarray&&cuda.of.nvOFDestroyGPUBufferCuda&&cuda.of.nvOFDestroy;
  if(!cuda.cudaOfReady&&!NvofD3D11::available()){cuda.status="nvof_d3d11_api5_and_cuda_api2_unavailable";return;}
  cuda.loaded=true;cuda.status="ready_waiting_for_turing_d3d11_or_d3d12";
 });
 return cuda.loaded;
}
const char* runtime_status(){return cuda.status.load();}
struct Interpolator::Impl {
 std::unique_ptr<DX12Transfer> dx12;
 struct Texture {
  ComPtr<ID3D11Texture2D> texture;ComPtr<ID3D11ShaderResourceView> srv;ComPtr<ID3D11RenderTargetView> rtv;
  CUgraphicsResource graphics{};NvOFGPUBufferHandle ofBuffer{};bool inputReady{};
 } frames[2],flows[2],saved,projected,reprojected,generated;
 ComPtr<ID3D11Device> device;ComPtr<ID3D11Device1> device1;
 ComPtr<ID3D11DeviceContext> context;ComPtr<ID3D11DeviceContext1> context1;
 ComPtr<ID3D11Multithread> gameMultithread;
 ComPtr<ID3DDeviceContextState> pipeline;
 ComPtr<ID3D11VertexShader> vertex;ComPtr<ID3D11PixelShader> capture,project,synthesize,resolve;
 ComPtr<ID3D11ShaderResourceView> snapshotView;
 ComPtr<ID3D11SamplerState> sampler;ComPtr<ID3D11Buffer> constants;
 CUcontext cuContext{};NvOFHandle optical{};
 std::unique_ptr<NvofD3D11> nativeFlow;
 unsigned width{},height{};DXGI_FORMAT format{};
 bool history{},captured{},generatedReady{},cudaFault{};
 std::uint64_t lastAccepted{};
 void texture(Texture& t,unsigned w,unsigned h,DXGI_FORMAT f,bool render,bool shader=true,unsigned extraBind=0){
  D3D11_TEXTURE2D_DESC d{};d.Width=w;d.Height=h;d.MipLevels=d.ArraySize=1;d.Format=f;d.SampleDesc.Count=1;d.Usage=D3D11_USAGE_DEFAULT;
  d.BindFlags=(shader?D3D11_BIND_SHADER_RESOURCE:0)|(render?D3D11_BIND_RENDER_TARGET:0)|extraBind;
  require(device->CreateTexture2D(&d,nullptr,&t.texture),"CreateTexture2D");
  if(shader)require(device->CreateShaderResourceView(t.texture.Get(),nullptr,&t.srv),"CreateSRV");
  if(render)require(device->CreateRenderTargetView(t.texture.Get(),nullptr,&t.rtv),"CreateRTV");
 }
 ComPtr<ID3DBlob> shader(const char* entry,const char* profile){
  ComPtr<ID3DBlob> code,error;auto hr=cuda.compile(shader_source,sizeof(shader_source)-1,"sm20.hlsl",nullptr,nullptr,entry,profile,D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&error);
  if(error)logf("[rtx20] shader %s: %s\n",entry,static_cast<const char*>(error->GetBufferPointer()));require(hr,"D3DCompile");return code;
 }
 void initialize(IDXGISwapChain* swap,ID3D12CommandQueue* queue){
  ComPtr<ID3D11Texture2D> back;
  if(queue){dx12=std::make_unique<DX12Transfer>();require(dx12->initialize(swap,queue),"DX12 transfer initialization");back=dx12->snapshot();device=dx12->device();}
  else{require(swap->GetBuffer(0,IID_PPV_ARGS(&back)),"D3D11 backbuffer");require(swap->GetDevice(IID_PPV_ARGS(&device)),"D3D11 device");}
  DXGI_SWAP_CHAIN_DESC chain{};require(swap->GetDesc(&chain),"GetDesc");
  D3D11_TEXTURE2D_DESC d{};back->GetDesc(&d);
  if(!chain.Windowed||d.SampleDesc.Count!=1||!supported_format(d.Format)||!dimensions(d.Width,d.Height))throw std::runtime_error("requires windowed/borderless DX11/DX12 SDR 128..3840 x 128..2160, single sample");
  // sRGB transfer is preserved by treating both snapshots as UNORM bytes.
  // GetBuffer SRVs use the source format; explicit UNORM views below avoid a
  // decode/encode mismatch for sRGB swapchains.
  width=d.Width;height=d.Height;format=d.Format;
  ComPtr<IDXGIOutput> output;DXGI_OUTPUT_DESC outputDesc{};DEVMODEW mode{};mode.dmSize=sizeof mode;
  if(SUCCEEDED(swap->GetContainingOutput(&output))&&SUCCEEDED(output->GetDesc(&outputDesc))&&
     EnumDisplaySettingsW(outputDesc.DeviceName,ENUM_CURRENT_SETTINGS,&mode))
   logf("[rtx20] Display: %ls %lux%lu refresh=%lu Hz; windowed=%u; generated Present sync=0 + DO_NOT_WAIT, original preserves game parameters; no runtime FPS cap.\n",
        outputDesc.DeviceName,mode.dmPelsWidth,mode.dmPelsHeight,mode.dmDisplayFrequency,unsigned(chain.Windowed));
  require(device.As(&device1),"D3D11.1 device");
  device->GetImmediateContext(&context);require(context.As(&context1),"D3D11.1 context");
  if(!dx12)context.As(&gameMultithread);
  ComPtr<IDXGIDevice> dxgi;ComPtr<IDXGIAdapter> adapter;require(device.As(&dxgi),"DXGI device");require(dxgi->GetAdapter(&adapter),"GetAdapter");
  DXGI_ADAPTER_DESC ad{};require(adapter->GetDesc(&ad),"AdapterDesc");
  if(ad.VendorId!=0x10de)throw std::runtime_error("selected game adapter is not NVIDIA");
  CUdevice gpu{};cu(cuda.d3dDevice(&gpu,adapter.Get()),"cuD3D11GetDevice");int major{},minor{};
  cu(cuda.attribute(&major,75,gpu),"compute major");cu(cuda.attribute(&minor,76,gpu),"compute minor");
  if(!supported_gpu(ad.VendorId,major,minor))throw std::runtime_error("RTX20 preview requires Turing SM75");
  D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_1,D3D_FEATURE_LEVEL_11_0},selected{};
  require(device1->CreateDeviceContextState((device->GetCreationFlags()&D3D11_CREATE_DEVICE_SINGLETHREADED)?D3D11_1_CREATE_DEVICE_CONTEXT_STATE_SINGLETHREADED:0,levels,2,D3D11_SDK_VERSION,__uuidof(ID3D11Device),&selected,&pipeline),"CreateDeviceContextState");
  // NVIDIA's D3D11 ABGR8 buffer maps to BGRA8; CUDA2 still requires the
  // existing RGBA byte layout. Typed RTV/SRV access preserves shader colors.
  // Native inputs need RT+SRV only; BGRA typed UAV support is not assumed.
  // Both the DX12 bridge and DX11 game expose an owning immediate context.
  // Pipeline saves/restores game state and borrows its existing multithread
  // protection. Native OF therefore need not be restricted to the DX12 bridge.
  if(NvofD3D11::available()){
   try{
    for(auto& t:frames)texture(t,width,height,NvofD3D11::input_format(),true);
    for(auto& t:flows)texture(t,grid_extent(width),grid_extent(height),DXGI_FORMAT_R16G16_SINT,false,true,D3D11_BIND_RENDER_TARGET|D3D11_BIND_UNORDERED_ACCESS);
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    auto candidate=std::make_unique<NvofD3D11>();
    ID3D11Texture2D* input[]={frames[0].texture.Get(),frames[1].texture.Get()};
    ID3D11Texture2D* output[]={flows[0].texture.Get(),flows[1].texture.Get()};
    if(candidate->initialize(device.Get(),context.Get(),width,height,input,output))nativeFlow=std::move(candidate);
   }catch(const std::exception& e){
    logf("[rtx20-nvof] Native texture setup unavailable: %s; recreating RGBA8 CUDA inputs.\n",e.what());
   }
  }
  if(!nativeFlow){
   // The unsuccessful candidate has unregistered all native resources before
   // entering this block. No capture or optical-flow execution has occurred.
   // Release both complete and partially allocated native sets before CUDA
   // registration, so BGRA bytes can never reach the RGBA CUDA copy path.
   for(auto& t:frames)t=Texture{};
   for(auto& t:flows)t=Texture{};
   for(auto& t:frames)texture(t,width,height,DXGI_FORMAT_R8G8B8A8_UNORM,true);
   for(auto& t:flows)texture(t,grid_extent(width),grid_extent(height),DXGI_FORMAT_R16G16_SINT,false);
   if(!cuda.cudaOfReady)throw std::runtime_error("native NVOF unavailable and CUDA API2 fallback missing");
  cu(cuda.create(&cuContext,4,gpu),"cuCtxCreate");CUcontext popped{};cu(cuda.pop(&popped),"cuCtxPopCurrent after create");
  CurrentContext current(cuContext);
  of(cuda.of.nvCreateOpticalFlowCuda(cuContext,&optical),"nvCreateOpticalFlowCuda");
  for(auto cap:{NV_OF_CAPS_WIDTH_MIN,NV_OF_CAPS_HEIGHT_MIN,NV_OF_CAPS_WIDTH_MAX,NV_OF_CAPS_HEIGHT_MAX}){
   std::uint32_t value{},size=1;of(cuda.of.nvOFGetCaps(optical,cap,&value,&size),"nvOFGetCaps");
   unsigned requested=(cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_WIDTH_MAX)?width:height;
   if((cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_HEIGHT_MIN)?requested<value:requested>value)throw std::runtime_error("dimensions outside NVOF capabilities");
  }
  NV_OF_INIT_PARAMS p{};p.width=width;p.height=height;p.outGridSize=NV_OF_OUTPUT_VECTOR_GRID_SIZE_4;p.mode=NV_OF_MODE_OPTICALFLOW;p.perfLevel=NV_OF_PERF_LEVEL_MEDIUM;
  of(cuda.of.nvOFInit(optical,&p),"nvOFInit");
  for(auto& t:frames){
   cu(cuda.reg(&t.graphics,t.texture.Get(),0),"register input D3D11 texture");
   NV_OF_BUFFER_DESCRIPTOR bd{width,height,NV_OF_BUFFER_USAGE_INPUT,NV_OF_BUFFER_FORMAT_ABGR8};
   of(cuda.of.nvOFCreateGPUBufferCuda(optical,&bd,NV_OF_CUDA_BUFFER_TYPE_CUARRAY,&t.ofBuffer),"allocate NVOF input");
  }
  for(auto& t:flows){
   cu(cuda.reg(&t.graphics,t.texture.Get(),0),"register flow D3D11 texture");
   NV_OF_BUFFER_DESCRIPTOR bd{grid_extent(width),grid_extent(height),NV_OF_BUFFER_USAGE_OUTPUT,NV_OF_BUFFER_FORMAT_SHORT2};
   of(cuda.of.nvOFCreateGPUBufferCuda(optical,&bd,NV_OF_CUDA_BUFFER_TYPE_CUARRAY,&t.ofBuffer),"allocate NVOF flow");
  }
   logf("[rtx20-nvof] nvof_api=CUDA API2 fallback ready: input_format=28 RGBA8, MEDIUM preset, cached previous input, bidirectional execute.\n");
  }
  DXGI_FORMAT plain=(format==DXGI_FORMAT_R8G8B8A8_UNORM_SRGB)?DXGI_FORMAT_R8G8B8A8_UNORM:(format==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB)?DXGI_FORMAT_B8G8R8A8_UNORM:format;
  if(dx12)require(device->CreateShaderResourceView(dx12->snapshot(),nullptr,&snapshotView),"Create DX12 snapshot SRV");
  else texture(saved,width,height,plain,false);
  // Grid of the two distinct motions crossing each 4x4 cell at the midpoint.
  texture(projected,grid_extent(width),grid_extent(height),DXGI_FORMAT_R32G32B32A32_FLOAT,true);
  texture(reprojected,width,height,DXGI_FORMAT_R16G16B16A16_FLOAT,true);
  texture(generated,width,height,plain,true);
  auto vs=shader("Fullscreen","vs_5_0"),ps=shader("Capture","ps_5_0"),js=shader("Project","ps_5_0"),ms=shader("Synthesize","ps_5_0"),rs=shader("Resolve","ps_5_0");
  require(device->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,&vertex),"CreateVertexShader");
  require(device->CreatePixelShader(ps->GetBufferPointer(),ps->GetBufferSize(),nullptr,&capture),"CreateCaptureShader");
  require(device->CreatePixelShader(js->GetBufferPointer(),js->GetBufferSize(),nullptr,&project),"CreateProjectionShader");
  require(device->CreatePixelShader(ms->GetBufferPointer(),ms->GetBufferSize(),nullptr,&synthesize),"CreateSynthesisShader");
  require(device->CreatePixelShader(rs->GetBufferPointer(),rs->GetBufferSize(),nullptr,&resolve),"CreateResolveShader");
  D3D11_SAMPLER_DESC sd{};sd.Filter=D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.MaxLOD=D3D11_FLOAT32_MAX;sd.ComparisonFunc=D3D11_COMPARISON_NEVER;
  require(device->CreateSamplerState(&sd,&sampler),"CreateSamplerState");
  float settings[]={float(width),float(height),1.f/width,1.f/height};D3D11_BUFFER_DESC cb{};cb.ByteWidth=16;cb.Usage=D3D11_USAGE_IMMUTABLE;cb.BindFlags=D3D11_BIND_CONSTANT_BUFFER;D3D11_SUBRESOURCE_DATA data{settings,0,0};
  require(device->CreateBuffer(&cb,&data,&constants),"CreateConstantBuffer");
  logf("[rtx20] Turing backend ready: adapter=%ls SM%d%d %ux%u; NVOF %s MEDIUM preset, bidirectional flow, 2x SDR synthesis; artifact_guard=occlusion_aware_v2 (midpoint motion projection, per-pixel candidate matching, one-sided occlusion fill, stationary-detail protection). Display output remains unverified.\n",ad.Description,major,minor,width,height,nativeFlow?"D3D11 API5":"CUDA API2");
 }
 bool quiesce(){
  if(cudaFault)return false;
  if(dx12&&!dx12->quiesce())return false;
  ContextTransaction<ID3D11Multithread> transaction(gameMultithread.Get());
  return !nativeFlow||nativeFlow->quiesce();
 }
 void draw(ID3D11PixelShader* ps,ID3D11RenderTargetView* target,const std::array<ID3D11ShaderResourceView*,6>& srvs,unsigned targetWidth=0,unsigned targetHeight=0){
  // Protect swap/draw/restore as one transaction if the game already enabled
  // multithread protection. The private DX12 context and CUDA waits are outside.
  Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
  context->ClearState();
  context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  context->VSSetShader(vertex.Get(),nullptr,0);context->PSSetShader(ps,nullptr,0);
  context->PSSetShaderResources(0,static_cast<UINT>(srvs.size()),srvs.data());auto s=sampler.Get();context->PSSetSamplers(0,1,&s);
  auto cb=constants.Get();context->PSSetConstantBuffers(0,1,&cb);
  D3D11_VIEWPORT vp{0,0,float(targetWidth?targetWidth:width),float(targetHeight?targetHeight:height),0,1};context->RSSetViewports(1,&vp);context->OMSetRenderTargets(1,&target,nullptr);
  context->Draw(3,0);context->ClearState();
 }
 bool prepare(IDXGISwapChain* swap){
  ComPtr<ID3D11Texture2D> back;
  if(dx12){performance::Scope timing(performance::Phase::capture);require(dx12->capture(swap),"DX12 snapshot");back=dx12->snapshot();}
  else require(swap->GetBuffer(0,IID_PPV_ARGS(&back)),"GetBuffer");
  D3D11_TEXTURE2D_DESC desc{};back->GetDesc(&desc);
  if(desc.Width!=width||desc.Height!=height||desc.Format!=format)throw std::runtime_error("swapchain changed without resize notification");
  captured=generatedReady=false;
  if(dx12)dx12->mark_d3d11_work();
  if(!dx12)context->CopyResource(saved.texture.Get(),back.Get());
  draw(capture.Get(),frames[1].rtv.Get(),{dx12?snapshotView.Get():saved.srv.Get(),nullptr,nullptr,nullptr,nullptr,nullptr});
  frames[1].inputReady=false;captured=true;
  if(!history||!fresh_history(lastAccepted,GetTickCount64()))return false;
  if(!nativeFlow)context->Flush();
  try{
   performance::Scope timing(performance::Phase::optical_flow);
   if(nativeFlow){
    Pipeline scope(context1.Get(),pipeline.Get(),gameMultithread.Get());
    ID3D11Texture2D* output[]={flows[0].texture.Get(),flows[1].texture.Get()};
    require(nativeFlow->execute(frames[0].texture.Get(),frames[1].texture.Get(),output),"native D3D11 NVOF execute");
   }else{
   CurrentContext current(cuContext);
   Mapped map({frames[0].graphics,frames[1].graphics,flows[0].graphics,flows[1].graphics});
   CUarray images[4]{};for(unsigned i=0;i<4;++i)cu(cuda.array(images+i,map.resources[i],0,0),"get mapped CUDA array");
   for(unsigned i=0;i<2;++i)if(!frames[i].inputReady){
    copy_array(images[i],cuda.of.nvOFGPUBufferGetCUarray(frames[i].ofBuffer),width*4,height);frames[i].inputReady=true;
   }
   for(unsigned direction=0;direction<2;++direction){
    NV_OF_EXECUTE_INPUT_PARAMS in{};in.inputFrame=frames[direction].ofBuffer;in.referenceFrame=frames[1-direction].ofBuffer;in.disableTemporalHints=NV_OF_TRUE;
    NV_OF_EXECUTE_OUTPUT_PARAMS out{};out.outputBuffer=flows[direction].ofBuffer;
    of(cuda.of.nvOFExecute(optical,&in,&out),"nvOFExecute");
   }
   cu(cuda.sync(),"NVOF completion");
   for(unsigned i=0;i<2;++i)copy_array(cuda.of.nvOFGPUBufferGetCUarray(flows[i].ofBuffer),images[i+2],grid_extent(width)*4,grid_extent(height));
   // cuGraphicsUnmapResources orders prior CUDA work before subsequent D3D11
   // work. An extra context-wide CPU synchronization after unmap is redundant.
   map.close();
   }
   ++flow_pairs;
  }catch(...){cudaFault=true;throw;}
  {performance::Scope timing(performance::Phase::synthesis);
   draw(project.Get(),projected.rtv.Get(),{nullptr,nullptr,flows[0].srv.Get(),flows[1].srv.Get(),nullptr,nullptr},grid_extent(width),grid_extent(height));
   draw(synthesize.Get(),reprojected.rtv.Get(),{frames[0].srv.Get(),frames[1].srv.Get(),flows[0].srv.Get(),flows[1].srv.Get(),nullptr,projected.srv.Get()});
   draw(resolve.Get(),generated.rtv.Get(),{frames[0].srv.Get(),frames[1].srv.Get(),nullptr,nullptr,reprojected.srv.Get(),nullptr});}
  generatedReady=true;return true;
 }
 bool write(IDXGISwapChain* swap,ID3D11Texture2D* texture){
  ComPtr<ID3D11Texture2D> back;if(FAILED(swap->GetBuffer(0,IID_PPV_ARGS(&back))))return false;
  context->CopyResource(back.Get(),texture);return SUCCEEDED(device->GetDeviceRemovedReason());
 }
 ~Impl(){
  if(!cuContext)return;
  if(cuda.push(cuContext)==0){
   for(auto& t:frames){if(t.graphics)cuda.unreg(t.graphics);if(t.ofBuffer)cuda.of.nvOFDestroyGPUBufferCuda(t.ofBuffer);}
   for(auto& t:flows){if(t.graphics)cuda.unreg(t.graphics);if(t.ofBuffer)cuda.of.nvOFDestroyGPUBufferCuda(t.ofBuffer);}
   if(optical)cuda.of.nvOFDestroy(optical);CUcontext old{};cuda.pop(&old);
  }
  cuda.destroy(cuContext);
 }
};
Interpolator::Interpolator()=default;
Interpolator::~Interpolator(){reset(false);}
void Interpolator::reset(bool retry){
 // On a CUDA failure the driver's ownership of resources is uncertain. Keep a
 // single failed session alive until process exit; never reuse it.
 if(impl_&&!impl_->quiesce()){
  // A timeout after submission is not safe passthrough: the game buffer may
  // still be referenced by queued work. Keep the complete session alive.
  if(impl_->dx12&&impl_->dx12->uncertain())terminal_=DXGI_ERROR_DEVICE_RESET;
  (void)impl_.release();failed_=retryBlocked_=true;return;
 }
 impl_.reset();
 if(retry&&!terminal_&&!retryBlocked_)failed_=false;
}
bool Interpolator::prepare(IDXGISwapChain* swap,ID3D12CommandQueue* queue){
 if(failed_||!load_runtime())return false;
 try{
  if(!impl_){impl_=std::make_unique<Impl>();impl_->initialize(swap,queue);}
  return impl_->prepare(swap);
 }catch(const std::exception& e){++failures;logf("[rtx20] Session disabled: %s; fallback is allowed only after completed GPU work.\n",e.what());failed_=true;reset(false);return false;}
 catch(...){++failures;failed_=true;reset(false);return false;}
}
bool Interpolator::write(IDXGISwapChain* s,bool generated){
 if(!impl_||failed_||(generated?!impl_->generatedReady:!impl_->captured))return false;
 const auto hr=impl_->dx12?(generated?impl_->dx12->write_generated(s,impl_->generated.texture.Get()):impl_->dx12->write_original(s)):
     (impl_->write(s,generated?impl_->generated.texture.Get():impl_->saved.texture.Get())?S_OK:DXGI_ERROR_DEVICE_RESET);
 if(SUCCEEDED(hr))return true;
 ++failures;failed_=true;
 if(!generated||!impl_->dx12||impl_->dx12->uncertain())terminal_=DXGI_ERROR_DEVICE_RESET;
 logf("[rtx20] %s copy failed hr=0x%08lx terminal=0x%08lx.\n",generated?"generated":"original",(unsigned long)hr,(unsigned long)terminal_);
 reset(false);return false;
}
bool Interpolator::write_generated(IDXGISwapChain* s){return write(s,true);}
bool Interpolator::write_original(IDXGISwapChain* s){return write(s,false);}
void Interpolator::accepted(){if(impl_&&impl_->captured){std::swap(impl_->frames[0],impl_->frames[1]);impl_->history=true;impl_->captured=false;impl_->lastAccepted=GetTickCount64();}}
void Interpolator::discard_history(){if(impl_)impl_->history=impl_->captured=impl_->generatedReady=false;}
bool Interpolator::ready()const{return impl_&&!failed_;}
}
