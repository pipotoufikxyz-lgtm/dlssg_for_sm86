#pragma once
namespace helper_identity {
inline constexpr char installer[]="1d9ea0257de7c0dc76f57f423663dbd394deae80a420277871ce83479054c5cd";
inline constexpr char collector[]="5cb65fda1a9e4e6a4de9068a422d99236244644304f46eab4da9bf3b440fcd65";
}
