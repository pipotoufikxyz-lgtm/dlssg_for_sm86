// Generated from current payloads and pinned legacy ownership identities.
#pragma once
namespace payload_hashes {
inline constexpr const char native_proxy[] = "de569e10ca033a1ed1ad76ff163cc3b9de27f04161cb034409931bf6c151537f";
inline constexpr const char motion[] = "3c861afaf29c066419c2ef4c24ce713425f04147f5f5db38991a98c4d4355526";
inline constexpr const char loader[] = "031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
inline constexpr const char ini[] = "7fbe28780c05b182220c61197ba7ea9506816fb3637897c3ae4a0ecd7fd7d650";
inline constexpr const char standalone[] = "feb05f255d09bc207a7eeacd55cb87b0bbfeedc5337b97aaa37245ed36a98bc7";
inline constexpr const char asi[] = "16b7b560d100f9f26d3d0454617a128337374320c468f4a5ec46b99dcc6c594e";
}
