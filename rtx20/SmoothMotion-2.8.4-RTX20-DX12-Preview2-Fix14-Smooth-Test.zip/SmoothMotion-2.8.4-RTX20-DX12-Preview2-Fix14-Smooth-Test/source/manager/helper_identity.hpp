#pragma once
namespace helper_identity {
inline constexpr char installer[]="b98ad4358630b45660cdb675ee9eb599f258eb3323878b909e4457b83af32219";
inline constexpr char collector[]="37679457e379763122fa35a14d5d41e658ad995e58a0398388e0cc2be508fa01";
}
