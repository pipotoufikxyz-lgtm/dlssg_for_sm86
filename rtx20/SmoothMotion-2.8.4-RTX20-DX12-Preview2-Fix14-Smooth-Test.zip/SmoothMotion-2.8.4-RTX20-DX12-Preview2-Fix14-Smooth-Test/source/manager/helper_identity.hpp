#pragma once
namespace helper_identity {
inline constexpr char installer[]="b8097b285bdcfdbcf6f1543cc9eef93a1096a061b6eea5fca44e8cd4d89ca3ae";
inline constexpr char collector[]="8caab19214d18c4a6939fed92f1e7bf79c646977c673f6dd63d31e99b2691e29";
}
