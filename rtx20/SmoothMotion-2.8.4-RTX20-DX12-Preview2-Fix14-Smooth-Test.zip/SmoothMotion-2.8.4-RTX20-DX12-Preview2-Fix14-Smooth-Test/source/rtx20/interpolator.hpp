#pragma once
#include "nvs30/common.hpp"
#include <memory>
#include "present_sequence.hpp"
namespace sm20 {
bool load_runtime();
const char* runtime_status();
extern std::atomic_ullong flow_pairs,generated_submissions,real_submissions,failures;
class Interpolator {
 struct Impl; std::unique_ptr<Impl> impl_;
 bool failed_{},retryBlocked_{},deferredFailure_{};
 HRESULT terminal_{};
 bool write(IDXGISwapChain*,bool generated);
public:
 Interpolator(); ~Interpolator();
 Interpolator(const Interpolator&)=delete;
 // DX12 requires the exact presentation queue captured at creation/resize.
 // vsync: the game presents with sync interval 1 (pairs on refreshes).
 // Returns whether a generated frame is to be presented; plan() has details.
 bool prepare(IDXGISwapChain* swap,ID3D12CommandQueue* queue=nullptr,bool vsync=false);
 // After the generated Present: pipelined computation of the next pair;
 // returns when the generated frame became visible (seconds) or -1.
 double after_generated(bool shown);
 HRESULT terminal_error()const{return terminal_;}
 bool write_generated(IDXGISwapChain* swap);
 bool write_original(IDXGISwapChain* swap);
 void accepted();
 void discard_history();
 void reset(bool retry=true);
 bool ready() const;
 // Presentation plan decided by the last prepare().
 PairPlan plan() const;
};
}
