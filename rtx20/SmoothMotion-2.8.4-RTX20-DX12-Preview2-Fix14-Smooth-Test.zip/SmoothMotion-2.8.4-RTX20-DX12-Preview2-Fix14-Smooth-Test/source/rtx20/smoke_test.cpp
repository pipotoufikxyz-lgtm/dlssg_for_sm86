#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11_1.h>
#include <dxgi1_2.h>
#include <wrl/client.h>
#include <cstdio>
#include <string>
#include <cmath>
using Microsoft::WRL::ComPtr;
LRESULT CALLBACK procedure(HWND w,UINT m,WPARAM a,LPARAM b){if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,b);}
int main(){
 SetProcessDPIAware();
 wchar_t file[32768]{};GetModuleFileNameW(nullptr,file,32768);std::wstring dir(file);dir.resize(dir.find_last_of(L"\\/")+1);
 // The test scene runs far above the display refresh; keep generation active
 // (the runtime otherwise pauses it there) unless the user chose a value.
 if(!GetEnvironmentVariableW(L"SM86_GENERATE_ABOVE_REFRESH",nullptr,0))SetEnvironmentVariableW(L"SM86_GENERATE_ABOVE_REFRESH",L"1");
 auto module=LoadLibraryExW((dir+L"new.asi").c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
 using Entry=void(*)();using Status=unsigned(WINAPI*)(char*,unsigned);
 auto start=module?reinterpret_cast<Entry>(GetProcAddress(module,"InitializeASI")):nullptr;
 auto status=module?reinterpret_cast<Status>(GetProcAddress(module,"SmoothMotionGetStatus")):nullptr;
 if(!start||!status){std::puts("Missing test new.asi. Extract the full ZIP.");return 2;}start();
 WNDCLASSW wc{};wc.hInstance=GetModuleHandleW(nullptr);wc.lpfnWndProc=procedure;wc.lpszClassName=L"SM20_Hardware_Test";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);RegisterClassW(&wc);
 HWND window=CreateWindowW(wc.lpszClassName,L"RTX20 test - 10s VSync then 10s uncapped - F11 toggles",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,1000,620,nullptr,nullptr,wc.hInstance,nullptr);
 DXGI_SWAP_CHAIN_DESC sd{};sd.BufferDesc.Width=960;sd.BufferDesc.Height=540;sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;sd.SampleDesc.Count=1;
 sd.BufferCount=2;sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.OutputWindow=window;sd.Windowed=TRUE;sd.SwapEffect=DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
 ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;ComPtr<IDXGISwapChain> swap;D3D_FEATURE_LEVEL level;
 ComPtr<IDXGIFactory1> factory;ComPtr<IDXGIAdapter1> selected;
 CreateDXGIFactory1(IID_PPV_ARGS(&factory));if(factory){for(UINT i=0;;++i){ComPtr<IDXGIAdapter1> a;if(factory->EnumAdapters1(i,&a)==DXGI_ERROR_NOT_FOUND)break;DXGI_ADAPTER_DESC1 d{};if(a&&SUCCEEDED(a->GetDesc1(&d))&&d.VendorId==0x10de){selected=a;break;}}}
 auto hr=D3D11CreateDeviceAndSwapChain(selected.Get(),selected?D3D_DRIVER_TYPE_UNKNOWN:D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,&sd,&swap,&device,&level,&context);
 if(FAILED(hr)){std::printf("D3D11 creation failed: %lx\n",(unsigned long)hr);return 3;}
 ComPtr<ID3D11DeviceContext1> c1;context.As(&c1);if(!c1){std::puts("D3D11.1 context unavailable");return 4;}
 auto begin=GetTickCount64();unsigned frames=0;MSG msg{};bool running=true;
 while(running&&GetTickCount64()-begin<20000){
  while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)running=false;TranslateMessage(&msg);DispatchMessageW(&msg);}if(!running)break;
  ComPtr<ID3D11Texture2D> back;ComPtr<ID3D11RenderTargetView> view;swap->GetBuffer(0,IID_PPV_ARGS(&back));device->CreateRenderTargetView(back.Get(),nullptr,&view);
  float bg[]={0.035f,0.05f,0.08f,1};context->ClearRenderTargetView(view.Get(),bg);
  float elapsed=float(GetTickCount64()-begin)*0.001f;
  for(int j=0;j<6;++j){int x=int(std::fmod(elapsed*125+j*159,1100.f))-100;D3D11_RECT rect{x,65+j*60,x+65,110+j*60};float color[]={0.1f+j*.12f,.85f-j*.10f,.3f+j*.10f,1};c1->ClearView(view.Get(),color,&rect,1);}
  hr=swap->Present(elapsed<10.f?1:0,0);if(FAILED(hr)){std::printf("Present failed: %lx\n",(unsigned long)hr);break;}++frames;
 }
 char json[8192]{};status(json,sizeof json);std::puts(json);
 FILE* out=nullptr;_wfopen_s(&out,(dir+L"rtx20-test-report.txt").c_str(),L"wb");if(out){std::fprintf(out,"RTX20 test - first 10 seconds VSync, next 10 seconds interval 0; %u application frames\n%s\n\nAccepted Present calls are not proof that the display showed each frame. Compare F11 on/off and inspect the moving bars.\n",frames,json);std::fclose(out);}
 MessageBoxW(window,L"Test finished. The status is saved in rtx20-test-report.txt and nvsmooth30.log in this Test folder.\n\nNonzero flow_pairs and generated_present_accepted show that processing and presentation submission ran. Visual quality still needs checking.",L"RTX20 hardware test",MB_OK);
 DestroyWindow(window);return FAILED(hr)?5:0;
}
