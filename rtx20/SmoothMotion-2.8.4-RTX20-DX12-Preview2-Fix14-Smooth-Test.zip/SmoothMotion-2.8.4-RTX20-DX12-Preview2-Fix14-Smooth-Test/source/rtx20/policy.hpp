#pragma once
#include <algorithm>
#include <cstdint>
namespace sm20 {
// Control flags and dirty/scroll updates keep their original presentation.
inline constexpr unsigned present_test=0x1, present_allow_tearing=0x200, swapchain_allow_tearing=0x800;
enum class Admission { eligible, test, partial, interval, flags, tearing_contract };
inline Admission request_admission(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) {
 if(flags&present_test)return Admission::test;
 if(partial)return Admission::partial;
 if(sync>1)return Admission::interval;
 if(flags==0)return Admission::eligible;
 if(flags!=present_allow_tearing)return Admission::flags;
 return sync==0&&windowed&&(swapFlags&swapchain_allow_tearing)?Admission::eligible:Admission::tearing_contract;
}
inline bool supported_gpu(unsigned vendor,int major,int minor) { return vendor==0x10de && major==7 && minor==5; }
inline bool supported_format(unsigned f) { return f==28 || f==29 || f==87 || f==91; }
inline bool interpolate_request(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) { return request_admission(sync,flags,partial,windowed,swapFlags)==Admission::eligible; }
inline bool fresh_history(std::uint64_t previous,std::uint64_t now) { return previous && now>=previous && now-previous<=250; }
inline unsigned grid_extent(unsigned n) { return (n+3)/4; }
inline bool dimensions(unsigned w,unsigned h) { return w>=128 && h>=128 && w<=3840 && h<=2160; }
// Optical-flow resolution. Full-resolution NVOF (4-pixel cells) preserves thin
// detail; half resolution (8-pixel cells) costs about a quarter of the flow
// GPU time. Automatic mode uses half resolution only when the real frame rate
// is already high: motion per frame is then small and GPU time decides the
// generated frame rate. Hysteresis avoids switching back and forth.
enum class FlowResolution { automatic, full, half };
// Case-insensitive comparison of a setting value with a lower-case word.
inline bool setting_equals(const wchar_t* value,const wchar_t* word) {
 if(!value)return false;
 for(;*value&&*word;++value,++word){wchar_t c=*value;if(c>=L'A'&&c<=L'Z')c=wchar_t(c-L'A'+L'a');if(c!=*word)return false;}
 return !*value&&!*word;
}
inline FlowResolution parse_flow_resolution(const wchar_t* value) {
 if(setting_equals(value,L"full"))return FlowResolution::full;
 if(setting_equals(value,L"half"))return FlowResolution::half;
 return FlowResolution::automatic;
}
inline constexpr double half_flow_enter_fps=58, half_flow_leave_fps=45;
inline bool use_half_flow(FlowResolution setting,bool available,bool current,double realFps) {
 if(!available||setting==FlowResolution::full)return false;
 if(setting==FlowResolution::half)return true;
 return realFps>=(current?half_flow_leave_fps:half_flow_enter_fps);
}
// Optical-flow quality at full resolution: NVIDIA's SLOW preset gives the best
// vectors but takes longest. Automatic mode uses it at low real frame rates,
// where motion per frame (and so artifact visibility) is largest and each
// frame leaves the most GPU time; MEDIUM above. Half resolution has priority.
enum class FlowQuality { automatic, high, medium };
inline FlowQuality parse_flow_quality(const wchar_t* value) {
 if(setting_equals(value,L"high")||setting_equals(value,L"slow"))return FlowQuality::high;
 if(setting_equals(value,L"medium")||setting_equals(value,L"balanced"))return FlowQuality::medium;
 return FlowQuality::automatic;
}
inline const char* flow_quality_name(FlowQuality q) {return q==FlowQuality::high?"high":q==FlowQuality::medium?"medium":"auto";}
inline constexpr double quality_flow_enter_fps=40, quality_flow_leave_fps=48;
inline bool use_quality_flow(FlowQuality setting,bool available,bool current,double realFps) {
 if(!available||setting==FlowQuality::medium)return false;
 if(setting==FlowQuality::high)return true;
 return realFps>0&&realFps<(current?quality_flow_leave_fps:quality_flow_enter_fps);
}
// Exponential average of the real frame interval; gaps longer than the
// history window (pauses, F11, loading) restart the measurement.
inline double update_frame_interval(double average,double seconds) {
 if(!(seconds>0)||seconds>0.25)return 0;
 return average>0?average+(seconds-average)*0.1:seconds;
}
// Generated frames beyond the display refresh rate are never shown: they only
// add tearing, latency and GPU load. While generating, the measured real
// rate already includes generation cost; pause once it reaches the refresh
// rate, and resume only when the native rate drops clearly below it.
inline bool generation_useful(bool generating,double realFps,double refreshHz) {
 if(!(refreshHz>1)||!(realFps>0))return true;
 return realFps<refreshHz*(generating?1.02:0.9);
}
// Presentation of generated frames. Both frames of a pair are submitted from
// the game's own Present call. Submitted back to back, the generated frame is
// replaced within about a millisecond and only the real frames are seen.
//
// Spaced presentation holds the real frame until half a real-frame interval
// after the generated frame became visible, so both are shown for equal time:
//   timed:     capture, flow and synthesis, generated Present, wait, real
//              Present. Lowest latency; the wait and the generation cost both
//              occupy the game thread.
//   pipelined: the previous pair is presented (generated, then the previous
//              real frame) and flow/synthesis for the next pair run on the GPU
//              during the wait. One real frame more latency; generation cost
//              leaves the game thread, so even spacing fits at low base rates.
// The wait never deliberately lowers the game's frame rate: a controller
// shrinks it whenever the real rate falls below the rate measured without it.
// Games presenting with VSync pair both frames on consecutive refreshes
// (sync interval 1) instead of waiting on the CPU.
//   measuring: ~0.75 s unspaced, to measure the real rate;
//   timed / pipelined: spaced presentation (Pacing=auto chooses);
//   vblank:    both frames with sync interval 1 (Pacing=vblank, Fix13);
//   immediate: unspaced (Pacing=off);
//   paused:    real rate already at/above refresh, generated frames would not
//              be visible; resume (via measuring) below 90% of refresh.
enum class Pacing { automatic, low_latency, smooth, vblank, off };
inline Pacing parse_pacing(const wchar_t* value) {
 for(const auto* word:{L"off",L"0",L"false",L"no",L"immediate"})if(setting_equals(value,word))return Pacing::off;
 for(const auto* word:{L"low_latency",L"lowlatency",L"timed"})if(setting_equals(value,word))return Pacing::low_latency;
 for(const auto* word:{L"smooth",L"pipelined"})if(setting_equals(value,word))return Pacing::smooth;
 for(const auto* word:{L"vblank",L"refresh"})if(setting_equals(value,word))return Pacing::vblank;
 return Pacing::automatic;
}
inline const char* pacing_name(Pacing p) {
 return p==Pacing::off?"off":p==Pacing::low_latency?"low_latency":p==Pacing::smooth?"smooth":p==Pacing::vblank?"vblank":"auto";
}
enum class Presentation { measuring, timed, pipelined, vblank, immediate, paused };
inline const char* presentation_name(Presentation p) {
 constexpr const char* names[]={"measuring","timed","pipelined","vblank","immediate","paused"};
 return names[static_cast<int>(p)];
}
struct PresentationPolicy {
 Pacing pacing{Pacing::automatic};bool generateAboveRefresh{};double refreshHz{};
 Presentation state{Presentation::measuring};
 double measureStart{-1};unsigned measureFrames{};
 // Real frame interval measured without spacing, in seconds.
 double reference{};
 // Current wait (seconds) and its smoothed fraction of half the reference
 // interval, used by Pacing=auto to choose the pipelined order.
 double wait{},averageSpacing{1};
 double windowStart{-1},lastFrame{-1},longestFrame{};unsigned windowFrames{},windows{},fastWindows{},stalledWindows{},shortWindows{};
 // Pacing=auto keeps the pipelined order once timed spacing proved too short.
 bool learnedPipeline{};
 static constexpr double window_seconds=0.5,probe=0.00025,margin=0.0005,tolerance=0.01,timed_minimum=0.85,maximum_wait=0.1;
 void reset(){state=Presentation::measuring;measureStart=-1;measureFrames=0;windowStart=-1;lastFrame=-1;}
 double ideal() const {return std::min(maximum_wait,reference*0.5);}
 void enter(Presentation next,double now){
  state=next;wait=ideal();averageSpacing=1;windowStart=now;lastFrame=-1;longestFrame=0;windowFrames=windows=fastWindows=stalledWindows=shortWindows=0;
 }
 // Once per real frame; realFps is the running average of the real rate.
 // spacingApplied: false for VSync pairs (no CPU wait to control).
 Presentation update(double now,double realFps,bool spacingApplied=true){
  const bool visible=generateAboveRefresh||generation_useful(state!=Presentation::paused,realFps,refreshHz);
  switch(state){
   case Presentation::measuring:
    if(measureStart<0){measureStart=now;measureFrames=0;}
    if(++measureFrames>=20&&now-measureStart>=0.75){
     reference=(now-measureStart)/(measureFrames-1);
     measureStart=-1;
     if(!visible)state=Presentation::paused;
     else if(pacing==Pacing::off)state=Presentation::immediate;
     else if(pacing==Pacing::vblank)state=Presentation::vblank;
     else enter(pacing==Pacing::smooth||(pacing==Pacing::automatic&&learnedPipeline)?Presentation::pipelined:Presentation::timed,now);
    }
    break;
   case Presentation::immediate:
   case Presentation::vblank:
    if(!visible)state=Presentation::paused;
    break;
   case Presentation::paused:
    if(visible)reset();
    break;
   case Presentation::timed:
   case Presentation::pipelined:
    if(!visible){state=Presentation::paused;break;}
    if(spacingApplied)control(now);else{windowStart=now;windowFrames=0;lastFrame=-1;longestFrame=0;}
    break;
  }
  return state;
 }
 // Every half second compare the mean real interval with the reference. A
 // wait beyond the game's slack delays every frame by exactly the excess,
 // so the excess is removed in one step; otherwise probe upward slowly.
 void control(double now){
  ++windowFrames;
  if(lastFrame>=0)longestFrame=std::max(longestFrame,now-lastFrame);
  lastFrame=now;
  if(windowStart<0){windowStart=now;windowFrames=0;longestFrame=0;return;}
  const double elapsed=now-windowStart;
  if(elapsed<window_seconds||!windowFrames)return;
  const double interval=elapsed/windowFrames,longest=longestFrame;
  windowStart=now;windowFrames=0;longestFrame=0;++windows;
  if(!(reference>0))return;
  // A single hitch (loading, shader compilation) says nothing about the
  // spacing; skip such windows instead of cutting the wait.
  if(longest>2.5*reference)return;
  if(interval>reference*(1+tolerance)+0.0002){
   wait=std::max(0.0,wait-(interval-reference)-margin);fastWindows=0;
   // Still slow with almost no wait: the game itself slowed down (heavier
   // scene). Measure against the new interval and probe from the ideal.
   if(wait<=ideal()*0.1&&++stalledWindows>=4){reference=interval;wait=ideal();stalledWindows=0;}
  }else{
   stalledWindows=0;wait=std::min(ideal(),wait+probe);
   // Faster than the reference (limiter raised, lighter scene): follow it.
   if(interval<reference*0.93){if(++fastWindows>=3){reference=interval;wait=std::min(wait,ideal());fastWindows=0;}}else fastWindows=0;
  }
  averageSpacing+=(spacing()-averageSpacing)*0.3;
  // Only sustained short spacing selects the pipelined order.
  shortWindows=averageSpacing<timed_minimum?shortWindows+1:0;
  if(state==Presentation::timed&&pacing==Pacing::automatic&&windows>=6&&shortWindows>=4){
   learnedPipeline=true;enter(Presentation::pipelined,now);
  }
 }
 // Fraction of the ideal (half-interval) spacing currently applied.
 double spacing() const {const double i=ideal();return i>0?wait/i:0;}
 // Seconds between the generated frame becoming visible and the real Present.
 double wait_seconds() const {
  if((state!=Presentation::timed&&state!=Presentation::pipelined)||!(reference>0))return 0;
  return std::min(maximum_wait,wait);
 }
 bool generating() const {return state!=Presentation::paused;}
 bool spaced() const {return state==Presentation::timed||state==Presentation::pipelined;}
 bool pipelined() const {return state==Presentation::pipelined;}
 bool paced() const {return state==Presentation::vblank;}
};
}
