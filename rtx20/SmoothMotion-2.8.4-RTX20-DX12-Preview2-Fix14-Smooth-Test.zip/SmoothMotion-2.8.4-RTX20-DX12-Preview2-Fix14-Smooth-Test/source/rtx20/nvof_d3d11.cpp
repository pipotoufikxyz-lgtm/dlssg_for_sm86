#include "nvof_d3d11.hpp"
#include "nvs30/log.hpp"
#include <stdexcept>

// Use the matched SDK5 header set as its own ABI, without changing the existing
// CUDA2 structures in interpolator.cpp. System headers are already included.
namespace sm20::native_of {
#include "../../third_party/nvidia-optical-flow/d3d11-api5/nvOpticalFlowD3D11.h"
inline constexpr unsigned apiVersion=NV_OF_API_VERSION;
// Guard the exact Windows x64 layout used with this matched SDK5 header set.
// These must never silently compile against the smaller CUDA2 structures.
static_assert(apiVersion==0x50&&sizeof(void*)==8);
static_assert(sizeof(NV_OF_D3D11_API_FUNCTION_LIST)==80);
static_assert(offsetof(NV_OF_D3D11_API_FUNCTION_LIST,nvOFExecute)==48);
static_assert(offsetof(NV_OF_D3D11_API_FUNCTION_LIST,nvOFGetCaps)==72);
static_assert(sizeof(NV_OF_INIT_PARAMS)==64);
static_assert(offsetof(NV_OF_INIT_PARAMS,predDirection)==48);
static_assert(offsetof(NV_OF_INIT_PARAMS,inputBufferFormat)==56);
static_assert(sizeof(NV_OF_EXECUTE_INPUT_PARAMS)==56);
static_assert(offsetof(NV_OF_EXECUTE_INPUT_PARAMS,roiData)==48);
static_assert(sizeof(NV_OF_EXECUTE_OUTPUT_PARAMS)==48);
static_assert(offsetof(NV_OF_EXECUTE_OUTPUT_PARAMS,bwdOutputBuffer)==24);
static_assert(sizeof(NV_OF_FLOW_VECTOR)==4);
}
// SDK macros are translation-unit global even when types are namespaced.
#undef NV_OF_API_VERSION
#undef NV_OF_API_MAJOR_VERSION
#undef NV_OF_API_MINOR_VERSION

namespace sm20 {
namespace {
using namespace native_of;
using nvs30::ComPtr;
struct Runtime {
 HMODULE module{};
 NV_OF_D3D11_API_FUNCTION_LIST api{};
 bool ready{};
} runtime;
std::once_flag loadFlag;
void load(){
 std::call_once(loadFlag,[]{
  runtime.module=LoadLibraryExW(L"nvofapi64.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  if(!runtime.module){nvs30::logf("[rtx20-nvof] D3D11 unavailable: system nvofapi64.dll missing.\n");return;}
  auto create=reinterpret_cast<decltype(&NvOFAPICreateInstanceD3D11)>(GetProcAddress(runtime.module,"NvOFAPICreateInstanceD3D11"));
  auto version=reinterpret_cast<decltype(&NvOFGetMaxSupportedApiVersion)>(GetProcAddress(runtime.module,"NvOFGetMaxSupportedApiVersion"));
  std::uint32_t maximum{};
  if(!create||!version||version(&maximum)!=NV_OF_SUCCESS||maximum<apiVersion){
   nvs30::logf("[rtx20-nvof] D3D11 API5 unavailable: max_version=0x%x; CUDA2 fallback permitted.\n",maximum);return;
  }
  const auto status=create(apiVersion,&runtime.api);
  if(status!=NV_OF_SUCCESS){nvs30::logf("[rtx20-nvof] NvOFAPICreateInstanceD3D11(API5) failed: NVOF=%d.\n",int(status));return;}
  const auto& a=runtime.api;
  runtime.ready=a.nvCreateOpticalFlowD3D11&&a.nvOFInit&&a.nvOFGetCaps&&a.nvOFExecute&&a.nvOFDestroy&&
   a.nvOFGetSurfaceFormatCountD3D11&&a.nvOFGetSurfaceFormatD3D11&&a.nvOFRegisterResourceD3D11&&a.nvOFUnregisterResourceD3D11;
  if(!runtime.ready)nvs30::logf("[rtx20-nvof] Incomplete D3D11 API5 table; CUDA2 fallback permitted.\n");
 });
}
void require(bool condition,const char* operation){if(!condition)throw std::runtime_error(operation);}
void require_hr(HRESULT hr,const char* operation){
 if(FAILED(hr)){nvs30::logf("[rtx20-nvof] %s: hr=0x%08lx.\n",operation,(unsigned long)hr);throw std::runtime_error(operation);}
}
bool same_device(ID3D11Device* a,ID3D11Device* b){
 ComPtr<IUnknown> x,y;return a&&b&&SUCCEEDED(a->QueryInterface(IID_PPV_ARGS(&x)))&&SUCCEEDED(b->QueryInterface(IID_PPV_ARGS(&y)))&&x.Get()==y.Get();
}
}
struct NvofD3D11::Impl {
 NvOFHandle session{};
 ComPtr<ID3D11Device> device;
 ComPtr<ID3D11DeviceContext> context;
 ComPtr<ID3D11Query> completion;
 struct Registered {ComPtr<ID3D11Texture2D> texture;NvOFGPUBufferHandle handle{};} images[4];
 bool submitted{},unsafe{},initialized{};
 void status(NV_OF_STATUS code,const char* operation){
  if(code==NV_OF_SUCCESS)return;
  char detail[512]{};std::uint32_t size=sizeof detail;
  if(session&&runtime.api.nvOFGetLastError)runtime.api.nvOFGetLastError(session,detail,&size);
  detail[sizeof detail-1]=0;
  nvs30::logf("[rtx20-nvof] %s failed: NVOF=%d detail=%s.\n",operation,int(code),detail);
  throw std::runtime_error(operation);
 }
 std::vector<std::uint32_t> caps(NV_OF_CAPS kind){
  std::uint32_t count{};status(runtime.api.nvOFGetCaps(session,kind,nullptr,&count),"nvOFGetCaps(count)");
  require(count&&count<=64,"invalid NVOF capability count");std::vector<std::uint32_t> values(count);
  status(runtime.api.nvOFGetCaps(session,kind,values.data(),&count),"nvOFGetCaps(values)");
  require(count&&count<=values.size(),"invalid populated NVOF capability count");values.resize(count);return values;
 }
 void supported(NV_OF_BUFFER_USAGE usage,DXGI_FORMAT required){
  std::uint32_t count{};status(runtime.api.nvOFGetSurfaceFormatCountD3D11(session,usage,NV_OF_MODE_OPTICALFLOW,&count),"nvOFGetSurfaceFormatCountD3D11");
  if(!count||count>128){
   nvs30::logf("[rtx20-nvof] Invalid D3D11 advertised format count=%u usage=%u; refusing format query allocation.\n",count,unsigned(usage));
   throw std::runtime_error("invalid NVOF format count");
  }
  std::vector<DXGI_FORMAT> formats(count);
  status(runtime.api.nvOFGetSurfaceFormatD3D11(session,usage,NV_OF_MODE_OPTICALFLOW,formats.data()),"nvOFGetSurfaceFormatD3D11");
  // Include successful queries too: diagnostics must show the actual driver
  // contract. Bound each log payload well below a 1024-byte logger buffer.
  std::string advertised;advertised.reserve(768);unsigned first=0;
  for(unsigned i=0;i<count;++i){
   const auto value=std::to_string(unsigned(formats[i]));
   if(advertised.size()+value.size()+1>768){
    nvs30::logf("[rtx20-nvof] D3D11 usage=%u count=%u advertised_formats[%u..%u]=[%s].\n",unsigned(usage),count,first,i-1,advertised.c_str());
    advertised.clear();first=i;
   }
   if(!advertised.empty())advertised+=',';advertised+=value;
  }
  nvs30::logf("[rtx20-nvof] D3D11 usage=%u count=%u advertised_formats[%u..%u]=[%s].\n",unsigned(usage),count,first,count-1,advertised.c_str());
  if(std::find(formats.begin(),formats.end(),required)==formats.end()){
   nvs30::logf("[rtx20-nvof] D3D11 format=%u unavailable for usage=%u; advertised count=%u (full list above).\n",unsigned(required),unsigned(usage),count);
   throw std::runtime_error("required D3D11 NVOF format unsupported");
  }
 }
 void initialize(ID3D11Device* d,ID3D11DeviceContext* c,unsigned width,unsigned height,
                 ID3D11Texture2D* const frames[2],ID3D11Texture2D* const flows[2],bool quality){
  require(d&&c&&frames&&flows,"invalid D3D11 NVOF initialization arguments");
  ComPtr<ID3D11Device> owner;c->GetDevice(&owner);
  require(same_device(d,owner.Get())&&c->GetType()==D3D11_DEVICE_CONTEXT_IMMEDIATE,"NVOF requires owning immediate context");
  device=d;context=c;
  status(runtime.api.nvCreateOpticalFlowD3D11(d,c,&session),"nvCreateOpticalFlowD3D11");
  for(auto cap:{NV_OF_CAPS_WIDTH_MIN,NV_OF_CAPS_HEIGHT_MIN,NV_OF_CAPS_WIDTH_MAX,NV_OF_CAPS_HEIGHT_MAX}){
   const auto values=caps(cap);require(values.size()==1,"invalid NVOF dimension capability");
   const auto size=(cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_WIDTH_MAX)?width:height;
   require((cap==NV_OF_CAPS_WIDTH_MIN||cap==NV_OF_CAPS_HEIGHT_MIN)?size>=values[0]:size<=values[0],"dimensions outside D3D11 NVOF capabilities");
  }
  const auto grids=caps(NV_OF_CAPS_SUPPORTED_OUTPUT_GRID_SIZES);
  require(std::find(grids.begin(),grids.end(),4u)!=grids.end(),"D3D11 NVOF output grid 4 unsupported");
  // NVIDIA SDK5 NvOFD3DCommon.cpp maps ABGR8 to B8G8R8A8_UNORM for
  // Direct3D. CUDA's identically named buffer format is a separate contract.
  supported(NV_OF_BUFFER_USAGE_INPUT,NvofD3D11::input_format());
  supported(NV_OF_BUFFER_USAGE_OUTPUT,DXGI_FORMAT_R16G16_SINT);
  NV_OF_INIT_PARAMS p{};p.width=width;p.height=height;p.outGridSize=NV_OF_OUTPUT_VECTOR_GRID_SIZE_4;
  p.mode=NV_OF_MODE_OPTICALFLOW;p.perfLevel=quality?NV_OF_PERF_LEVEL_SLOW:NV_OF_PERF_LEVEL_MEDIUM;p.predDirection=NV_OF_PRED_DIRECTION_BOTH;
  p.inputBufferFormat=NV_OF_BUFFER_FORMAT_ABGR8;
  // SDK5 exposes no separate performance-level capability query. nvOFInit
  // validates the preset and BOTH support; rejection leaves CUDA2 as the init
  // fallback (MEDIUM) or MEDIUM only (SLOW session).
  status(runtime.api.nvOFInit(session,&p),quality?"nvOFInit(D3D11 SLOW BOTH)":"nvOFInit(D3D11 MEDIUM BOTH)");
  for(unsigned i=0;i<4;++i){
   auto* texture=i<2?frames[i]:flows[i-2];require(texture!=nullptr,"null D3D11 NVOF texture");
   D3D11_TEXTURE2D_DESC desc{};texture->GetDesc(&desc);ComPtr<ID3D11Device> td;texture->GetDevice(&td);
   require(same_device(d,td.Get())&&desc.Width==(i<2?width:(width+3)/4)&&desc.Height==(i<2?height:(height+3)/4)&&
    desc.Format==(i<2?NvofD3D11::input_format():DXGI_FORMAT_R16G16_SINT)&&desc.MipLevels==1&&desc.ArraySize==1&&
    desc.SampleDesc.Count==1&&desc.Usage==D3D11_USAGE_DEFAULT,"D3D11 NVOF texture contract");
   for(unsigned j=0;j<i;++j)require(images[j].texture.Get()!=texture,"duplicate D3D11 NVOF texture");
   images[i].texture=texture;status(runtime.api.nvOFRegisterResourceD3D11(session,texture,&images[i].handle),"nvOFRegisterResourceD3D11");
  }
  D3D11_QUERY_DESC q{D3D11_QUERY_EVENT,0};require_hr(d->CreateQuery(&q,&completion),"CreateQuery(native OF reset)");
  initialized=true;
  nvs30::logf("[rtx20-nvof] nvof_api=D3D11 API5 ready: %ux%u preset=%s, grid=4, single bidirectional execute; direct registered BGRA8(input_format=%u)/SHORT2, no CUDA frame copies/map/unmap/context-sync.\n",width,height,quality?"SLOW (best quality)":"MEDIUM (balanced quality)",unsigned(NvofD3D11::input_format()));
 }
 NvOFGPUBufferHandle handle(ID3D11Texture2D* texture,unsigned begin,unsigned end){
  for(unsigned i=begin;i<end;++i)if(images[i].texture.Get()==texture)return images[i].handle;
  return nullptr;
 }
 HRESULT execute(ID3D11Texture2D* previous,ID3D11Texture2D* current,ID3D11Texture2D* const flows[2]){
  if(!initialized||unsafe)return DXGI_ERROR_DEVICE_RESET;
  if(!flows||previous==current||flows[0]==flows[1])return E_INVALIDARG;
  NV_OF_EXECUTE_INPUT_PARAMS in{};in.inputFrame=handle(previous,0,2);in.referenceFrame=handle(current,0,2);
  in.disableTemporalHints=NV_OF_TRUE;
  NV_OF_EXECUTE_OUTPUT_PARAMS out{};out.outputBuffer=handle(flows[0],2,4);out.bwdOutputBuffer=handle(flows[1],2,4);
  if(!in.inputFrame||!in.referenceFrame||!out.outputBuffer||!out.bwdOutputBuffer)return E_INVALIDARG;
  // The SDK's D3D11 interface supplies runtime/driver ordering on this same
  // immediate context. The next D3D11 synthesis draw consumes these textures;
  // CPU synchronization and CUDA graphics ownership transitions are unnecessary.
  // Set submitted before entering the driver: an error may follow submission.
  submitted=true;const auto code=runtime.api.nvOFExecute(session,&in,&out);
  if(code!=NV_OF_SUCCESS){unsafe=true;status(code,"nvOFExecute(D3D11 bidirectional)");}
  const auto hr=device->GetDeviceRemovedReason();if(FAILED(hr))unsafe=true;return hr;
 }
 bool quiesce(){
  if(unsafe)return false;if(!submitted)return true;
  context->End(completion.Get());context->Flush();const auto start=GetTickCount64();
  for(;;){
   BOOL complete=FALSE;auto hr=context->GetData(completion.Get(),&complete,sizeof complete,D3D11_ASYNC_GETDATA_DONOTFLUSH);
   if(hr==S_OK&&complete){submitted=false;return true;}
   if(FAILED(hr)||FAILED(device->GetDeviceRemovedReason())||GetTickCount64()-start>=500){
    unsafe=true;nvs30::logf("[rtx20-nvof] Native OF reset completion uncertain; retaining session.\n");return false;
   }
   Sleep(0);
  }
 }
 ~Impl(){
  // Public owner verifies quiescence before destruction; failed initialization
  // reaches this destructor before execute, so resources can be unregistered.
  for(auto& image:images)if(image.handle){
   const auto code=runtime.api.nvOFUnregisterResourceD3D11(image.handle);
   if(code!=NV_OF_SUCCESS)nvs30::logf("[rtx20-nvof] unregister resource failed NVOF=%d.\n",int(code));
   image.handle=nullptr;
  }
  if(session){const auto code=runtime.api.nvOFDestroy(session);if(code!=NV_OF_SUCCESS)nvs30::logf("[rtx20-nvof] destroy session failed NVOF=%d.\n",int(code));}
 }
};
NvofD3D11::NvofD3D11()=default;
NvofD3D11::~NvofD3D11(){if(impl_&&!impl_->quiesce())(void)impl_.release();}
bool NvofD3D11::available()noexcept{try{load();return runtime.ready;}catch(...){return false;}}
bool NvofD3D11::initialize(ID3D11Device* device,ID3D11DeviceContext* context,unsigned width,unsigned height,
                         ID3D11Texture2D* const frames[2],ID3D11Texture2D* const flows[2],bool quality)noexcept{
 if(impl_||!available())return false;
 try{auto candidate=std::make_unique<Impl>();candidate->initialize(device,context,width,height,frames,flows,quality);impl_=std::move(candidate);return true;}
 catch(const std::exception& e){nvs30::logf("[rtx20-nvof] Native D3D11 initialization unavailable: %s; CUDA2 fallback permitted.\n",e.what());}
 catch(...){nvs30::logf("[rtx20-nvof] Native D3D11 initialization exception; CUDA2 fallback permitted.\n");}
 return false;
}
HRESULT NvofD3D11::execute(ID3D11Texture2D* previous,ID3D11Texture2D* current,ID3D11Texture2D* const flows[2])noexcept{
 if(!impl_)return E_UNEXPECTED;
 try{return impl_->execute(previous,current,flows);}catch(...){impl_->unsafe=true;return E_FAIL;}
}
bool NvofD3D11::ready()const noexcept{return impl_&&impl_->initialized&&!impl_->unsafe;}
bool NvofD3D11::quiesce()noexcept{return !impl_||impl_->quiesce();}
}
