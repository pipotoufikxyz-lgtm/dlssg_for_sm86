#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d12.h>
#include <d3d12sdklayers.h>
#include <dxgi1_5.h>
#include <wrl/client.h>
#include <cstdio>
#include <string>
#include <cmath>
#include <vector>
#include "../native/include/nvs30/gpu_wait.hpp"
#include "smoke_validation.hpp"
using Microsoft::WRL::ComPtr;
namespace {
struct Error {HRESULT hr;const char* operation;};
void check(HRESULT hr,const char* what){if(FAILED(hr))throw Error{hr,what};}
LRESULT CALLBACK procedure(HWND w,UINT m,WPARAM a,LPARAM b){if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,b);}
D3D12_RESOURCE_BARRIER transition(ID3D12Resource* r,D3D12_RESOURCE_STATES a,D3D12_RESOURCE_STATES b){
 D3D12_RESOURCE_BARRIER x{};x.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;x.Transition={r,D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES,a,b};return x;
}
struct Renderer {
 ComPtr<ID3D12Device> device;ComPtr<ID3D12CommandQueue> queues[2];ComPtr<IDXGISwapChain3> swap;
 ComPtr<ID3D12CommandAllocator> allocator;ComPtr<ID3D12GraphicsCommandList> commands;
 ComPtr<ID3D12DescriptorHeap> rtv;ComPtr<ID3D12Fence> fence;HANDLE event{};
 ComPtr<ID3D12InfoQueue> infoQueue;std::uint64_t debugErrors{},debugDiscarded{};bool debugEnabled{};
 UINT active{},width=960,height=540,swapFlags{};UINT64 fenceValue{};bool inFlight{};
 unsigned tearingFrames{},vsyncFrames{};
 ~Renderer(){if(event)CloseHandle(event);}
 void initialize(HWND window){
  // Enable the optional Windows Graphics Tools debug layer before creating a
  // device. The test also runs when that optional component is not installed.
  ComPtr<ID3D12Debug> debug;
  if(SUCCEEDED(D3D12GetDebugInterface(IID_PPV_ARGS(&debug)))){debug->EnableDebugLayer();debugEnabled=true;}
  ComPtr<IDXGIFactory4> factory;check(CreateDXGIFactory1(IID_PPV_ARGS(&factory)),"CreateDXGIFactory1");
  ComPtr<IDXGIFactory5> factory5;BOOL tearing=FALSE;
  if(SUCCEEDED(factory.As(&factory5))&&SUCCEEDED(factory5->CheckFeatureSupport(DXGI_FEATURE_PRESENT_ALLOW_TEARING,&tearing,sizeof tearing))&&tearing)
   swapFlags=DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING;
  std::puts(swapFlags?"Tearing supported: phases use tearing / VSync / tearing.":"Tearing unavailable: all phases use VSync; tearing path remains untested.");
  ComPtr<IDXGIAdapter1> selected;
  for(UINT i=0;;++i){ComPtr<IDXGIAdapter1> a;auto hr=factory->EnumAdapters1(i,&a);if(hr==DXGI_ERROR_NOT_FOUND)break;check(hr,"EnumAdapters1");DXGI_ADAPTER_DESC1 d{};check(a->GetDesc1(&d),"AdapterDesc");if(d.VendorId==0x10de){selected=a;break;}}
  if(!selected)throw Error{DXGI_ERROR_NOT_FOUND,"NVIDIA adapter not found"};
  check(D3D12CreateDevice(selected.Get(),D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&device)),"D3D12CreateDevice");
  if(debugEnabled)device.As(&infoQueue);
  std::puts(infoQueue?"D3D12 debug validation available.":"D3D12 debug validation unavailable; API counters will still be checked.");
  D3D12_COMMAND_QUEUE_DESC q{};q.Type=D3D12_COMMAND_LIST_TYPE_DIRECT;
  for(auto& queue:queues)check(device->CreateCommandQueue(&q,IID_PPV_ARGS(&queue)),"CreateCommandQueue");
  DXGI_SWAP_CHAIN_DESC1 d{};d.Width=width;d.Height=height;d.Format=DXGI_FORMAT_R8G8B8A8_UNORM;d.SampleDesc.Count=1;d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.BufferCount=3;d.SwapEffect=DXGI_SWAP_EFFECT_FLIP_DISCARD;
  d.Flags=swapFlags;
  ComPtr<IDXGISwapChain1> first;check(factory->CreateSwapChainForHwnd(queues[0].Get(),window,&d,nullptr,nullptr,&first),"CreateSwapChainForHwnd");check(first.As(&swap),"Swapchain3");
  factory->MakeWindowAssociation(window,DXGI_MWA_NO_ALT_ENTER);
  check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&allocator)),"CreateCommandAllocator");
  check(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,allocator.Get(),nullptr,IID_PPV_ARGS(&commands)),"CreateCommandList");check(commands->Close(),"Close initial list");
  D3D12_DESCRIPTOR_HEAP_DESC heap{};heap.Type=D3D12_DESCRIPTOR_HEAP_TYPE_RTV;heap.NumDescriptors=1;
  check(device->CreateDescriptorHeap(&heap,IID_PPV_ARGS(&rtv)),"Create RTV heap");
  check(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence)),"CreateFence");
  event=CreateEventW(nullptr,FALSE,FALSE,nullptr);if(!event)check(HRESULT_FROM_WIN32(GetLastError()),"CreateEvent");
 }
 void collect_debug(){
  if(!infoQueue)return;
  const auto discarded=infoQueue->GetNumMessagesDiscardedByMessageCountLimit();
  if(discarded>debugDiscarded)debugDiscarded=discarded;
  const auto stored=infoQueue->GetNumStoredMessagesAllowedByRetrievalFilter();
  for(UINT64 i=0;i<stored;++i){
   SIZE_T bytes{};if(FAILED(infoQueue->GetMessage(i,nullptr,&bytes))||!bytes)continue;
   std::vector<unsigned char> storage(bytes);auto* message=reinterpret_cast<D3D12_MESSAGE*>(storage.data());
   if(FAILED(infoQueue->GetMessage(i,message,&bytes)))continue;
   if(message->Severity==D3D12_MESSAGE_SEVERITY_ERROR||message->Severity==D3D12_MESSAGE_SEVERITY_CORRUPTION){
    ++debugErrors;if(debugErrors<=5)std::printf("D3D12 debug error %u: %s\n",unsigned(message->ID),message->pDescription);
   }
  }
  infoQueue->ClearStoredMessages();
 }
 void wait(){
  check(queues[active]->Signal(fence.Get(),++fenceValue),"Signal game fence");
  check(static_cast<HRESULT>(nvs30::gpu_wait::fence(fenceValue,2000,
   [&]{return fence->GetCompletedValue();},[&](UINT64 v){return fence->SetEventOnCompletion(v,event);},
   [&](unsigned ms)->HRESULT{auto r=WaitForSingleObject(event,ms);return r==WAIT_OBJECT_0?S_OK:r==WAIT_TIMEOUT?HRESULT_FROM_WIN32(WAIT_TIMEOUT):HRESULT_FROM_WIN32(GetLastError());},
   []{return GetTickCount64();})),"Wait game fence");inFlight=false;
 }
 void resize(bool newQueue){
  wait();
  if(newQueue){
   width=960;height=540;UINT masks[]={1,1,1};IUnknown* present[]={queues[1].Get(),queues[1].Get(),queues[1].Get()};
   check(swap->ResizeBuffers1(3,width,height,DXGI_FORMAT_UNKNOWN,swapFlags,masks,present),"ResizeBuffers1 / queue change");active=1;
  }else{width=1280;height=720;check(swap->ResizeBuffers(2,width,height,DXGI_FORMAT_UNKNOWN,swapFlags),"ResizeBuffers / two buffers");}
 }
 HRESULT frame(float elapsed,bool requestTearing){
  wait();check(allocator->Reset(),"Reset game allocator");check(commands->Reset(allocator.Get(),nullptr),"Reset game list");
  ComPtr<ID3D12Resource> back;check(swap->GetBuffer(swap->GetCurrentBackBufferIndex(),IID_PPV_ARGS(&back)),"Get current backbuffer");
  const auto view=rtv->GetCPUDescriptorHandleForHeapStart();device->CreateRenderTargetView(back.Get(),nullptr,view);
  auto begin=transition(back.Get(),D3D12_RESOURCE_STATE_PRESENT,D3D12_RESOURCE_STATE_RENDER_TARGET);commands->ResourceBarrier(1,&begin);
  float bg[]={.035f,.05f,.08f,1};commands->ClearRenderTargetView(view,bg,0,nullptr);
  for(int j=0;j<6;++j){int x=int(std::fmod(elapsed*125+j*159,float(width+100)))-100;
   D3D12_RECT rect{LONG(x<0?0:x),LONG(65+j*60),LONG(x+65>int(width)?width:x+65),LONG(110+j*60)};
   if(rect.right<=rect.left)continue;
   float color[]={.1f+j*.12f,.85f-j*.10f,.3f+j*.10f,1};commands->ClearRenderTargetView(view,color,1,&rect);
  }
  auto end=transition(back.Get(),D3D12_RESOURCE_STATE_RENDER_TARGET,D3D12_RESOURCE_STATE_PRESENT);commands->ResourceBarrier(1,&end);check(commands->Close(),"Close game list");
  ID3D12CommandList* list=commands.Get();inFlight=true;queues[active]->ExecuteCommandLists(1,&list);
  const bool tearing=requestTearing&&swapFlags;
  auto hr=swap->Present(tearing?0:1,tearing?DXGI_PRESENT_ALLOW_TEARING:0);
  if(hr==S_OK){if(tearing)++tearingFrames;else ++vsyncFrames;}
  wait();collect_debug();return hr;
 }
};
}
int main(){
 SetProcessDPIAware();wchar_t file[32768]{};GetModuleFileNameW(nullptr,file,32768);std::wstring dir(file);dir.resize(dir.find_last_of(L"\\/")+1);
 // The test scene runs far above the display refresh; keep generation active
 // (the runtime otherwise pauses it there) unless the user chose a value.
 if(!GetEnvironmentVariableW(L"SM86_GENERATE_ABOVE_REFRESH",nullptr,0))SetEnvironmentVariableW(L"SM86_GENERATE_ABOVE_REFRESH",L"1");
 auto module=LoadLibraryExW((dir+L"new.asi").c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
 using Entry=void(*)();using Status=unsigned(WINAPI*)(char*,unsigned);
 auto entry=module?reinterpret_cast<Entry>(GetProcAddress(module,"InitializeASI")):nullptr;
 auto status=module?reinterpret_cast<Status>(GetProcAddress(module,"SmoothMotionGetStatus")):nullptr;
 if(!entry||!status){std::puts("Missing Test\\new.asi. Extract the full ZIP.");return 2;}entry();
 WNDCLASSW wc{};wc.hInstance=GetModuleHandleW(nullptr);wc.lpfnWndProc=procedure;wc.lpszClassName=L"SM20_DX12_Test";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);RegisterClassW(&wc);
 auto window=CreateWindowW(wc.lpszClassName,L"RTX20 DX12 - moving bars - F11 toggle - resize at 8s, queue change at 16s",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,1000,620,nullptr,nullptr,wc.hInstance,nullptr);
 HRESULT outcome=S_OK;const char* operation="completed";unsigned frames{},phase{};char snapshots[4][8192]{};bool completed=false;
 std::array<sm20::smoke::Snapshot,4> observations;
 auto capture_status=[&](unsigned index){
  const auto needed=status(snapshots[index],sizeof snapshots[index]);
  observations[index]=needed&&needed<=sizeof snapshots[index]?sm20::smoke::parse(snapshots[index]):sm20::smoke::Snapshot{};
 };
 // On uncertain GPU completion retain the renderer until process exit.
 auto renderer=new Renderer;
 try{
  renderer->initialize(window);capture_status(0);auto begin=GetTickCount64();MSG message{};bool running=true;
  while(running&&GetTickCount64()-begin<24000){
   while(PeekMessageW(&message,nullptr,0,0,PM_REMOVE)){if(message.message==WM_QUIT)running=false;TranslateMessage(&message);DispatchMessageW(&message);}if(!running)break;
   auto ms=GetTickCount64()-begin;
   if(phase==0&&ms>=8000){capture_status(1);renderer->resize(false);phase=1;}
   if(phase==1&&ms>=16000){capture_status(2);renderer->resize(true);phase=2;}
   outcome=renderer->frame(float(ms)*.001f,phase!=1);check(outcome,"Present");++frames;
  }
  completed=running&&phase==2;renderer->wait();
 }catch(const Error& e){outcome=e.hr;operation=e.operation;std::printf("%s failed: 0x%08lx\n",operation,(unsigned long)outcome);}
 capture_status(3);renderer->collect_debug();std::puts(snapshots[3]);
 auto validation=sm20::smoke::validate(observations,completed,renderer->swapFlags!=0,renderer->debugErrors);
 if(FAILED(outcome))validation={sm20::smoke::Result::fail,"The D3D12 renderer encountered an API error",phase+1};
 else if(validation.result==sm20::smoke::Result::pass&&renderer->debugDiscarded)validation={sm20::smoke::Result::inconclusive,"D3D12 debug messages were discarded; full debug validation is unavailable",0};
 const bool backendPassed=validation.result==sm20::smoke::Result::pass;
 std::printf("Backend execution: %s (phase %u): %s\n",sm20::smoke::label(validation.result),validation.phase,validation.reason);
 FILE* out=nullptr;_wfopen_s(&out,(dir+L"rtx20-dx12-test-report.txt").c_str(),L"wb");
 if(out){std::fprintf(out,"RTX20 DX12 test\nBackend execution: %s\nValidation: %s\nValidation phase: %u (0 = whole run)\nApplication frames: %u\nResize phases reached: %u/2\n24-second run completed: %s\nRenderer result: 0x%08lx (%s)\nTearing capability: %s\nAccepted application Presents: tearing=%u vsync=%u\nD3D12 debug validation: %s\nD3D12 debug errors: %llu\nD3D12 debug messages discarded: %llu\nPhases: tearing / VSync / tearing (VSync fallback if tearing unavailable)\n\nBaseline:\n%s\n\nBefore ResizeBuffers:\n%s\n\nBefore ResizeBuffers1 / queue change:\n%s\n\nFinal status:\n%s\n\nPASS requires capture, writes, optical flow and generated Presents in all three phases with zero recorded backend/transfer/Present errors. Tearing eligibility must advance when supported. Keep F11 enabled for this automated run; disabling interpolation can make the result inconclusive.\nAPI/backend PASS does not confirm displayed interpolation, image quality or pacing. Perform a separate F11 on/off visual comparison.\n",sm20::smoke::label(validation.result),validation.reason,validation.phase,frames,phase,completed?"yes":"no",(unsigned long)outcome,operation,renderer->swapFlags?"supported":"unavailable; tearing path untested",renderer->tearingFrames,renderer->vsyncFrames,renderer->infoQueue?"available":"unavailable; debug layer was not checked",(unsigned long long)renderer->debugErrors,(unsigned long long)renderer->debugDiscarded,snapshots[0],snapshots[1],snapshots[2],snapshots[3]);std::fclose(out);}
 if(!renderer->inFlight)delete renderer;
 MessageBoxW(window,backendPassed?L"PASS: DX12 capture, optical flow and generated Presents executed in every phase with no recorded errors. Displayed interpolation, image quality and pacing still require visual checking. See rtx20-dx12-test-report.txt.":validation.result==sm20::smoke::Result::inconclusive?L"INCONCLUSIVE: backend execution was not demonstrated in every phase. Leave F11 enabled, finish the full run, and inspect rtx20-dx12-test-report.txt and nvsmooth30.log.":L"FAIL: the renderer, backend counters or D3D12 debug layer reported a problem. See rtx20-dx12-test-report.txt and nvsmooth30.log.",L"RTX20 DX12 hardware test",MB_OK);
 DestroyWindow(window);return backendPassed?0:FAILED(outcome)?3:completed?5:4;
}
