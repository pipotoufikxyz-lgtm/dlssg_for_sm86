#pragma once
// Small CPU model for the HLSL constructs used by shaders.hlsl. The production
// function bodies are compiled verbatim after syntax-only substitutions.
// This tests image behavior, not D3DCompiler, GPU precision or NVOF execution.
#include <algorithm>
#include <cmath>
#include <vector>
#include <stdexcept>
using uint=unsigned;
using SamplerState=int;
template<int N> struct Vec {
 float x{},y{},z{},w{};
 Vec()=default;
 Vec(float a):x(a),y(a),z(a),w(a){}
 Vec(float a,float b):x(a),y(b){}
 Vec(float a,float b,float c):x(a),y(b),z(c){}
 Vec(float a,float b,float c,float d):x(a),y(b),z(c),w(d){}
 Vec(const Vec<2>& a,float b):x(a.x),y(a.y),z(b){}
 Vec(const Vec<2>& a,float b,float c):x(a.x),y(a.y),z(b),w(c){}
 Vec(const Vec<3>& a,float b):x(a.x),y(a.y),z(a.z),w(b){}
 Vec(const Vec<2>& a,const Vec<2>& b):x(a.x),y(a.y),z(b.x),w(b.y){}
 float& operator[](int i){if(i==0)return x;if(i==1)return y;if(i==2)return z;return w;}
 float operator[](int i)const{if(i==0)return x;if(i==1)return y;if(i==2)return z;return w;}
 Vec<2> xy()const{return {x,y};}
 Vec<3> rgb()const{return {x,y,z};}
};
using float2=Vec<2>;using int2=Vec<2>;using float3=Vec<3>;using int3=Vec<3>;using float4=Vec<4>;
#define VEC_OPERATOR(OP) \
 template<int N> Vec<N> operator OP(Vec<N> a,Vec<N> b){Vec<N> c;for(int i=0;i<N;++i)c[i]=a[i] OP b[i];return c;} \
 template<int N> Vec<N> operator OP(Vec<N> a,float b){return a OP Vec<N>(b);} \
 template<int N> Vec<N> operator OP(float a,Vec<N> b){return Vec<N>(a) OP b;}
VEC_OPERATOR(+)
VEC_OPERATOR(-)
VEC_OPERATOR(*)
VEC_OPERATOR(/)
VEC_OPERATOR(>=)
VEC_OPERATOR(<=)
VEC_OPERATOR(>)
VEC_OPERATOR(<)
#undef VEC_OPERATOR
template<int N> Vec<N>& operator+=(Vec<N>& a,Vec<N> b){a=a+b;return a;}
template<int N> Vec<N> operator-(Vec<N> a){return Vec<N>(0.f)-a;}
// HLSL abs is floating point; without this the C library int abs would be
// chosen for float arguments and truncate them.
inline float abs(float a){return std::fabs(a);}
inline float min(float a,float b){return std::min(a,b);}
inline float max(float a,float b){return std::max(a,b);}
template<int N> Vec<N> min(Vec<N> a,Vec<N> b){for(int i=0;i<N;++i)a[i]=std::min(a[i],b[i]);return a;}
template<int N> Vec<N> max(Vec<N> a,Vec<N> b){for(int i=0;i<N;++i)a[i]=std::max(a[i],b[i]);return a;}
inline float saturate(float a){return std::clamp(a,0.f,1.f);}
inline float smoothstep(float a,float b,float x){float t=saturate((x-a)/(b-a));return t*t*(3-2*t);}
template<int N> Vec<N> floor(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::floor(a[i]);return a;}
template<int N> Vec<N> ceil(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::ceil(a[i]);return a;}
template<int N> Vec<N> frac(Vec<N> a){return a-floor(a);}
template<int N> Vec<N> abs(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::abs(a[i]);return a;}
template<int N> Vec<N> clamp(Vec<N> a,Vec<N> lo,Vec<N> hi){for(int i=0;i<N;++i)a[i]=std::clamp(a[i],lo[i],hi[i]);return a;}
template<int N> Vec<N> log(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::log(a[i]);return a;}
template<int N> Vec<N> exp(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::exp(a[i]);return a;}
template<int N> Vec<N> sqrt(Vec<N> a){for(int i=0;i<N;++i)a[i]=std::sqrt(a[i]);return a;}
template<int N> float length(Vec<N> a){float d=0;for(int i=0;i<N;++i)d+=a[i]*a[i];return std::sqrt(d);}
template<int N> bool all(Vec<N> a){for(int i=0;i<N;++i)if(!a[i])return false;return true;}
template<class T> T lerp(T a,T b,float t){return a*(1-t)+b*t;}
template<class T> struct Texture2D {
 int width{},height{};std::vector<T> pixels;
 void reset(int w,int h,T value=T{}){width=w;height=h;pixels.assign(w*h,value);}
 T& at(int x,int y){return pixels.at(y*width+x);}
 T texel(int x,int y)const{return pixels.at(std::clamp(y,0,height-1)*width+std::clamp(x,0,width-1));}
 T Load(int3 p)const{
  int x=int(p.x),y=int(p.y);if(x<0||y<0||x>=width||y>=height)throw std::runtime_error("flow Load out of range");
  return pixels.at(y*width+x);
 }
 T SampleLevel(SamplerState,float2 uv,int)const{
  float x=uv.x*width-0.5f,y=uv.y*height-0.5f;int ix=int(std::floor(x)),iy=int(std::floor(y));
  return lerp(lerp(texel(ix,iy),texel(ix+1,iy),x-ix),lerp(texel(ix,iy+1),texel(ix+1,iy+1),x-ix),y-iy);
 }
};
