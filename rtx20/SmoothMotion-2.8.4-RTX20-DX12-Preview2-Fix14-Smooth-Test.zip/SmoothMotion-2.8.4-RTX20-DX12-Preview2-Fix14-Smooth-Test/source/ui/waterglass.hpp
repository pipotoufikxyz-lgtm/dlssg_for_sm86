#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <vector>
#include "themes.hpp"

// Portable material renderer shared by the Windows UI and its visual preview.
// Frosting and refraction sample our own artwork. Desktop/game pixels belong
// to DWM and are never captured, sampled, or intercepted by this code.
//
// Liquid glass: every panel refracts a pre-blurred copy of the backdrop
// (frosted), bends it more strongly at its thick rounded rim, and is lit from
// the top left: a thin specular rim on edges facing the light, a soft caustic
// glow inside the opposite edge, a sheen that fades down the panel, a faint
// grain against banding, and a soft floating shadow.
namespace waterglass {
inline int styleIndex=0;
inline unsigned primaryColor=0x1265cd;
struct Rect { float left, top, right, bottom; };
struct RGB { float r, g, b; };
enum class Material { Sheet, Control, Primary, Disabled };
inline float clamp(float v) { return std::clamp(v, 0.f, 1.f); }
inline float smooth(float v) { v=clamp(v); return v*v*(3.f-2.f*v); }
inline RGB mix(RGB a, RGB b, float f) { return {a.r+(b.r-a.r)*f,a.g+(b.g-a.g)*f,a.b+(b.b-a.b)*f}; }
inline RGB add(RGB a, RGB b, float f) { return {a.r+b.r*f,a.g+b.g*f,a.b+b.b*f}; }
inline RGB rgb(unsigned c) { return {((c>>16)&255)/255.f,((c>>8)&255)/255.f,(c&255)/255.f}; }
// Push a colour away from its grey value (pastel theme colours need it to
// read as colour through frosted glass).
inline RGB saturate(RGB c,float amount) {
    float grey=c.r*.3f+c.g*.59f+c.b*.11f;
    return {std::clamp(grey+(c.r-grey)*amount,0.f,1.f),std::clamp(grey+(c.g-grey)*amount,0.f,1.f),std::clamp(grey+(c.b-grey)*amount,0.f,1.f)};
}
inline float blob(float x,float y,float cx,float cy,float rx,float ry) {
    float dx=(x-cx)/rx,dy=(y-cy)/ry;
    return std::exp(-(dx*dx+dy*dy)*2.2f);
}
// Aurora backdrop from the theme's four colours plus the accent: large soft
// colour fields, a diagonal light sheet and two faint flowing ribbons.
inline RGB scene(float x,float y,float width,float height,bool dark) {
    float u=x/std::max(1.f,width),v=y/std::max(1.f,height);
    const auto& theme=installer_theme::themes[installer_theme::clampTheme(styleIndex)];
    const float vivid=dark?1.15f:1.7f;
    RGB c=rgb(theme.base);
    c=mix(c,saturate(rgb(theme.a),vivid),blob(u,v,.12f,.18f,.62f,.70f)*(dark?.85f:.90f));
    c=mix(c,saturate(rgb(theme.b),vivid),blob(u,v,.86f,.10f,.58f,.62f)*.88f);
    c=mix(c,saturate(rgb(theme.c),vivid),blob(u,v,.72f,.96f,.70f,.62f)*.85f);
    c=mix(c,mix(rgb(primaryColor),rgb(theme.base),dark?.35f:.55f),blob(u,v,.40f,.62f,.42f,.40f)*(dark?.55f:.38f));
    c=mix(c,rgb(dark?0x563f6b:0xffd9cf),blob(u,v,1.02f,.52f,.36f,.46f)*(dark?.55f:.70f));
    // Diagonal light sheet from the top left.
    const float sheet=std::exp(-std::pow((u*.62f+v*.38f-.30f)/.20f,2.f));
    c=mix(c,rgb(dark?0x3b5a86:0xffffff),sheet*(dark?.16f:.30f));
    // Two faint ribbons give the frosted glass something to refract.
    const float wave=.56f+.13f*std::sin(u*5.0f-.6f);
    c=mix(c,rgb(dark?0x6f8fc4:0xffffff),std::exp(-std::pow((v-wave)/.030f,2.f))*(dark?.26f:.50f));
    const float second=.80f-.10f*std::sin(u*4.4f+.5f);
    c=mix(c,rgb(dark?0x2b5d7a:0xd3f3ff),std::exp(-std::pow((v-second)/.07f,2.f))*.30f);
    // Gentle vignette keeps the eye on the content.
    const float edge=(u-.5f)*(u-.5f)+(v-.5f)*(v-.5f);
    c=mix(c,rgb(dark?0x05090f:0xb4c2d6),clamp(edge*1.1f-.12f)*(dark?.55f:.22f));
    return c;
}
inline std::uint32_t pixel(RGB c,float alpha) {
    const auto byte=[](float v){return static_cast<unsigned>(std::lround(clamp(v)*255.f));};
    unsigned a=byte(alpha);
    return (a<<24)|(std::min(a,byte(c.r*alpha))<<16)|
        (std::min(a,byte(c.g*alpha))<<8)|std::min(a,byte(c.b*alpha));
}
struct Image {
    unsigned width=0,height=0;
    std::vector<std::uint32_t> bgra;
};
inline Image allocate(float w,float h) {
    if(!std::isfinite(w)||!std::isfinite(h)||w<=0||h<=0||w>8192||h>8192)
        throw std::runtime_error("Glass surface bounds are invalid");
    unsigned width=static_cast<unsigned>(std::ceil(w)),height=static_cast<unsigned>(std::ceil(h));
    if(static_cast<std::uint64_t>(width)*height>8u*1024u*1024u)
        throw std::runtime_error("Glass surface exceeds its allocation limit");
    return {width,height,std::vector<std::uint32_t>(static_cast<size_t>(width)*height)};
}
inline Image background(float w,float h,bool dark,bool desktop) {
    auto im=allocate(w,h);
    for(unsigned y=0;y<im.height;++y)for(unsigned x=0;x<im.width;++x)
        im.bgra[size_t(y)*im.width+x]=pixel(scene(x+.5f,y+.5f,w,h,dark),desktop?.26f:1.f);
    return im;
}
// Frosted backdrop: the scene at half resolution, blurred by three box passes
// (close to a Gaussian of about 14 canvas pixels), sampled bilinearly.
struct Frost {
    unsigned width=0,height=0;float scale=2;
    std::vector<RGB> pixels;
    RGB sample(float x,float y) const {
        if(pixels.empty())return {0,0,0};
        float fx=std::clamp(x/scale-.5f,0.f,float(width-1)),fy=std::clamp(y/scale-.5f,0.f,float(height-1));
        unsigned ix=static_cast<unsigned>(fx),iy=static_cast<unsigned>(fy);
        unsigned jx=std::min(ix+1,width-1),jy=std::min(iy+1,height-1);float tx=fx-ix,ty=fy-iy;
        const auto& a=pixels[size_t(iy)*width+ix];const auto& b=pixels[size_t(iy)*width+jx];
        const auto& c=pixels[size_t(jy)*width+ix];const auto& d=pixels[size_t(jy)*width+jx];
        return mix(mix(a,b,tx),mix(c,d,tx),ty);
    }
};
inline Frost frost(float w,float h,bool dark) {
    if(!std::isfinite(w)||!std::isfinite(h)||w<=0||h<=0||w>8192||h>8192)
        throw std::runtime_error("Frost bounds are invalid");
    Frost f;f.width=std::max(1u,static_cast<unsigned>(std::ceil(w/f.scale)));f.height=std::max(1u,static_cast<unsigned>(std::ceil(h/f.scale)));
    f.pixels.resize(size_t(f.width)*f.height);
    for(unsigned y=0;y<f.height;++y)for(unsigned x=0;x<f.width;++x)
        f.pixels[size_t(y)*f.width+x]=scene((x+.5f)*f.scale,(y+.5f)*f.scale,w,h,dark);
    std::vector<RGB> line(std::max(f.width,f.height));
    const int r=4;
    for(int pass=0;pass<3;++pass){
        for(unsigned y=0;y<f.height;++y){
            for(unsigned x=0;x<f.width;++x){RGB s{0,0,0};
                for(int k=-r;k<=r;++k){auto& p=f.pixels[size_t(y)*f.width+std::clamp<int>(int(x)+k,0,int(f.width)-1)];s=add(s,p,1);}
                line[x]={s.r/(2*r+1),s.g/(2*r+1),s.b/(2*r+1)};}
            for(unsigned x=0;x<f.width;++x)f.pixels[size_t(y)*f.width+x]=line[x];
        }
        for(unsigned x=0;x<f.width;++x){
            for(unsigned y=0;y<f.height;++y){RGB s{0,0,0};
                for(int k=-r;k<=r;++k){auto& p=f.pixels[size_t(std::clamp<int>(int(y)+k,0,int(f.height)-1))*f.width+x];s=add(s,p,1);}
                line[y]={s.r/(2*r+1),s.g/(2*r+1),s.b/(2*r+1)};}
            for(unsigned y=0;y<f.height;++y)f.pixels[size_t(y)*f.width+x]=line[y];
        }
    }
    return f;
}
// Signed distance to a rounded rectangle centred at the origin (negative inside).
inline float roundedDistance(float cx,float cy,float halfW,float halfH,float radius,float& nx,float& ny) {
    float qx=std::abs(cx)-(halfW-radius),qy=std::abs(cy)-(halfH-radius);
    float ox=std::max(0.f,qx),oy=std::max(0.f,qy),len=std::sqrt(ox*ox+oy*oy);
    nx=0;ny=0;
    if(len>0){nx=ox/len;ny=oy/len;}else if(qx>qy)nx=1;else ny=1;
    nx*=cx<0?-1.f:1.f;ny*=cy<0?-1.f:1.f;
    return len+std::min(std::max(qx,qy),0.f)-radius;
}
inline float grain(unsigned x,unsigned y) {
    std::uint32_t h=x*374761393u+y*668265263u;h=(h^(h>>13))*1274126177u;h^=h>>16;
    return (h&0xffff)/32767.5f-1.f;
}
// Margin reserved around a surface for its soft shadow.
inline constexpr float shadowMargin=26.f;
// A glass surface for box (canvas coordinates) with the given corner radius.
// With margin>0 the image is larger by margin on every side and carries the
// panel's floating shadow there; draw it at the box expanded by margin.
inline Image surface(Rect box,float radius,const Frost& backdrop,bool dark,bool desktop,Material material,float margin=0) {
    float w=box.right-box.left,h=box.bottom-box.top;
    auto im=allocate(w+2*margin,h+2*margin);radius=std::clamp(radius,1.f,std::min(w,h)*.5f);
    const auto& theme=installer_theme::themes[installer_theme::clampTheme(styleIndex)];
    const RGB tintColor=rgb(theme.sheet),white{1,1,1},shade=rgb(dark?0x02060d:0x10294b);
    const float lx=-.45f,ly=-.89f; // towards the light (top left)
    float tint=material==Material::Sheet?(dark?.46f:.26f):material==Material::Control?(dark?.56f:.46f):.60f;
    for(unsigned y=0;y<im.height;++y)for(unsigned x=0;x<im.width;++x) {
        float px=x+.5f-margin,py=y+.5f-margin,cx=px-w*.5f,cy=py-h*.5f,nx,ny;
        float d=roundedDistance(cx,cy,w*.5f,h*.5f,radius,nx,ny);
        float coverage=clamp(.5f-d);
        // Floating shadow: offset downwards, soft, outside the panel only.
        float shadow=0;
        if(margin>0&&coverage<1){
            float sx,sy;float ds=roundedDistance(cx,cy-7.f,w*.5f,h*.5f,radius,sx,sy);
            float spread=std::max(0.f,ds);
            shadow=(dark?.42f:.20f)*std::exp(-spread*spread/(2*11.f*11.f))*(ds<0?1.f:1.f);
            float contact=std::max(0.f,d);shadow+=(dark?.20f:.08f)*std::exp(-contact*contact/(2*2.5f*2.5f));
            shadow=std::min(shadow,.6f)*(1-coverage);
        }
        if(coverage==0){
            if(shadow>0)im.bgra[size_t(y)*im.width+x]=pixel(shade,shadow);
            continue;
        }
        float depth=std::max(0.f,-d);
        // Thick rounded rim: steepest bend and strongest dispersion there.
        float rim=std::exp(-depth/7.f),bend=20.f*rim*std::sqrt(rim);
        float gx=box.left+w*.5f+cx*.985f-nx*bend,gy=box.top+h*.5f+cy*.985f-ny*bend;
        RGB c=backdrop.sample(gx,gy);
        c.r=backdrop.sample(gx-nx*1.1f*rim,gy-ny*1.1f*rim).r;
        c.b=backdrop.sample(gx+nx*1.1f*rim,gy+ny*1.1f*rim).b;
        c=mix(c,tintColor,tint);
        if(material==Material::Primary){
            RGB top=mix(rgb(primaryColor),white,.18f),bottom=mix(rgb(primaryColor),rgb(0x000000),.12f);
            c=mix(c,mix(top,bottom,clamp(py/std::max(1.f,h))),.93f);
        }
        if(material==Material::Disabled)c=mix(c,rgb(dark?0x263649:0xe7edf6),.60f);
        float facing=nx*lx+ny*ly; // >0: edge faces the light
        float line=std::exp(-depth/.9f);
        c=mix(c,white,line*clamp((dark?.20f:.12f)+.62f*std::max(0.f,facing)));
        // Caustic: light entering at the lit edge exits as a soft glow inside
        // the opposite edge.
        float caustic=std::exp(-std::pow((depth-3.2f)/2.2f,2.f))*std::max(0.f,-facing);
        c=add(c,white,caustic*(dark?.10f:.09f));
        // Inner depth shade just below the lit rim.
        float inner=std::exp(-std::pow((depth-2.8f)/1.6f,2.f))*std::max(0.f,facing);
        c=mix(c,shade,inner*(dark?.10f:.06f));
        // Sheen fading down the panel (cap for tall panels).
        float sheen=1-smooth(py/std::min(std::max(1.f,h),160.f));
        c=add(c,white,sheen*(material==Material::Primary?.10f:dark?.035f:.05f));
        float noise=grain(x+unsigned(box.left),y+unsigned(box.top))*(dark?.010f:.008f);
        c={c.r+noise,c.g+noise,c.b+noise};
        float alpha=desktop?(material==Material::Sheet?.50f:.68f):1.f;
        if(material==Material::Primary)alpha=desktop?.96f:1.f;
        alpha=std::min(1.f,alpha+line*.27f);
        // Composite the glass over its own shadow at anti-aliased edges.
        float a=alpha*coverage,sa=shadow*(1-a);
        float outA=a+sa;
        RGB outC=outA>0?RGB{(c.r*a+shade.r*sa)/outA,(c.g*a+shade.g*sa)/outA,(c.b*a+shade.b*sa)/outA}:c;
        im.bgra[size_t(y)*im.width+x]=pixel(outC,outA);
    }
    return im;
}
}
