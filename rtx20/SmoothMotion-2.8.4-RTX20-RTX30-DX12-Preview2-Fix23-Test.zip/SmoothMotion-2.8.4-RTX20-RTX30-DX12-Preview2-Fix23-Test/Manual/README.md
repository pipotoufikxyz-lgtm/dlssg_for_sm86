# Manual installation

Close the game and copy exactly one `Manual/` kit beside its actual x64 EXE.
`Version` contains standalone `version.dll`; `Dinput8` and `Winmm` contain their
ASI loader, INI and `new.asi`; `ASI_Only` is for an existing compatible ASI loader.
The game must load the chosen carrier before graphics creation. Never rename
the standalone proxy to another DLL name or combine it with `new.asi`.
Use the Manager to upgrade a managed installation so its ownership receipt and
uninstaller remain correct. Manual copying does not create an uninstall receipt.
See README.md for the DirectX 11 / DirectX 12 SDR requirements and F11 toggle.

For this release, confirm `2.8.4-rtx20-rtx30-dx12-preview2-fix23-test` and `artifact_guard=occlusion_aware_v6` in the log. See FIX22_NOTES.md (freezes, guard across resizes), FIX21_NOTES.md (image quality), FIX20_NOTES.md (GPU-bound games), FIX19_NOTES.md (crosshair/HUD), FIX18_NOTES.md (RTX 30), FIX17_NOTES.md (performance guard), FIX16_NOTES.md (10-bit SDR) and FIX15_NOTES.md (GpuBudget, ExclusiveFullscreen).
The real frame waits until the generated frame has been visible for half a real-frame interval (VSync games: consecutive refreshes); generation pauses when the game reaches the refresh rate. Pacing=off restores Fix12 immediate presentation.
For the first artifact comparison keep your existing limiter/VSync settings; use borderless.
No fixed FPS limiter is added; keep your own frame cap (in-game or RTSS) at the base rate you want, and each generated frame is shown for half a real-frame interval. Look for artifact_guard=occlusion_aware_v5. Optional nvsmooth30.ini (FlowResolution=auto|full|half): see nvsmooth30.example.ini. Pacing=auto|low_latency|smooth|vblank|off, FlowQuality=auto|high|medium and GenerateAboveRefresh=0|1 are also read there. See FIX14_NOTES.md for pacing, quality and limits.
