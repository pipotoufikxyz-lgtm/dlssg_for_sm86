@echo off
rem Fix15: older-DX11-game setup - DISCARD swapchain, 4x MSAA backbuffer,
rem 10 s at Present interval 2 (30 FPS lock on 60 Hz), then 10 s uncapped.
cd /d "%~dp0"
RTX20_SmokeTest.exe legacy
