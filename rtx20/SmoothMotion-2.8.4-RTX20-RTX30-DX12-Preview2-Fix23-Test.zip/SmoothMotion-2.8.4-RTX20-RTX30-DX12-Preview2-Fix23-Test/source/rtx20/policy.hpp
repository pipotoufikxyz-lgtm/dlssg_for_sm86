#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
namespace sm20 {
// Control flags and dirty/scroll updates keep their original presentation.
inline constexpr unsigned present_test=0x1, present_allow_tearing=0x200, swapchain_allow_tearing=0x800;
enum class Admission { eligible, test, partial, interval, flags, tearing_contract };
inline Admission request_admission(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) {
 if(flags&present_test)return Admission::test;
 if(partial)return Admission::partial;
 // Intervals 2-4 lock a game to a fraction of the refresh (a 30 FPS lock on
 // 60 Hz presents with interval 2); the pair then shares those refreshes.
 if(sync>4)return Admission::interval;
 if(flags==0)return Admission::eligible;
 if(flags!=present_allow_tearing)return Admission::flags;
 return sync==0&&windowed&&(swapFlags&swapchain_allow_tearing)?Admission::eligible:Admission::tearing_contract;
}
// VSync-paired presentation of a request with sync interval N: the generated
// frame takes the first half of the game's refreshes, the real frame the rest
// (interval 1: one refresh each, Fix13 behaviour; interval 2: one each).
struct PairedIntervals { unsigned generated, real; };
constexpr PairedIntervals paired_intervals(unsigned sync) {
 const unsigned n=sync<1?1:(sync>4?4:sync);
 const unsigned generated=n/2<1?1:n/2;
 return {generated,n-generated<1?1:n-generated};
}
// Turing SM75 (RTX 20) and, since Fix18, Ampere SM86 (RTX 30). Both have the
// D3D11 NVOF API5 engine (grid 4, MEDIUM/SLOW presets) used here; synthesis is
// plain D3D11 shader code. Other architectures are not accepted.
inline bool supported_gpu(unsigned vendor,int major,int minor) { return vendor==0x10de && ((major==7 && minor==5)||(major==8 && minor==6)); }
// RGBA8/BGRA8 UNORM and sRGB; RGB10A2 UNORM (24, Fix16: God of War 2018 uses
// it for SDR). All are 4 bytes per pixel. FP16/HDR formats are unsupported.
inline bool supported_format(unsigned f) { return f==24 || f==28 || f==29 || f==87 || f==91; }
inline bool interpolate_request(unsigned sync,unsigned flags,bool partial,bool windowed=false,unsigned swapFlags=0) { return request_admission(sync,flags,partial,windowed,swapFlags)==Admission::eligible; }
inline bool fresh_history(std::uint64_t previous,std::uint64_t now) { return previous && now>=previous && now-previous<=250; }
inline unsigned grid_extent(unsigned n) { return (n+3)/4; }
inline bool dimensions(unsigned w,unsigned h) { return w>=128 && h>=128 && w<=3840 && h<=2160; }
// Optical-flow resolution. Full-resolution NVOF (4-pixel cells) preserves thin
// detail; half resolution (8-pixel cells) costs about a quarter of the flow
// GPU time. Automatic mode uses half resolution only when the real frame rate
// is already high: motion per frame is then small and GPU time decides the
// generated frame rate. Hysteresis avoids switching back and forth.
enum class FlowResolution { automatic, full, half };
// Case-insensitive comparison of a setting value with a lower-case word.
inline bool setting_equals(const wchar_t* value,const wchar_t* word) {
 if(!value)return false;
 for(;*value&&*word;++value,++word){wchar_t c=*value;if(c>=L'A'&&c<=L'Z')c=wchar_t(c-L'A'+L'a');if(c!=*word)return false;}
 return !*value&&!*word;
}
inline FlowResolution parse_flow_resolution(const wchar_t* value) {
 if(setting_equals(value,L"full"))return FlowResolution::full;
 if(setting_equals(value,L"half"))return FlowResolution::half;
 return FlowResolution::automatic;
}
inline constexpr double half_flow_enter_fps=58, half_flow_leave_fps=45;
inline bool use_half_flow(FlowResolution setting,bool available,bool current,double realFps) {
 if(!available||setting==FlowResolution::full)return false;
 if(setting==FlowResolution::half)return true;
 return realFps>=(current?half_flow_leave_fps:half_flow_enter_fps);
}
// Optical-flow quality at full resolution: NVIDIA's SLOW preset gives the best
// vectors but takes longest. Automatic mode uses it at low real frame rates,
// where motion per frame (and so artifact visibility) is largest and each
// frame leaves the most GPU time; MEDIUM above. Half resolution has priority.
enum class FlowQuality { automatic, high, medium };
inline FlowQuality parse_flow_quality(const wchar_t* value) {
 if(setting_equals(value,L"high")||setting_equals(value,L"slow"))return FlowQuality::high;
 if(setting_equals(value,L"medium")||setting_equals(value,L"balanced"))return FlowQuality::medium;
 return FlowQuality::automatic;
}
inline const char* flow_quality_name(FlowQuality q) {return q==FlowQuality::high?"high":q==FlowQuality::medium?"medium":"auto";}
inline constexpr double quality_flow_enter_fps=40, quality_flow_leave_fps=48;
inline bool use_quality_flow(FlowQuality setting,bool available,bool current,double realFps) {
 if(!available||setting==FlowQuality::medium)return false;
 if(setting==FlowQuality::high)return true;
 return realFps>0&&realFps<(current?quality_flow_leave_fps:quality_flow_enter_fps);
}
// GPU budget for frame generation (Fix15). Fix14 used the SLOW optical-flow
// preset whenever the base rate was below 40 FPS; a user log (RTX 2080,
// 1080p, 30 FPS) measured about 5.7 ms of GPU time per generated frame with
// it, against about 3.1 ms for MEDIUM in Fix13, and utilisation at 30 to 60
// matched native 60. The GPU time of each pair (optical flow + synthesis) is
// now measured per flow mode and compared with a fraction of the real frame
// interval. Automatic modes pick the best mode whose cost fits:
// SLOW (if its FPS rule allows), then MEDIUM, then half-resolution flow.
// A mode found over budget is measured again after retry_seconds, since the
// cost depends on the scene. Explicit FlowQuality=high / FlowResolution
// settings are always honoured. GpuBudget=0 disables the limit (Fix14).
enum class FlowMode { slow, medium, half };
inline const char* flow_mode_name(FlowMode m) {return m==FlowMode::slow?"high (SLOW)":m==FlowMode::medium?"medium":"half resolution";}
inline double parse_gpu_budget(const wchar_t* value) {
 if(!value||!*value||setting_equals(value,L"auto"))return 0.10;
 if(setting_equals(value,L"off")||setting_equals(value,L"unlimited"))return 0;
 double v=0;unsigned digits=0;
 for(;*value>=L'0'&&*value<=L'9';++value,++digits)v=v*10+(*value-L'0');
 if(*value==L'%')++value;
 if(!digits||*value)return 0.10;
 return v<=0?0:(v>=100?1:v/100);
}
struct FlowBudget {
 double fraction{0.10};
 std::array<double,3> estimate{-1,-1,-1},observed{-1e9,-1e9,-1e9};
 std::array<unsigned,3> samples{};
 // Fix23 (Monster Hunter World log 51): re-measuring a rejected mode costs
 // a few expensive pairs (a visible hitch); a mode found over budget again
 // waits twice as long before the next measurement (30 s up to 300 s).
 std::array<double,3> retryDelay{30,30,30};
 static constexpr double retry_seconds=30,maximum_retry=300,hysteresis=1.15,smoothing=0.2;
 static constexpr unsigned minimum_samples=4;
 static unsigned index(FlowMode m){return static_cast<unsigned>(m);}
 // One measured pair (seconds of GPU time) generated in mode m.
 void observe(FlowMode m,double seconds,double now){
  // Warm-up and loading pairs (Fix20: 'MEDIUM 166 ms' in God of War log 46)
  // say nothing about the steady cost.
  if(!(seconds>0)||seconds>0.05)return;
  const auto i=index(m);
  estimate[i]=estimate[i]<0?seconds:estimate[i]+(seconds-estimate[i])*smoothing;observed[i]=now;++samples[i];
 }
 double limit(double interval) const {return fraction>0&&interval>0?fraction*interval:0;}
 bool over(FlowMode m,double interval,bool current) const {
  const double l=limit(interval);const auto i=index(m);
  // Far over budget (twice the limit) is clear after two pairs.
  return l>0&&(samples[i]>=minimum_samples||(samples[i]>=2&&estimate[i]>2*l))&&estimate[i]>l*(current?hysteresis:1);
 }
 // Whether mode m may be used. An over-budget estimate is forgotten after
 // retry_seconds without use, so the mode is measured again.
 bool fits(FlowMode m,double interval,double now,bool current){
  const auto i=index(m);
  if(!over(m,interval,current)){if(samples[i]>=minimum_samples)retryDelay[i]=retry_seconds;return true;}
  if(!current&&now-observed[i]>retryDelay[i]){estimate[i]=-1;samples[i]=0;retryDelay[i]=std::min(maximum_retry,retryDelay[i]*2);return true;}
  return false;
 }
};
inline FlowMode choose_flow_mode(FlowResolution resolution,bool halfAvailable,FlowQuality quality,bool slowAvailable,
                                 FlowMode current,double realFps,double interval,FlowBudget& budget,double now) {
 if(use_half_flow(resolution,halfAvailable,current==FlowMode::half,realFps))return FlowMode::half;
 if(use_quality_flow(quality,slowAvailable,current==FlowMode::slow,realFps)&&
    (quality==FlowQuality::high||budget.fits(FlowMode::slow,interval,now,current==FlowMode::slow)))return FlowMode::slow;
 // MEDIUM over budget: half resolution (automatic resolution only).
 if(halfAvailable&&resolution==FlowResolution::automatic&&!budget.fits(FlowMode::medium,interval,now,current==FlowMode::medium))
  return FlowMode::half;
 return FlowMode::medium;
}
// Waiting for the GPU to reach the generated Present (DX11, spaced pairs)
// drains the GPU pipeline: in a GPU-bound game the game thread then cannot
// prepare the next frame while the GPU works, and the real rate roughly
// halves (Fix20, God of War log 46: native 70 FPS, 35-45 while generating).
// When that wait averages over `enter`, spacing is timed from the Present
// call instead; one pair in probe_every still measures it, to notice when
// the game is no longer GPU-bound.
struct VisibilityWait {
 double average{};bool skipping{};unsigned count{};
 static constexpr double enter=0.003,leave=0.001;static constexpr unsigned probe_every=120;
 bool measure_now(){return !skipping||(++count%probe_every)==0;}
 // Returns true when the mode changed.
 bool observe(double seconds){
  if(!(seconds>=0))return false;
  average=average>0?average+(seconds-average)*0.2:seconds;
  const bool before=skipping;
  if(!skipping&&average>enter)skipping=true;else if(skipping&&average<leave)skipping=false;
  return skipping!=before;
 }
};
// MinimumBaseRate (Fix20): percent of the native rate the real rate must
// keep while generating (default 65; 0 disables).
inline double parse_minimum_base(const wchar_t* value) {
 if(!value||!*value||setting_equals(value,L"auto"))return 0.65;
 if(setting_equals(value,L"off"))return 0;
 double v=0;unsigned digits=0;
 for(;*value>=L'0'&&*value<=L'9';++value,++digits)v=v*10+(*value-L'0');
 if(*value==L'%')++value;
 if(!digits||*value)return 0.65;
 return v<=0?0:(v>=100?1:v/100);
}
// Exponential average of the real frame interval; gaps longer than the
// history window (pauses, F11, loading) restart the measurement.
inline double update_frame_interval(double average,double seconds) {
 if(!(seconds>0)||seconds>0.25)return 0;
 return average>0?average+(seconds-average)*0.1:seconds;
}
// Generated frames beyond the display refresh rate are never shown: they only
// add tearing, latency and GPU load. While generating, the measured real
// rate already includes generation cost; pause once it reaches the refresh
// rate, and resume only when the native rate drops clearly below it.
inline bool generation_useful(bool generating,double realFps,double refreshHz) {
 if(!(refreshHz>1)||!(realFps>0))return true;
 return realFps<refreshHz*(generating?1.02:0.9);
}
// Presentation of generated frames. Both frames of a pair are submitted from
// the game's own Present call. Submitted back to back, the generated frame is
// replaced within about a millisecond and only the real frames are seen.
//
// Spaced presentation holds the real frame until half a real-frame interval
// after the generated frame became visible, so both are shown for equal time:
//   timed:     capture, flow and synthesis, generated Present, wait, real
//              Present. Lowest latency; the wait and the generation cost both
//              occupy the game thread.
//   pipelined: the previous pair is presented (generated, then the previous
//              real frame) and flow/synthesis for the next pair run on the GPU
//              during the wait. One real frame more latency; generation cost
//              leaves the game thread, so even spacing fits at low base rates.
// The wait never deliberately lowers the game's frame rate: a controller
// shrinks it whenever the real rate falls below the rate measured without it.
// Games presenting with VSync pair both frames on consecutive refreshes
// (sync interval 1) instead of waiting on the CPU.
//   native:    ~0.5 s without generation, to measure the game's own rate
//              (Fix17);
//   measuring: ~0.75 s unspaced, to measure the real rate;
//   timed / pipelined: spaced presentation (Pacing=auto chooses);
//   vblank:    both frames with sync interval 1 (Pacing=vblank, Fix13);
//   immediate: unspaced (Pacing=off);
//   paused:    real rate already at/above refresh, generated frames would not
//              be visible; resume (via native) below 90% of refresh. Also
//              (Fix17) when generation lowered the displayed rate below the
//              native one; retried later with growing delays.
//
// Fix17, Genshin Impact log 45 (RTX 2070 Max-Q, 144 Hz): native 120 FPS fell
// to 12-35 real FPS while generating, and waits of up to 100 ms came from a
// reference measured across loading hitches (2.8 FPS). Both measurements now
// use the median interval and restart on any hitch, and a guard compares the
// displayed rate with the native rate.
enum class Pacing { automatic, low_latency, smooth, vblank, off };
inline Pacing parse_pacing(const wchar_t* value) {
 for(const auto* word:{L"off",L"0",L"false",L"no",L"immediate"})if(setting_equals(value,word))return Pacing::off;
 for(const auto* word:{L"low_latency",L"lowlatency",L"timed"})if(setting_equals(value,word))return Pacing::low_latency;
 for(const auto* word:{L"smooth",L"pipelined"})if(setting_equals(value,word))return Pacing::smooth;
 for(const auto* word:{L"vblank",L"refresh"})if(setting_equals(value,word))return Pacing::vblank;
 return Pacing::automatic;
}
inline const char* pacing_name(Pacing p) {
 return p==Pacing::off?"off":p==Pacing::low_latency?"low_latency":p==Pacing::smooth?"smooth":p==Pacing::vblank?"vblank":"auto";
}
enum class Presentation { measuring, timed, pipelined, vblank, immediate, paused, native };
inline const char* presentation_name(Presentation p) {
 constexpr const char* names[]={"measuring","timed","pipelined","vblank","immediate","paused","native"};
 return names[static_cast<int>(p)];
}
// Median of frame intervals collected over a short measurement. Any interval
// longer than hitch_seconds (loading, shader compilation, alt-tab) restarts
// it: a mean across such a gap made Fix14 wait 100 ms per frame.
struct IntervalSample {
 static constexpr unsigned capacity=256;static constexpr double hitch_seconds=0.1;
 std::array<double,capacity> values{};unsigned count{};double start{-1},last{-1};
 void reset(){count=0;start=last=-1;}
 // Returns the median interval once `seconds` and `frames` are reached, else 0.
 double add(double now,double seconds,unsigned frames){
  if(last>=0){
   const double d=now-last;
   if(!(d>=0)||d>hitch_seconds){count=0;start=now;}
   else if(count<capacity)values[count++]=d;
  }else start=now;
  last=now;
  if(count+1<frames||now-start<seconds)return 0;
  std::array<double,capacity> sorted=values;
  std::nth_element(sorted.begin(),sorted.begin()+count/2,sorted.begin()+count);
  return sorted[count/2];
 }
};
struct PresentationPolicy {
 Pacing pacing{Pacing::automatic};bool generateAboveRefresh{};double refreshHz{};
 Presentation state{Presentation::native};
 IntervalSample sample;
 // The game's own frame rate, measured without generation (0: unknown).
 double nativeFps{};
 // Real frame interval measured without spacing, in seconds.
 double reference{};
 // Current wait (seconds) and its smoothed fraction of half the reference
 // interval, used by Pacing=auto to choose the pipelined order.
 double wait{},averageSpacing{1};
 double windowStart{-1},lastFrame{-1},longestFrame{};unsigned windowFrames{},windows{},fastWindows{},stalledWindows{},shortWindows{};
 // Pacing=auto keeps the pipelined order once timed spacing proved too short.
 bool learnedPipeline{};
 // Cost guard (Fix17): half-second windows while generating compare the
 // displayed rate with the native one. Losing windows in a row pause
 // generation until pausedUntil; the retry delay doubles each time.
 double guardStart{-1},guardLast{-1},guardLongest{},pausedUntil{},pausedNative{},retryDelay{retry_seconds};
 unsigned guardFrames{},losingWindows{};bool counterproductive{};double lastDisplayed{};unsigned pauses{};
 // Fix23 (God of War log 49): each retry after a pause cost seconds of low
 // FPS although nothing had changed. The extra time generation added per
 // real frame at the last pause predicts a retry; one that cannot win is
 // skipped silently (the paused rate is measured all along), until at most
 // maximum_retry after the last real attempt.
 double extraCost{-1},pausedRate{},pausedAt{-1},lastAttempt{-1};unsigned skippedRetries{};
 // Predicted real rate with generation at a native rate, and whether it
 // would pass the guard.
 double predictedReal(double native) const {return extraCost>=0&&native>0?1/(1/native+extraCost):0;}
 bool beneficial(double native) const {
  const double real=predictedReal(native);
  return real>0&&displayed(2*real)>=displayed(native)*minimum_gain&&!(minimumBase>0&&real<native*minimumBase);
 }
 static constexpr double window_seconds=0.5,probe=0.00025,margin=0.0005,tolerance=0.01,timed_minimum=0.85,maximum_wait=0.1;
 static constexpr double native_seconds=0.5,measure_seconds=0.75,minimum_gain=1.1,retry_seconds=30,maximum_retry=300;
 double minimumBase{0.65};double lastReal{};
 static constexpr unsigned native_frames=15,measure_frames=20,losing_limit=4;
 void reset(){state=Presentation::native;sample.reset();windowStart=-1;lastFrame=-1;resetGuard();}
 // After discarded frames or a session rebuild: measure again, but a pause
 // the guard decided (generation lowered the displayed rate) runs its course
 // (Fix21, God of War log 48: every resize restarted generation at once).
 void restart(){if(state==Presentation::paused&&counterproductive){sample.reset();return;}reset();}
 void resetGuard(){guardStart=guardLast=-1;guardLongest=0;guardFrames=losingWindows=0;}
 double ideal() const {return std::min(maximum_wait,reference*0.5);}
 void enter(Presentation next,double now){
  state=next;wait=ideal();averageSpacing=1;windowStart=now;lastFrame=-1;longestFrame=0;windowFrames=windows=fastWindows=stalledWindows=shortWindows=0;
 }
 void pause(double now,bool losing){
  state=Presentation::paused;counterproductive=losing;
  if(losing){pausedUntil=now+retryDelay;pausedNative=nativeFps;retryDelay=std::min(maximum_retry,retryDelay*2);++pauses;sample.reset();
   pausedAt=lastAttempt=now;pausedRate=0;
   extraCost=lastReal>0&&nativeFps>0?std::max(0.0,1/lastReal-1/nativeFps):-1;}
  else pausedUntil=0;
 }
 // Displayed frames per second: generation doubles the real rate, capped
 // by the refresh (frames beyond it are never shown).
 double displayed(double fps) const {return refreshHz>1?std::min(fps,refreshHz):fps;}
 // Once per real frame; realFps is the running average of the real rate.
 // spacingApplied: false for VSync pairs (no CPU wait to control).
 Presentation update(double now,double realFps,bool spacingApplied=true){
  const bool generatingNow=state!=Presentation::paused&&state!=Presentation::native;
  const bool visible=generateAboveRefresh||generation_useful(generatingNow,realFps,refreshHz);
  switch(state){
   case Presentation::native:
    if(const double m=sample.add(now,native_seconds,native_frames);m>0){
     nativeFps=1/m;sample.reset();
     if(!generateAboveRefresh&&!generation_useful(false,nativeFps,refreshHz))pause(now,false);
     else state=Presentation::measuring;
    }
    break;
   case Presentation::measuring:
    if(const double m=sample.add(now,measure_seconds,measure_frames);m>0){
     reference=m;sample.reset();resetGuard();
     if(!visible)pause(now,false);
     else if(pacing==Pacing::off)state=Presentation::immediate;
     else if(pacing==Pacing::vblank)state=Presentation::vblank;
     else enter(pacing==Pacing::smooth||(pacing==Pacing::automatic&&learnedPipeline)?Presentation::pipelined:Presentation::timed,now);
    }
    break;
   case Presentation::immediate:
   case Presentation::vblank:
    if(!visible){pause(now,false);break;}
    guard(now);
    break;
   case Presentation::paused:
    if(counterproductive){
     // Retry later, or at once when the game became much slower by itself
     // (a heavier scene may now benefit). The rate is measured afresh here:
     // the running average still holds the slow generating rate.
     if(const double m=sample.add(now,native_seconds,native_frames);m>0){
      sample.reset();pausedRate=1/m;
      // With a known cost: retry as soon as the prediction says it wins
      // (a heavier scene); without: when the game became much slower.
      const bool retry=extraCost>=0?beneficial(pausedRate)&&now-pausedAt>=5:pausedNative>0&&pausedRate<pausedNative*0.6;
      if(retry){counterproductive=false;reset();break;}
     }
     if(now>=pausedUntil){
      if(extraCost>=0&&pausedRate>0&&now-lastAttempt<maximum_retry&&!beneficial(pausedRate)){
       pausedUntil=now+retry_seconds;++skippedRetries;break;
      }
      counterproductive=false;reset();break;
     }
    }else if(visible)reset();
    break;
   case Presentation::timed:
   case Presentation::pipelined:
    if(!visible){pause(now,false);break;}
    if(spacingApplied)control(now);else{windowStart=now;windowFrames=0;lastFrame=-1;longestFrame=0;}
    if(state==Presentation::timed||state==Presentation::pipelined)guard(now);
    break;
  }
  return state;
 }
 // Generation must raise the displayed rate by at least minimum_gain over
 // the native rate; otherwise it only adds latency, GPU load and stutter.
 // GenerateAboveRefresh=1 (explicit request, hardware tests) skips it.
 void guard(double now){
  if(generateAboveRefresh||!(nativeFps>0))return;
  if(guardLast>=0&&now<guardLast)guardStart=guardLast=-1;
  ++guardFrames;
  if(guardLast>=0)guardLongest=std::max(guardLongest,now-guardLast);
  guardLast=now;
  if(guardStart<0){guardStart=now;guardFrames=0;guardLongest=0;return;}
  const double elapsed=now-guardStart;
  if(elapsed<window_seconds||!guardFrames)return;
  const double interval=elapsed/guardFrames,longest=guardLongest;
  guardStart=now;guardFrames=0;guardLongest=0;
  if(longest>IntervalSample::hitch_seconds)return;
  lastDisplayed=displayed(2/interval);lastReal=1/interval;
  // Losing: fewer frames shown than 10% above native, or (Fix20) the game's
  // own rate cut below minimumBase (65%) of native (70 native -> 35 real + 35
  // generated looks like 70 with twice the latency and artifacts).
  const bool losing=lastDisplayed<displayed(nativeFps)*minimum_gain||(minimumBase>0&&lastReal<nativeFps*minimumBase);
  if(losing){if(++losingWindows>=losing_limit)pause(now,true);}
  else{losingWindows=0;retryDelay=retry_seconds;extraCost=-1;}
 }
 // Every half second compare the mean real interval with the reference. A
 // wait beyond the game's slack delays every frame by exactly the excess,
 // so the excess is removed in one step; otherwise probe upward slowly.
 void control(double now){
  // A clock step backwards restarts the window (never mixes two timelines).
  if(lastFrame>=0&&now<lastFrame){windowStart=lastFrame=-1;}
  ++windowFrames;
  if(lastFrame>=0)longestFrame=std::max(longestFrame,now-lastFrame);
  lastFrame=now;
  if(windowStart<0){windowStart=now;windowFrames=0;longestFrame=0;return;}
  const double elapsed=now-windowStart;
  if(elapsed<window_seconds||!windowFrames)return;
  const double interval=elapsed/windowFrames,longest=longestFrame;
  windowStart=now;windowFrames=0;longestFrame=0;++windows;
  if(!(reference>0))return;
  // A single hitch (loading, shader compilation) says nothing about the
  // spacing; skip such windows instead of cutting the wait.
  if(longest>2.5*reference)return;
  if(interval>reference*(1+tolerance)+0.0002){
   wait=std::max(0.0,wait-(interval-reference)-margin);fastWindows=0;
   // Still slow with almost no wait: the game itself slowed down (heavier
   // scene). Measure against the new interval and probe from the ideal.
   if(wait<=ideal()*0.1&&++stalledWindows>=4){reference=interval;wait=ideal();stalledWindows=0;}
  }else{
   stalledWindows=0;wait=std::min(ideal(),wait+probe);
   // Faster than the reference (limiter raised, lighter scene): follow it.
   // Much faster means the reference was wrong: follow at once.
   if(interval<reference*0.7){reference=interval;wait=std::min(wait,ideal());fastWindows=0;}
   else if(interval<reference*0.93){if(++fastWindows>=3){reference=interval;wait=std::min(wait,ideal());fastWindows=0;}}else fastWindows=0;
  }
  averageSpacing+=(spacing()-averageSpacing)*0.3;
  // Only sustained short spacing selects the pipelined order.
  shortWindows=averageSpacing<timed_minimum?shortWindows+1:0;
  if(state==Presentation::timed&&pacing==Pacing::automatic&&windows>=6&&shortWindows>=4){
   learnedPipeline=true;enter(Presentation::pipelined,now);
  }
 }
 // Fraction of the ideal (half-interval) spacing currently applied.
 double spacing() const {const double i=ideal();return i>0?wait/i:0;}
 // Seconds between the generated frame becoming visible and the real Present.
 double wait_seconds() const {
  if((state!=Presentation::timed&&state!=Presentation::pipelined)||!(reference>0))return 0;
  return std::min(maximum_wait,wait);
 }
 bool generating() const {return state!=Presentation::paused&&state!=Presentation::native;}
 bool spaced() const {return state==Presentation::timed||state==Presentation::pipelined;}
 bool pipelined() const {return state==Presentation::pipelined;}
 bool paced() const {return state==Presentation::vblank;}
};
}
