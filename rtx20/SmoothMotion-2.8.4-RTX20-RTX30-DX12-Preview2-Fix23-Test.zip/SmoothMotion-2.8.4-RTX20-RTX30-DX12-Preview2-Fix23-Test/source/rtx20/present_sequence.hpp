#pragma once
#include <array>
#include <atomic>
#include <cstdint>
namespace sm20 {
// A resize/fullscreen call can run on the window thread while Present waits.
// Count every transition, including same-size and failed requests: old captures
// must not be restored after one, even when it finished before Present returns.
class PresentationRevision {
 std::atomic_uint active_{};
 std::atomic_ullong revision_{};
 std::atomic_bool reset_{};
public:
 void begin_transition() noexcept {++active_;++revision_;reset_=true;}
 void end_transition() noexcept {reset_=true;--active_;}
 bool transitioning() const noexcept {return active_.load()!=0;}
 bool consume_reset() noexcept {return reset_.exchange(false);}
 std::uint64_t checkpoint() const noexcept {return revision_.load();}
 bool current(std::uint64_t checkpoint) const noexcept {
  return !transitioning()&&!reset_.load()&&revision_.load()==checkpoint;
 }
};
enum class RestoreResult { restored, interrupted, failed };
inline constexpr unsigned generated_do_not_wait=0x8;
inline constexpr std::int32_t present_still_drawing=static_cast<std::int32_t>(0x887a000au);
// Admission has already validated flags (0 or a legal ALLOW_TEARING).
// Unpaced: synthetic work never requests a VBlank or waits for a full
// presentation queue; queue pressure drops only that optional submission.
// Paced (VSync games or Pacing=vblank): both frames use sync intervals of 1
// or more (ALLOW_TEARING is invalid with them). The generated frame occupies
// the first refresh(es), the real frame the next; a game presenting with
// interval N keeps N refreshes per real frame (see paired_intervals).
// Spaced (timed/pipelined): after the generated Present, `between` runs (the
// pipelined order computes the next pair there) and returns when the
// generated frame became visible; the real Present waits until `spacing`
// seconds after that. The wait returns whether the restored frame is still
// valid (no resize/transition began); if not, it is never submitted. Other DXGI statuses/errors retain their result and
// reject history. Restore the real image before forwarding the caller's
// Present exactly once.
inline constexpr unsigned paced_flags_mask=~0x200u;
struct PairPlan {
 bool generated{};   // a generated frame is written to the backbuffer
 bool paced{};       // both frames on refreshes (VSync pairs)
 unsigned generatedInterval{1},realInterval{1}; // paced sync intervals
 bool restore{};     // write a real frame even without a generated Present
 bool compute{};     // run `between` even without a generated Present
 double spacing{};   // seconds from generated visibility to the real Present
};
// Captured real frames alternate between two slots. The pipelined order
// shows, at each Present, the pair computed at the previous Present (its
// generated frame, then that real frame) and computes the next pair. Without
// a previous real frame the game's own frame is shown; a pair computed on it
// would step backwards after it, so that Present computes nothing and the
// next repeats the frame once. Timed presentation restores the current slot.
struct FrameRing {
 unsigned slot{};std::array<bool,2> valid{};bool pending{};
 struct Step {unsigned capture{},restore{};bool restoreReal{},generated{},compute{};};
 void reset(){valid={};pending=false;}
 Step begin(bool pipelined,bool fresh,bool interpolating,bool twoSlots){
  if(!fresh)reset();
  const unsigned previous=slot;slot=twoSlots?slot^1u:0u;valid[slot]=false;
  Step step;step.capture=slot;
  if(pipelined&&twoSlots){
   step.restore=previous;step.restoreReal=fresh&&valid[previous];
   step.generated=step.restoreReal&&pending;step.compute=interpolating&&step.restoreReal;
  }else{step.restore=slot;step.generated=interpolating;}
  pending=false;return step;
 }
 void captured(){valid[slot]=true;}
 void computed(){pending=true;}
};
template<class Present,class Between,class Wait,class Restore,class Finish,class Generated,class Busy>
std::int32_t present_scheduled(const PairPlan& plan,unsigned sync,unsigned flags,Present present,Between between,Wait wait_until,
                               Restore restore,Finish finish,Generated generated_accepted,Busy generated_busy){
 const bool paced=plan.paced&&plan.generated;
 double shown=-1;std::int32_t first=0;
 if(plan.generated){
  first=static_cast<std::int32_t>(paced?present(plan.generatedInterval,flags&paced_flags_mask):present(0,flags|generated_do_not_wait));
  if(first!=0&&first!=present_still_drawing){restore();finish(false);return first;}
  if(first==0)generated_accepted();else generated_busy();
  shown=between(first==0);
 }else if(plan.compute)(void)between(false);
 if(plan.generated||plan.restore){
  const auto restored=restore();
  if(restored!=RestoreResult::restored&&(plan.generated||restored==RestoreResult::failed)){
   finish(false);
   // A transition invalidates the captured image, including after a rejected
   // nonblocking submission. Never write or submit the stale original frame.
   return restored==RestoreResult::interrupted?first:static_cast<std::int32_t>(0x887a0007u);
  }
  // An interrupted restore-only write left the game's own frame in place;
  // forward it (finish rejects the history).
 }
 if(shown>=0&&plan.spacing>0&&!wait_until(shown+plan.spacing)){finish(false);return first;}
 // No fixed-rate limiter. Game/driver VSync and engine limits still apply to
 // this original submission. Accepted Presents are not proof of distinct
 // displayed frames: compositor drops and uneven cadence remain possible.
 auto hr=static_cast<std::int32_t>(paced?present(plan.realInterval,flags&paced_flags_mask):present(sync,flags));finish(hr==0);return hr;
}
template<class Present,class Restore,class Finish,class Generated,class Busy>
std::int32_t present_pair(bool generated,bool paced,unsigned sync,unsigned flags,Present present,Restore restore,Finish finish,Generated generated_accepted,Busy generated_busy){
 PairPlan plan;plan.generated=generated;plan.paced=paced;
 return present_scheduled(plan,sync,flags,present,[](bool){return -1.0;},[](double){return true;},restore,finish,generated_accepted,generated_busy);
}
template<class Present,class Restore,class Finish,class Generated,class Busy>
std::int32_t present_pair(bool generated,unsigned sync,unsigned flags,Present present,Restore restore,Finish finish,Generated generated_accepted,Busy generated_busy){
 return present_pair(generated,false,sync,flags,present,restore,finish,generated_accepted,generated_busy);
}
}
