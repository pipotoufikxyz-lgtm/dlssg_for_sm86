#pragma once
#include <windows.h>
#include <algorithm>
#include <chrono>
#ifndef CREATE_WAITABLE_TIMER_HIGH_RESOLUTION
#define CREATE_WAITABLE_TIMER_HIGH_RESOLUTION 0x00000002
#endif
namespace sm20::pacing {
inline double now(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}
// Precise wait for spaced presentation: sleep on a high-resolution waitable
// timer (Windows 10 1803+) until about 1 ms before the target, then spin.
// Without that timer the whole wait spins with yields, because a default
// resolution sleep can overshoot by a full 15.6 ms tick. Sleeps in slices of
// at most 2 ms so a resize/transition (abort() true) ends the wait promptly.
// Never waits longer than 100 ms.
template<class Abort> void wait_until(double target,Abort abort){
 thread_local const HANDLE timer=CreateWaitableTimerExW(nullptr,nullptr,CREATE_WAITABLE_TIMER_HIGH_RESOLUTION,TIMER_ALL_ACCESS);
 const double limit=now()+0.1;if(target>limit)target=limit;
 for(;;){
  if(abort())return;
  const double remaining=target-now();
  if(remaining<=0)return;
  if(timer&&remaining>0.0015){
   LARGE_INTEGER due{};due.QuadPart=-static_cast<LONGLONG>(std::min(remaining-0.001,0.002)*1e7);
   if(SetWaitableTimerEx(timer,&due,0,nullptr,nullptr,nullptr,0)&&WaitForSingleObject(timer,200)==WAIT_OBJECT_0)continue;
  }
  if(remaining>0.002)SwitchToThread();else YieldProcessor();
 }
}
}
