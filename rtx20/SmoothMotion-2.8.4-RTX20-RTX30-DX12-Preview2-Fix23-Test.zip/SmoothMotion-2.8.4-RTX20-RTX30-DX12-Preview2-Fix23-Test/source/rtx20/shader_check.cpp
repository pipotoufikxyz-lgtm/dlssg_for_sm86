#include <windows.h>
#include <d3dcompiler.h>
#include <cstdio>
#include <cstring>
#include "shader_source.hpp"
int main(){
 auto dll=LoadLibraryExW(L"d3dcompiler_47.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
 auto compile=dll?reinterpret_cast<decltype(&D3DCompile)>(GetProcAddress(dll,"D3DCompile")):nullptr;
 if(!compile){std::puts("D3DCompiler47 unavailable");return 1;}
 const char* entries[]={"Fullscreen","Capture","Project","Synthesize","Resolve","Blit","BlitSrgb","OverlayMask","OverlayGrow"};
 for(auto e:entries){ID3DBlob *code=nullptr,*errors=nullptr;
  auto hr=compile(shader_source,sizeof(shader_source)-1,"sm20.hlsl",nullptr,nullptr,e,!std::strcmp(e,"Fullscreen")?"vs_5_0":"ps_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&errors);
  if(errors){std::puts(static_cast<const char*>(errors->GetBufferPointer()));errors->Release();}
  if(FAILED(hr)){std::printf("FAIL %s %lx\n",e,(unsigned long)hr);return 2;}
  std::printf("PASS %s: %zu DXBC bytes\n",e,code->GetBufferSize());code->Release();
 }
 return 0;
}
