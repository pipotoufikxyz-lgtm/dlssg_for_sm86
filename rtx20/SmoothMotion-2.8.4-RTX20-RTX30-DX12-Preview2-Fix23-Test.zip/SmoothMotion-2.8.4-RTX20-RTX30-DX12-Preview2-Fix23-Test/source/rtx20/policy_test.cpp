#include <cmath>
#include "policy.hpp"
#include "present_sequence.hpp"
#include <cassert>
#include <iostream>
#include <utility>
#include <string>
#include <vector>
int main(){
 using namespace sm20;
 assert(supported_gpu(0x10de,7,5));assert(!supported_gpu(0x1002,7,5));assert(supported_gpu(0x10de,8,6));assert(!supported_gpu(0x1002,8,6));
 assert(!supported_gpu(0x10de,7,0));assert(!supported_gpu(0x10de,8,0));assert(!supported_gpu(0x10de,8,9));assert(!supported_gpu(0x10de,6,1));
 for(unsigned f=0;f<200;++f)assert(supported_format(f)==(f==24||f==28||f==29||f==87||f==91));
 for(unsigned sync=0;sync<7;++sync)for(unsigned flags=0;flags<2048;++flags)for(bool partial:{false,true})
 for(bool windowed:{false,true})for(unsigned swapFlags:{0u,0x42u,0x800u,0x842u}){
  const bool tearing=sync==0&&flags==0x200&&windowed&&(swapFlags&0x800);
  assert(interpolate_request(sync,flags,partial,windowed,swapFlags)==(!partial&&((sync<5&&flags==0)||tearing)));
  if(flags&1)assert(request_admission(sync,flags,partial,windowed,swapFlags)==Admission::test);
 }
 assert(!interpolate_request(0,0x200,false)); // Unknown swapchain is not assumed eligible.
 assert(request_admission(0,0x200,false,true,0x842)==Admission::eligible);
 assert(request_admission(1,0x200,false,true,0x842)==Admission::tearing_contract);
 assert(request_admission(0,0x208,false,true,0x842)==Admission::flags); // DO_NOT_WAIT
 assert(request_admission(0,0,false)==Admission::eligible);
 // Fix15: interval 2-4 (30 FPS locks on 60 Hz, e.g. NFS Most Wanted 2012) are
 // admitted and paired on refreshes; DXGI rejects anything above 4.
 assert(request_admission(2,0,false)==Admission::eligible);
 assert(request_admission(4,0,false)==Admission::eligible);
 assert(request_admission(5,0,false)==Admission::interval);
 assert(request_admission(2,0x200,false,true,0x842)==Admission::tearing_contract);
 for(unsigned n=0;n<=6;++n){
  const auto i=paired_intervals(n);const unsigned k=n<1?1:(n>4?4:n);
  assert(i.generated>=1&&i.real>=1&&i.generated<=i.real);
  assert(k==1?(i.generated==1&&i.real==1):i.generated+i.real==k);
 }
 assert(paired_intervals(2).generated==1&&paired_intervals(2).real==1);
 assert(paired_intervals(3).generated==1&&paired_intervals(3).real==2);
 assert(paired_intervals(4).generated==2&&paired_intervals(4).real==2);
 {
  // Paced pairs submit the planned intervals: generated first, then real.
  PairPlan plan;plan.generated=plan.paced=true;plan.generatedInterval=1;plan.realInterval=1;
  std::vector<unsigned> syncs;
  present_scheduled(plan,2,0,[&](unsigned s,unsigned f){assert(f==0);syncs.push_back(s);return 0;},[](bool){return -1.0;},[](double){return true;},
   []{return RestoreResult::restored;},[](bool ok){assert(ok);},[]{},[]{assert(false);});
  assert((syncs==std::vector<unsigned>{1,1}));
  plan.generatedInterval=2;plan.realInterval=2;syncs.clear();
  present_scheduled(plan,4,0,[&](unsigned s,unsigned){syncs.push_back(s);return 0;},[](bool){return -1.0;},[](double){return true;},
   []{return RestoreResult::restored;},[](bool){},[]{},[]{});
  assert((syncs==std::vector<unsigned>{2,2}));
 }
 {
  // GPU budget (Fix15): parse, then choose the best flow mode that fits.
  assert(std::abs(parse_gpu_budget(L"auto")-0.10)<1e-9&&std::abs(parse_gpu_budget(nullptr)-0.10)<1e-9);
  assert(parse_gpu_budget(L"0")==0&&parse_gpu_budget(L"off")==0&&parse_gpu_budget(L"Unlimited")==0);
  assert(std::abs(parse_gpu_budget(L"15")-0.15)<1e-9&&std::abs(parse_gpu_budget(L"20%")-0.20)<1e-9);
  assert(std::abs(parse_gpu_budget(L"abc")-0.10)<1e-9&&parse_gpu_budget(L"250")==1);
  const double interval=1/30.0; // limit 3.33 ms at 10%
  FlowBudget budget;double now=100;
  auto choose=[&](FlowMode current,FlowQuality q=FlowQuality::automatic,FlowResolution r=FlowResolution::automatic,double rate=30){
   return choose_flow_mode(r,true,q,true,current,rate,1/rate,budget,now);};
  // Unknown costs: SLOW is tried first (Fix14 behaviour below 40 FPS).
  assert(choose(FlowMode::medium)==FlowMode::slow);
  for(int i=0;i<3;++i)budget.observe(FlowMode::slow,0.0057,now);
  assert(choose(FlowMode::slow)==FlowMode::slow); // too few samples to judge
  budget.observe(FlowMode::slow,0.0057,now);
  assert(choose(FlowMode::slow)==FlowMode::medium); // 5.7 ms > 3.33 ms: the user log case
  for(int i=0;i<6;++i)budget.observe(FlowMode::medium,0.0031,now);
  assert(choose(FlowMode::medium)==FlowMode::medium);
  // Hysteresis: a mode in use may run up to 15% over before it is left.
  for(int i=0;i<30;++i)budget.observe(FlowMode::medium,0.0036,now);
  assert(choose(FlowMode::medium)==FlowMode::medium);
  for(int i=0;i<30;++i)budget.observe(FlowMode::medium,0.0045,now);
  assert(choose(FlowMode::medium)==FlowMode::half);
  // Forced settings are honoured regardless of the budget.
  assert(choose(FlowMode::half,FlowQuality::high)==FlowMode::slow);
  assert(choose(FlowMode::half,FlowQuality::automatic,FlowResolution::full)==FlowMode::medium);
  assert(choose(FlowMode::half,FlowQuality::medium)==FlowMode::half);
  // After retry_seconds a rejected mode is measured again.
  now+=FlowBudget::retry_seconds+1;
  assert(choose(FlowMode::half)==FlowMode::slow);
  assert(budget.samples[0]==0&&budget.estimate[0]<0);
  // Above 40 FPS SLOW is not used; above 58 FPS half resolution as before.
  assert(choose(FlowMode::medium,FlowQuality::automatic,FlowResolution::automatic,50)!=FlowMode::slow);
  assert(choose(FlowMode::medium,FlowQuality::automatic,FlowResolution::automatic,60)==FlowMode::half);
  // GpuBudget=0: Fix14 behaviour, never over budget.
  FlowBudget unlimited;unlimited.fraction=0;for(int i=0;i<10;++i)unlimited.observe(FlowMode::slow,0.02,now);
  assert(choose_flow_mode(FlowResolution::automatic,true,FlowQuality::automatic,true,FlowMode::slow,30,interval,unlimited,now)==FlowMode::slow);
  // Implausible samples (pauses, disjoint queries) are ignored.
  FlowBudget noisy;noisy.observe(FlowMode::medium,0,now);noisy.observe(FlowMode::medium,1.0,now);assert(noisy.samples[1]==0);
 }
 assert(request_admission(0,0,true)==Admission::partial);
 // Distinct captures can share one coarse GetTickCount64 tick. The caller's
 // history bit establishes that a prior capture exists; equality is fresh.
 assert(!fresh_history(0,0));assert(!fresh_history(0,30));assert(!fresh_history(50,49));
 assert(fresh_history(50,50));assert(fresh_history(50,51));assert(fresh_history(50,300));assert(!fresh_history(50,301));
 for(unsigned n=1;n<=4096;++n)assert(grid_extent(n)*4>=n&&(grid_extent(n)-1)*4<n);
 assert(dimensions(1920,1080));assert(!dimensions(0,1080));assert(!dimensions(3841,2160));
 for(const auto& request:{std::pair{0u,0u},std::pair{0u,present_allow_tearing},std::pair{1u,0u}})
 for(bool gen:{false,true})for(std::int32_t first:{0,std::int32_t(0x087a0001),std::int32_t(0x887a0005u),std::int32_t(0x887a000au)})
 for(std::int32_t second:{0,std::int32_t(0x887a0005u)})for(auto restored:{RestoreResult::restored,RestoreResult::interrupted,RestoreResult::failed}){
  const auto [sync,flags]=request;
  int presents=0,restores=0,finishes=0,generated=0,busy=0;bool accepted=false;std::vector<unsigned> syncs;
  auto hr=present_pair(gen,sync,flags,[&](unsigned s,unsigned f){
   const bool synthetic=gen&&presents==0;
   assert(s==(synthetic?0:sync)&&f==(synthetic?(flags|generated_do_not_wait):flags));
   assert(!(f&present_allow_tearing)||s==0); // Never create an invalid tearing call.
   if(gen&&!synthetic)assert(restores==1&&generated+busy==1);
   syncs.push_back(s);return ++presents==1?first:second;
  },
   [&]{++restores;return restored;},[&](bool ok){++finishes;accepted=ok;},[&]{++generated;},[&]{++busy;});
  assert(finishes==1);
  if(!gen){assert(presents==1&&restores==0&&generated==0&&busy==0&&syncs[0]==sync&&hr==first&&accepted==(first==0));}
  else if(first!=0&&first!=present_still_drawing){assert(presents==1&&restores==1&&generated==0&&busy==0&&hr==first&&!accepted);}
  else {
   assert(generated==(first==0)&&busy==(first==present_still_drawing));
   if(restored!=RestoreResult::restored){assert(presents==1&&restores==1&&hr==(restored==RestoreResult::interrupted?first:std::int32_t(0x887a0007u))&&!accepted);}
   else{assert(presents==2&&restores==1&&syncs[0]==0&&syncs[1]==sync&&hr==second&&accepted==(second==0));}
  }
 }
 for(unsigned sync=0;sync<6;++sync)for(unsigned flags=0;flags<2048;++flags){
  unsigned submits=0;
  present_pair(false,sync,flags,[&](unsigned s,unsigned f){++submits;assert(s==sync&&f==flags);return 0;},
   []{assert(false);return RestoreResult::failed;},[](bool ok){assert(ok);},[]{assert(false);},[]{assert(false);});
  assert(submits==1);
 }
 // A window-thread transition can remain active or finish entirely inside the
 // first Present. Neither is a copy failure; old-size/same-size captures are
 // invalidated by revision, with no stale write and no second submission.
 for(bool active:{false,true})for(std::int32_t first:{0,std::int32_t(0x087a0001),std::int32_t(0x887a0005u),std::int32_t(0x887a000au)}){
  PresentationRevision epoch;const auto captured=epoch.checkpoint();
  int presents=0,copies=0,finishes=0,generated=0;bool history=true;
  const auto result=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){
   assert(sync==0&&flags==(present_allow_tearing|generated_do_not_wait));++presents;epoch.begin_transition();if(!active)epoch.end_transition();return first;
  },[&]{if(!epoch.current(captured))return RestoreResult::interrupted;++copies;return RestoreResult::restored;},
  [&](bool accepted){++finishes;history=accepted&&epoch.current(captured);},[&]{++generated;},[]{});
  assert(result==first&&presents==1&&copies==0&&finishes==1&&!history&&generated==(first==0));
  if(active)epoch.end_transition();
  assert(!epoch.current(captured)&&!epoch.transitioning());
  // The next eligible call consumes the reset and gets a fresh revision, so a
  // resize interruption does not permanently disable frame generation.
  assert(epoch.consume_reset());const auto recovered=epoch.checkpoint();
  assert(epoch.current(recovered)&&recovered!=captured&&!epoch.consume_reset());
  presents=copies=finishes=generated=0;
  const auto next=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){assert(sync==0&&flags==(presents?present_allow_tearing:(present_allow_tearing|generated_do_not_wait)));++presents;return 0;},
   [&]{assert(epoch.current(recovered));++copies;return RestoreResult::restored;},
   [&](bool accepted){++finishes;history=accepted&&epoch.current(recovered);},[&]{++generated;},[]{assert(false);});
  assert(next==0&&presents==2&&copies==1&&finishes==1&&history&&generated==1);
 }
 // Transitions during the final original submission keep that actual HRESULT,
 // while rejecting old history even when the transition already completed.
 for(bool generated:{false,true})for(std::int32_t final:{0,std::int32_t(0x887a0005u)}){
  PresentationRevision epoch;const auto captured=epoch.checkpoint();int presents=0;bool history=true;
  const auto hr=present_pair(generated,0,0,[&](unsigned,unsigned){
   if(++presents==(generated?2:1)){epoch.begin_transition();epoch.end_transition();return final;}return std::int32_t(0);
  },[]{return RestoreResult::restored;},[&](bool accepted){history=accepted&&epoch.current(captured);},[]{},[]{assert(false);});
  assert(hr==final&&!history&&presents==(generated?2:1));
 }
 // A transition after prepare also prevents the first generated write, and
 // nested wrapper transitions remain active until the last matching exit.
 PresentationRevision epoch;const auto beforeWrite=epoch.checkpoint();assert(epoch.current(beforeWrite));
 epoch.begin_transition();epoch.begin_transition();assert(!epoch.current(beforeWrite));
 epoch.end_transition();assert(epoch.transitioning()&&!epoch.current(beforeWrite));
 epoch.end_transition();assert(!epoch.transitioning()&&!epoch.current(beforeWrite));
 assert(epoch.consume_reset());assert(!epoch.current(beforeWrite));assert(epoch.current(epoch.checkpoint()));
 // Repeated queue saturation must neither retry synthetic submissions nor
 // starve/replace the real image or count a dropped frame as accepted.
 for(unsigned frame=0;frame<1000;++frame){
  int submits=0,restores=0,busy=0;bool accepted=false;
  auto hr=present_pair(true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){
   assert(sync==0);
   if(++submits==1){assert(flags==(present_allow_tearing|generated_do_not_wait));return present_still_drawing;}
   assert(submits==2&&restores==1&&flags==present_allow_tearing);return std::int32_t(0);
  },[&]{++restores;return RestoreResult::restored;},[&](bool ok){accepted=ok;},[]{assert(false);},[&]{++busy;});
  assert(hr==0&&accepted&&submits==2&&busy==1&&restores==1);
 }
 {
  // Flow resolution: explicit settings win, automatic mode uses hysteresis
  // and never selects an unavailable half-resolution session.
  assert(parse_flow_resolution(nullptr)==FlowResolution::automatic);
  assert(parse_flow_resolution(L"Full")==FlowResolution::full&&parse_flow_resolution(L"HALF")==FlowResolution::half);
  assert(parse_flow_resolution(L"auto")==FlowResolution::automatic&&parse_flow_resolution(L"halfx")==FlowResolution::automatic);
  assert(!use_half_flow(FlowResolution::half,false,false,200));
  assert(use_half_flow(FlowResolution::half,true,false,20)&&!use_half_flow(FlowResolution::full,true,true,200));
  assert(!use_half_flow(FlowResolution::automatic,true,false,30));   // 30 FPS base: keep detail
  assert(!use_half_flow(FlowResolution::automatic,true,false,57));
  assert(use_half_flow(FlowResolution::automatic,true,false,70));    // e.g. Blackwood with full flow
  assert(use_half_flow(FlowResolution::automatic,true,true,50));     // hysteresis keeps half
  assert(!use_half_flow(FlowResolution::automatic,true,true,40));
  double average=0;
  for(int i=0;i<200;++i)average=update_frame_interval(average,1/90.0);
  assert(std::abs(1/average-90)<0.5);
  assert(update_frame_interval(average,0.4)==0&&update_frame_interval(average,0)==0);
  assert(update_frame_interval(0,1/60.0)==1/60.0);
 }
 {
  // Flow quality: SLOW preset below 40 real FPS (30 FPS base: yes), back to
  // MEDIUM from 48; forced settings; unavailable session never selected.
  assert(parse_flow_quality(L"HIGH")==FlowQuality::high&&parse_flow_quality(L"slow")==FlowQuality::high);
  assert(parse_flow_quality(L"medium")==FlowQuality::medium&&parse_flow_quality(L"auto")==FlowQuality::automatic&&parse_flow_quality(nullptr)==FlowQuality::automatic);
  assert(use_quality_flow(FlowQuality::automatic,true,false,30)&&!use_quality_flow(FlowQuality::automatic,true,false,45));
  assert(use_quality_flow(FlowQuality::automatic,true,true,45)&&!use_quality_flow(FlowQuality::automatic,true,true,50));
  assert(!use_quality_flow(FlowQuality::automatic,true,false,0));        // unknown rate: stay MEDIUM
  assert(use_quality_flow(FlowQuality::high,true,false,120)&&!use_quality_flow(FlowQuality::medium,true,true,20));
  assert(!use_quality_flow(FlowQuality::high,false,false,20));
 }
 std::cout<<"PASS: flow resolution and quality selection, frame-interval averaging\n";
 {
  // Refresh gate: 118 native FPS on a 92 Hz display pauses; 30 on 60 Hz does not.
  assert(generation_useful(true,30,60)&&generation_useful(false,30,60));
  assert(!generation_useful(true,100,92));            // generating, already above refresh
  assert(!generation_useful(false,118,92));           // paused, native above refresh
  assert(!generation_useful(false,85,92)&&generation_useful(false,80,92));  // hysteresis
  assert(generation_useful(true,93,92)&&!generation_useful(true,94,92));
  assert(generation_useful(true,200,0)&&generation_useful(false,0,92));    // unknown rates
  // Pacing setting names (Fix13 "on" keeps the default).
  assert(parse_pacing(L"auto")==Pacing::automatic&&parse_pacing(L"on")==Pacing::automatic&&parse_pacing(nullptr)==Pacing::automatic);
  assert(parse_pacing(L"OFF")==Pacing::off&&parse_pacing(L"0")==Pacing::off);
  assert(parse_pacing(L"Low_Latency")==Pacing::low_latency&&parse_pacing(L"smooth")==Pacing::smooth&&parse_pacing(L"vblank")==Pacing::vblank);
  // Game-loop model: after Present returns the game works `work` seconds,
  // then an optional frame limiter holds it to `cap`; inside Present the
  // capture waits for the game's GPU tail, then (timed) flow and synthesis
  // run before the generated Present, then the spacing wait. Pipelined
  // presentation computes during the wait instead.
  struct Game {double work,tail,generation,cap;};
  struct Result {double fps,spacing,wait;Presentation state;};
  auto run=[](PresentationPolicy& policy,const Game& g,double seconds,double t=0){
   double target=0,interval=0,last=-1,returned=t;unsigned frames=0;double startCount=-1;
   while(t<seconds){
    double entry=returned+g.work;
    if(g.cap>0){target+=g.cap;if(entry>target)target=entry;entry=target;}
    if(last>=0)interval=update_frame_interval(interval,entry-last);
    last=entry;
    policy.update(entry,interval>0?1/interval:0);
    const double wait=policy.wait_seconds();
    double inside=g.tail;
    if(!policy.generating())inside+=0.0005; // native measurement or paused
    else if(policy.state==Presentation::pipelined)inside+=std::max(wait,0.0005);
    else inside+=g.generation+wait+0.0005;
    returned=entry+inside;t=returned;
    if(t>seconds-2){if(startCount<0)startCount=entry;++frames;}
   }
   return Result{frames>1?(frames-1)/(last-startCount):0,policy.spacing(),policy.wait_seconds(),policy.state};
  };
  // RE3-like (log 38): capped at 30, game ~11.5 ms of the frame, flow and
  // synthesis 8.5 ms. Timed spacing cannot reach 85% of 16.7 ms without
  // lowering 30 FPS, so auto switches to the pipelined order, which spaces
  // evenly (wait ~16.7 ms) at the full 30 FPS.
  {
   PresentationPolicy re3;re3.refreshHz=92;
   const Game game{0.005,0.0065,0.0085,1/30.0};
   auto r=run(re3,game,2.0);
   assert(r.state==Presentation::timed);
   r=run(re3,game,12.0);
   assert(r.state==Presentation::pipelined&&re3.learnedPipeline);
   assert(std::abs(r.fps-30)<0.6&&r.spacing>=0.95&&std::abs(r.wait-1/60.0)<0.001);
   // Re-measuring (F11, resize) returns straight to the learned order.
   re3.reset();r=run(re3,game,3.0);assert(r.state==Presentation::pipelined);
  }
  // Fix17, Genshin Impact log 45 (RTX 2070 Max-Q, 144 Hz): native about
  // 118 FPS, but a pair costs about 20 ms of GPU time, so generating drops
  // the real rate to ~30 (60 displayed < 118 native). The guard pauses after
  // 2 s and keeps the native rate; retries back off (30 s, then 60 s).
  {
   PresentationPolicy genshin;genshin.refreshHz=144;
   const Game game{0.004,0.004,0.020,0};
   auto r=run(genshin,game,25.0);
   assert(r.state==Presentation::paused&&genshin.counterproductive&&genshin.pauses==1);
   assert(genshin.nativeFps>110&&r.fps>110); // native rate restored
   // Fix23: the pause measured the cost (~25 ms per real frame), so the
   // retry at ~33 s is predicted to lose (22 real / 44 shown vs 118) and is
   // skipped: no low-FPS seconds, still one pause.
   r=run(genshin,game,60.0,25.0);
   assert(r.state==Presentation::paused&&genshin.pauses==1&&genshin.skippedRetries>=1&&r.fps>110);
   assert(genshin.extraCost>0.02&&genshin.extraCost<0.03&&!genshin.beneficial(118)&&!genshin.beneficial(50));
   // A real attempt still comes at most maximum_retry after the last one.
   r=run(genshin,game,400.0,60.0);
   assert(genshin.pauses>=2);
   // Prediction: a cheaper pair wins at 100 native, not at 140 (capped at 144).
   PresentationPolicy cheap;cheap.refreshHz=144;cheap.extraCost=0.004;
   assert(cheap.beneficial(100)&&!cheap.beneficial(140));
   // Without a known cost, a much heavier scene retries at once (Fix17).
   genshin.extraCost=-1;genshin.pausedUntil=1e9;genshin.pausedNative=118;
   double t=400.0;Presentation state=genshin.state;
   if(state==Presentation::paused&&genshin.counterproductive){
    for(int i=0;i<40&&state==Presentation::paused;++i){state=genshin.update(t,50);t+=0.02;}
    assert(state==Presentation::native&&t<401.0);
   }
  }
  // Fix20, God of War log 46 (RTX 2060, 144 Hz, uncapped GPU-bound 70 FPS):
  // generating ran at ~40 real (80 displayed, above Fix17's 10% gain), which
  // looks like native with twice the latency. The base-rate floor (65% of
  // native) pauses it; with the floor off, Fix17 behaviour is kept.
  {
   PresentationPolicy gow;gow.refreshHz=144;
   const Game game{0.006,0.008,0.011,0}; // native ~70, generating ~40 real
   auto r=run(gow,game,20.0);
   assert(gow.nativeFps>65&&gow.nativeFps<75&&r.state==Presentation::paused&&gow.counterproductive&&r.fps>65);
   PresentationPolicy loose;loose.refreshHz=144;loose.minimumBase=0;
   r=run(loose,game,20.0);
   assert(r.state!=Presentation::paused&&loose.lastDisplayed>loose.nativeFps*1.1);
   // A cheap enough pair keeps generating: ~55 real of 70 native (79%).
   PresentationPolicy light;light.refreshHz=144;
   r=run(light,{0.006,0.008,0.0035,0},20.0);
   assert(r.state!=Presentation::paused&&light.pauses==0&&light.lastReal>=light.nativeFps*0.65);
   // Fix21, God of War log 48: the game resized its swapchain right after
   // each guard pause; the rebuild (and discarded frames) reset the policy,
   // so generation restarted and tanked again. restart() keeps the pause
   // and its backoff, and ends it only when it expires.
   const double until=gow.pausedUntil,delay=gow.retryDelay;const unsigned pauses=gow.pauses;
   PresentationPolicy rebuilt=gow;rebuilt.restart();
   assert(rebuilt.state==Presentation::paused&&rebuilt.counterproductive&&rebuilt.pausedUntil==until&&rebuilt.retryDelay==delay);
   double t=20.0;
   for(int i=0;i<100;++i){assert(rebuilt.update(t,70)==Presentation::paused);t+=1/70.0;}
   assert(rebuilt.pauses==pauses);
   // Fix23: at the retry time the known cost predicts ~40 real / 80 shown
   // vs 70 native (below 65%): skipped. Without a known cost it retries.
   t=until+0.01;assert(rebuilt.update(t,70)==Presentation::paused&&rebuilt.skippedRetries==1);
   rebuilt.extraCost=-1;t=rebuilt.pausedUntil+0.01;assert(rebuilt.update(t,70)==Presentation::native);
   // Other states measure again, as before.
   PresentationPolicy running;running.refreshHz=144;run(running,{0.006,0.008,0.0035,0},5.0);
   assert(running.generating());running.restart();assert(running.state==Presentation::native);
  }
  {
   assert(std::abs(parse_minimum_base(L"auto")-0.65)<1e-9&&std::abs(parse_minimum_base(nullptr)-0.65)<1e-9);
   assert(parse_minimum_base(L"0")==0&&parse_minimum_base(L"off")==0&&std::abs(parse_minimum_base(L"80%")-0.8)<1e-9);
   assert(std::abs(parse_minimum_base(L"x")-0.65)<1e-9);
   // GPU-bound detection for the DX11 visibility wait.
   VisibilityWait v;
   for(int i=0;i<3;++i){assert(v.measure_now());v.observe(0.0005);}
   assert(!v.skipping);
   bool changed=false;for(int i=0;i<10&&!changed;++i)changed=v.observe(0.008);
   assert(changed&&v.skipping);
   unsigned measured=0;for(unsigned i=0;i<VisibilityWait::probe_every*3;++i)measured+=v.measure_now();
   assert(measured==3); // one probe per probe_every pairs
   changed=false;for(int i=0;i<30&&!changed;++i)changed=v.observe(0.0002);
   assert(changed&&!v.skipping&&v.measure_now());
   // Budget samples from warm-up/loading are ignored.
   FlowBudget b;b.observe(FlowMode::medium,0.166,0);b.observe(FlowMode::medium,0.06,0);assert(b.samples[1]==0);
   b.observe(FlowMode::medium,0.003,0);assert(b.samples[1]==1);
   // Fix23 (Monster Hunter World log 51): a mode far over budget (SLOW 13 ms
   // at 30 FPS, limit 3.3 ms) is rejected after two pairs, and each failed
   // re-measurement doubles the wait before the next (30 s, 60 s, ...).
   FlowBudget fb;const double iv=1/30.0;
   for(int i=0;i<4;++i)fb.observe(FlowMode::slow,0.013,0);
   assert(!fb.fits(FlowMode::slow,iv,10,false)&&fb.fits(FlowMode::slow,iv,31,false));
   fb.observe(FlowMode::slow,0.013,31);fb.observe(FlowMode::slow,0.013,31.03);
   assert(!fb.fits(FlowMode::slow,iv,31.1,true));
   assert(!fb.fits(FlowMode::slow,iv,80,false)&&fb.fits(FlowMode::slow,iv,92,false));
   // A mode within budget resets its wait.
   for(int i=0;i<4;++i)fb.observe(FlowMode::slow,0.002,93);
   assert(fb.fits(FlowMode::slow,iv,94,true)&&fb.retryDelay[0]==FlowBudget::retry_seconds);
  }
  // A capped 30 FPS game gains (60 displayed vs 30 native): never paused.
  {
   PresentationPolicy capped;capped.refreshHz=144;
   const auto r=run(capped,{0.005,0.0065,0.0085,1/30.0},20.0);
   assert(capped.pauses==0&&r.state!=Presentation::paused&&std::abs(r.fps-30)<0.6);
  }
  // A 2-second loading hitch during measuring restarts the measurement:
  // Fix14 averaged across it (reference 2.8 FPS) and waited 100 ms per frame.
  {
   PresentationPolicy load;load.refreshHz=60;double t=0;
   for(int i=0;i<20;++i){load.update(t,30);t+=1/30.0;}
   assert(load.state==Presentation::measuring);
   for(int i=0;i<5;++i){load.update(t,30);t+=1/30.0;}
   t+=2.0;                                     // hitch
   for(int i=0;i<40;++i){load.update(t,30);t+=1/30.0;}
   assert(load.state==Presentation::timed&&std::abs(load.reference-1/30.0)<1e-3&&load.wait_seconds()<0.02);
  }
  // The same hitch in the native measurement: native stays the real rate.
  {
   PresentationPolicy load;load.refreshHz=144;double t=0;
   for(int i=0;i<5;++i){load.update(t,60);t+=1/60.0;}
   t+=1.5;
   for(int i=0;i<40;++i){load.update(t,60);t+=1/60.0;}
   assert(std::abs(load.nativeFps-60)<0.5);
  }
  // Median intervals ignore single slow frames.
  {
   IntervalSample m;double t=0,r=0;
   for(int i=0;i<30&&!(r>0);++i){r=m.add(t,0.2,10);t+=(i%7==3)?0.05:0.01;}
   assert(std::abs(r-0.01)<1e-9);
  }
  // Light game capped at 30: timed spacing fits, lowest latency is kept.
  {
   PresentationPolicy light;light.refreshHz=60;
   const auto r=run(light,{0.003,0.003,0.004,1/30.0},15.0);
   assert(r.state==Presentation::timed&&std::abs(r.fps-30)<0.6&&r.spacing>=0.95);
  }
  // Pacing=low_latency never pipelines; the spacing shrinks until 30 FPS holds.
  {
   PresentationPolicy timed;timed.pacing=Pacing::low_latency;timed.refreshHz=92;
   const auto r=run(timed,{0.005,0.0065,0.0085,1/30.0},15.0);
   assert(r.state==Presentation::timed&&r.fps>29.2&&r.spacing<0.9&&r.spacing>0.3);
  }
  // Uncapped GPU-bound 39 FPS (25.5 ms per frame including generation):
  // pipelined spacing uses the generation time that left the game thread
  // (about 8.5 ms) and keeps the frame rate within the controller band.
  {
   PresentationPolicy heavy;heavy.pacing=Pacing::smooth;heavy.refreshHz=144;
   const auto r=run(heavy,{0.005,0.012,0.0085,0},20.0);
   assert(r.state==Presentation::pipelined&&r.fps>1/0.0255*0.94&&r.wait>0.005&&r.wait<0.0125);
  }
  // Pacing=smooth pipelines at once; Pacing=vblank keeps the Fix13 pairs.
  {
   PresentationPolicy smooth;smooth.pacing=Pacing::smooth;smooth.refreshHz=60;
   double t=0;for(int i=0;i<60;++i){smooth.update(t,30);t+=1/30.0;}
   assert(smooth.state==Presentation::pipelined&&smooth.pipelined()&&smooth.spaced()&&std::abs(smooth.wait_seconds()-1/60.0)<1e-3);
   PresentationPolicy vblank;vblank.pacing=Pacing::vblank;vblank.refreshHz=60;t=0;
   for(int i=0;i<60;++i){vblank.update(t,30);t+=1/30.0;}
   assert(vblank.state==Presentation::vblank&&vblank.paced()&&!vblank.spaced()&&vblank.wait_seconds()==0);
  }
  // Fix17: first ~0.5 s without generation (native rate), then measuring:
  // 30 FPS on 60 Hz needs 0.75 s unspaced; then timed.
  PresentationPolicy witcher;witcher.refreshHz=60;
  double t=0;int frame=0;
  for(;frame<16;++frame){assert(witcher.update(t,30)==Presentation::native&&!witcher.generating()&&witcher.wait_seconds()==0);t+=1/30.0;}
  assert(witcher.update(t,30)==Presentation::measuring&&std::abs(witcher.nativeFps-30)<0.01);t+=1/30.0;
  for(int i=0;i<23;++i){assert(witcher.update(t,30)==Presentation::measuring&&witcher.generating()&&witcher.wait_seconds()==0);t+=1/30.0;}
  assert(witcher.update(t,30)==Presentation::timed&&std::abs(witcher.reference-1/30.0)<1e-3);
  witcher.reset();assert(witcher.state==Presentation::native);
  // Blackwood-like: native 100 FPS on 92 Hz -> paused (not counterproductive,
  // a refresh pause); native 118 stays paused; a heavy scene at 80 resumes
  // (native measurement again).
  PresentationPolicy blackwood;blackwood.refreshHz=92;t=0;
  for(int i=0;i<80;++i){blackwood.update(t,100);t+=0.01;}
  assert(blackwood.state==Presentation::paused&&!blackwood.generating()&&!blackwood.counterproductive);
  assert(blackwood.update(t,118)==Presentation::paused);
  assert(blackwood.update(t,85)==Presentation::paused);
  assert(blackwood.update(t,80)==Presentation::native);
  // A spaced state also pauses once the real rate exceeds the refresh.
  PresentationPolicy rising;rising.refreshHz=60;t=0;
  for(int i=0;i<60;++i){rising.update(t,30);t+=1/30.0;}
  assert(rising.state==Presentation::timed&&rising.update(t,70)==Presentation::paused);
  // Pacing=off: measuring -> immediate; immediate pauses above refresh.
  PresentationPolicy uncapped;uncapped.pacing=Pacing::off;uncapped.refreshHz=144;t=0;
  for(int i=0;i<160;++i){uncapped.update(t,70);t+=1/70.0;}
  assert(uncapped.state==Presentation::immediate&&uncapped.generating()&&!uncapped.spaced());
  assert(uncapped.update(t,150)==Presentation::paused);
  // GenerateAboveRefresh=1 never pauses; unknown refresh never pauses.
  PresentationPolicy forced;forced.generateAboveRefresh=true;forced.refreshHz=60;t=0;
  for(int i=0;i<400;++i){forced.update(t,200);t+=0.005;}
  assert(forced.state==Presentation::timed);
  PresentationPolicy unknown;t=0;
  for(int i=0;i<400;++i){unknown.update(t,200);t+=0.005;}
  assert(unknown.state==Presentation::timed);
  // Too few frames or too little time: still measuring.
  PresentationPolicy brief;brief.refreshHz=60;
  for(int i=0;i<100;++i)brief.update(i*0.001,30);
  assert(brief.state==Presentation::native);
  // One 100 ms hitch (loading) neither cuts the spacing nor selects the
  // pipelined order.
  {
   PresentationPolicy hitch;hitch.refreshHz=144;double t=0,interval=0,last=-1;
   for(int i=0;i<600;++i){
    double step=(i==300)?0.1:1/60.0;t+=step;
    if(last>=0){interval=update_frame_interval(interval,t-last);}
    last=t;
    hitch.update(t,interval>0?1/interval:0);
   }
   assert(hitch.state==Presentation::timed&&!hitch.learnedPipeline&&hitch.spacing()>0.95);
  }
  // VSync pairs apply no CPU wait: the controller does not run (a halved
  // rate against the unpaired reference must not teach the pipelined order).
  {
   // (Fix17: native 40 FPS with VSync on 60 Hz; pairs run at 30 real.)
   PresentationPolicy vsync;vsync.refreshHz=60;double t=0;
   for(int i=0;i<24;++i){vsync.update(t,40,false);t+=1/40.0;}
   for(int i=0;i<600;++i){vsync.update(t,30,false);t+=1/30.0;}
   assert(vsync.state==Presentation::timed&&!vsync.learnedPipeline&&vsync.spacing()>0.99);
  }
  // A game that slows down by itself (heavier scene) is re-measured instead
  // of leaving the spacing at zero.
  {
   PresentationPolicy scene;scene.pacing=Pacing::low_latency;scene.refreshHz=144;
   run(scene,{0.004,0.004,0.004,1/40.0},6.0);
   const auto r=run(scene,{0.004,0.018,0.004,0},30.0,6.0);
   assert(r.state==Presentation::timed&&scene.reference>1/40.0);
  }
 }
 {
  // Paced pair: both frames at sync interval 1, tearing flag removed, the
  // generated submission may wait (no DO_NOT_WAIT); unpaced is unchanged.
  std::vector<std::pair<unsigned,unsigned>> calls;unsigned restores=0;bool ok=false;
  const auto hr=present_pair(true,true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){calls.push_back({sync,flags});return 0;},
   [&]{++restores;return RestoreResult::restored;},[&](bool accepted){ok=accepted;},[]{},[]{assert(false);});
  assert(hr==0&&ok&&restores==1&&calls.size()==2&&calls[0]==std::make_pair(1u,0u)&&calls[1]==std::make_pair(1u,0u));
  calls.clear();
  present_pair(false,true,0,present_allow_tearing,[&](unsigned sync,unsigned flags){calls.push_back({sync,flags});return 0;},
   [&]{return RestoreResult::restored;},[](bool){},[]{},[]{});
  assert(calls.size()==1&&calls[0]==std::make_pair(0u,present_allow_tearing));   // no generated frame: caller's own parameters
  calls.clear();
  present_pair(true,false,1,0,[&](unsigned sync,unsigned flags){calls.push_back({sync,flags});return 0;},
   [&]{return RestoreResult::restored;},[](bool){},[]{},[]{});
  assert(calls.size()==2&&calls[0]==std::make_pair(0u,generated_do_not_wait)&&calls[1]==std::make_pair(1u,0u));
 }
 {
  // Spaced pair: generated Present, `between` (pipelined computation and
  // visibility time), restore, wait until visibility + spacing, real Present
  // with the caller's parameters (tearing kept).
  std::vector<std::string> order;double waited=-1;
  PairPlan plan;plan.generated=true;plan.spacing=0.0167;
  auto hr=present_scheduled(plan,0,present_allow_tearing,[&](unsigned sync,unsigned flags){
    order.push_back(order.empty()?"generated":"real");
    if(order.size()==1)assert(sync==0&&flags==(present_allow_tearing|generated_do_not_wait));
    else assert(sync==0&&flags==present_allow_tearing);
    return 0;},
   [&](bool accepted){assert(accepted);order.push_back("between");return 5.0;},[&](double until){order.push_back("wait");waited=until;return true;},
   [&]{order.push_back("restore");return RestoreResult::restored;},[&](bool ok){assert(ok);order.push_back("finish");},[]{},[]{assert(false);});
  assert(hr==0&&std::abs(waited-5.0167)<1e-9);
  assert((order==std::vector<std::string>{"generated","between","restore","wait","real","finish"}));
  // Queue busy: no generated frame was shown, so no wait; between still runs.
  order.clear();waited=-1;
  hr=present_scheduled(plan,0,0,[&](unsigned,unsigned){order.push_back("present");return order.size()==1?present_still_drawing:0;},
   [&](bool accepted){assert(!accepted);order.push_back("between");return -1.0;},[&](double){waited=1;return true;},
   [&]{order.push_back("restore");return RestoreResult::restored;},[](bool){},[]{assert(false);},[&]{order.push_back("busy");});
  assert(hr==0&&waited<0&&(order==std::vector<std::string>{"present","busy","between","restore","present"}));
  // Pipelined start-up: no generated frame yet, previous real frame restored,
  // next pair computed; exactly one Present with the caller's parameters.
  PairPlan start;start.restore=true;start.compute=true;start.spacing=0.0167;
  order.clear();
  hr=present_scheduled(start,1,0,[&](unsigned sync,unsigned flags){assert(sync==1&&flags==0);order.push_back("real");return 0;},
   [&](bool accepted){assert(!accepted);order.push_back("compute");return -1.0;},[&](double){assert(false);return true;},
   [&]{order.push_back("restore");return RestoreResult::restored;},[](bool ok){assert(ok);},[]{assert(false);},[]{assert(false);});
  assert(hr==0&&(order==std::vector<std::string>{"compute","restore","real"}));
  // Restore-only interrupted by a transition: the game's frame is forwarded.
  int presents=0;bool accepted=true;
  hr=present_scheduled(start,0,0,[&](unsigned,unsigned){++presents;return 0;},[](bool){return -1.0;},[](double){return true;},
   []{return RestoreResult::interrupted;},[&](bool ok){accepted=ok;},[]{},[]{});
  assert(hr==0&&presents==1&&accepted);
  // Restore-only failure: nothing presented, device-reset result.
  presents=0;
  hr=present_scheduled(start,0,0,[&](unsigned,unsigned){++presents;return 0;},[](bool){return -1.0;},[](double){return true;},
   []{return RestoreResult::failed;},[&](bool ok){accepted=ok;},[]{},[]{});
  assert(hr==std::int32_t(0x887a0007u)&&presents==0&&!accepted);
  // A resize that begins during the wait: the restored frame is never
  // submitted, history is rejected and the generated Present's result returns.
  {
   PairPlan spaced;spaced.generated=true;spaced.spacing=0.0167;int presents=0;bool ok=true;
   auto hr=present_scheduled(spaced,0,0,[&](unsigned,unsigned){++presents;return 0;},[](bool){return 1.0;},[](double){return false;},
    []{return RestoreResult::restored;},[&](bool accepted){ok=accepted;},[]{},[]{});
   assert(hr==0&&presents==1&&!ok);
  }
  // VSync game while spaced: paced pair; the caller plans no CPU wait.
  PairPlan vsync;vsync.generated=true;vsync.paced=true;
  std::vector<std::pair<unsigned,unsigned>> calls;
  present_scheduled(vsync,1,0,[&](unsigned sync,unsigned flags){calls.push_back({sync,flags});return 0;},[](bool){return 1.0;},
   [&](double){assert(false);return true;},[]{return RestoreResult::restored;},[](bool){},[]{},[]{});
  assert(calls.size()==2&&calls[0]==std::make_pair(1u,0u)&&calls[1]==std::make_pair(1u,0u));
 }
 {
  // Displayed order. Pipelined: frame 1 has no history; from frame 2 the
  // previous real frame is restored (frame 1 once more), and from frame 3 on
  // each Present shows G(n-2,n-1) then R(n-1). Never a backward step.
  auto simulate=[](bool pipelined,int count,int breakAt){
   FrameRing ring;std::array<int,2> content{};int computed=-1;std::vector<std::string> shown;
   for(int frame=1;frame<=count;++frame){
    const bool fresh=frame>1&&frame!=breakAt;
    const auto step=ring.begin(pipelined,fresh,fresh,true);
    content[step.capture]=frame;ring.captured();
    if(!pipelined){if(step.generated)shown.push_back("G"+std::to_string(frame-1)+std::to_string(frame));shown.push_back("R"+std::to_string(frame));continue;}
    if(step.generated){assert(computed==frame-1);shown.push_back("G"+std::to_string(frame-2)+std::to_string(frame-1));}
    if(step.compute){ring.computed();computed=frame;}
    shown.push_back("R"+std::to_string(step.restoreReal?content[step.restore]:frame));
    assert(step.restore!=step.capture||!step.restoreReal);
   }
   return shown;
  };
  assert((simulate(true,5,0)==std::vector<std::string>{"R1","R1","G12","R2","G23","R3","G34","R4"}));
  assert((simulate(false,3,0)==std::vector<std::string>{"R1","G12","R2","G23","R3"}));
  // Broken history (pause, F11, gap) at frame 4 restarts the pipeline.
  assert((simulate(true,6,4)==std::vector<std::string>{"R1","R1","G12","R2","R4","R4","G45","R5"}));
  // One slot (DX12 staging): the pipelined order is not used.
  FrameRing single;const auto step=single.begin(true,true,true,false);
  assert(step.capture==0&&step.restore==0&&step.generated&&!step.compute&&!step.restoreReal);
 }
 std::cout<<"PASS: refresh-rate generation gate, spaced timed/pipelined presentation policy, pipelined frame order and scheduled pairs\n";
 std::cout<<"PASS: admission/pass-through policies, immediate nonblocking generated submissions, queue saturation recovery, original frame priority, errors and transition interruption/recovery\n";
}
