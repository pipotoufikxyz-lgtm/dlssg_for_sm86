#include "nvs30/log.hpp"

#include <cstdarg>
#include <cstdio>
#include <share.h>

namespace nvs30 {
namespace {
std::mutex g_mutex;
FILE* g_file{};
}

void log_open() {
    // GetModuleFileName may acquire the loader lock. Resolve the path before
    // taking our log mutex, so a loader callback can log without lock inversion.
    std::wstring module(32768,L'\0');
    const auto n=GetModuleFileNameW(nullptr,module.data(),static_cast<DWORD>(module.size()));
    if(!n||n>=32768)return;
    module.resize(n);
    std::filesystem::path path(module);
    path = path.parent_path() / L"nvsmooth30.log";
    std::scoped_lock lock(g_mutex);
    if (g_file) return;
    // logf formats UTF-8/narrow text and writes it with fputs.  Opening with
    // ccs=UTF-8 makes the CRT stream wide-oriented, so narrow writes fail and
    // leave an empty log file.  Keep the stream byte-oriented instead.
    // Collect diagnostics without closing the game or depending on CRT
    // secure-open sharing defaults. Keep append mode and byte-oriented output.
    g_file = _wfsopen(path.c_str(), L"ab", _SH_DENYNO);
    // Games installed under Program Files (Red Dead Redemption 2 report: "no
    // log at all") often cannot write beside the executable. Fall back to
    // %LOCALAPPDATA%\SmoothMotion\<exe name>-nvsmooth30.log.
    bool fallback=false;
    if(!g_file){
        wchar_t base[1024]{};
        const auto length=GetEnvironmentVariableW(L"LOCALAPPDATA",base,1024);
        if(length&&length<1024){
            std::filesystem::path folder=std::filesystem::path(base)/L"SmoothMotion";
            CreateDirectoryW(folder.c_str(),nullptr);
            const auto alternative=folder/(std::filesystem::path(module).stem().wstring()+L"-nvsmooth30.log");
            g_file=_wfsopen(alternative.c_str(),L"ab",_SH_DENYNO);fallback=g_file!=nullptr;
        }
    }
    if(g_file){
        SYSTEMTIME utc{};GetSystemTime(&utc);
        std::fprintf(g_file,"\n=== Smooth Motion %s session UTC=%04u-%02u-%02uT%02u:%02u:%02uZ PID=%lu ===\n",
            NVS30_VERSION,utc.wYear,utc.wMonth,utc.wDay,utc.wHour,utc.wMinute,utc.wSecond,GetCurrentProcessId());
        if(fallback)std::fprintf(g_file,"The game folder is not writable; this log is kept in %%LOCALAPPDATA%%\\SmoothMotion instead of beside the game executable.\n");
        std::fflush(g_file);
    }
}

void log_close() {
    std::scoped_lock lock(g_mutex);
    if (g_file) std::fclose(g_file);
    g_file = nullptr;
}

void logf(const char* format, ...) noexcept {
    const DWORD savedError=GetLastError();
    char line[8192]{};
    va_list args;
    va_start(args, format);
    vsnprintf_s(line, sizeof(line), _TRUNCATE, format, args);
    va_end(args);

    // Diagnostics must not throw through a hooked Win32/CUDA/COM boundary.
    try {
        OutputDebugStringA(line);
        std::scoped_lock lock(g_mutex);
        if (g_file) {
            std::fprintf(g_file,"[pid=%lu tick=%llu] ",GetCurrentProcessId(),GetTickCount64());
            std::fputs(line, g_file);
            std::fflush(g_file);
        }
    } catch (...) {}
    SetLastError(savedError);
}
}
