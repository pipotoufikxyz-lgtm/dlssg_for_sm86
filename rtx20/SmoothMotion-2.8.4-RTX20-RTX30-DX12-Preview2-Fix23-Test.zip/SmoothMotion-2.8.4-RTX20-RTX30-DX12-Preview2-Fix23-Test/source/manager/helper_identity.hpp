#pragma once
namespace helper_identity {
inline constexpr char installer[]="c8bc4325e52bf67c5d995fd8e264706828fa99e01595f5fc548f977615156b2c";
inline constexpr char collector[]="634a253af777184323133f7b6e9fb514fbd777bfbf9796f5f030cd4d22bca004";
}
