// Included inside the installer's namespace after the transaction primitives.
int install(const std::wstring& self,const std::wstring& package,const std::wstring& selectedExe=L"",bool automatic=false,bool reviewedAPI=false) {
    (void)automatic;(void)reviewedAPI;
    if(!install_modes::valid(utf8(requestedMode)))fail(L"Choose version.dll or new.asi.");
    const bool asi=requestedMode==L"asi";
    if(!normal_motion::choice(requestedFG))fail(L"Only normal RTX20 Optical Flow is available.");
    constexpr unsigned multiplier=2;
    const auto loader=package+L"payload\\loader\\version.dll";
    const auto ini=package+L"payload\\loader\\loader-template.ini";
    const auto custom=package+L"payload\\native\\normal.asi";
    const auto nativeProxy=package+L"payload\\native\\version.dll";
    for(const auto& p:std::vector<std::pair<std::wstring,std::string>>{{loader,payload_hashes::loader},{ini,payload_hashes::ini},{custom,payload_hashes::motion},{nativeProxy,payload_hashes::native_proxy}}){
        if(fileHash(p.first)!=p.second)fail(L"A package file is missing or changed. Extract the complete ZIP again:\n"+p.first);
    }
    for(const auto& p:{loader,custom,nativeProxy}){auto info=preflight::inspectFile(p);if(info.machine!=0x8664||!info.plus||!info.dll)fail(L"The package contains an invalid x64 DLL:\n"+p);}
    const auto chosen=selectedExe.empty()?file_picker::choose(nullptr,tr(L"Choose the actual 64-bit game executable")):selectedExe;
    if(chosen.empty())return ERROR_CANCELLED;
    const auto exe=absolute(chosen),root=parent(exe);
    auto target=preflight::inspectExecutable(exe);auto imports=target.imports;
    if(imports.machine!=0x8664||!imports.plus)fail(L"Both supplied builds require a Windows x64 game. Select its 64-bit executable.");
    requireClosed(root,exe);
    const auto dependencies=preflight::dependencies(imports,[&](const std::string& name){checkParents(root,wide(name));return preflight::inspectFile(root+wide(name));});
    const bool rendering=((preflight::renderingAPIs(imports)|dependencies.apis)&3)!=0;
    const auto apis=preflight::renderingAPIs(imports)|dependencies.apis;
    if(apis&&!normal_motion::supportedAPIs(apis))fail(L"This RTX20 preview requires DirectX 11 or DirectX 12. Select a DX11/DX12 executable or launch mode. Vulkan and OpenGL are unsupported.");
    if(exists(root+L"doorstop_config.ini")||exists(root+L"BepInEx"))fail(L"BepInEx / Doorstop already controls DLL loading here. Its files were preserved. Restore that installation before testing these builds separately.");
    if(asi)for(const auto* rel:{L"global.ini",L"scripts\\global.ini",L"plugins\\global.ini",L"update\\global.ini"})if(exists(root+rel))fail(L"This ASI configuration can override deferred startup:\n"+root+rel+L"\nReview or move it aside before installing new.asi. Nothing was changed.");
    auto found=scan(root);
    file_plan::Inventory inventory;inventory.direct=imports.direct;inventory.delay=imports.delay;inventory.dependencyDirect=dependencies.direct;inventory.dependencyDelay=dependencies.delay;
    for(const auto& f:found){inventory.scanned.push_back({utf8(f.relative),f.digest,f.asi,f.loader});inventory.files[file_plan::lower(utf8(f.relative))]=f.digest;if(known(f.digest))inventory.legacyModHashes.push_back(f.digest);}
    // The uploaded ASI is an approved build even when it occupies an old path.
    inventory.legacyModHashes.push_back(payload_hashes::asi);
    inventory.legacyModHashes.push_back(payload_hashes::motion);
    inventory.legacyModHashes.push_back(motion::previousRenderer);
    inventory.legacyModHashes.push_back(motion::release18Renderer);
    inventory.legacyModHashes.push_back(motion::release181Renderer);
    for(const auto* name:install_modes::carriers){
        const auto n=wide(name),in=n.substr(0,n.size()-4)+L".ini";checkParents(root,n);checkParents(root,in);
        inventory.files[name]=fileHash(root+n);inventory.files[file_plan::lower(utf8(in))]=fileHash(root+in);
        if(install_modes::needsOriginal(name)){bool ready=false;try{auto original=root+wide(install_modes::original(name));auto info=preflight::inspectFile(original);ready=info.dll&&info.plus&&info.machine==0x8664&&fileHash(original)!=payload_hashes::loader;}catch(...){}inventory.originals[name]=ready;}
    }
    for(const auto* rel:{L"SM86\\SM86_Menu.exe",L"SM86\\SM86_Guard.exe"}){checkParents(root,rel);inventory.files[file_plan::lower(utf8(rel))]=fileHash(root+rel);}
    const auto plan=file_plan::make(inventory,utf8(requestedMode),utf8(lower(requestedProxy)),multiplier);
    const auto proxy=wide(plan.proxy);std::vector<Change> changes;
    for(const auto& c:plan.changes){
        const auto source=c.source=="loader"?loader:c.source=="ini"?ini:c.source=="motion"?custom:c.source=="native_proxy"?nativeProxy:L"";
        appendChange(changes,root,wide(c.path),source,c.before,c.after);
    }
    std::string configDigest="-";
    checkParents(root,normal_motion::oldConfigPath);
    if(exists(root+normal_motion::oldConfigPath)){
        auto bytes=read(root+normal_motion::oldConfigPath,16384);std::string old(bytes.begin(),bytes.end());
        configDigest=hash(bytes);
        if(old.rfind("; SM86 Motion ",0)==0)
            appendChange(changes,root,normal_motion::oldConfigPath,L"",configDigest,"-");
    }
    prepareUninstaller(root,exe,proxy,asi,self,changes);
    std::string warning="RTX20/RTX30 preview: Turing/Ampere NVOF with custom synthesis, DirectX 11 or DirectX 12 SDR windowed/borderless. Generated Presents use interval 0 and DO_NOT_WAIT. Game/driver VSync still applies. No runtime FPS cap. Display cadence remains unverified. F11 toggles interpolation. Check nvsmooth30.log for flow and Present counters. API success is not proof of displayed frames. GPU/game testing is outstanding.";
    if(target.metadataOnly)warning+=" Windows denies reading the EXE. Its x64 PC architecture comes from MicrosoftGame.config; graphics API and carrier imports could not be inspected. Launch through the Xbox app after installation.";
    if(!apis)warning+=" The graphics API is loaded dynamically or could not be identified; the runtime will report supported or pass-through status.";
    if(plan.fallback)warning+=" No import evidence confirms the selected carrier. Try an imported alternative such as dinput8.dll or winmm.dll if no runtime log appears.";
    if(dependencies.limited)warning+=" Dependency inspection reached its bounded limit.";
    if(!plan.otherPlugins.empty()){warning+=" Existing scripts/plugins ASIs will also load:";for(const auto& p:plan.otherPlugins)warning+=" "+p;}
    std::wstring fingerprint=L"SM86-PLAN-2.8.2-R3-GP2-NORMAL\n"+requestedMode+L"\n"+exe+L"\n"+proxy+L"\n"+wide(requestedFG)+L"\n"+wide(configDigest)+L"\n";
    if(target.metadataOnly)fingerprint+=L"game-config:"+target.metadataPath+L":"+wide(hash(target.metadata))+L"\n";
    for(const auto& c:changes)fingerprint+=c.relative+L"\t"+wide(c.before)+L"\t"+wide(c.after)+L"\n";
    // Include full inventory, including untouched files, to invalidate stale reviews.
    for(const auto& f:found)fingerprint+=f.relative+L"\t"+wide(f.digest)+L"\n";
    for(const auto& f:inventory.files)fingerprint+=wide(f.first)+L"\t"+wide(f.second)+L"\n";
    for(const auto& n:imports.direct)fingerprint+=L"direct:"+wide(n)+L"\n";
    for(const auto& n:imports.delay)fingerprint+=L"delay:"+wide(n)+L"\n";
    for(const auto& n:dependencies.direct)fingerprint+=L"engine-direct:"+wide(n)+L"\n";
    for(const auto& n:dependencies.delay)fingerprint+=L"engine-delay:"+wide(n)+L"\n";
    WIN32_FILE_ATTRIBUTE_DATA state{};if(!GetFileAttributesExW(exe.c_str(),GetFileExInfoStandard,&state))fail(L"Cannot recheck executable.",GetLastError());
    fingerprint+=std::to_wstring(state.nFileSizeHigh)+L":"+std::to_wstring(state.nFileSizeLow)+L":"+std::to_wstring(state.ftLastWriteTime.dwHighDateTime)+L":"+std::to_wstring(state.ftLastWriteTime.dwLowDateTime);
    const auto token=hash(utf16(fingerprint));
    if(machineMode&&planOnly){
        std::string out="{\"schema\":1,\"status\":\"ready\",\"mode\":"+setup_protocol::quote(utf8(requestedMode))+",\"frame_generation\":"+setup_protocol::quote(requestedFG)+",\"frame_generation_label\":"+setup_protocol::quote(normal_motion::label(requestedFG))+",\"target\":"+setup_protocol::quote(utf8(exe))+",\"proxy\":"+setup_protocol::quote(utf8(proxy))+",\"token\":"+setup_protocol::quote(token)+",\"fallback\":"+(plan.fallback?"true":"false")+",\"api_confirmed\":"+(rendering?"true":"false")+",\"warning\":"+setup_protocol::quote(warning)+",\"changes\":[";
        bool first=true;for(const auto& c:changes){if(!first)out+=',';first=false;out+="{\"path\":"+setup_protocol::quote(utf8(c.relative))+",\"action\":"+setup_protocol::quote(c.after=="-"?"Remove previous owned build":c.before=="-"?"Add":"Update owned file")+"}";}
        out+="],\"choices\":[";first=true;
        for(const auto& choice:plan.choices){const auto& c=choice.candidate;if(!first)out+=',';first=false;
            const bool available=setup_policy::usable(c)&&choice.original;
            const auto reason=!choice.original?"Requires original "+install_modes::original(c.name):!available?setup_policy::collision(c):c.direct?"Imported by game EXE":c.dependencyDirect?"Imported by local engine DLL":c.delay?"Delay-imported by game EXE":c.dependencyDelay?"Delay-imported by local engine DLL":"Fallback: game loading must be tested";
            out+="{\"name\":"+setup_protocol::quote(c.name)+",\"available\":"+(available?"true":"false")+",\"reason\":"+setup_protocol::quote(reason)+"}";
        }
        out+="]}\n";emit(out);return 0;
    }
    if(machineMode&&(!setup_protocol::validToken(reviewedToken)||reviewedToken!=token))fail(L"Files or installation choices changed after review. Nothing was installed. Refresh the plan first.");
    if(!machineMode){std::wstring review=L"Install "+std::wstring(asi?L"new.asi + selected loader":L"version.dll (standalone)")+L" for:\n"+exe+L"\n\n";for(const auto& c:changes)review+=c.relative+L"\n";review+=L"\n"+wide(warning)+L"\n\nAn uninstall.bat will be created beside the game executable. Continue?";if(!confirm(review))return ERROR_CANCELLED;}
    const auto backup=transaction(root,exe,self,changes,true);finishLocal(backup);
    std::string message=changes.empty()?"This selection is already installed.":"Files installed. Start the game through its normal launcher. Run uninstall.bat beside the game executable to remove Smooth Motion.";
    const std::wstring localized=tr(wide(message))+L"\n"+tr(L"RTX20 preview installed. Use DX11 or DX12 SDR windowed/borderless. F11 toggles interpolation. Check nvsmooth30.log after launch.");
    message+="\nRTX20 preview installed. Use DX11 or DX12 SDR windowed/borderless. F11 toggles interpolation. Check nvsmooth30.log after launch.";
    if(machineMode)emit(setup_protocol::result("installed",message));else show(localized);
    return 0;
}
