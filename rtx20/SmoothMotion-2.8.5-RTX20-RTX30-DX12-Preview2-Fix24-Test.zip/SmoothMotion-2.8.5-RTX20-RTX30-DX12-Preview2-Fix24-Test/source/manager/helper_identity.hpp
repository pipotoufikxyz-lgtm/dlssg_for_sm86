#pragma once
namespace helper_identity {
inline constexpr char installer[]="6dcc164ad62a1677ff09ef21ead53d5bd3bed88efbcde000c7cbb554a7f62597";
inline constexpr char collector[]="d8bf1eb35e88780c9e0eae83aa4af33b66d5402cb95fc731f3608bb624c04bf3";
}
