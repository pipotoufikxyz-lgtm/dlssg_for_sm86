#pragma once
namespace helper_identity {
inline constexpr char installer[]="98a5de517b24f6ac5c5b5d2cde0b1c58f30146e90525a1d13b5d5969596c5c78";
inline constexpr char collector[]="c362f70663b1a395f11c946b9e065453a392ec1c9bcb38deb302b67c82a17fcb";
}
