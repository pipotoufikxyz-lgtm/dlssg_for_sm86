#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>

namespace sm20::performance {
enum class Phase { prepare, capture, optical_flow, synthesis, generated_write, original_write, generated_present, real_present, spacing_wait, count };
struct Sample {std::atomic_ullong calls{},total_us{},max_us{};};
inline std::array<Sample,static_cast<unsigned>(Phase::count)> samples{};
inline constexpr const char* names[]={"prepare","capture","optical_flow","synthesis","generated_write","original_write","generated_present","real_present","spacing_wait"};
struct Scope {
 using Clock=std::chrono::steady_clock;
 Phase phase;Clock::time_point start=Clock::now();
 explicit Scope(Phase p):phase(p){}
 ~Scope(){
  const auto elapsed=std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
  const auto us=static_cast<unsigned long long>(elapsed<0?0:elapsed);
  auto& s=samples[static_cast<unsigned>(phase)];s.total_us.fetch_add(us,std::memory_order_relaxed);s.calls.fetch_add(1,std::memory_order_relaxed);
  auto old=s.max_us.load(std::memory_order_relaxed);
  while(old<us&&!s.max_us.compare_exchange_weak(old,us,std::memory_order_relaxed)){}
 }
};
// GPU durations from D3D11 timestamp queries, read back a few frames later
// without stalling. Stages: capture (+ half-resolution copy), optical flow,
// synthesis (projection, synthesis and resolve). Also counts pairs per flow
// resolution so logs show which mode produced the timings.
enum class GpuPhase { capture, optical_flow, synthesis, count };
inline std::array<Sample,static_cast<unsigned>(GpuPhase::count)> gpu_samples{};
inline constexpr const char* gpu_names[]={"capture","optical_flow","synthesis"};
inline std::atomic_ullong full_flow_pairs{},half_flow_pairs{},quality_flow_pairs{};
inline void add_gpu(GpuPhase phase,unsigned long long us){
 auto& s=gpu_samples[static_cast<unsigned>(phase)];s.total_us.fetch_add(us,std::memory_order_relaxed);s.calls.fetch_add(1,std::memory_order_relaxed);
 auto old=s.max_us.load(std::memory_order_relaxed);
 while(old<us&&!s.max_us.compare_exchange_weak(old,us,std::memory_order_relaxed)){}
}
// Presentation statistics: pairs by presentation (spaced timed, spaced
// pipelined, VSync-paired), frames where generation was paused because the
// real rate already reached the display refresh, the configured pacing, and
// the current state, spacing wait and reference real rate.
inline std::atomic_ullong paced_pairs{},timed_pairs{},pipelined_pairs{},paused_frames{},spacing_wait_us{};
inline std::atomic<const char*> pacing_setting{"auto"},presentation_state{"measuring"};
inline std::atomic_uint spacing_us{},reference_us{};
// GPU budget (Fix15): limit in permille of the real frame interval, flow mode
// in use, and the measured GPU time per pair of each flow mode (0: unknown).
inline std::atomic_uint gpu_budget_permille{},pair_gpu_us_slow{},pair_gpu_us_medium{},pair_gpu_us_half{};
inline std::atomic<const char*> flow_mode{"medium"};
inline void gpu_json(char* buffer,std::size_t size){
 if(!size)return;buffer[0]=0;std::size_t used=0;
 for(unsigned i=0;i<gpu_samples.size();++i){
  const auto& s=gpu_samples[i];const int n=std::snprintf(buffer+used,size-used,
   "\"%s\":{\"calls\":%llu,\"total_us\":%llu,\"max_us\":%llu},",gpu_names[i],
   s.calls.load(std::memory_order_relaxed),s.total_us.load(std::memory_order_relaxed),s.max_us.load(std::memory_order_relaxed));
  if(n<0||static_cast<std::size_t>(n)>=size-used){buffer[0]=0;return;}used+=static_cast<std::size_t>(n);
 }
 const unsigned reference=reference_us.load(std::memory_order_relaxed);
 const int n=std::snprintf(buffer+used,size-used,"\"flow_pairs_full\":%llu,\"flow_pairs_half\":%llu,\"flow_pairs_high_quality\":%llu},\"pacing_setting\":\"%s\",\"presentation\":\"%s\","
  "\"spacing_us\":%u,\"reference_fps\":%.1f,\"timed_pairs\":%llu,\"pipelined_pairs\":%llu,\"paced_pairs\":%llu,\"spacing_wait_us\":%llu,\"generation_paused_frames\":%llu,"
  "\"gpu_budget_percent\":%.1f,\"flow_mode\":\"%s\",\"pair_gpu_us\":{\"slow\":%u,\"medium\":%u,\"half\":%u}",
  full_flow_pairs.load(std::memory_order_relaxed),half_flow_pairs.load(std::memory_order_relaxed),quality_flow_pairs.load(std::memory_order_relaxed),pacing_setting.load(),presentation_state.load(),
  spacing_us.load(std::memory_order_relaxed),reference?1e6/reference:0.0,timed_pairs.load(std::memory_order_relaxed),pipelined_pairs.load(std::memory_order_relaxed),
  paced_pairs.load(std::memory_order_relaxed),spacing_wait_us.load(std::memory_order_relaxed),paused_frames.load(std::memory_order_relaxed),
  gpu_budget_permille.load(std::memory_order_relaxed)/10.0,flow_mode.load(),pair_gpu_us_slow.load(std::memory_order_relaxed),pair_gpu_us_medium.load(std::memory_order_relaxed),pair_gpu_us_half.load(std::memory_order_relaxed));
 if(n<0||static_cast<std::size_t>(n)>=size-used)buffer[0]=0;
}
// Cumulative CPU wall time, including waits. These are not GPU durations or
// displayed FPS. Snapshot deltas can separate processing from Present stalls.
inline void json(char* buffer,std::size_t size){
 if(!size)return;buffer[0]=0;std::size_t used=0;
 for(unsigned i=0;i<samples.size();++i){
  const auto& s=samples[i];const int n=std::snprintf(buffer+used,size-used,
   "%s\"%s\":{\"calls\":%llu,\"total_us\":%llu,\"max_us\":%llu}",i?",":"",names[i],
   s.calls.load(std::memory_order_relaxed),s.total_us.load(std::memory_order_relaxed),s.max_us.load(std::memory_order_relaxed));
  if(n<0||static_cast<std::size_t>(n)>=size-used){buffer[0]=0;return;}used+=static_cast<std::size_t>(n);
 }
}
}
