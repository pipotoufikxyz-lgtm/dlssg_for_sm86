#!/usr/bin/env python3
"""Verify the RTX20 deliverable. Never executes Windows/GPU code."""
import hashlib,json,pathlib,struct,sys,uuid
root=pathlib.Path(__file__).resolve().parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(root/'source/native/tools'))
from inspect_nvp import PE
def pdb_stream(path,index):
 b=path.read_bytes();assert b.startswith(b'Microsoft C/C++ MSF 7.00')
 block,free,count,n,reserved,mapblock=struct.unpack_from('<6I',b,32)
 ids=struct.unpack_from('<'+'I'*((n+block-1)//block),b,mapblock*block)
 d=b''.join(b[i*block:(i+1)*block] for i in ids)[:n]
 count=struct.unpack_from('<I',d)[0];sizes=struct.unpack_from('<'+'I'*count,d,4);offset=4+4*count
 for i,size in enumerate(sizes):
  n=0 if size==0xffffffff else (size+block-1)//block
  ids=struct.unpack_from('<'+'I'*n,d,offset);offset+=4*n
  if i==index:return b''.join(b[j*block:(j+1)*block] for j in ids)[:size]
 raise ValueError(index)
runtime=json.loads((root/'source/rtx20/build-report.json').read_text())
assert runtime['version']=='2.8.4-rtx20-dx12-preview2-fix15-test'
assert runtime['render_api']=='D3D11 + D3D12 SDR'
# New backend, private matched API5 headers and their preserved provenance must
# accompany the binaries. CUDA2 headers remain a distinct initialization fallback.
required_sources=['source/rtx20/nvof_d3d11.cpp','source/rtx20/nvof_d3d11.hpp',
 'source/rtx20/performance.hpp','third_party/nvidia-optical-flow/d3d11-api5/nvOpticalFlowCommon.h',
 'third_party/nvidia-optical-flow/d3d11-api5/nvOpticalFlowD3D11.h']
for name in required_sources:
 assert (root/name).is_file(), 'Missing Fix6 source: '+name
 assert runtime['source_sha256'].get(name)==sha(root/name), 'Unrecorded Fix6 source: '+name
native_provenance=root/'third_party/nvidia-optical-flow/d3d11-api5/provenance.json'
provenance=json.loads(native_provenance.read_text())
assert provenance['api_version']=='5.0'
for name,metadata in provenance['headers'].items():
 header=native_provenance.parent/name
 assert sha(header)==metadata['sha256'] and header.stat().st_size==metadata['bytes'], 'API5 header provenance: '+name
assert (root/'FIX6_NOTES.md').is_file()
assert (root/'FIX7_NOTES.md').is_file()
assert (root/'FIX8_NOTES.md').is_file()
assert (root/'FIX9_NOTES.md').is_file()
assert (root/'FIX10_NOTES.md').is_file()
assert (root/'FIX11_NOTES.md').is_file()
assert (root/'FIX12_NOTES.md').is_file()
assert (root/'FIX13_NOTES.md').is_file()
assert (root/'FIX14_NOTES.md').is_file()
assert (root/'FIX15_NOTES.md').is_file()
shader=json.loads((root/'validation/shader-and-abi.json').read_text())
assert sha(root/'source/rtx20/shaders.hlsl')==shader['shader_sha256']
assert sha(root/'source/rtx20/include/cuda.h')==shader['cuda_header_sha256']
behavior=json.loads((root/'validation/shader-regression.json').read_text())
assert behavior['result']=='PASS' and behavior['shader_sha256']==shader['shader_sha256']
for name,digest in behavior['source_sha256'].items():assert sha(root/name)==digest,'Shader test source changed: '+name
assert len(behavior['results'])==2 and all(x['result']=='PASS' for x in behavior['results'])
assert {x['entry'] for x in shader['results']}=={'Fullscreen','Capture','Project','Synthesize','Resolve','Blit','BlitSrgb'}
assert all(x['result']=='PASS' for x in shader['results'])
expected_shader='#pragma once\ninline constexpr char shader_source[]=R"SM20HLSL(\n'+(root/'source/rtx20/shaders.hlsl').read_text()+')SM20HLSL";\n'
assert (root/'source/rtx20/shader_source.hpp').read_text()==expected_shader
for name,item in runtime['artifacts'].items():assert sha(root/'payload/native'/name)==item['sha256'],name
for name,digest in runtime['source_sha256'].items():assert sha(root/name)==digest,'Stale runtime input: '+name
for folder,binary in [('setup','Install.exe'),('manager','SmoothMotion_Manager.exe'),('diagnostic','Collect_Diagnostics.exe')]:
 report=json.loads((root/'source'/folder/'build-report.json').read_text());assert sha(root/binary)==report['sha256'],binary
 for name,digest in report['source_sha256'].items():assert sha(root/'source'/folder/name)==digest,'Stale helper: '+folder+'/'+name
setup=json.loads((root/'source/setup/build-report.json').read_text());manager=json.loads((root/'source/manager/build-report.json').read_text())
for key,path in [('motion','native/normal.asi'),('native_proxy','native/version.dll'),('loader','loader/version.dll'),('ini','loader/loader-template.ini')]:assert setup['payload_sha256'][key]==sha(root/'payload'/path)
for key,path in [('installer','Install.exe'),('collector','Collect_Diagnostics.exe')]:assert manager['helpers'][key]==sha(root/path)
symbols=[]
for binary,pdb in [('payload/native/normal.asi','normal.pdb'),('payload/native/version.dll','version.pdb'),('Install.exe','Install.pdb'),('SmoothMotion_Manager.exe','SmoothMotion_Manager.pdb'),('Collect_Diagnostics.exe','Collect_Diagnostics.pdb'),('Test/RTX20_SmokeTest.exe','RTX20_SmokeTest.pdb'),('Test/ShaderCheck.exe','ShaderCheck.pdb'),('Test/RTX20_DX12_SmokeTest.exe','RTX20_DX12_SmokeTest.pdb'),('Test/RTX20_TransferTest.exe','RTX20_TransferTest.pdb')]:
 pe=PE(root/binary);assert struct.unpack_from('<H',pe.data,pe.pe+4)[0]==0x8664 if hasattr(pe,'pe') else pe.data[:2]==b'MZ'
 rva,size=struct.unpack_from('<II',pe.data,pe.optional+112+6*8);offset=pe.rva_to_offset(rva);entries=[]
 for i in range(0,size,28):
  chars,stamp,major,minor,kind,n,addr,ptr=struct.unpack_from('<IIHHIIII',pe.data,offset+i)
  if kind==2 and pe.data[ptr:ptr+4]==b'RSDS':entries.append((pe.data[ptr+4:ptr+20],struct.unpack_from('<I',pe.data,ptr+20)[0]))
 assert len(entries)==1,binary
 guid,age=entries[0];stream=pdb_stream(root/'Symbols'/pdb,1)
 assert stream[12:28]==guid and struct.unpack_from('<I',stream,8)[0]==age,'PDB mismatch: '+binary
 symbols.append({'binary':binary,'sha256':sha(root/binary),'pdb':'Symbols/'+pdb,'pdb_sha256':sha(root/'Symbols'/pdb),'guid':str(uuid.UUID(bytes_le=guid)),'age':age})
for name in ['normal.asi','version.dll']:
 pe=PE(root/'payload/native'/name);assert {'InitializeASI','SmoothMotionGetStatus'}<=pe.exports().keys()
 assert b'2.8.4-rtx20-dx12-preview2-fix15-test' in pe.data
 assert b'NvPresent64.dll' not in pe.data and 'NvPresent64.dll'.encode('utf-16-le') not in pe.data
 assert b'cuGraphicsD3D11RegisterResource' in pe.data and b'NvOFAPICreateInstanceCuda' in pe.data
 assert b'NvOFAPICreateInstanceD3D11' in pe.data and b'nvof_api=D3D11 API5 ready' in pe.data
 assert b'performance_cpu_wall_us' in pe.data
 assert b'artifact_guard=occlusion_aware_v6' in pe.data
 assert b'GPU budget:' in pe.data and b'pair_gpu_us' in pe.data and b'ExclusiveFullscreen' in pe.data.replace(b'\x00',b'')
 assert b'Multisampled DX11 backbuffer' in pe.data and b'Sync interval %u' in pe.data
 assert b'performance_gpu_us' in pe.data and b'flow_pairs_half' in pe.data
 assert b'flow_resolution' in pe.data and 'nvsmooth30.ini'.encode('utf-16-le') in pe.data
 assert b'artifact_guard=conservative_v1' not in pe.data
 assert b'MEDIUM preset' in pe.data
 assert (root/'source/rtx20/shaders.hlsl').read_bytes() in pe.data
 assert b'generated_half_interval_spaced_or_paired' in pe.data
 assert b'generated_present_queue_busy' in pe.data
 assert b'generated_vsync_original_game' not in pe.data
 assert b'[rtx20-dx12] Same-adapter D3D11/CUDA transfer ready' in pe.data
 assert b'dx12_captures' in pe.data and b'dx12_writes' in pe.data
 assert b'Present reached an unregistered swapchain' in pe.data and b'registering for presentation only' in pe.data
 assert b'present_skips' in pe.data and b'present_tearing_eligible' in pe.data
 assert b'Tearing Present admitted' in pe.data and b'Present bypass: reason=' in pe.data
 assert b'transition' in pe.data
 assert b'CreateCommittedResource(shared RT+simultaneous)' in pe.data
 assert b'cpu-staging' in pe.data and b'shared-texture' in pe.data
 assert b'[rtx20-dx12] API failed:' in pe.data
 expected=root/'payload/native'/name
 if name=='version.dll':assert sha(root/'Manual/Version/version.dll')==sha(expected)
 else:
  for kit in ['Dinput8','Winmm','ASI_Only']:assert sha(root/'Manual'/kit/'new.asi')==sha(expected)
  assert sha(root/'Test/new.asi')==sha(expected)
smoke=PE(root/'Test/RTX20_DX12_SmokeTest.exe')
assert b'Backend execution: %s' in smoke.data and b'INCONCLUSIVE' in smoke.data
assert b'D3D12 debug errors' in smoke.data
tests=json.loads((root/'validation/host-tests.json').read_text());assert tests['result']=='PASS'
assert tests['suite_count']==21 and tests['test_runs']==42
for name,digest in tests['source_sha256'].items():assert sha(root/name)==digest,'Test input changed: '+name
report={'result':'PASS','version':runtime['version'],'symbol_pairs':symbols,'host_test_runs':tests['test_runs'],'GPU_tested':False,'Windows_executed':False,'notes':['Nine x64 PE/PDB identities','Runtime source and binary hashes','Installer payload hashes and Manager helper hashes','Manual/test carrier identity','Native D3D11 API5 and CUDA2 fallback symbols; private header provenance; no NvPresent DLL dependency','Host test source identity']}
(root/'validation/package.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS: RTX20 package identities, source hashes, 9 PE/PDB pairs, manual kits and host reports')
