// Generated from current payloads and pinned legacy ownership identities.
#pragma once
namespace payload_hashes {
inline constexpr const char native_proxy[] = "2fb29b1d387bf279d198b4b5f2a2719b7426281d14d4e275a5e2f024173d4dbb";
inline constexpr const char motion[] = "0d410ad4ad7353f21c71fc06f62bf0d479e6c2cfd3fdfd4e864ed6dd9cac0a8a";
inline constexpr const char loader[] = "031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
inline constexpr const char ini[] = "7fbe28780c05b182220c61197ba7ea9506816fb3637897c3ae4a0ecd7fd7d650";
inline constexpr const char standalone[] = "feb05f255d09bc207a7eeacd55cb87b0bbfeedc5337b97aaa37245ed36a98bc7";
inline constexpr const char asi[] = "16b7b560d100f9f26d3d0454617a128337374320c468f4a5ec46b99dcc6c594e";
}
