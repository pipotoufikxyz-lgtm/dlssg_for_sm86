#pragma once
namespace helper_identity {
inline constexpr char installer[]="315e0b2f5790e8830f09c64ef7d0961ec7bd29e6173247dcfd37ffe806ccfbf1";
inline constexpr char collector[]="843dbb45aff7394cbdf5b3963dbf4681f1872eb7b449f54e9323b0dcbbace74d";
}
