// Generated from current payloads and pinned legacy ownership identities.
#pragma once
namespace payload_hashes {
inline constexpr const char native_proxy[] = "3823d8dc52d2a04d31b61b0945a450edc19c384a2bf9e56bd6b999e880aca85d";
inline constexpr const char motion[] = "68236391f5d09ad566d941178bee8aa944370ac3685982ffce436cf3dc619583";
inline constexpr const char loader[] = "031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
inline constexpr const char ini[] = "7fbe28780c05b182220c61197ba7ea9506816fb3637897c3ae4a0ecd7fd7d650";
inline constexpr const char standalone[] = "feb05f255d09bc207a7eeacd55cb87b0bbfeedc5337b97aaa37245ed36a98bc7";
inline constexpr const char asi[] = "16b7b560d100f9f26d3d0454617a128337374320c468f4a5ec46b99dcc6c594e";
}
